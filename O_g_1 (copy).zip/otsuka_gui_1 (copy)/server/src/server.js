/*
This script is to start the server for local/production development for Otsuka GUI
Copyright: Next Solution Lab
Author: Shuvo
*/
require("dotenv").config();
const mongoose = require("mongoose");
const app = require("./api/configuration/app");
const worker = require("./api/helpers/worker");
const PORT = process.env.PORT || 3001 ;

const local_DB = process.env.LOCAL_MONGODB_URL; 
const global_db = process.env.GLOBALDB;
const MongoDb = process.env.MONGODB;
let testReplicaMongodb = "mongodb://localhost:27017,localhost:27018,localhost:27019?replicaSet=rs";
// const testDB = "mongodb://nsladmin:nsladmphase1@gui-phase1-dev-local.cluster-ccastthtyfz2.ap-northeast-1.docdb.amazonaws.com:27017/testdb?ssl=true&tlsAllowInvalidHostnames=true&replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false"
//db connection
(async function dbConnection(url){
    mongoose.connect(url, {
      // tlsCAFile: './src/rds-combined-ca-bundle.pem'
      
   });

})(MongoDb).then(()=> console.log("Successfully DB Connected"))
    .catch(err => console.log("DB not connected" , err))

   
app.listen(PORT, ()=>{
   console.log(`Listening on Port ${PORT}`);
})
