const {Schema, model, default: mongoose} = require("mongoose");

const userSchema = Schema({
    userName: String,
    email: {
        type: String,
        unique: true,
    },
    role: {
        type: String,
        enum: ['superadmin', 'admin', 'user'],
        default: 'user'
    },
    employeeCode: String, //10char
    lastLogin: {
        type: Date,
    },
    phoneNumber: {
        type: String
    }


}, { timestamps: true, optimisticConcurrency: true });

userSchema.pre("save",  function(next){
    this.increment();
    next()

    
})


module.exports = model("UserTest", userSchema);