const {Schema, model} = require("mongoose");

const fusenSchema = Schema({
    fileId: {
        type: Schema.Types.ObjectId,
        ref: "File"
    },
    actualWorkingDate: String,
    paymentRequestDate: Date,
    description: String,
    costCenter: String,
    firstApprover: String,
    firstApproverCode: String,
    protocolNo: String,
},{timestamps: true});

module.exports = model("FusenInfo", fusenSchema);