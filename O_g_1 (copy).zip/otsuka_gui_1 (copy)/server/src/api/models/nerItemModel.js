const {Schema, model} = require("mongoose");

const nerInformationTableSchema = Schema({
    fileId: {
        type: Schema.Types.ObjectId,
        ref: "File"
    },
    // accountNo: {type: [[String]]},
    // accountInfo: {type: [[String]]},
    multipleSellerInfo:{type: Object, default: {}},
    currencyCode: {type: [String]},
    invoiceNumber: {type: [String]},
    issueDate: {type: [String]},
    paymentDeadline: {type: [String]},
    sellerName: {type: [String]},
    sellerCode: {type: [[String]]},
    sellerSelectedIndex: {type: [Number]},
    sellerCorrectedValues: {type: [String]},
    hospitalName: {type: [String]},
    hospitalCode: {type: [[String]]},
    hospitalSelectedIndex: {type: [Number]},
    hospitalCorrectedValues: {type : [String]},
    protocolName: {type: [[String]]}, //project code
    protocolNo: {type: [String]},
    protocolSelectedIndex: {type: [Number]},
    protocolCorrectedValues: {type: [String]},
    totalAmount: {type: [Number]},
    purposeOfPayment: {type: [String]},
    
    isSellerUserInput: {type : Boolean, default: false},
    isHospitalUserInput: {type : Boolean, default: false},
    isProtocolUserInput: {type : Boolean, default: false},

    isSellerDropdownchanged: {type: Boolean, default: false},
    isHospitalDropdownchanged: {type: Boolean, default: false},
    isProtocolDropdownchanged: {type: Boolean, default: false},
    
    
},{timestamps: true, minimize:false});

module.exports = model("NerInformation", nerInformationTableSchema);