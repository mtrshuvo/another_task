const {Schema, model} = require("mongoose");

const itemTableSchema = Schema({
    itemId: Number,
    fileId: {
        type: Schema.Types.ObjectId,
        ref: "File"
    },
    pageNumber:{type: Number},
    itemName: {type: [String]}, //[extracted, temporary, corrected]
    itemNameCord: {type: [Number]}, //[x, y, height, width]
    amountWithOutTax: {type: [Number]},
    amountWithOutTaxCord: {type: [Number]}, //[x, y, height, width]
    consumptionTax: {type: [Number]},
    taxRate:{type: [String]},
    amountWithTax: {type: [Number]},
    categoryNumber: {type: [String]},
    categoryName: {type: [String]},
    subCategory: {type: [String]},
    exclude: {type: [Boolean]},

}, {timestamps: true});

module.exports = model("ItemTable", itemTableSchema);