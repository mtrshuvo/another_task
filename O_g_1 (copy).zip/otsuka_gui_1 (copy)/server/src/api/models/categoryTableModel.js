
const {Schema, model} = require("mongoose");

const categoryTableSchema = Schema({
    fileId: {
        type: Schema.Types.ObjectId,
        ref: "File"
    },
    taxRate:{type: [String]},
    text: {type: [String]},
    amount: {type: [Number]},
    categoryNumber: {type: [String]},
    categoryName: {type : [String]},
    subCategory:{type: [String]},
    exclude: {type: [Boolean]}
}, {timestamps: true});

module.exports = model("CategoryTable", categoryTableSchema);