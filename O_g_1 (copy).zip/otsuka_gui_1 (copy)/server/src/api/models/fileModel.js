const {Schema, model} = require("mongoose");

const fileSchema = Schema({
    fileName: String,
    inputFilePath: String,
    fileKey: String,
    outputRootPath: String,
    fileSize: String,
    ocrStatus: {
        type: String,
        enum: ["Not Started", "In Process", "Completed", "OCR Error"],
        default: "Not Started"
    },
    invoiceError: [String],
    resultCheck: {
        type: String,
        enum: ["raw", "checked", "temp" , "done"],
        default: "raw"
    },
    isDeleted: {
        type: Boolean,
        default: false
    },
    uploadedBy: { 
        type: Schema.Types.ObjectId,
        ref: "UserTest",
    },
    uploadSerial: {
        type: String,
        unique: true
    }
}, {timestamps: true});


module.exports = model("File", fileSchema);

