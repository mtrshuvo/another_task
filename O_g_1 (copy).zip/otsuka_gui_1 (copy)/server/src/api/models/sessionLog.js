const {Schema, model} = require("mongoose");

const sessionSchema = new Schema({
    userId: {
        type: Schema.Types.ObjectId,
        ref: "UserTest"
    },
    isActive: {type: String},
    jwt: String,
}, {timestamps: true})

sessionSchema.index({createdAt: 1}, {expireAfterSeconds: parseInt(process.env.SESSION_TTL)});
module.exports = model('SessionLog', sessionSchema)