const v1UserRouter = require("../v1/routers/userRouter");
const v1FileRouter = require("../v1/routers/fileRouter");
const v1DeepicrRouter = require("../v1/routers/deepicrRouter");
const v1Biz = require("../v1/routers/bizApi");



const apiV1 = "/api/v1";

module.exports = (app) => {
    app.use(`${apiV1}/users`, v1UserRouter);
    app.use(`${apiV1}/file`, v1FileRouter);
    app.use(`${apiV1}/deepicr`, v1DeepicrRouter);
    app.use(`${apiV1}/biz-logic`, v1Biz);
}
