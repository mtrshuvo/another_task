require("express-async-errors")
const express = require("express");
const app = express();
const { notFoundUrl } = require("../middleware/notFoundMiddleware");
const errorMiddleware = require("../middleware/errorMiddleware");
const path = require("path")
const worker = require("../helpers/worker")
// console.log(__baseDir);
// index middleware
app.disabled("x-powered-by")
require('./index')(app);


//routes middleware
require("./routes")(app);

// (async()=>{
//     await worker.loop()
// })()
//url not found middleware
app.use(notFoundUrl);

//default error handeling middleware
app.use(errorMiddleware);

module.exports = app;

