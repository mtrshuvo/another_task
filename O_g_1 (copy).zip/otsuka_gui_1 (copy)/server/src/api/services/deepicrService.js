const { writeFile } = require("fs/promises");
const NerModel = require("../models/nerItemModel");
const ItemTable = require("../models/itemTableModel");
const CategoryTable = require("../models/categoryTableModel");
const FusenModel = require("../models/fusenModel")
const FileModel = require("../models/fileModel")
const { getPrevandNextId } = require("./fileService");
const { inputJsonUpload } = require("../controllers/S3Connector");
const fetch = require("node-fetch")
const {regexForText, regexForPop} = require("../helpers/commonHelper");
const axios = require("axios");
const utf8 = require("utf8");
const { logger } = require("../helpers/logger");

module.exports.creteSingleCategoryTableData = async (singleData, id) => {
  const result = await new CategoryTable({ ...singleData, fileId: id }).save();
  return result._id;
};

module.exports.createSingleItemTableData = async (singleData, id) => {
  const result = await new ItemTable({ ...singleData, fileId: id }).save();
  return result._id;
};

module.exports.createSingleNerData = async (singleData, id, session) => {
  const isNerDataAvailable = await NerModel.findOne({fileId: id},null, {session: session}).session(session);
  if(!isNerDataAvailable){
    const result = await new NerModel({ ...singleData, fileId: id }).save({session: session});
    return result._id;
  }else{
    console.log("already avilable ner data");
  }
};

module.exports.creatingJsonInput = async (inputJsonPath, jsonData) => {
 const file = await writeFile(inputJsonPath, JSON.stringify(jsonData), "utf-8");
//  const responseUrl = await inputJsonUpload(jsonData,inputJsonPath);
//  return responseUrl;
};

module.exports.fusenUpdate = async (fusenId, fusenObj, session)=> {
  await FusenModel.findOneAndUpdate({_id: fusenId}, {$set: {
    ...fusenObj
  }}).session(session)
}
const errorList = {
  mandatoryField: "Mandatory field missing",
  totalAmounError: "Total amount missmatch",
  multiple: "Multiple"
}

//converting into category table
//minimize for
// 0-> for extracted value
// 1-> for temp value
// 2-> for corrected value
module.exports.minimizingTable = (
  detailsTableData = [],
  minimizeFor = 2,
  id = ""
) => {
  if (minimizeFor >= 3 || minimizeFor < 0)
    throw "minimize value must be 0 to 2";
  const minimizeTableArry = [];
  const obj = {};
  for (let item of detailsTableData) {
    const name = `${item['categoryName'][minimizeFor]}_${item['taxRate'][minimizeFor]}`;
    // console.log(name);
  if (name in obj) {
    obj[name].amount[minimizeFor] += item["amountWithTax"][minimizeFor];
      obj[name].amount[minimizeFor] +=
      item["amountWithTax"][minimizeFor];
  } else {
    obj[name] = {
      categoryName: [...item["categoryName"]],
      categoryNumber: [...item["categoryNumber"]],
      amount: [...item["amountWithTax"]],
      taxRate: [...item["taxRate"]],
      subCategory: [...item['subCategory']],
      text: ["", "", ""],
      exclude: new Array(3).fill(false)
    };
  }
}

  //converting obj to array
  for (let item in obj) {
    minimizeTableArry.push({ fileId: id, ...obj[item] });
  }
  return minimizeTableArry;
};

module.exports.ExtractedJsonToDB = async (jsonData, fileId, session) => {

  //deleting 
try{
  let invoiceErrors = [];
  const extractedData = jsonData["extracted_output"];

  if (!extractedData) console.log("Extracted data not avialable in json");
  const nerDBData = {};
  const detailTableDBData = [];
  const categoryTableDBData = [];
  const accountno = extractedData?.["account_no"];
  const accountinfo = extractedData?.["account_info"];
  const currencycode = extractedData?.["currency_code"];
  const hospitalname = extractedData?.["hospital_name"];
  const hospitalcode = extractedData?.["hospital_code"];
  const invoicenumber = extractedData?.["invoice_number"];
  const issuedate = extractedData?.["issue_date"];
  const paymentdeadline = extractedData?.["payment_deadline"];
  const protocolname = extractedData?.["project_name"];
  const protocolno = extractedData?.["protocol_no"] ;
  const sellername = extractedData?.["seller_name"];
  const sellercode = extractedData?.["seller_code"];
  const totalamount = extractedData?.["total_amount"] ;
  const pop = extractedData?.["purpose_of_payment"];
    // console.log("account info", accountinfo);
  //if already in fusen data then input in fusen
  const fusen = await FusenModel.findOne({fileId: fileId}).session(session).lean();
  


  // const accountNo = [...accountno?.values];
  const accountInfo = [...accountinfo?.values];
  nerDBData.currencyCode = [currencycode.values[0] || "", "", currencycode.values[0]|| ""];
  nerDBData.invoiceNumber = [invoicenumber.values[0] || "", "", invoicenumber.values[0] || "" ];
  nerDBData.issueDate = [issuedate.values[0] || "", "", issuedate.values[0] || ""];
  nerDBData.sellerName = [...sellername.values];
  nerDBData.sellerCode = sellercode.values?.length ? sellercode?.values : [['']];
  nerDBData.hospitalName = [...hospitalname.values];
  nerDBData.hospitalCode = hospitalcode?.values?.length ? hospitalcode.values : [['']];
  nerDBData.totalAmount = [Math.round(totalamount.values[0]) || 0, "", Math.round(totalamount.values[0]) || 0];
  nerDBData.protocolNo = [...protocolno?.values];
  nerDBData.protocolName = protocolname?.values?.length ? protocolname?.values: [['']] ;
  nerDBData.purposeOfPayment = [pop.values[0] || "", "", pop.values[0] || "" ]
  nerDBData.multipleSellerInfo = this.getMultipleSellerInfo(nerDBData.sellerName, nerDBData.sellerCode, accountInfo);
  nerDBData.sellerSelectedIndex = new Array(2).fill(0);
  nerDBData.hospitalSelectedIndex = new Array(2).fill(0);
  nerDBData.protocolSelectedIndex = new Array(2).fill(0);
  
  if(fusen?.protocolNo){
    // console.log("geeting protocol name");
    const protocolName = await getProtocolName(fusen?.protocolNo);
    // console.log("api protocol", protocolName? protocolName : [['']]);
    nerDBData.protocolNo = [fusen.protocolNo];
    nerDBData.protocolName = protocolName? [protocolName]: [[""]]

    nerDBData.protocolCorrectedValues = [fusen?.protocolNo, protocolName ? protocolName[0]: [""]]
    nerDBData.protocolSelectedIndex = [-1, protocolName ? -1: -1];
  }else{
    // console.log(nerDBData.protocolNo.length? 0 : null, nerDBData.protocolName.length ? 0: null);
    // nerDBData.protocolSelectedIndex = [nerDBData.protocolNo.length? 0 : 0, nerDBData.protocolName.length ? 0: 0];
    
  }



  

  if(fusen?.paymentRequestDate){
    nerDBData.paymentDeadline = [fusen.paymentRequestDate, "", fusen.paymentRequestDate];
  }else{
    nerDBData.paymentDeadline = [paymentdeadline?.values[0] || "", "", paymentdeadline?.values[0] || ""];
  }


  if(accountInfo[0] && nerDBData.currencyCode[0] && getLength([...nerDBData.protocolName])>=1 && nerDBData.sellerName[0] && getLength([...nerDBData.sellerCode])>=1 && nerDBData.totalAmount[0] &&nerDBData.purposeOfPayment[0] && nerDBData.protocolNo[0] && nerDBData.paymentDeadline[0] && (nerDBData.invoiceNumber[0] || nerDBData.issueDate[0])){
    console.log("no err");
  }else{

    invoiceErrors.push(errorList.mandatoryField)
  }



  if (nerDBData.sellerName.length) {nerDBData.sellerSelectedIndex[0] = 0}
  if (nerDBData.sellerCode.length && nerDBData.sellerCode[0][0]){nerDBData.sellerSelectedIndex[1]=0}else{}
  if (nerDBData.hospitalName.length){nerDBData.hospitalSelectedIndex[0]=0}
  if (nerDBData.hospitalCode.length && nerDBData.hospitalCode[0][0]){nerDBData.hospitalSelectedIndex[1]=0}

  if(nerDBData.sellerName?.length > 1 || getLength([...nerDBData?.sellerCode])> 1 || getLength(accountInfo)>1 || nerDBData.hospitalName?.length > 1 || getLength([...nerDBData?.hospitalCode]) > 1 || nerDBData.protocolNo?.length > 1 || getLength([...nerDBData?.protocolName]) > 1){
    invoiceErrors.push(errorList.multiple);
  }



nerDBData.isSellerDropdownchanged = chekingForMultiple(nerDBData?.sellerName, [...nerDBData?.sellerCode])
nerDBData.isHospitalDropdownchanged = chekingForMultiple(nerDBData?.hospitalName, [...nerDBData?.hospitalCode])
nerDBData.isProtocolDropdownchanged = chekingForMultiple(nerDBData?.protocolNo, [...nerDBData?.protocolName])



  let itemId = 1;

  if(extractedData["item_table_extracted_field"].length){
    for await (let item of extractedData["item_table_extracted_field"]) {
      const singleItemData = { fileId: fileId };
      singleItemData.itemId = itemId;
      itemId = itemId +1; //incrementing itemid
      singleItemData.itemName = [item["item_name"]?.text || "", "", item["item_name"]?.text ];
      singleItemData.itemNameCord = [
        item["item_name"].x || "",
        item["item_name"].y || "",
        item["item_name"].height || "",
        item["item_name"].width || "",
      ];
      singleItemData.amountWithOutTax = [
        parseFloat(item["amount_without_tax"].text) || 0,
        "",
        parseFloat(item["amount_without_tax"].text) || 0,
      ];
      singleItemData.amountWithOutTaxCord = [
        item["amount_without_tax"].x,
        item["amount_without_tax"].y,
        item["amount_without_tax"].height,
        item["amount_without_tax"].width,
      ];
      //calculating consumtion tax;
      // parseInt(price.replace(/,/g, ''), 10)
      // console.log(`${parseInt(item?.tax_rate)}` );
      const tempConsumptionTax = parseFloat(
        (parseFloat(taxRateObj[taxRateMap[`${parseInt(item?.tax_rate)}` ] ]) *
          parseFloat(singleItemData.amountWithOutTax[0])) /
          100
      );
      //calculating consumpiton tax + without tax value;
      const tempwithtax = Math.round(parseFloat(
        tempConsumptionTax + parseFloat(singleItemData.amountWithOutTax[0])
      ));
      // console.log(tempConsumptionTax, tempwithtax);
      singleItemData.consumptionTax = [tempConsumptionTax, item[""], tempConsumptionTax];
      singleItemData.taxRate = [
       taxRateMap[`${parseInt(item['tax_rate'])}`] ||"10%",
        "",
        taxRateMap[`${parseInt(item['tax_rate'])}`]||"10%",
      ];
      singleItemData.amountWithTax = [tempwithtax || 0, "", tempwithtax || 0];
      singleItemData.categoryNumber = [item["item_name"].category_number, "", item["item_name"].category_number];
      singleItemData.categoryName = [item["item_name"].category_name, "", item["item_name"].category_name];
      singleItemData.subCategory = [item["item_name"]["sub-category"], "", item["item_name"]["sub-category"]];
      singleItemData.pageNumber = item['page_number'];
      singleItemData.exclude = [false, false, false]
      detailTableDBData.push(singleItemData);
      // await this.createSingleItemTableData(singleItemData, fileId);
    }

  }

  await ItemTable.insertMany(detailTableDBData, {session: session});

  //finding max sub category if actual working date
  if(fusen?.actualWorkingDate && detailTableDBData.length){
    const maxSubCategory =  getMaxSubcategory(detailTableDBData);
    // console.log(maxSubCategory);
    let popResponse = await gettingPop(nerDBData?.purposeOfPayment[0], [...nerDBData.hospitalCode],[...nerDBData.sellerCode], maxSubCategory?.maxVal, fusen.actualWorkingDate)
    // console.log("pop response", popResponse);
    nerDBData.purposeOfPayment = new Array(3).fill(popResponse)
  }

  // console.log("ner data", nerDBData);
  // return;
  await this.createSingleNerData(nerDBData, fileId, session);

  //extracted category table
  const categoryData = extractedData['category_table_extracted_field'];
  if(categoryData){
   let subcategoryNameObj = getMaxSubcategoryName(detailTableDBData);
  //  console.log("sub category list with amount", subcategoryNameObj);
    for await( let item of categoryData){
      const singleCategoryData = { fileId: fileId };
      singleCategoryData.taxRate = new Array(3).fill(taxRateMap[`${parseInt(item['tax_rate'])}`]||"10%");
      singleCategoryData.amount = new Array(3).fill(Math.round(item.amount));
      singleCategoryData.categoryNumber = new Array(3).fill(item.category_number);
      singleCategoryData.categoryName = new Array(3).fill(item.category_name);
      singleCategoryData.subCategory = new Array(3).fill(subcategoryNameObj[singleCategoryData.categoryNumber[0]]);
      singleCategoryData.text = new Array(3).fill(item.text)
      /**************** getting text api calling ******************/


      
      /********************************* text update before loading **************************************************/
     
      if(fusen?.actualWorkingDate || fusen?.protocolNo){
        let tempText = await gettingText(singleCategoryData.text[0], fusen?.protocolNo? fusen.protocolNo:nerDBData.protocolNo[0] || "", nerDBData.sellerCode, nerDBData.hospitalCode, singleCategoryData.categoryNumber, singleCategoryData?.subCategory, fusen?.actualWorkingDate, nerDBData?.issueDate);
        singleCategoryData.text = new Array(3).fill(tempText)
      }
      
      singleCategoryData.exclude = new Array(3).fill(false);
      categoryTableDBData.push(singleCategoryData)
      
    }
  
    // const categoryTableData = this.minimizingTable(detailTableDBData, 0, fileId);
    await CategoryTable.insertMany(categoryTableDBData, {session:session});
    // console.log("category table data", categoryTableDBData);
    // throw new Error("some")
    //mandatory field checking
    let checkingCategoryMAndatoryField = checkingMandoryField(categoryData);
    if(checkingCategoryMAndatoryField && !invoiceErrors.includes(errorList.mandatoryField)){
      invoiceErrors.push(errorList.mandatoryField)
    }
  
    let totalAmountFromMinimizeTable = categoryTableDBData.reduce((total, curr)=> {
      total += curr.amount[0]
      return total;
   }, 0)
  //  console.log("toal amount missmatch", totalAmountFromMinimizeTable, nerDBData.totalAmount[0]);
   if(totalAmountFromMinimizeTable !== nerDBData.totalAmount[0]){
    invoiceErrors.push(errorList.totalAmounError);
   }
  }
  
 let file = await FileModel.findOneAndUpdate(
    { _id: fileId },
    {
      $set: {
        ocrStatus: "Completed",
        invoiceError: [...invoiceErrors],
      },
    }, {session: session}
  );
  return { nerDBData, detailTableDBData, categoryTableDBData , invoiceErrors };
}catch(err){
  console.log(err);
  throw new Error(err)
}
 
};

//getting next prev functionality
module.exports.prevNextIdForOcrComplete = async (role, uploadedBy=[], rpaCheck, fileId ,date={}) => {
  // let nextFileId;
  // let prevFileId;
  let fileInformation;
  // const startDate = new Date(date.startDate).setHours(00, 00, 00, 000);
  // const endDate = new Date(date.endDate).setHours(23, 59, 59, 999);
  
  const args = {
    isDeleted: false,
    resultCheck: rpaCheck === true ? "done": {$in: ["raw", "checked", "temp"] },
    ocrStatus: "Completed",
    uploadedBy: { $in: uploadedBy },
    createdAt: {
      $gte: new Date(date.startDate),
      $lte: new Date(date.endDate),
  },
  }

  const {prevFileId:prevId, nextFileId:nextId, currentIndex, totalIndex}  = await getPrevandNextId(args, fileId);
  
  return {prevId, nextId, currentIndex, totalIndex};


};

module.exports.itemToCategoryWithTax = (items, id) => {
  let  count = 0;
  const minimizeTableArry = [];
  const obj = {};
  for (let item of items){
    count = count+1;
      const name = `${item.categoryName}_${item.taxRate}`;
      if(name in obj){
          obj[name].amount += item?.amountWithTax
      }else{
          obj[name] = {
              _id: count,
              categoryName: item?.categoryName,
              categoryNumber: item?.categoryNumber,
              amount: item?.amountWithTax,
              taxRate: item?.taxRate,
              subCategory: item?.subCategory,
              text: item?.text || "",
              exclude: false
            };
      }
  }

// console.log(obj);
  //converting obj to array
for (let item in obj) {
  minimizeTableArry.push({ fileId: id, ...obj[item] });
}
return minimizeTableArry;
}

module.exports.findItemTableLastId = async(fileId, session)=> {
  const result = await ItemTable.find({
    fileId: fileId,
    itemId: {$lte:  1000}
  }).session(session).sort({itemId: -1}).lean().limit(1);
  return result.length ? result : undefined;
}


/*********************************helper function ********************/
async function getTextFromBizApi({fileId, issueDate, hospitalCode, sellerCode, protocolNo, subCategory, categoryNo}){
  let targetMonth;
  let onlyMonth;
  let sellerCodeEncoded = encodeURI(sellerCode);
  let hospitalCodeEncoded = encodeURI(hospitalCode);
  let protocolNoEncoded = encodeURI(protocolNo);
  let subcategoryEncoded = encodeURI(subCategory);
  let categoryNoEncoded = encodeURI(categoryNo);

  const fusen = await FusenModel.findOne({ fileId: fileId }).lean();
      if (fusen?.actualWorkingDate) {
        targetMonth = encodeURI(getMonthName(fusen.actualWorkingDate).yearAndMonth);
        onlyMonth = encodeURI(getMonthName(fusen.actualWorkingDate).onlyMonth);

      } else {
        targetMonth = encodeURI(getMonthName(issueDate).yearAndMonth);
        onlyMonth = encodeURI(getMonthName(issueDate).onlyMonth);

      }
      const result = await fetch(
        `${process.env.BIZAPIURL}/text-field/get-text-field?hospital_code=${
          utf8.decode(hospitalCodeEncoded)
        }&seller_code=${utf8.decode(sellerCodeEncoded)}&protocol_no=${
          utf8.decode(protocolNoEncoded)
        }&category_no=${utf8.decode(categoryNoEncoded)}&subcategory_name=${utf8.decode(
          subcategoryEncoded
        )}&target_month=${utf8.decode(targetMonth)}`,
        {
          method: "GET",
          headers: {
            "x-api-key": process.env.BIZXAPIKEY,
          },
        }
      );
      if (result.status === 200) {
        const response = await result.json();
        // console.log("getting text", response);
        const textData = response?.text_field;
        return textData;
      } 
      return undefined;
}

function getMonthName(date) {
  if(!date){
    return { yearAndMonth:`月`, onlyMonth: `月`};
  }
  const month = new Date(date).getMonth();
  const year = new Date(date).getFullYear();
  return { yearAndMonth:`${year}.${month+1}月`, onlyMonth: `${month+1}月`};
}

async function getProtocolName(protocolNo){
  // console.log("calling protocol name api");
  let response;
  const encodingProtocolNo = encodeURI(protocolNo)
  const result = await axios.get(`${process.env.BIZAPIURL}/protocol-no/get-project-name?protocol_no=${utf8.decode(encodingProtocolNo)}`, {
    headers: {
        "x-api-key": process.env.BIZXAPIKEY
    }
});
if(result.status === 200){
    // console.log("protocol no", result?.data);
    response = result?.data?.project_name;
}else{
  response = ""
}
return response
}


function checkingMandoryField(datas){
  for (let item of datas){
    let checking = checkingforSingleData(item);
    if (checking === true){
      // console.log("mandotary field missing");
      return true
    }
  }
  return false
}

function checkingforSingleData(data){
  for (let key in data){
    if (data['category_name'] && data['category_number'] && data['amount'] && data['tax_rate'] && data['text']){
      continue;
    }else{
      return true
    }
  }
  return false;
}

function checkingIntegerValue(categoryDatas){
  for (let item of categoryDatas){
    if(item.amount && !Number.isInteger(item.amount)){
      logger.log("info", "not integer value")
    }
    
  }
}

//text protocol no change

 function replaceProtocolNoInText(text, fusenProtocolNo="", sellerCode="", hospitalCode="", category="", subCategory="", targetMonth=""){
  try{

    if(fusenProtocolNo){
      let regex = /^[0-9]{3,50}/;
      let temp = text.match(regex);
      let finalText;
  
      if (temp){
          let replaceText = temp[0]
          let otherText = text.substring(replaceText.length,) 
  
         finalText = `${fusenProtocolNo.substring(3,)}${otherText}`
         return finalText
    }
  }
          return text
  }catch(err){
    return text;
  }

 
  
}

  module.exports.getMultipleSellerInfo = (sellerName, sellerCode, accountInfo, accountNo) => {
    let obj = {};
    for(let sn = 0; sn < sellerName.length; sn++){
       // rplacing . and dollar char
      let alterSellerName = sellerName[sn].replace(/\./g, "ঙ").replace(/\$/g, "ঞ");
      obj[alterSellerName] = {};
      // console.log(sellerCode[sn]?.length);
      for(let sd = 0; sd < sellerCode[sn]?.length; sd++){
        let code = sellerCode[sn][sd]
        let alterSellerCode = code.replace(/\./g, "ঙ").replace(/\$/g, "ঞ")
        obj[alterSellerName][alterSellerCode] = {"formatted_account_info": ""}
      }
      for(let ai = 0; ai < accountInfo[sn]?.length; ai++ ){
        let code = sellerCode[sn][ai]
        let alterSellerCode = code.replace(/\./g, "ঙ").replace(/\$/g, "ঞ")

        obj[alterSellerName][alterSellerCode] = {"formatted_account_info": accountInfo[sn][ai]}
  
      }
    }
    return obj;
  }
  
const taxRateObj = {
  "10%": 10,
  "軽減8%": 8,
  "海外免税": 0,
  "非課税": 0,
  "不課税": 0,
  "8%": 8,
  "5%": 5,
  "輸入10%": 10,
  "輸入8%": 8,
  "売上10%": 10,
  "不課税売上": 0
}

const taxRateMap = {
  "10": "10%",
  "8": "8%",
  "5": "5%",
  "0": "海外免税"
}



function getMaxSubcategoryName(itemTableData){
  let obj = {};
  // console.log(itemTableData);
  for(let item of itemTableData){
      obj[item?.categoryNumber[0]] = item?.subCategory[0]
      // obj[item?.subCategory[0]] = item?.categoryNumber[0]

  }
  // console.log(obj);
  // let maxVal = Object.keys(obj).reduce((a, b) => obj[a] > obj[b] ? a : b);
  return obj;

}

async function gettingText(text, protocolNo,sellerCode, hospitalCode, category, subCategory, targetMonth, issueDate){
   try{

    // console.log("category ", category);
    sellerCode = sellerCode[0].length? sellerCode[0][0]: "";
    hospitalCode = hospitalCode[0].length? hospitalCode[0][0]: "";
    category = category[0]? category[0]: "";
    subCategory = subCategory[0]?.length? subCategory[0]: "";
    issueDate = issueDate[0]? `${new Date(issueDate[0]).getFullYear()}.${new Date(issueDate[0]).getMonth()+1}月`: ""
    // targetMonth
    
    // if(protocolNo){

      console.log( `${process.env.BIZAPIURL}/text-field/get-text-field?hospital_code=${hospitalCode}&seller_code=${sellerCode}&protocol_no=${protocolNo}&category_no=${category}&subcategory_name=${subCategory}&target_month=${targetMonth? targetMonth: issueDate}`);
      const result = await fetch(
        `${process.env.BIZAPIURL}/text-field/get-text-field?hospital_code=${hospitalCode}&seller_code=${sellerCode}&protocol_no=${protocolNo}&category_no=${category}&subcategory_name=${subCategory}&target_month=${targetMonth? targetMonth: issueDate}`,
        {
          method: "GET",
          headers: {
            "x-api-key": process.env.BIZXAPIKEY,
          },
        }
      );
      if (result.status === 200) {
        const response = await result.json();
        // console.log("getting text", response);
        const textData = response?.text_field;
        // console.log("text data", textData);
        return textData
      } 
    
      return text;
    
  }catch(err){

    return text
  }
}

async function gettingPop(pop, hospitalCode, sellerCode, maxSubcategoryName, targetMonth, issueDate){
   try{ sellerCode = sellerCode[0].length? sellerCode[0][0]: "";
    hospitalCode = hospitalCode[0].length? hospitalCode[0][0]: "";
    // subCategory = subCategory[0]?.length? subCategory[0]: "";
    // issueDate = issueDate[0]? `${new Date(issueDate[0]).getFullYear()}.${new Date(issueDate[0]).getMonth()+1}月`: "";

    console.log(`${process.env.BIZAPIURL
    }/purpose-of-payment/get-purpose-of-payment?hospital_code=${hospitalCode}&seller_code=${sellerCode}&subcategory_name=${maxSubcategoryName}&target_month=${targetMonth}`);
    const popReponse = await fetch(
      `${process.env.BIZAPIURL
      }/purpose-of-payment/get-purpose-of-payment?hospital_code=${hospitalCode}&seller_code=${sellerCode}&subcategory_name=${maxSubcategoryName}&target_month=${targetMonth}`,
      {
        method: "GET",
        headers: {
          "x-api-key": process.env.BIZXAPIKEY,
        },
      }
    );
    if (popReponse.status === 200) {
      const popRes = await popReponse.json();
      return popRes?.pop;
      // console.log("pop",pop);
    } else {
      return pop
    }
  
  }catch(err){
    return pop
  }
    
}
/**
 * checking array has multiple value
 * @param {Array} arr - Nested array/ Array
 * @returns {number}
 */
const getLength = (arr) => {
  // let c = [...arr]
  let a = arr.flat(Infinity);
  let b;
  if (arr.length = 0) {
    b = 0;
  } else b = a.length;
  return b;
};

function chekingForMultiple (name, code){
  let isDropDownChnaged = false;
  if(name.length < 2){
    if(getLength([...code]) < 2){
      isDropDownChnaged = true;
    }
  }
  return isDropDownChnaged;
}




function getMaxSubcategory(itemTableData){
  let obj = {};
  // console.log(itemTableData);
  for(let item of itemTableData){
    if(obj[item?.subCategory[0]]){
      obj[item?.subCategory[0]] += item?.amountWithTax[0];
    }else{
      obj[item?.subCategory[0]] = item?.amountWithTax[0]
    }
      

  }
  console.log("sub",obj);
  let maxVal = Object.keys(obj).reduce((a, b) => obj[a] > obj[b] ? a : b);
  console.log("max sub",maxVal);
  return {obj, maxVal};
}