const User = require("../models/userModel");
const SessionLog = require("../models/sessionLog");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

module.exports.isUserAvialable = async(userId)=> {
        const user = await User.findOne({_id: userId}).lean();
        return user? user._id : undefined;
}
// module.exports.modifyUser = async(userInfo)=> {
//         const user = await User.findOneAndUpdate({_id: userInfo.userId}, {$set: {
//                 role: userInfo.role,
//                 userName: userInfo.userName,
//                 employeeCode: userInfo.employeeCode,

//         }, $inc: {__v: 1}} )
//         return user? user : undefined;
// }

module.exports.modifyUser = async(userInfo)=> {

        const user = await User.findById({_id: userInfo.userId});
        user.role = userInfo.role;
        const result = await user.save();
        return result? result : undefined;
}
module.exports.checkUser = async(userinfo)=> {
        const email = userinfo.email;
        const password = userinfo.password;
        let user = await User.findOne({email}).lean();
        if(user) {
                let isValid = await bcrypt.compare(password, user.password);
                let {password: userPass, ...rest} = user;
                return isValid? rest : undefined
        }
        return undefined;
}

module.exports.getAllUsers = async()=> {
        const users = await User.find().select({createdAt: 0, updatedAt: 0, __v: 0, password: 0, phoneNumber: 0}).sort({lastLogin:-1}).lean();
        return users.length? users: undefined;
         
}

module.exports.tokenCreation = async(data)=> {
        const token = await jwt.sign(data, process.env.JWT_SECRET_KEY, {expiresIn: 90 * 60});
        return token;
}

module.exports.checkUserSession = async(sid)=> {
        const check = await SessionLog.findOne({_id:sid}).lean();
        return check? check : undefined
 
}

module.exports.deleteUserSession = async(userId)=> {
        // let isAvail = await this.checkUserSession(userId);
        await SessionLog.findOneAndDelete({userId})
        // const check = await SessionLog.findOne({userId}).lean();
        // return check? check: undefined;
}

module.exports.createSession = async(userId, tokenData)=> {
        const result = await new SessionLog({userId}).save();
        const token = await this.tokenCreation({...tokenData, sessionId: result._id})
        await SessionLog.findOneAndUpdate({userId}, {$set: {jwt: token}})
        const data = {
                token,
                sessionId: result._id
        }
        return token? data : undefined;
}

module.exports.destroySession = async(id)=> {
        const result = await SessionLog.findOneAndDelete({_id: id});
        return result._id;
}

