const { readFile, stat } = require("node:fs/promises");
const fs = require("node:fs");
const path = require("path");
const FileModel = require("../models/fileModel");
const FusenModel = require("../models/fusenModel");
const { fileReadFromS3 } = require("../controllers/S3Connector");

module.exports.totalFileDoc = async (uploadBy, isSuperAdmin, rpaCheck) => {
    // console.log(uploadBy, isSuperAdmin, rpaCheck);
    if (isSuperAdmin) {
        return await FileModel.find({
            isDeleted: false,
            uploadedBy: uploadBy,
            resultCheck: rpaCheck === true ? "done" : "raw" || "checked",
        }).count();
    } else {
        return await FileModel.find({
            isDeleted: false,
            uploadedBy: uploadBy,
            resultCheck: rpaCheck === true ? "done" : "raw" || "checked",
        }).count();
    }
};

module.exports.fileExistInDb = async(fileId)=>  {
   const file = await FileModel.findOne({_id: fileId, isDeleted: false}).lean();
    return file? file : undefined;
} 

module.exports.getFileandNextPrevFileId = async (
    fileId,
    userRole,
    userId,
    uploadedBy = [],
    rpaCheck = false,
    date = {}
) => {
    let nextFileId;
    let prevFileId;
    let fileInformation;
    let totalFiles;
    let currentIn;
    const startDate = new Date(date.startDate).setHours(0,0,0,0);
    const endDate = new Date(date.endDate).setHours(23, 59, 59, 999);
    const args = {
        resultCheck: rpaCheck === true ? "done" : { $in: ["raw"] },
        isDeleted: false,
        ocrStatus: {
            $in: ["Not Started", "OCR Error"],
        },
        createdAt: {
            $gte: new Date(startDate),
            $lte: new Date(endDate),
        },
    };
    if (uploadedBy && uploadedBy.length > 0) {
        args["uploadedBy"] = { $in: uploadedBy };
    }

    if (userRole === "user" && fileId !== "nofileId") {
        // console.log("i am user", args);
        fileInformation = await this.getSingleFile(fileId, args);
        const { nextFileId: nextId, prevFileId: prevId, currentIndex, totalIndex } =
            await this.getPrevandNextId(args, fileInformation.fileInfo._id, userId);
        nextFileId = nextId;
        prevFileId = prevId;
        currentIn = currentIndex;
        totalFiles = totalIndex;
    } else if (userRole === "superadmin" && fileId !== "nofileId") {
        fileInformation = await this.getSingleFile(fileId, args);
        const { nextFileId: nextId, prevFileId: prevId, currentIndex, totalIndex } =
            await this.getPrevandNextId(args, fileInformation.fileInfo._id);
        nextFileId = nextId;
        prevFileId = prevId;
        currentIn = currentIndex;
        totalFiles = totalIndex;
        // console.log("current index", currentIndex, "total index", totalIndex);
    } else {
        let fileBase64;
        let filesize;
        let fileInformation = await FileModel.find({
            isDeleted: false,
            resultCheck: "raw",
            ocrStatus: {
                $in: ["Not Started", "OCR Error"],
            },
            uploadedBy: { $in: uploadedBy },
            createdAt: {

                $gte: new Date(startDate),
                $lte: new Date(endDate),
            },
        })
            .sort({ createdAt: -1, fileName: -1 })
            .limit(1)
            .lean().select({fileLink: 0});
        fileInformation = fileInformation[0];
        if(!fileInformation) throw new Error("No data found")
        const { nextFileId: nextId, prevFileId: prevId, currentIndex, totalIndex } =
            await this.getPrevandNextId(args, fileInformation?._id);
            nextFileId = nextId;
            prevFileId = prevId;
            let prevCount = currentIndex;
            let totalNotstartedFile = totalIndex;

        const response = await fileReadFromS3(fileInformation);
        fileBase64 =  Buffer.from(response?.Body).toString("base64")
        return {
            fileInformation,
            nextFileId,
            prevFileId,
            fileSize: filesize?.size,
            fileBase64,
            totalNotstartedFile,
            prevCount,
        };
    }

    return { fileInformation, nextFileId, prevFileId, currentIn, totalFiles };
};

module.exports.getSingleFile = async (fileId, args) => {
    let fileBase64;
    let filesize;
    let newargs = { _id: fileId, ...args };
    let fileInfo = await FileModel.findOne({
        _id: fileId,
        ...args,
    }).lean().select({fileLink: 0});

    if (!fileInfo) throw { statusCode: 400, message: "file not found" };
    if(process.env.NODE_ENV !== "development"){
        //aws s3 connection
        const f = await fileReadFromS3(fileInfo);
        const buff =  Buffer.from(f?.Body);
        fileBase64 = buff.toString("base64")
        
     }
     else{

         let isFileExist = fs.existsSync(
             path.join(fileInfo.inputFilePath, fileInfo.fileName)
         );
         filesize = await stat(path.join(fileInfo.inputFilePath, fileInfo.fileName));
        //  console.log("file exist in my dir?", isFileExist);
         if (!isFileExist) fileBase64 = "nothing";
         if (isFileExist) {
             fileBase64 = await readFile(
                 path.join(fileInfo.inputFilePath, fileInfo.fileName),
                 "base64"
             );
         }
     }

    return {
        fileInfo,
        fileBase64,
        size: filesize?.size,
    };
};

module.exports.getFusenInfo = async (fileId) => {
    const fusenInfo = await FusenModel.findOne({ fileId: fileInfo._id }).lean();
    return fusenInfo._id ? fusenInfo : "Fusen not create";
};

module.exports.pervnextcount = async (fileId, args) => {
    console.log("pervnextcount", args);
    let prevCount;
    if (fileId === "nofileId") return { prevCount: (prevCount = 1) };
    prevCount = await FileModel.find({ ...args, _id: { $gt: fileId } }).count();
    console.log("count ", prevCount);
    return { prevCount: prevCount + 1 };
};

module.exports.getPrevandNextId = async (args, currentFileId, userId = "", createdAt) => {
    if (userId.length > 0) {
        args["uploadedBy"] = userId;
    }
    
// console.log("args", args);

/* for testing purpose */
const nextFileIds = await FileModel.find({
    ...args,
})
    .sort({ createdAt: -1, fileName: -1})
    .select({ _id: 1, fileName: 1, createdAt:1 });

let nextFileId;
let prevFileId;
let currentIndex=0;
let totalIndex = nextFileIds.length;
nextFileIds.forEach((item, ind)=> {
    if(item._id.toString() === currentFileId.toString()){
        currentIndex =  ind + 1;
        let prevIndex = ind - 1;
        let nextIndex = ind + 1;
        
        prevFileId = prevIndex < 0 ? []: [nextFileIds[prevIndex]]
        nextFileId = nextIndex >= nextFileIds.length ? []: [nextFileIds[nextIndex]]
        
    }
})



    return { nextFileId, prevFileId, currentIndex, totalIndex};
};

