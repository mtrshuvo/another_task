const router = require("express").Router();
const {
    loginValidation,
    userModifyValidation,
    ssoLoginValidation
} = require("../../middleware/validation/commonValidator")
const { 
    signIn,signOut, modifyUser, getAll
    } = require("../../controllers/userController");

const { Authorize, isSuperAdmin } = require("../../middleware/commonMiddlewares");

//@router 
//user modify router
router.route("/")
    .put( Authorize, isSuperAdmin, userModifyValidation, modifyUser);
//@router 
//user get all user router
router.route("/getall")
    .get(Authorize, isSuperAdmin, getAll);
//@router 
//user sign in router
router.route("/signin")
    .post(signIn);
//@router 
//user sign out router
router.route("/signout")
    .post(Authorize, signOut);




module.exports = router;