const { getCategoryNames, getProtocolNumbers, getSellerNames, getHospitalNames, getNerInfoFromBizAPi, getCostCenters, getFirstApprover, getCostCentersLocal, getSellerInfo, getHospitalInfo } = require("../../controllers/bizApiControllers");
const { Authorize } = require("../../middleware/commonMiddlewares");

const router = require("express").Router();

router.route("/get-category-names").get(Authorize,getCategoryNames);
router.route("/get-protocol-numbers").get(Authorize, getProtocolNumbers);
router.route("/get-seller-names").post(Authorize, getSellerNames);
router.route("/get-hospital-names").post(Authorize,getHospitalNames);
router.route("/get-cost-center").get(Authorize, getCostCenters);
router.route("/get-first-approver").get(Authorize,getFirstApprover);
router.route("/bizinfoupdate").post(Authorize, getNerInfoFromBizAPi);
// router.route("/get-seller-info").get(getSellerInfo);
// router.route("/get-hospital-info").get(getHospitalInfo);




module.exports = router;