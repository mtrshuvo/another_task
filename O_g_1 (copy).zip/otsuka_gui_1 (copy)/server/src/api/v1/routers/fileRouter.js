const multer = require("multer");
const path = require("node:path");
const router = require("express").Router();
const { fileUpload, getSingleFile, fileuploadwithmulter, fileFilter, deleteFile, getSingleImage } = require("../../controllers/fileController");
const { Authorize } = require("../../middleware/commonMiddlewares");
const { fileuploadingValidation, getSingleImgValidation, deleteFilesValidation, filFiltermiddleware, getSingleFileMiddleware, presignedURLvalidation } = require("../../middleware/validation/commonValidator");
const fs = require("fs");
const FileModel = require("../../models/fileModel");
const { createHashUserName } = require("../../helpers/commonHelper");
var utf8 = require('utf8');
const { getPresignedUrl } = require("../../controllers/S3Connector");



//stroge location selection
const storage = multer.diskStorage({
   
    destination: (req, file, cb)=>{

        const random = `${new Date().getTime().toString()}${createHashUserName(req.user.userName)}${req.files.length}`;
        const baseDir = process.env.FILEPATH;
        const uniqueFolder = `${baseDir}/filedir/${random}`;
        // console.log("Uploaded Files",utf8.decode(file.originalname));
        // setTimeout(() => {
            
            fs.mkdir(uniqueFolder, async(err)=> {
                if(!err){
                    cb(null, uniqueFolder);
                    const singleFileInfo = {
                        fileName: utf8.decode(file.originalname),
                        inputFilePath: uniqueFolder,
                        uploadedBy: req.user._id,
                        uploadSerial: random,
                    }
    setTimeout(()=> {
         new FileModel(singleFileInfo).save()
    },1000)
                      
                   
                }
            })
        // }, 5000);
    },
    filename: (req, file, cb)=> {
        cb(null, utf8.decode(file.originalname))
    }
    
})

//upload funtionality
const upload = multer({
    storage: storage,
    fileFilter: (req, files, callback)=>{
        const ext = path.extname(files.originalname.trim());
        const allowed = ['.png', '.jpg', '.jpeg', '.pdf'];
        if (allowed.includes(ext)) {
          callback(null, true);
        } else {
          callback(null, false); // handle error in middleware, not here
        }
      },
      
}).array("file")

//get single file route
router.route("/").post(Authorize, getSingleFileMiddleware, getSingleFile)

//@router
// file filter router
router.route("/filter")
.post(Authorize, filFiltermiddleware,fileFilter)
//@router
//file upload router
router.route("/fileupload")
    .post(Authorize, process.env.NODE_ENV !== "development" ? aws : upload, fileuploadwithmulter);

function aws (req, res, next){
        next()
}
//@router
//file delete router
router.route("/delete").put(Authorize, deleteFilesValidation, deleteFile);

//@router
//file delete router
router.route("/getimg").get(Authorize, getSingleImgValidation ,getSingleImage);

//@router
//presigned url for file upload post method
router.route("/getpresignedurl").post(Authorize, presignedURLvalidation, getPresignedUrl);

//@router
//presigned url for file upload put method

module.exports = router;