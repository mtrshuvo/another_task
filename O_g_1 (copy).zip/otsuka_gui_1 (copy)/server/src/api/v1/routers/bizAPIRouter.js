const router = require("express").Router();

const { getNerInfoFromBizAPi } = require("../../controllers/bizApiControllers");
const { Authorize } = require("../../middleware/commonMiddlewares");


//@router
//ocr start router
router.route("/bizinfoupdate").post(getNerInfoFromBizAPi)



module.exports = router;