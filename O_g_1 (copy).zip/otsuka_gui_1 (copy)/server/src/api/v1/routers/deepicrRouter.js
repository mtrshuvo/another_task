const router = require("express").Router();

const { 
        startOcr, 
        extractedJsonSaveInDB, 
        getSingleFileResultPageData, 
        RPACreation, 
        updateTable, 
        modifyResultPage, 
        redoOCR
    } = require("../../controllers/deepicrController");
const { Authorize } = require("../../middleware/commonMiddlewares");
const {ocrInfoValidation, fidValidation, firstApp, jsonFileValidation, mongodIdValidation, nerDataValidation, itemTableDataValidation, rpaCreationValidation, getSingleFileMiddleware, categoryTableDataValidation } = require("../../middleware/validation/commonValidator");


//@router
//ocr start router
router.route("/startocr").post(Authorize,[...ocrInfoValidation, ...jsonFileValidation, fidValidation],startOcr)
// router.route("/test").post(dummypost).get(dummyget)
//@router
//find output json and saving it to db
router.route("/findjson").post(Authorize, extractedJsonSaveInDB);
//@router
//extracted data for result page
//@router
//modify result api
router.route("/extracted")
    .post( Authorize, getSingleFileMiddleware,  getSingleFileResultPageData)
    .put(Authorize, fidValidation, nerDataValidation, itemTableDataValidation, categoryTableDataValidation, modifyResultPage);
//@router
//rpa creation
router.route("/rpa").post(Authorize, rpaCreationValidation, RPACreation);

//@router
//update table api
router.route("/tableupdate").post(Authorize, mongodIdValidation, nerDataValidation, itemTableDataValidation ,updateTable);
// router.route("/tableupdate").post( updateTable);

//@router
//redo ocr router -> get fusen details
router.route("/redoOCR").get(Authorize,redoOCR);



module.exports = router;