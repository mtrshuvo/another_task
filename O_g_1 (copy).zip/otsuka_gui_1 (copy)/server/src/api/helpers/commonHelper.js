const crypto = require("crypto");
const bcrypt = require("bcrypt");
const mongoose = require("mongoose");


module.exports.passwordHashing = async(password) =>{
    return await bcrypt.hash(password, parseInt(process.env.SALT_ROUNDS))
}

module.exports.capitalizeFirstLetter = (string)=>{
    return string.charAt(0).toUpperCase() + (string.slice(1)).toLowerCase();
}

module.exports.getTimeUniqueHash = (datetime = new Date().getTime().toString())=> {
    return datetime.length ? crypto.createHash('sha256').update(datetime).digest('hex') : undefined;
}

module.exports.createHashUserName = (value)=> {
    const hashvalue = crypto.createHash("sha256").update(`${value}`).digest("hex");
    const middle = parseInt(hashvalue.length/2);
    const randomHash = `${hashvalue.substring(0, 2)}${hashvalue.substring(middle, middle+2)}${hashvalue.substring(hashvalue.length-2, hashvalue.length)}`;
    return randomHash && randomHash;
}



  module.exports.parsingNerData = (obj, temp=false) => {
    //not checking temp extracted or corrected
    const checkList = ["sellerName", "sellerCode", "hospitalName", "hospitalCode", "protocolNo", "protocolName", "multipleSellerInfo","sellerSelectedIndex", "hospitalSelectedIndex", "protocolSelectedIndex", "sellerCorrectedValues", "hospitalCorrectedValues", "protocolCorrectedValues", "isSellerUserInput", "isHospitalUserInput", "isProtocolUserInput", "isSellerDropdownchanged", "isHospitalDropdownchanged", "isProtocolDropdownchanged"];
    // const notCheckingList = ["sellerSelectedIndex", "hospitalSelectedIndex", "protocolSelectedIndex", "sellerCorrectedValues", "hospitalCorrectedValues", "protocolCorrectedValues", "isSellerUserInput", "isHospitalUserInput", "isProtocolUserInput"]
      let newObj={}
      for (let key in obj){
          let updatedValue;
          if(obj[key]?.length === 3 && Array.isArray(obj[key]) && !checkList.includes(key)){
              updatedValue = temp===true? tempDataShow(obj[key]) : mostUpdatedValue(obj[key]);
              newObj[key] = updatedValue

          }else{
              newObj[key] = obj[key];
          }
      }
      return newObj;
  }
  function mostUpdatedValue(array){
      return array[2];
  }
  function tempDataShow(array){
    return array[1]
  }


  function getMonthName (date){
    const month = new Date(date).toLocaleString('default', {month: 'long'});
    return month;
  }

  module.exports.totalAmountMissMatch = (catagoryData)=> {

    let totalAmountFromMinimizeTable = catagoryData.reduce((total, curr)=> {
      total += curr.amount
      return total;
   }, 0)
   return totalAmountFromMinimizeTable && totalAmountFromMinimizeTable;
  }

  module.exports.formatDateInNer = date => {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    return [year, month, day].join('-');
  }


module.exports.regexForText = (stringValue="", actualWorkingDate) => {
  try{
    let finalText;
    const regexcheck = stringValue;
    let output = regexcheck.match(/[0-9]{4}\.[0-9]{1,2}/);
    // console.log("output", output);
    if(actualWorkingDate){
        // const month = new Date(actualWorkingDate).getMonth();
        // const year = new Date(actualWorkingDate).getFullYear();
        finalText = `${stringValue.slice(0, output.index)}${actualWorkingDate}`
        // console.log("actual data ache", finalText);
        return finalText;
    }else{
        let tirmingYearAndMonth = output[0]?.split(".")[1]
        let trimMonth = (tirmingYearAndMonth?.length === 2 && tirmingYearAndMonth[0] === "0")? tirmingYearAndMonth.slice(1): tirmingYearAndMonth;
        finalText = `${stringValue.slice(0, output.index)}${output[0].split(".")[0]}.${trimMonth}月`
        return finalText;
    }
}catch(err){
    // console.log(err );
    return stringValue

}
}



module.exports.regexForPop = (stringValue, actualWorkingDate) => {
  try{
    let finalText;
    console.log("stringValue", stringValue);
  // stringValue = utf8.decode(stringValue)
  let output = stringValue.match(/[0-9]{1,2}月/)
  // console.log("output",stringValue.replace(output[0]));
  if(actualWorkingDate){
    finalText = stringValue.replace(output[0], actualWorkingDate)
      // const month = new Date(actualWorkingDate).getMonth();
  //     finalText = `${stringValue.substring(0, output.index)}${actualWorkingDate}`
  //     return finalText
  // }
  //   if(output[0][0] === "0"){
  //     finalText = `${stringValue.substring(0, output.index)}${output[0].substring(1,)}`
      return finalText

    }
    return stringValue;
  }catch(err){
      // console.log(err);
    return stringValue
  }
}

