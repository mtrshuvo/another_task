
const worker = {};

worker.pingMredulVaiLambdaFunction = () => {
    console.log("calling mredul vai");
}

worker.loop = async()=> {
    try{
        setInterval(()=> {
            worker.pingMredulVaiLambdaFunction();
            
        },1000)
    }catch(err){
        console.log("err");
    }
}
module.exports = worker;