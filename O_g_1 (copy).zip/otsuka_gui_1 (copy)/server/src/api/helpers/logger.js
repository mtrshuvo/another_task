const { format } = require('winston');
var winston = require('winston');

// require('winston-daily-rotate-file');

// var transport = new winston.transports.DailyRotateFile({
//     filename: 'application-%DATE%.log',
//     datePattern: 'YYYY-MM-DD-HH',
//     zippedArchive: false,
//     maxSize: '20m',
//     maxFiles: '14d'
//   });

//   transport.on('rotate', function(oldFilename, newFilename) {
//     // do something fun
    
//   });

//   var logger = winston.createLogger({
//     transports: [
//       transport
//     ]
//   });


const logger = winston.createLogger({
    level: 'info',
  format: winston.format.json(),
    transports: [
      new winston.transports.Console(),
      new winston.transports.File({ filename: 'combined.log', level: "info", format:format.combine(format.timestamp(), format.json()) })
    ]
  });
module.exports.logger = logger;
