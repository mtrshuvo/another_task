const fs = require("fs/promises");
const { existsSync } = require("node:fs");
const path = require("path");
const utf8 = require("utf8");
const fetch = require("node-fetch");
const mongoose = require("mongoose");

const { validationResult } = require("express-validator");
//db model
const NerModel = require("../models/nerItemModel");
const ItemTableModel = require("../models/itemTableModel");
const CategoryTableModel = require("../models/categoryTableModel");
const FileModel = require("../models/fileModel");
const FusenModel = require("../models/fusenModel");

// helper function
const {
  isErrorFounds,
  validationMessages,
} = require("../helpers/errorMsgHelper");
const {
  parsingNerData,
  totalAmountMissMatch,
  formatDateInNer,
} = require("../helpers/commonHelper");

// deepicr service function
const {
  createSingleItemTable,
  creteSingleCategoryTable,
  createSingleItemTableData,
  creteSingleCategoryTableData,
  createSingleNerData,
  creatingJsonInput,
  ExtractedJsonToDB,
  prevNextIdForOcrComplete,
  minimizingTable,
  fusenUpdate,
  findItemTableLastId,
  itemToCategoryWithTax,
} = require("../services/deepicrService");
const { pervnextcount, fileExistInDb } = require("../services/fileService");


const {
  extractedJsonRead,
  extractedJsonReadFromS3,
  fileReadFromS3,
  updateJsonInS3,
  inputJsonUpload,
  isOutputJsonExist,
  deleteJson,
  deleteInputJson,
  rpaFilePressignedUrl,
} = require("./S3Connector");
const { logger } = require("../helpers/logger");
const { log } = require("console");



module.exports.inProcessToComplete = async (startDate) => {
  try {
    //extracted dir

    const inProcessFileList = await FileModel.find({
      isDeleted: false,
      ocrStatus: "In Process",
      createdAt: { $gte: new Date(startDate) }
    })
      .lean()
      .select({ uploadSerial: 1, fileName: 1, fileKey: 1 });
    // console.log("in process list", inProcessFileList);
    for await (let f of inProcessFileList) {
      const session = await mongoose.startSession()
      try {

        //reading from aws
        let parseJson;
        const response = await extractedJsonReadFromS3(f);
        //  console.log("response",response);
        if (response !== undefined) {
          // console.log(response);
          session.startTransaction();
          const bufferData = Buffer.from(response?.Body);
          parseJson = JSON.parse(bufferData.toString("utf-8"));
          // console.log(parseJson);
          if (parseJson.statusCode === 200 && parseJson.extracted_output) {

            const {
              nerDBData,
              detailTableDBData,
              categoryTableDBData,
              invoiceErrors,
              
            } = await ExtractedJsonToDB(parseJson, f._id, session);

          } else if (parseJson.statusCode !== 200 || !parseJson.extracted_output) {
            await FileModel.findOneAndUpdate(
              { _id: f._id },
              {
                $set: {
                  ocrStatus: "OCR Error",
                  // invoiceError: [...invoiceErrors],
                },
              }
            ).session(session);
            // console.log("changing ocr status OCR ERROR");
          }
          else {
            await FileModel.findOneAndUpdate(
              { _id: f._id },
              {
                $set: {
                  ocrStatus: "OCR Error",
                },
              }
            ).session(session);;
          }
        } else {

          // console.log("not found in s3");
          continue;
        }
      } catch (err) {
        logger.log("info", `errors in file id: ${f._id}, message: ${err.message} `)
        await session.abortTransaction()
        session.endSession()
        continue;
      }finally{
        if(session.inTransaction()){
          await session.commitTransaction();
      }
      session.endSession()
      }

    }
    // return res.status(200).json({ message: "done" });
  } catch (err) {
    // console.log(err);
    // logger.log("info", err.message)
    throw new Error(err)
    // return res.status(400).json({ message: "Something went wrong" });
  }
};
//@start single file ocr
module.exports.startOcr = async (req, res) => {
  try {

    const errors = validationMessages(validationResult(req).mapped());
    if (isErrorFounds(errors)) return res.status(400).json(errors);
    const fileId = req.query.fid;
    const ocrinfo = req.body.ocrInfo;
    const jsonFile = req.body.jsonFile;
    // console.log("after validation",jsonFile);
    const key = decodeURI(req.body.key);
    jsonFile.img_file_name = decodeURI(jsonFile.img_file_name);
    jsonFile.output_json_name = decodeURI(jsonFile.output_json_name);

    const baseDir = `${process.env.FILEPATH}/jsondir`;

    const argsForNewDoc = {
      isDeleted: false,
    };

    for (let key in ocrinfo) {

      if (key === "protocolNo") {
        argsForNewDoc["protocolNo"] = ocrinfo["protocolNo"];
      }
      if (key === "actualWorkingDate") {
        argsForNewDoc["actualWorkingDate"] = ocrinfo["actualWorkingDate"]
      }
      if (key === "paymentRequestDate") {
        argsForNewDoc["paymentRequestDate"] = new Date(
          ocrinfo["paymentRequestDate"]
        );
      }
      if (key === "description") {
        argsForNewDoc["description"] = ocrinfo["description"];
      }
      if (key === "firstApprover") {
        argsForNewDoc["firstApprover"] = ocrinfo["firstApprover"];
        argsForNewDoc["firstApproverCode"] = ocrinfo["firstApproverCode"];
      }
      if (key === "costCenter") {
        argsForNewDoc["costCenter"] = ocrinfo["costCenter"];
      }
    }


    if (req.user.role === "superadmin") {
      const file = await FileModel.findOne({
        _id: fileId,
        isDeleted: false,
        // ocrStatus: "Not Started",
      }).lean();
      if (!file) return res.status(400).json({ message: "file not found" });

      //deleting fusen data before redoocr
      await FusenModel.findOneAndDelete({ fileId: file._id });
      const fusenDetail = await new FusenModel({
        fileId: fileId,
        ...ocrinfo,
      }).save();
      let updataingStatus = await FileModel.findOneAndUpdate(
        { _id: fileId },
        {
          $set: {
            ocrStatus: "In Process",
            resultCheck: "raw",
          },
        },
        { new: true }
      );

      // console.log("file info", fiahfdiha);
      //creating json file in json dir for single file
      // const baseDir = `${process.env.FILEPATH}/jsondir`;
      // const inputJsonPath = `${file.fileName.match(/(.*)(?:\.([^.]+$))/)[1]}_input.json`

      //  const url = await creatingJsonInput(inputJsonPath, jsonFile);

      if (process.env.NODE_ENV === "development") {
        const inputJsonPath = `${baseDir}/${file.uploadSerial}_${file.fileName.match(/(.*)(?:\.([^.]+$))/)[1] + "_input.json"
          }`;
        await creatingJsonInput(inputJsonPath, jsonFile);
      } else {
        // let isJsonExist = await isOutputJsonExist(key);
        // // console.log("is json exist",isJsonExist);
        // if(isJsonExist){
        //   await deleteJson(key);
        //   await deleteInputJson(key)
        // }
        //for production
        await inputJsonUpload(jsonFile, key);
        //deleting ouptput json if already in s3 bucket
      }
      //  console.log(url);
      await NerModel.findOneAndDelete({ fileId: file._id });
      await ItemTableModel.deleteMany({ fileId: file._id });
      await CategoryTableModel.deleteMany({ fileId: file._id });
      return res.status(200).json({ message: "ocr started" });
      // file.name.match(/(.*)(?:\.([^.]+$))/)[1] + '.json'
    } else {
      const file = await FileModel.findOne({
        _id: fileId,
        uploadedBy: req.user._id,
        // ocrStatus: "Not Started",
      }).lean();
      if (!file) return res.status(400).json({ message: "file not found" });
      // deleting fusen details before reocr
      await FusenModel.findOneAndDelete({ fileId: file._id });
      const fusenDetail = await new FusenModel({
        fileId: fileId,
        ...ocrinfo,
      }).save();
      await FileModel.findOneAndUpdate(
        { _id: fileId },
        {
          $set: {
            ocrStatus: "In Process",
          },
        }
      );
      //creating json
      if (process.env.NODE_ENV === "development") {
        const inputJsonPath = `${baseDir}/${file.uploadSerial}_${file.fileName.match(/(.*)(?:\.([^.]+$))/)[1] + "_input.json"
          }`;
        await creatingJsonInput(inputJsonPath, jsonFile);
      } else {
        //for production
        //deletin out json if available
        // let isJsonExist = await isOutputJsonExist(key);
        // // console.log("is json exist",isJsonExist);
        // if(isJsonExist){
        //   await deleteJson(key);
        //   await deleteInputJson(key);
        // }
        await inputJsonUpload(jsonFile, key);

      }
      await NerModel.findOneAndDelete({ fileId: file._id });
      await ItemTableModel.deleteMany({ fileId: file._id });
      await CategoryTableModel.deleteMany({ fileId: file._id });
      return res.status(200).json({ message: "ocr started" });
    }
  } catch(err) {
    
    return res.status(400).json({ message: "Something went wrong" });
  }
};

//extracted json to db load informaion
module.exports.extractedJsonSaveInDB = async (req, res) => {
  try {
    //extracted dir
    let count = 0;
    let basedDir = process.env.EXTRACTEDPATH;
    let isFolderExist = existsSync(basedDir);
    const readfolderFiles = await fs.readdir(
      path.join(process.env.EXTRACTEDPATH)
    );
    const inProcessFileList = await FileModel.find({
      isDeleted: false,
      ocrStatus: "In Process",
    })
      .lean()
      .select({ uploadSerial: 1, fileName: 1 });

    // console.log("from db",inProcessFileList);
    // console.log("from dir",readfolderFiles);

    for (let f of inProcessFileList) {
      const fpath = path.join(
        basedDir,
        `${f.uploadSerial}`,
        `${f.uploadSerial}_${f.fileName.match(/(.*)(?:\.([^.]+$))/)[1]
        }_output.json`
      );
      let isFileExist = existsSync(fpath);
      // console.log(f._id, ":", isFileExist);

      if (isFileExist) {
        const fileRead = await fs.readFile(fpath, "utf-8");
        const parseJson = JSON.parse(fileRead);

        if (parseJson.statusCode === 200 && parseJson.extracted_output) {
          await FileModel.findOneAndUpdate(
            { _id: f._id },
            {
              $set: {
                ocrStatus: "Completed",
                // ocrStatus: ""
              },
            }
          );
          // console.log("changring ocr status Completed");
          // parsing json
          const {
            nerDBData,
            detailTableDBData,
            categoryTableData,
            invoiceErrors,
          } = await ExtractedJsonToDB(parseJson, f._id);
          // console.log("invoice errors", invoiceErrors);
          await CategoryTableModel.insertMany(categoryTableData);
          // console.log("ner db data",nerDBData );
          // console.log("details table db data", detailTableDBData);
          // console.log("category data", categoryTableData);
        } else if (parseJson.statusCode !== 200 && parseJson.extracted_output) {
          await FileModel.findOneAndUpdate(
            { _id: f._id },
            {
              $set: {
                ocrStatus: "OCR Error",
                invoiceError: [...invoiceErrors],
              },
            }
          );
          // console.log("changing ocr status OCR ERROR");
        }
      } else {
        // console.log("file not exist");
        // continue;
      }
    }
    return res.status(200).json({ message: "done" });
  } catch (err) {
    // console.log(err);
    return res.status(400).json({ message: "Something went wrong" });
  }
};

//getting single fileid extracted data information
module.exports.getSingleFileResultPageData = async (req, res) => {
  try {
    const errors = validationMessages(validationResult(req).mapped());
    if (isErrorFounds(errors)) return res.status(400).json(errors);
    const fid = req.query.fid;
    const uploadedBy = req.body.uploadedBy;
    const rpaCheck = req.body.rpaCheck;
    let startDate = req.body.startDate;
    let endDate = req.body.endDate;

    startDate = new Date(startDate).setHours(0, 0, 0, 0);
    endDate = new Date(endDate).setHours(23, 59, 59, 999);

    if (!req.query.fid || !req.query.fid.length)
      return res.status(400).json({ message: "file id required" });

    if (!uploadedBy.length)
      return res.status(400).json({ message: "uploaded by empty" });
    if (new Date(startDate) > new Date(endDate))
      return res.status(400).json({ message: "Date range not valid" });

    const args = {
      isDeleted: false,
      resultCheck:
        rpaCheck === true ? "done" : { $in: ["raw", "checked", "temp"] },
      ocrStatus: "Completed",
      uploadedBy: { $in: uploadedBy },
      createdAt: {
        $gte: new Date(startDate),
        $lte: new Date(endDate),
      },
    };
    const fileInfo = await FileModel.findOne({
      _id: fid,
      ...args,
    })
      .lean()
      .select({ __v: 0 });
    if (!fileInfo) return res.status(400).json({ message: "file not found" });
    const nerData = await NerModel.findOne({ fileId: fileInfo._id })
      .lean()
      .select({ __v: 0, updatedAt: 0 });

    const isTemp = fileInfo.resultCheck === "temp" ? true : false;

    //parsing multiple sellerInfo from (sellerName, sellerCode, accountInfo, accountNo)
    //  const multipleSellerInfo = getMultipleSellerInfo(nerData.sellerName, nerData.sellerCode, nerData.accountInfo, nerData.accountNo);
    //parsing most updated ner data
    let responseNerData = parsingNerData(nerData, isTemp);

    // console.log("ner data after parsing", responseNerData)
    if(responseNerData?.multipleSellerInfo){
      responseNerData = alterSpecialChar(responseNerData)
    }
    // replacing key 
    // console.log("after reaplacing", responseNerData);



    const itemTableData = await ItemTableModel.find({ fileId: fileInfo._id })
      .lean()
      .select({ __v: 0 });

    //item parsing
    let newItem = [];
    for (let i of itemTableData) {
      newItem.push(parsingNerData(i, isTemp));
    }
    const categoryTableData = await CategoryTableModel.find({
      fileId: fileInfo._id,
    })
      .lean()
      .select({ __v: 0 });

    //category item parsing
    let categoryItem = [];
    for (let i of categoryTableData) {
      categoryItem.push(parsingNerData(i, isTemp));
    }
    const fusenInfo = await FusenModel.findOne({ fileId: fileInfo._id })
      .lean()
      .select({ __v: 0 });

    //getting prev & next file id in result page
    const response = await prevNextIdForOcrComplete(
      req.user.role,
      uploadedBy,
      rpaCheck,
      fileInfo._id,
      { startDate, endDate },
      fileInfo.createdAt,
    );


    return res.status(200).json({
      totalCompletedFile: response?.totalIndex,
      currentFileNo: response?.currentIndex,
      prevId: response?.prevId,
      nextId: response?.nextId,
      nerData: responseNerData && responseNerData,
      fusen: fusenInfo || {},
      itemTableData: newItem && newItem,
      categoryTableData: categoryItem && categoryItem,
      fileInfo: fileInfo,
    });
  } catch (err) {
    console.log(err);
    return res.status(400).json({ message: "Something went wrong" });
  }
};

//creating rpa file
module.exports.RPACreation = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction()
  try {
    const errors = validationMessages(validationResult(req).mapped());
    if (isErrorFounds(errors)) return res.status(400).json(errors);
    const filesId = req.body.fids;
    if (!Array.isArray(filesId) || filesId.length <= 0) {
      return res.status(400).json({ message: "no file selected" });

    }
    const args = {};
    if (req.user.role === "user") {
      args["uploadedBy"] = req.user._id;
    }

    const filesInfo = await FileModel.find({
      isDeleted: false,
      _id: { $in: filesId },
      ocrStatus: "Completed",
      // invoiceError:

      ...args,
    })
      .lean()
      .select({ _id: 1 }).session(session);

    const requestor = req.user.employeeCode;
    const files_to_download = [];
    for await (let f of filesInfo) {
      let singleFile = await FileModel.findOne({ _id: f._id }).lean().session(session);
      if (singleFile?.invoiceError?.length) {
        return res
          .status(400)
          .json({ message: "Please select without invoice error files" });
      } else {

      }
    }

    if (filesInfo.length !== filesId.length)
      return res
        .status(400)
        .json({ message: "Please select only OCR completed files" });


    for (let item of filesId) {
      const fusenInfo = await FusenModel.findOne({ fileId: item }).lean().session(session);
      let urls = await updatingExtractedJson(item);
      if (urls.Location) {
        const obj = {
          filepath: urls.Key,
          first_approver: fusenInfo.firstApproverCode,
          cost_center: fusenInfo.costCenter.split("-")[0].trim() || fusenInfo.costCenter,
          description: fusenInfo.description || "",
        };
        files_to_download.push(obj);
      }

    }
    const data = {
      requestor,
      files_to_download
    }

    const lambdaCall = await fetch(process.env.RPA_URL, {
      method: "POST",
      headers: {
        "x-api-key": process.env.RPA_KEY
      },
      body: JSON.stringify(data)
    });

    if (lambdaCall.status === 200) {
      const response = await lambdaCall.json();
      await FileModel.updateMany({ _id: { $in: filesId } }, {
        resultCheck: "done"
      }).session(session);
      // console.log("rpa lambda response",response);
      const downloadbleLink = await rpaFilePressignedUrl(response);
      return res.status(200).json({ link: downloadbleLink, response });

    } else {
      // console.log("pai nai");
      await session.abortTransaction();
      return res.status(400).json({ "message": "Something went wrong" });
    }

  } catch (err) {
    console.log(err);
    logger.log("error", err.message)
    await session.abortTransaction();
    session.endSession()

    return res.status(400).json({ message: "Something went wrong" });
  } finally {
    if (session.inTransaction()) {
      await session.commitTransaction()
    }
    session.endSession()
  }
};

function categoryData(categoryTableData) {

  return new Promise(function (resolve, reject) {
    let categoryItem = [];
    if (!categoryTableData.length) {
      reject([])
    }
    for (let i of categoryTableData) {
      categoryItem.push(parsingNerData(i));
    }
    resolve(categoryItem);

  })
}


module.exports.updateTable = async (req, res) => {
  try {
    const errors = validationMessages(validationResult(req).mapped());
    if (isErrorFounds(errors)) return res.status(400).json(errors);
    //from request body
    const fid = req.body.fid;
    const reqItemTableData = req.body.itemTableData;
    const isDone = req.body.isDone ? req.body.isDone : false;
    const reqNerData = req.body.nerData;

    if (!Array.isArray(reqItemTableData) || reqItemTableData.length <= 0) {
      return res.status(400).json({ "message": "Item table data not found" });
    }
    if (!fid)
      return res.status(400).json({ message: "file id not defined" });


    const fileInfo = await fileExistInDb(fid);
    if (!fileInfo) return res.status({ message: "File not exist" });

    let newItemTableData = [];

    let anotherItemTable = [];
    for (let item of reqItemTableData) {
      if (item.exclude !== true) {
        newItemTableData.push(item);
      } else {
        anotherItemTable.push(item);
      }
    }

    // reqItemTableData
    for (let n of newItemTableData) {
      const bizApiItemName = encodeURI(n?.itemName);
      const bizApiCategoryName = encodeURI(n?.categoryName);

      let result = await fetch(
        `${process.env.BIZAPIURL
        }/sub-category/get-sub-category?item_name=${utf8.decode(
          bizApiItemName
        )}&category_name=${utf8.decode(bizApiCategoryName)}`,
        {
          method: "GET",
          headers: {
            "x-api-key": process.env.BIZXAPIKEY,
          },
        }
      );
      // console.log(result);
      if (result.status === 200) {
        let result2 = await result.json();
        // console.log("sub category", result2);
        n.subCategory = result2?.subcategory
      } else {
        n.subCategory = n.subCategory;
      }

    }

    const newData = itemToCategoryWithTax(newItemTableData, fid);
    // console.log("new category", newData);



    let targetMonth;
    let onlyMonth;
    for (let item of newData) {
      const bizApisubcategoryName = encodeURIComponent(item.subCategory);
      // let targetMonth;
      //if actual targetmonth;
      const fusen = await FusenModel.findOne({ fileId: fid }).lean();
      if (fusen?.actualWorkingDate) {
        // targetMonth = encodeURI(getMonthName(fusen.actualWorkingDate).yearAndMonth);
        // onlyMonth = encodeURI(getMonthName(fusen.actualWorkingDate).onlyMonth);
        targetMonth = encodeURI(fusen?.actualWorkingDate);
        onlyMonth = encodeURI(fusen?.actualWorkingDate);

      } else {
        targetMonth = encodeURI(getMonthName(reqNerData?.issueDate).yearAndMonth);
        onlyMonth = encodeURI(getMonthName(reqNerData?.issueDate).onlyMonth);
      }

      // console.log(`get text: ${process.env.BIZAPIURL}/text-field/get-text-field?hospital_code=${reqNerData?.hospitalCode
      // }&seller_code=${reqNerData?.sellerSelectedIndex[1] === -1 ? reqNerData.sellerCorrectedValues[1] : reqNerData.sellerCode[reqNerData.sellerSelectedIndex[0]][reqNerData.sellerSelectedIndex[1]]}&protocol_no=${reqNerData?.protocolSelectedIndex[0] === -1 ? reqNerData.protocolCorrectedValues[0] : reqNerData.protocolNo[reqNerData.protocolSelectedIndex[0]]
      // }&category_no=${item.categoryNumber}&subcategory_name=${utf8.decode(
      //   bizApisubcategoryName
      // )}&target_month=${utf8.decode(targetMonth)}`);

      const result = await fetch(
        `${process.env.BIZAPIURL}/text-field/get-text-field?hospital_code=${reqNerData?.hospitalCode
        }&seller_code=${reqNerData?.sellerSelectedIndex[1] === -1 ? reqNerData.sellerCorrectedValues[1] : reqNerData.sellerCode[reqNerData.sellerSelectedIndex[0]][reqNerData.sellerSelectedIndex[1]]}&protocol_no=${reqNerData?.protocolSelectedIndex[0] === -1 ? reqNerData.protocolCorrectedValues[0] : reqNerData.protocolNo[reqNerData.protocolSelectedIndex[0]]
        }&category_no=${item.categoryNumber}&subcategory_name=${utf8.decode(
          bizApisubcategoryName
        )}&target_month=${utf8.decode(targetMonth)}`,
        {
          method: "GET",
          headers: {
            "x-api-key": process.env.BIZXAPIKEY,
          },
        }
      );
      if (result.status === 200) {
        const response = await result.json();
        // console.log("getting text", response);
        const textData = response?.text_field;
        // console.log("text data", textData);
        item.text = `${textData}`;
      } else {
        item.text = item.subCategory;
      }
    }

    //finding max subcategory
    const maxSubCategory = subCategoryWiseAmount(newData);
    // console.log("maxSubCategory: ", maxSubCategory);
    const encodeMaxSubcategory = encodeURI(maxSubCategory);

    // console.log(`${process.env.BIZAPIURL
    //   }/purpose-of-payment/get-purpose-of-payment?hospital_code=${reqNerData?.hospitalSelectedIndex[1] === -1 ? reqNerData.hospitalCorrectedValues[1] : reqNerData.hospitalCode[reqNerData.hospitalSelectedIndex[0]][reqNerData.hospitalSelectedIndex[1]]
    //   }&seller_code=${reqNerData?.sellerSelectedIndex[1] === -1 ? reqNerData.sellerCorrectedValues[1] : reqNerData.sellerCode[reqNerData.sellerSelectedIndex[0]][reqNerData.sellerSelectedIndex[1]]}&subcategory_name=${utf8.decode(
    //     encodeMaxSubcategory
    //   )}&target_month=${utf8.decode(onlyMonth)}`);
    const popReponse = await fetch(
      `${process.env.BIZAPIURL
      }/purpose-of-payment/get-purpose-of-payment?hospital_code=${reqNerData?.hospitalSelectedIndex[1] === -1 ? reqNerData.hospitalCorrectedValues[1] : reqNerData.hospitalCode[reqNerData.hospitalSelectedIndex[0]][reqNerData.hospitalSelectedIndex[1]]
      }&seller_code=${reqNerData?.sellerSelectedIndex[1] === -1 ? reqNerData.sellerCorrectedValues[1] : reqNerData.sellerCode[reqNerData.sellerSelectedIndex[0]][reqNerData.sellerSelectedIndex[1]]}&subcategory_name=${utf8.decode(
        encodeMaxSubcategory
      )}&target_month=${utf8.decode(onlyMonth)}`,
      {
        method: "GET",
        headers: {
          "x-api-key": process.env.BIZXAPIKEY,
        },
      }
    );
    if (popReponse.status === 200) {
      const pop = await popReponse.json();
      reqNerData.purposeOfPayment = pop?.pop;
      // console.log("pop",pop);
    } else {
      reqNerData.purposeOfPayment = reqNerData.purposeOfPayment;
    }





    //testing start
    const parsedCategoyData = [];
    for (let cateData of newData) {
      parsedCategoyData.push(parsingNerData(cateData))
    }


    return res.status(200).json({
      itemTableData: reqItemTableData,
      categoryTableData: parsedCategoyData || [],
      nerData: reqNerData,
    });



  } catch (err) {
    console.log(err);
    return res.status(400).json({ message: "Something went wrong" });
  }
};
module.exports.modifyResultPage = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const errors = validationMessages(validationResult(req).mapped());
    if (isErrorFounds(errors)) return res.status(400).json(errors);

    const fid = req.query.fid;
    const reqNerData = req.body.nerData;
    const reqItemTableData = req.body.itemTableData;
    const reqCategoryTableData = req.body.categoryTableData;
    const reqFusenData = req.body.fusen;
    const isDone = req.body.isDone ? req.body.isDone : false;


    //if fusen protocol no
    if (reqFusenData) {
      const { _id: fusenId, ...restFusen } = reqFusenData;
      if (
        reqFusenData?.protocolNo ||
        reqFusenData?.paymentRequestDate ||
        reqFusenData?.description ||
        reqFusenData?.costCenter ||
        reqFusenData?.firstApprover ||
        reqFusenData?.firstApproverCode
      ) {
        const isFusen = await FusenModel.findOne({ fileId: fid }).session(session).lean();
        // console.log("is fusen: && rest fusen ", isFusen?._id, restFusen);
        if (isFusen) {
          await fusenUpdate(reqFusenData?._id, restFusen, session);
        } else {
          await new FusenModel({ fileId: fid, ...reqFusenData }).save({ session });
        }
      }
    }

    let countt = await findItemTableLastId(fid, session);
    let count;
    if (countt === undefined) {
      count = 0;
    } else {
      count = countt[0]?.itemId;

    }

    if (isDone === true) {
      //corected state
      //update data in last index
      const nerData = await NerModel.findOne({ fileId: fid }).session(session)
        .lean()
        .select();
      const itemTableData = await ItemTableModel.find({ fileId: fid }).session(session)
        .lean()
        .select({ createdAt: 0, __v: 0 });
      const categoryTableData = await CategoryTableModel.find({ fileId: fid }).session(session)
        .lean()
        .select({ createdAt: 0, __v: 0 });

      const { _id, fileId, updatedAt, createdAt, __v, ...nerRest } = nerData;
      // console.log("ner rest", nerRest);
      // nerjson -> request nerdata from gui
      const dbNerData = nerDataSaveIndex(nerRest, 2, reqNerData);
      // console.log("db ner data", dbNerData);
      const { _id: nerId, fileId: f, ...nerDBData } = dbNerData;

      // console.log("ner db data", nerDBData);
      alterSpecialCharForDB(nerDBData);
     
      //counting last data id
      // const count = await findItemTableLastId(fid)
      //item table data
      const { newLineData: newItemData, previouseData: previousItemData } =
        await itemDataSaveIndex(itemTableData, 2, reqItemTableData, count);
      // return
      //checking mandatory filed

      // console.log("new item data", newItemData);
      // console.log("prev item Data", previousItemData);
      //update prev item  data
      // saving in ner data base -> comment out will ber changed in db connection
      await saveNerData(nerData._id, nerDBData, session);
      await saveItemTableData(previousItemData, session);
      await ItemTableModel.insertMany(newItemData, { session });
      // inserting new item table data
      //update prev category  data

      //testing new way

      await CategoryTableModel.deleteMany({ fileId: fid }).session(session);
      //form reqcategory Table
      //processing new  category data
      let newCategoryData = [];
      for (let categorySingleData of reqCategoryTableData) {
        let singleData = {
          fileId: fid,
          taxRate: new Array(3).fill(categorySingleData?.taxRate),
          text: new Array(3).fill(categorySingleData?.text),
          amount: new Array(3).fill(categorySingleData?.amount),
          categoryNumber: new Array(3).fill(categorySingleData?.categoryNumber),
          categoryName: new Array(3).fill(categorySingleData?.categoryName),
          subCategory: new Array(3).fill(categorySingleData?.subCategory),
          exclude: new Array(3).fill(categorySingleData?.exclude || false)
        };
        newCategoryData.push(singleData);
      }
      // console.log("new Category Data", newCategoryData);
      await CategoryTableModel.insertMany(newCategoryData, { session });


      // changing file status to done
      await FileModel.findOneAndUpdate(
        { _id: fid },
        {
          $set: {
            resultCheck: "checked",
            invoiceError: [],
          },
        }
      ).session(session);
      return res.status(200).json({ message: "Updated Successfully" });
    } else {
      //tempoary state
      //update data in 1 index
      const nerData = await NerModel.findOne({ fileId: fid }).session(session)
        .lean()
        .select({ createdAt: 0, updatedAt: 0, __v: 0 });
      const itemTableData = await ItemTableModel.find({ fileId: fid }).session(session)
        .lean()
        .select({ createdAt: 0, updatedAt: 0, __v: 0 });
      const categoryTableData = await CategoryTableModel.find({ fileId: fid }).session(session)
        .lean()
        .select({ createdAt: 0, updatedAt: 0, __v: 0 });

      const { _id, fileId, createdAt, updatedAt, __v, ...nerRest } = nerData;

      // console.log("itemTable data", itemTableData);

      const dbNerData = nerDataSaveIndex(nerRest, 1, reqNerData);
      // console.log("from temp ner data", dbNerData);
      //upating ner data
      alterSpecialCharForDB(dbNerData)
      await saveNerData(_id, dbNerData, session);

      const { newLineData: newItemData, previouseData: prevItemData } =
        await itemDataSaveIndex(itemTableData, 1, reqItemTableData, count);
      // console.log("new item Data", newItemData);
      // console.log("prev item data", prevItemData);
      //updating prev data
      await saveItemTableData(prevItemData, session);
      //inseting new item data
      await ItemTableModel.insertMany(newItemData, { session });
      //testing new way

      await CategoryTableModel.deleteMany({ fileId: fid }).session(session);
      //form reqcategory Table
      //processing new  category data
      let newCategoryData = [];
      for (let categorySingleData of reqCategoryTableData) {
        let singleData = {
          fileId: fid,
          taxRate: new Array(3).fill(categorySingleData?.taxRate),
          text: new Array(3).fill(categorySingleData?.text),
          amount: new Array(3).fill(categorySingleData?.amount),
          categoryNumber: new Array(3).fill(categorySingleData?.categoryNumber),
          categoryName: new Array(3).fill(categorySingleData?.categoryName),
          subCategory: new Array(3).fill(categorySingleData?.subCategory),
          exclude: new Array(3).fill(categorySingleData?.exclude || false)
        };
        newCategoryData.push(singleData);

      }
      // console.log("new Category Data", newCategoryData);
      await CategoryTableModel.insertMany(newCategoryData, { session });

      const fileInformation = await FileModel.findOne({_id: fid}).session(session).lean();
      if(fileInformation?.invoiceError.includes("Multiple") && isMultpleError(reqNerData)){
        await FileModel.findOneAndUpdate({_id: fid}, {
          $set: {
            resultCheck: "temp",
            invoiceError: ["Multiple"],
          },
        }).session(session)
      }else{
        await FileModel.findOneAndUpdate(
          { _id: fid },
          {
            $set: {
              resultCheck: "temp",
              invoiceError: [],
            },
          }
        ).session(session);
      }

      // return;
      return res.status(200).json({ message: "Updated Successfully" });
    }
  } catch (err) {
    console.log(err);
    await session.abortTransaction();
    session.endSession()
    logger.log("error", err.message)
    return res.status(400).json({ message: "Something went wrong" });
  } finally {
    if (session.inTransaction()) {
      await session.commitTransaction()
    }
    session.endSession()
  }
};

module.exports.redoOCR = async (req, res) => {
  try {
    const fid = req.query.fid;
    if (!mongoose.isObjectIdOrHexString(fid)) return res.status(400).json({ "message": "Invalid request" })
    const fusen = await FusenModel.findOne({ fileId: fid })
      .lean()
      .select({ __v: 0, createdAt: 0, updatedAt: 0 });

    const file = await FileModel.findOne({ _id: fid }).lean();


    let isJsonExist = await isOutputJsonExist(file?.fileKey);
    // console.log("is json exist",isJsonExist);
    if (isJsonExist) {
      await deleteJson(file?.fileKey);
      await deleteInputJson(file?.fileKey)
    }

    if (file) {
      await FileModel.findOneAndUpdate({ _id: file._id }, {
        $set: {
          invoiceError: []
        }
      })
    }
    return res.status(200).json({ fusen: fusen });
  } catch (err) {
    logger.log("error", `${err}`)
    return res.status(400).json({ messag: "Something went wrong" });
  }
};
// ******************************** helper function *********************
//updating ner value for ner db schema;
function nerDataSaveIndex(requestObj = {}, index = 1, fromDb = {}) {
  const checkList = ["sellerName", "sellerCode", "hospitalName", "hospitalCode", "protocolNo", "protocolName", "sellerSelectedIndex", "hospitalSelectedIndex", "protocolSelectedIndex", "sellerCorrectedValues", "hospitalCorrectedValues", "protocolCorrectedValues", "multipleSellerInfo", "isProtocolUserInput", "isSellerUserInput", "isHospitalUserInput", "isSellerDropdownchanged", "isHospitalDropdownchanged", "isProtocolDropdownchanged"];
  for (let key in requestObj) {
    if (checkList.includes(key)) {
      requestObj[key] = fromDb[key];
    } else {
      requestObj[key][index] = fromDb[key];

    }
  }

  return requestObj;
}

//updating item table value for item db schema;
async function itemDataSaveIndex(
  fromDb = [],
  index,
  fromRequestGui = [],
  count = 0
) {
  let newLineData = [];
  let previouseData = [];
  // console.log("before inc", count);
  if (fromRequestGui.length) {

    for (let i = 0; i < fromRequestGui.length; i++) {
      const item = fromRequestGui[i];
      if (item._id && mongoose.isObjectIdOrHexString(item._id)) {
        //update specifiq id

        // console.log(`${item._id}===${fromDb[i]._id} : ${item._id.toString() === fromDb[i]._id.toString()}`);
        const newData = {
          ...fromDb[i],
        };
        newData.itemName[index] = item.itemName;
        newData.amountWithOutTax[index] = item.amountWithOutTax || 0;
        newData.consumptionTax[index] = item.consumptionTax || 0;
        newData.taxRate[index] = item.taxRate;
        newData.amountWithTax[index] = item.amountWithTax || 0;
        newData.categoryName[index] = item.categoryName;
        newData.categoryNumber[index] = item.categoryNumber;
        newData.subCategory[index] = item.subCategory || "";
        newData.pageNumber = item?.pageNumber;
        newData.exclude[index] = item?.exclude || false;

        // console.log("if",newData);

        previouseData.push(newData);
      } else {
        let idCount = count + 1;
        count = idCount
        //if  no id then creating another document in item table colection
        const { _id, createdAt, updatedAt, ...newData } = item;
        newData.itemId = idCount;
        // console.log("id count", idCount);
        newData.itemName = Array(3).fill(item.itemName);
        newData.amountWithOutTax = Array(3).fill(item.amountWithOutTax || 0);
        newData.consumptionTax = Array(3).fill(item.consumptionTax || 0);
        newData.taxRate = Array(3).fill(item.taxRate);
        newData.amountWithTax = Array(3).fill(item.amountWithTax);
        newData.categoryName = Array(3).fill(item.categoryName);
        newData.categoryNumber = Array(3).fill(item.categoryNumber);
        newData.subCategory = Array(3).fill(item?.subCategory || "");
        newData.pageNumber = "";
        newData.exclude = Array(3).fill(item?.exclude || false);
        // console.log("id nai", newData);
        newLineData.push(newData);
      }
    }
    return { newLineData, previouseData };
  }
}
//updating category table value for category db schema;
function categorySaveIndex(fromDb = [], index, fromRequestGui = []) {
  let newLineData = [];
  let previouseData = [];
  // console.log("from db",fromDb);
  if (Array.isArray(fromRequestGui) && fromRequestGui.length) {
    for (let i = 0; i < fromRequestGui.length; i++) {
      const item = fromRequestGui[i];
      if (item._id && item._id.length > 10) {
        //update specifiq id
        // console.log(
        //   `${item._id}===${fromDb[i]._id} : ${
        //     item._id.toString() === fromDb[i]._id.toString()
        //   }`
        // );
        const newData = {
          ...fromDb[i],
        };
        newData.taxRate[index] = item.taxRate;
        newData.text[index] = item.text;
        newData.amount[index] = item.amount || 0;
        newData.categoryNumber[index] = item.categoryNumber;
        newData.categoryName[index] = item.categoryName;
        newData.subCategory[index] = item?.subCategory || "";
        newData.exclude[index] = item?.exclude || false;
        previouseData.push(newData);

        // console.log("if", newData);
      } else {
        //if  no id then creating another document in item table colection
        // console.log("id nai", item);
        const { _id, createdAt, updatedAt, ...newData } = item;
        newData.taxRate = Array(3).fill(item.taxRate);
        newData.text = Array(3).fill(item.text);
        newData.amount = Array(3).fill(item.amount || 0);
        newData.taxRate = Array(3).fill(item.taxRate);
        newData.categoryNumber = Array(3).fill(item.categoryNumber);
        newData.categoryName = Array(3).fill(item.categoryName);
        newData.subCategory = Array(3).fill("");
        newData.exclude = Array(3).fill(item?.exclude || false);
        newLineData.push(newData);
      }
    }
    return { newLineData, previouseData };
  }
}

function itemToCategory(items) {
  const minimizeTableArry = [];
  const obj = {};
  for (let item of items) {
    const name = `${item["categoryNumber"]}_${item["taxRate"]}`;
    if (name in obj) {
      obj[name].amount[0] += item["amountWithTax"];
      obj[name].amount[2] += item["amountWithTax"];
    } else {
      obj[name] = {
        categoryName: [item["categoryName"], "", item["categoryName"]],
        categoryNumber: [item["categoryNumber"], "", item["categoryNumber"]],
        amount: [item["amountWithTax"], "", item["amountWithTax"]],
        taxRate: [item["taxRate"], "", item["amountWithTax"]],
        text: [item["text"] || "n/a", "", item["text"] || "n/a"],
        exclude: [item["exclude"], false, item["exclude"]],
        fileId: item["fileId"],
      };
    }
  }
  // return obj;

  for (let item in obj) {
    // creteSingleCategoryTableData(obj[item], id);
    // await new CategoryTable({ fileId: id, ...obj[item] }).save();
    minimizeTableArry.push({ ...obj[item] });
  }
  return minimizeTableArry;
}

//updating ner data in DB
async function saveNerData(id, data, session) {
  await NerModel.findOneAndUpdate({ _id: id }, { $set: data }).session(session);
}
//updating item table data in DB
async function saveItemTableData(arrayData = [], session) {
  for await (let item of arrayData) {
    const { _id, ...restItem } = item;
    await ItemTableModel.findOneAndUpdate(
      { _id: item._id },
      { $set: restItem }
    ).session(session);
  }
}
//updating category table data in DB
async function saveCategoryTableData(arrayData = []) {
  for await (let item of arrayData) {
    const { _id, ...restItem } = item;
    await CategoryTableModel.findOneAndUpdate(
      { _id: item._id },
      { $set: restItem }
    );
  }
}

//helper for update json in extracted json
async function updatingExtractedJson(fids, session) {
  let fileIds = fids;
  // console.log(fileIds);
  const CORRECTED_INDEX = 2;

  // for await (let id of fileIds) {
  //first load the first extracted json
  let file = await FileModel.findOne({ _id: fileIds }).session(session).lean();

  let response = await extractedJsonReadFromS3(file);
  // if(response === undefined) continue;
  if (response !== undefined) {

    let bufferData = Buffer.from(response?.Body).toString("utf-8");
    let extractedJson = JSON.parse(bufferData);
    // console.log(extractedJson);
    let extractedNerData = extractedJson["extracted_output"];
    let items = extractedJson["extracted_output"].item_table_extracted_field;
    // let categoryItems = extractedNerData['category_table_extracted_field'];
    delete extractedJson["category_table_extracted_field"];
    // categoryItems = []

    let dbItems = await ItemTableModel.find({ fileId: fileIds }).session(session)
      .lean()
      .sort({ itemId: 1 })
      .select({ createdAt: 0, updatedAt: 0 });
    let dbCategoryItems = await CategoryTableModel.find({ fileId: fileIds }).session(session)
      .lean()
      .select({ createdAt: 0, updatedAt: 0, subCategory: 0 });

    for (let i = 0; i < dbItems.length; i++) {
      let item = dbItems[i];
      // console.log(item);
      let correctedItemName = item.itemName[CORRECTED_INDEX];
      let correctedCategoryName = item.categoryName[CORRECTED_INDEX];
      let correctedCategoryNumber = item.categoryNumber[CORRECTED_INDEX];
      let correctedAmountWithOutTax = item.amountWithOutTax[CORRECTED_INDEX];
      let correctedSubcategory = item.subCategory[CORRECTED_INDEX];
      let correctedTaxRate = item.taxRate[CORRECTED_INDEX];
      if (i < items.length) {
        items[i].item_name.corrected_text = correctedItemName;
        items[i].item_name["corrected_sub-category"] = correctedSubcategory;
        items[i].item_name.corrected_category_number = correctedCategoryNumber;
        items[i].item_name.corrected_category_name = correctedCategoryName;
        items[i].item_name.corrected_category_name = correctedCategoryName;
        items[i].amount_without_tax.corrected_text = correctedAmountWithOutTax;
        items[i].corrected_tax_rate = correctedTaxRate;
      } else {
        //new item added
        const newItem = {
          item_name: {
            x: "",
            y: "",
            height: "",
            width: "",
            text: "",
            corrected_text: correctedItemName,
            "sub-category": "",
            "corrected_sub-category": correctedSubcategory,
            category_name: "",
            corrected_category_name: correctedCategoryName,
            category_number: "",
            corrected_category_number: correctedCategoryNumber,
          },
          amount_without_tax: {
            x: "",
            y: "",
            height: "",
            width: "",
            text: "",
            corrected_text: `${correctedAmountWithOutTax}`,
          },
          page_number: "",
          corrected_tax_rate: `${correctedTaxRate}`
        };

        items.push(newItem);
      }
    }

    // categoryItems = [];
    ///category tables
    const categoryItemArray = [];
    for (let item of dbCategoryItems) {
      if (item.exclude[CORRECTED_INDEX] === false) {
        const correctedCategoryName = item.categoryName[CORRECTED_INDEX];
        const correctedCategoryNumber = item.categoryNumber[CORRECTED_INDEX];
        const correctedCategoryText = item.text[CORRECTED_INDEX];
        const correctedCategoryAmount = item.amount[CORRECTED_INDEX];
        const correctedCategoryTax = item.taxRate[CORRECTED_INDEX];
        const schema = {
          category_name: "",
          corrected_category_name: correctedCategoryName,
          category_number: "",
          corrected_category_number: parseInt(correctedCategoryNumber),
          amount: "",
          corrected_amount: parseInt(correctedCategoryAmount),
          tax_rate: "",
          corrected_tax_rate: parseInt(correctedCategoryTax),
          text: "",
          corrected_text: correctedCategoryText, 
        };
        categoryItemArray.push(schema);
      }
    }
    extractedJson["extracted_output"]["category_table_extracted_field"] =
      categoryItemArray;

    const nerData = await NerModel.findOne({ fileId: fileIds }).session(session).lean();
    alterSpecialChar(nerData);
    // console.log("ner", nerData);
    //ner data
    let VALUE_INDEX = 2;

    let correctedSellerNameNew = (nerData.sellerSelectedIndex[0] === -1 || nerData.sellerSelectedIndex[1] === -1) ? nerData.sellerCorrectedValues[0] : nerData.sellerName[nerData.sellerSelectedIndex[0]];
    // let alterCorrectedSellerNameNew = correctedSellerNameNew.replace(/\./g, charAlterList['.']).replace('/\$/g', charAlterList['$']);
    // console.log(alterCorrectedSellerNameNew);

    let correctedSellerCodeNew = (nerData.sellerSelectedIndex[0] === -1 || nerData.sellerSelectedIndex[1] === -1) ? nerData.sellerCorrectedValues[1] : nerData.sellerCode[nerData.sellerSelectedIndex[0]][nerData.sellerSelectedIndex[1]];
    
    // let alterCorrectedSellerCodeNew = correctedSellerCodeNew.replace(/\./g, charAlterList['.']).replace('/\$/g', charAlterList['$']);

    let correctedHospitalNameNew = (nerData.hospitalSelectedIndex[0] === -1 || nerData.hospitalSelectedIndex[1] === -1) ? nerData.hospitalCorrectedValues[0] : nerData.hospitalName[nerData.hospitalSelectedIndex[0]];
    let correctedHospitalCodeNew = (nerData.hospitalSelectedIndex[0] === -1 || nerData.hospitalSelectedIndex[1] === -1) ? nerData.hospitalCorrectedValues[1] : nerData.hospitalCode[nerData.hospitalSelectedIndex[0]][nerData.hospitalSelectedIndex[1]];

    let correctedProtocolNoNew = (nerData.protocolSelectedIndex[0] === -1 || nerData.protocolSelectedIndex[1] === -1) ? nerData.protocolCorrectedValues[0] : nerData.protocolNo[nerData.protocolSelectedIndex[0]];
    let correctedProtocolNameNew = (nerData.protocolSelectedIndex[0] === -1 || nerData.protocolSelectedIndex[1] === -1) ? nerData.protocolCorrectedValues[1] : nerData.protocolName[nerData.protocolSelectedIndex[0]][nerData.protocolSelectedIndex[1]];

    let accountInfoNew = (nerData.sellerSelectedIndex[0] === -1 || nerData.sellerSelectedIndex[1] === -1) ? nerData.sellerCorrectedValues[2] : nerData.multipleSellerInfo[correctedSellerNameNew][correctedSellerCodeNew]['formatted_account_info'];
    let accountNoNew = nerData.multipleSellerInfo[correctedSellerNameNew][correctedSellerCodeNew]['account_number'] || "";


    let correctedAccountNo = accountNoNew;
    let correctedaccountInfo = accountInfoNew;
    let correctedprotocolName = correctedProtocolNameNew;
    let correctedprotocolNo = correctedProtocolNoNew;
    let correctedsellerName = correctedSellerNameNew;
    let correctedsellerCode = correctedSellerCodeNew;
    let correctedhospitalName = correctedHospitalNameNew;
    let correctedhospitalCode = correctedHospitalCodeNew;

    let correctedcurrencyCode = nerData.currencyCode[VALUE_INDEX];
    let correctedinvoiceNumber = nerData.invoiceNumber[VALUE_INDEX];
    let correctedissueDate = nerData.issueDate[VALUE_INDEX];
    let correctedpaymentDeadline = nerData.paymentDeadline[VALUE_INDEX];
    let correctedtotalAmount = nerData.totalAmount[VALUE_INDEX];
    let correctedpurposeOfPayment = nerData.purposeOfPayment[VALUE_INDEX];

    const NER_INDEX = 0;
    extractedNerData["account_no"]["corrected_values"][NER_INDEX] =
      correctedAccountNo || "";
    extractedNerData["account_info"]["corrected_values"][NER_INDEX] =
      correctedaccountInfo || "";
    extractedNerData["currency_code"]["corrected_values"][NER_INDEX] =
      correctedcurrencyCode || "";
    extractedNerData["hospital_name"]["corrected_values"][NER_INDEX] =
      correctedhospitalName || "";
    extractedNerData["hospital_code"]["corrected_values"][NER_INDEX] =
      correctedhospitalCode || "";
    extractedNerData["invoice_number"]["corrected_values"][NER_INDEX] =
      correctedinvoiceNumber || "";
    extractedNerData["issue_date"]["corrected_values"][NER_INDEX] =
      formatDateInNer(correctedissueDate) || "";
    extractedNerData["payment_deadline"]["corrected_values"][NER_INDEX] =
      formatDateInNer(correctedpaymentDeadline) || "";
    extractedNerData["protocol_no"]["corrected_values"][NER_INDEX] =
      correctedprotocolNo || "";
    extractedNerData["project_name"]["corrected_values"][NER_INDEX] =
      correctedprotocolName || "";
    extractedNerData["seller_name"]["corrected_values"][NER_INDEX] =
      correctedsellerName || "";
    extractedNerData["seller_code"]["corrected_values"][NER_INDEX] =
      correctedsellerCode || "";
    extractedNerData["total_amount"]["corrected_values"][NER_INDEX] =
      correctedtotalAmount || "";
    extractedNerData["purpose_of_payment"]["corrected_values"][NER_INDEX] =
      correctedpurposeOfPayment || "";

    const correcteExtractedOutput = extractedJson;
    const location = await updateJsonInS3(file, correcteExtractedOutput);
    if (location) {

      // await FileModel.findOneAndUpdate({_id: fileIds}, {$set: {
      //   resultCheck: "done"
      // }})
      return location;

    } else {
      console.log("location not found");
    }
  }

}

function getMonthName(date) {
  if (!date) {
    return { yearAndMonth: `月`, onlyMonth: `月` };
  }
  const month = new Date(date).getMonth();
  const year = new Date(date).getFullYear();
  return { yearAndMonth: `${year}.${month + 1}月`, onlyMonth: `${month + 1}月` };
}
//max sub category calculation
const subCategoryWiseAmount = (items) => {
  let obj = {};
  for (let item of items) {
    const subCategory = item.subCategory;
    if (subCategory in obj) {
      obj[subCategory].amount += parseFloat(
        item?.amount
      );
    } else {
      obj[subCategory] = {
        subCategory: item?.subCategory,
        amount: parseFloat(item?.amount),
      };
    }
  }
  // console.log("sub category",obj);
  //   return ;

  let maxSubCategory = "";
  let max = 0;
  for (let sub in obj) {
    // console.log("obj name",Object.values(obj[sub]));
    if (obj[sub]?.amount > max) {
      max = obj[sub].amount;
      maxSubCategory = sub;
    } else {
      // console.log(obj[sub]);
      continue;
    }
  }
  return maxSubCategory ? maxSubCategory : "";
};

function isMultpleError(nerData){
  // console.log(nerData);
  let isError = false;
  if(!nerData?.isSellerUserInput){
    // console.log("seller user input e achi");
    if(!nerData?.isSellerDropdownchanged){
      isError = true;
      return isError;
    }
  }
   if(!nerData?.isHospitalUserInput){
    if(!nerData?.isHospitalDropdownchanged){
      isError = true;
      return isError;
    }
  }
   if(!nerData?.isProtocolUserInput){
    if(!nerData?.isProtocolDropdownchanged){
      isError = true;
      return isError;
    }
  }
  return isError;
}
function alterSpecialChar (responseNerData){
  if(responseNerData?.multipleSellerInfo){
 for(let name in responseNerData.multipleSellerInfo){
  //  if(name.search(".") !== -1 || name.search("$") !== 1){
     let val = responseNerData.multipleSellerInfo[name] 
     let n = name.replace(/ঙ/g, ".").replace(/ঞ/g, "$");
    //  console.log("val",n);        
     
     delete responseNerData.multipleSellerInfo[name]
     responseNerData.multipleSellerInfo[n] = val

     if( Object.entries(responseNerData.multipleSellerInfo[n]).length){
       for(let sCode in responseNerData.multipleSellerInfo[n]){
           let sCodeVal = responseNerData.multipleSellerInfo[n][sCode];
           let alterSelleCOde = sCode.replace(/ঙ/g, ".").replace(/ঞ/g, "$");
           delete responseNerData.multipleSellerInfo[n][sCode]
           responseNerData.multipleSellerInfo[n][alterSelleCOde] = sCodeVal;

       }
     }

   
 }
}

return responseNerData;

}
function alterSpecialCharForDB (responseNerData){
  if(responseNerData?.multipleSellerInfo){
 for(let name in responseNerData.multipleSellerInfo){
  //  if(name.search(".") !== -1 || name.search("$") !== 1){
     let val = responseNerData.multipleSellerInfo[name] 
     let n = name.replace(/\./g, "ঙ").replace(/\$/g, "ঞ");
    //  console.log("val",n);        
     
     delete responseNerData.multipleSellerInfo[name]
     responseNerData.multipleSellerInfo[n] = val

     if( Object.entries(responseNerData.multipleSellerInfo[n]).length){
       for(let sCode in responseNerData.multipleSellerInfo[n]){
           let sCodeVal = responseNerData.multipleSellerInfo[n][sCode];
           let alterSelleCOde = sCode.replace(/\./g, "ঙ").replace(/\$/g, "ঞ");
           delete responseNerData.multipleSellerInfo[n][sCode]
           responseNerData.multipleSellerInfo[n][alterSelleCOde] = sCodeVal;

       }
     }

   
 }
}

return responseNerData;

}