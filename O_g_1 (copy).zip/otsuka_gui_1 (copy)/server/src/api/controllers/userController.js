const { validationResult, cookie } = require("express-validator");
const fetch = require("node-fetch");
const jwt = require('jsonwebtoken');
const jwkToPem = require('jwk-to-pem');

const User = require("../models/userModel");
const { validationMessages, isErrorFounds } = require("../helpers/errorMsgHelper");//validation msg formatter
const {
    signIn, checkUser, tokenCreation,
    createSession,
    checkUserSession, deleteUserSession,
    isUserAvialable, modifyUser, getAllUsers } = require("../services/userService");
const { logger } = require("../helpers/logger");

const M_TIME = 30 //second
module.exports.signIn = async (req, res) => {
    
    try {
        if(req.body.isSSO === true){
            const errors = validationMessages(validationResult(req).mapped());
            if (isErrorFounds(errors)) return res.status(400).json(errors);
            const credentials = req.body.credentials;
            // verifying jwt signature
            let deocdedToken = await tokenSingnatureValidation(credentials?.info)
            console.log(deocdedToken);
            let afterAddingTime = parseInt(deocdedToken.auth_time * 1000) + (M_TIME * 1000);
            if(deocdedToken.email !== credentials.email) throw new Error("Invalid request")
            const timedifference = afterAddingTime - new Date().getTime() ;
            console.log("time difference", timedifference);
            if((afterAddingTime > (new Date().getTime()) && (timedifference > 0 && timedifference  <= (M_TIME*1000)))){
                const user = await User.findOne({email: credentials.email}).select({password: 0});
                await deleteUserSession(user?._id); 
                if(user && user.employeeCode === credentials.employeeCode && user.email === credentials.email) {
                    // login 
                    const result = await User.findOneAndUpdate({ email: credentials.email }, { $set: { lastLogin: new Date().toISOString() } },
                                { new: true }).lean().select({ password: 0, updatedAt: 0 });
                    const data = await createSession(user._id, result);  
                    // console.log("result", data);
                    // res.cookie("jwtooken", data.token)
                    const cookie = `jwtooken=${data.token};samesite=strict; secure;path=/;`
                    res.setHeader('set-cookie',[cookie]);
                    
                    return res.status(200).json({ "data": { ...data } , 'msg': "existing user"});


                }else{
                const isNewUserAvailabe = await User.findOne({$or: [{email: credentials.email}, {employeeCode: credentials.employeeCode}]}).lean()
                if(isNewUserAvailabe) return res.status(400).json({"message": "Email or employee code already exist"});
                    const userData = {
                        userName: credentials.displayName,
                        email: credentials.email,
                        employeeCode: credentials.employeeCode,
                        lastLogin: new Date().toISOString()
                    };
                   const newUserInfo = await new User(userData).save();
                //    console.log("userinfo",newUserInfo);
                   const result = await User.findOne({email: userData.email}).lean().select({ password: 0, updatedAt: 0, createdAt:0, __v: 0 });
                   const data = await createSession(newUserInfo._id, result);
                
                //    res.cookie("jwtooken", data.token)
                    const cookie = `jwtooken=${data.token};samesite=strict; secure;path=/;`
                    res.setHeader('set-cookie',[cookie])
                    // logger.log("info","successfully login")
                    
                   return res.status(200).json({ "data": {...data } , 'msg': "new user created" });

                }
            }
            else{
                return res.status(400).json({"message": "Invalid request"})
            }
        }
        const errors = validationMessages(validationResult(req).mapped());
        if (isErrorFounds(errors)) return res.status(400).json(errors);
        const { email, password } = req.body;
        
        const user = await checkUser({ email, password });
        if (!user) return res.status(400).json({ "message": "wrong credentials" });
        await deleteUserSession(user._id); //if present then it will deletete
        const result = await User.findOneAndUpdate({ email }, { $set: { lastLogin: new Date().toISOString() } },
            { new: true }).lean().select({ password: 0, updatedAt: 0 });
            console.log("result", result);
        const data = await createSession(user._id, result);
        // const token = await tokenCreation({...result, sessionId: sessionId});
        // res.cookie("jwtooken", data.token, {httpOnly:true, sameSite: true})
        const cookie = `jwtooken=${data.token};samesite=strict; secure;path=/;`
        res.setHeader('set-cookie',[cookie]);
        
        logger.log("info",`successfully login, user: ${result.userName}`)

        return res.status(200).json({ "data": { ...user, ...data } });
    } catch (err) {
        console.log(err.message);
        logger.log('error', `${err.message}`)
        return res.status(500).json({ "message": "Something went wrong" });
    }

}


module.exports.signOut = async (req, res) => {
    try {

        const destroySession = await deleteUserSession(req.user._id);
        return res.status(200).json({ "message": "Successfully logout" })
    } catch (err) {
        return res.status(400).json({ "message": "Something went wrong"})
    }
}

module.exports.modifyUser = async (req, res) => {
    

    try {
        const errors = validationMessages(validationResult(req).mapped());
        if (isErrorFounds(errors)) return res.status(400).json(errors);
        const { u: userId } = req.query;
        const { role, employeeCode, userName } = req.body;
        const updateData = {};
        //role validation
        
        if (role && typeof role === "string" && ['superadmin', 'admin', 'user'].includes(role)) {
            updateData.role = role
        }
        else {
            return res.status(400).json({ "message": "Need Valid role" })
        }
        // regex.test(employeeCode.trim()
        /*
        if (employeeCode && typeof employeeCode === 'string' && employeeCode.trim().length >= 3) {
            updateData.employeeCode = employeeCode.trim();
        }
        else {
            return res.status(400).json({ "message": "Enter valid employee code" })
        }
        */
        //username  validation
        /*
        if (userName && typeof userName === 'string' && userName.length > 3) {
            updateData.userName = userName;
        }
        else {
            return res.status(400).json({ "message": "Valid username required" })
        }
        */
        if (userId && req.user.role === "superadmin") {
            // const {role, userId} = req.body;
            if (req.user._id === userId) return res.status(400).json({ "message": "You cannot change your information" });
            const user = await isUserAvialable(userId);
            if (!user) return res.status(400).json({ "message": "User Not found" });
            const anotheruser = await User.findOne({ $or: [{ userName: updateData.userName }, { employeeCode: updateData.employeeCode }], _id: { $nin: [userId] } });
            if (anotheruser) return res.status(400).json({ "message": "username or emp code already exist" })

            const result = await modifyUser({ ...updateData, userId });
            
            return res.status(200).json({ "message": "Successfully modified" })
        }
        if (userId && req.user.role === "user" && req.user._id === userId) {
            await User.findOneAndUpdate({ _id: userId }, { $set: { employeeCode } })
            return res.status(200).json({ "message": "Successfully modified" })
        }
        return res.status(200).json({ "message": "Not Updated" })

    } catch (err) {
        console.log(err);
        return res.status(500).json({ "message": "Server Error" })
    }
}
//get all users
module.exports.getAll = async (req, res) => {
    try {
        let users = await getAllUsers();
        if (users.length) return res.status(200).json({ "data": users });
        // console.log(users);
        return res.status(200).json({ "data": users });
    }
    catch (err) {
        return res.status(400).json({ "message": "Something went wrong" })
    }
}




/**************************************** helper function *****************************/

/**
 * aws congito token verifier function
 * @param {string} token 
 */
async function tokenSingnatureValidation (token){
    try{

        if(!token) throw new Error("Token required or invalid token");
        //calling aws token verifier
        const signatureValue = await getSignatureValue();
        const accessSignature = signatureValue.keys[1];
        const idTokenSingnature = signatureValue.keys[0];
        const pem = jwkToPem(idTokenSingnature);
        const result = jwt.verify(token, pem, {algorithms: [idTokenSingnature?.alg]})
        return result;
    }catch(err){
        throw new Error(err.message)
    }

}

const getSignatureValue = async () => {
    const signatureURL = `https://cognito-idp.${process.env.COGNITOREGION.trim()}.amazonaws.com/${process.env.COGNITOUSERPOLLID.trim()}/.well-known/jwks.json`;
    const jsonKey = await fetch(signatureURL, {method: "GET"});
    if(jsonKey.status !== 200){
         return undefined
    }

    const result = await jsonKey.json();
    return result;
} 
