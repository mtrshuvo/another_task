const AWS = require("aws-sdk");
const utf8 = require("utf8");
const path = require("path");
const { validationResult } = require("express-validator");
const FileModel = require("../models/fileModel");
const S3 = new AWS.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: process.env.AWS_S3_REGION
})
// helper function
const {
    isErrorFounds,
    validationMessages,
  } = require("../helpers/errorMsgHelper");
const BUCKETNAME = process.env.AWS_ROOT_BUCKET;
// const BUCKETNAME = "devguitestbucket";

const KEY = process.env.AWS_ROOT_BUCKET_KEY

module.exports.inputJsonUpload = async (file, key) => {
    let sanitizingPath = path.normalize(key).replace(/^(\.\.(\/|\\|$))+/, '')
    const keysplit = sanitizingPath.split("/");
    let fileExtNameChanged = keysplit[keysplit.length-1].match(/(.*)(?:\.([^.]+$))/)[1]+"_in.json"
    const keyName = path.join(keysplit[0],keysplit[1], keysplit[2], fileExtNameChanged)
    
    const params = {
        Bucket: BUCKETNAME,
        Key: decodeURI(keyName),
        Body: JSON.stringify(file),
    }
    const uplodUrl = await S3.upload(params).promise();
    return uplodUrl;

}

module.exports.fileReadFromS3 = async (fileInfo) => {
    const params = {
        Bucket: BUCKETNAME,
        Key: `${decodeURI(fileInfo.fileKey)}`,
    }
    // console.log("params", params);
    const res = await S3.getObject(params).promise();
    return res;

}

module.exports.extractedJsonReadFromS3 = async (fileInfo) => {
    // console.log(fileInfo);
    try {
        let sanitizingPath = path.normalize(fileInfo.fileKey).replace(/^(\.\.(\/|\\|$))+/, '')

        let splittingKey = sanitizingPath.split("/");
        let outputJsonName = `${fileInfo.fileName.match(/(.*)(?:\.([^.]+$))/)[1].trim()}_out.json`
        let newKeyName = path.join(splittingKey[0], splittingKey[1], splittingKey[2], outputJsonName);
        // console.log(concat);
        // console.log(newKeyName);
        const params = {
            Bucket: BUCKETNAME,
            Key: `${decodeURI(newKeyName)}`,
            
        }
        // console.log("age");
        const jsonFile = await S3.getObject(params).promise();
        return jsonFile;
    }
    catch (err) {
        return undefined;
    }
    // return jsonFile.Body.length ? jsonFile : undefined;
}

module.exports.updateJsonInS3 = async (fileInfo, data) => {
    // console.log("FileInfo",fileInfo);
    try {
        let sanitizingPath = path.normalize(fileInfo.fileKey).replace(/^(\.\.(\/|\\|$))+/, '')

        let splittingKey = sanitizingPath.split("/");
        // console.log("Splitting Key", splittingKey);
        let outputJsonName = `${fileInfo.fileName.match(/(.*)(?:\.([^.]+$))/)[1].trim()}_out.json`
        let newKeyName = path.join(splittingKey[0], splittingKey[1], splittingKey[2], outputJsonName);
        const params = {
            Bucket: BUCKETNAME,
            Key: `${decodeURI(newKeyName)}`,
            Body: JSON.stringify(data)
        }
        const updatedUrl = await S3.upload(params).promise();
        return updatedUrl
    } catch (err) {
        console.log(err);
        return undefined
    }

}

module.exports.isOutputJsonExist = async(key) => {
    try{
        let sanitizingPath = path.normalize(key).replace(/^(\.\.(\/|\\|$))+/, '')

        const keysplit = sanitizingPath.split("/");
        const fileExtNameChanged = keysplit[keysplit.length-1].match(/(.*)(?:\.([^.]+$))/)[1]+"_out.json"
        const keyName = path.join(keysplit[0],keysplit[1], keysplit[2], fileExtNameChanged)        
        const params = {
            Bucket: BUCKETNAME,
            Key: `${decodeURI(keyName)}`,
        }
    
        const res = await S3.getObject(params).promise();
        return res.Body? true: false;
    }catch(err){
        console.log(err);
    }
    
}

module.exports.deleteJson = async(key)=> {
    let sanitizingPath = path.normalize(key).replace(/^(\.\.(\/|\\|$))+/, '');
    sanitizingPath = sanitizingPath.replace(/%2e/ig, '.').replace(/%2f|%5c/ig, '/')
    const keysplit = sanitizingPath.split("/");
    const fileExtNameChanged = keysplit[keysplit.length-1].match(/(.*)(?:\.([^.]+$))/)[1]+"_out.json"
    const keyName = path.join(keysplit[0],keysplit[1], keysplit[2], fileExtNameChanged)
    const params = {
        Bucket: BUCKETNAME,
        Key: `${decodeURI(keyName)}`,
    }

    S3.deleteObject(params, (err, data)=> {
        if(!err){
            return true;
        }
        return false;
    });
    
}
module.exports.deleteInputJson = async(key) => {
    let sanitizingPath = path.normalize(key).replace(/^(\.\.(\/|\\|$))+/, '')
    sanitizingPath = sanitizingPath.replace(/%2e/ig, '.').replace(/%2f|%5c/ig, '/')
    const keysplit = sanitizingPath.split("/");
    const fileExtNameChanged = keysplit[keysplit.length-1].match(/(.*)(?:\.([^.]+$))/)[1]+"_in.json"
    const keyName = path.join(keysplit[0],keysplit[1], keysplit[2], fileExtNameChanged);
    const params = {
        Bucket: BUCKETNAME,
        Key: `${decodeURI(keyName)}`,
    }

    S3.deleteObject(params, (err, data)=> {
        if(!err){
            return true;
        }
        return false;
    });
}

//presigned url generator -> post method
module.exports.getPresignedUrl = async(req, res) => {
    try{
        const errors = validationMessages(validationResult(req).mapped());
        if (isErrorFounds(errors)) return res.status(400).json(errors);
        let key = encodeURI(req.body.key)

        const response =  S3.createPresignedPost({
            Bucket: BUCKETNAME,
            Fields: {
                key: decodeURI(key)
            },
            Expires: parseInt(process.env.AWS_PRESIGNEDURL_DURATION) * 60
        })

        if(!response.url) return res.status(400).json({"message": "Something went wrong"});

        return res.status(200).json(response);
    }  catch(err){
        console.log(err);
        return res.status(400).json({"message": "Something went wrong"})
    }
}

module.exports.rpaFilePressignedUrl = async(responseUrl) => {
    // console.log("response url", responseUrl);
    const params = {
        Bucket: BUCKETNAME,
        Key: responseUrl?.key,
        Expires: 120
    }
        const data = await S3.getSignedUrlPromise("getObject", params);
        if(!data) return "no url"
        return data 
}


/********************** helper **********************/

