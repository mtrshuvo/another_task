const path = require("path");
const fs = require("fs");
const { mkdir, createWriteStream, readFile, stat } = require("fs/promises")
const { validationResult } = require("express-validator");
const multer = require("multer");
const utf8 = require('utf8')
const moment = require("moment");


const FileModel = require("../models/fileModel");
const { v4: uuid } = require("uuid");
const { validationMessages, isErrorFounds } = require("../helpers/errorMsgHelper");
const FusenModel = require("../models/fusenModel");
const { totalFileDoc, getFileandNextPrevFileId } = require("../services/fileService");
const { inProcessToComplete } = require("./deepicrController");
const { createHashUserName } = require("../helpers/commonHelper");
const { fileReadFromS3 } = require("./S3Connector");
const mongoose = require("mongoose");
// const { logger } = require("../helpers/logger");





//file upload controller
module.exports.fileuploadwithmulter = async (req, res) => {
    try {
        // console.log(req.files);
        if(process.env.NODE_ENV === "development"){
            return res.status(201).json({
                "message": {
                    successfull: "Successfull"
    
                }
            });
        }else{
            // aws upload response db
            const fileInfo = req.body.fileInfo;
            // console.log("Data Base File Info",fileInfo);req.user.userName
            const random = `${new Date().getTime().toString()}${createHashUserName(req.user.userName)}${fileInfo.arraySize}`;
           const f = await new FileModel({
                fileName: fileInfo?.fileName,
                fileSize: fileInfo?.fileSize,
                fileKey: decodeURI(fileInfo?.key),
                uploadSerial: random,
                uploadedBy: req.user._id

            }).save();
        
            if(f._id){
                return res.status(200).json({ "message": "Upload success" })
            }
        }
    } catch (err) {
        console.log("error", err);
        return res.status(400).json({ "message": "Something went wrong" })
    }
}

//getsingle file controller for ocr start page
module.exports.getSingleFile = async (req, res) => {
    try {
        const errors = validationMessages(validationResult(req).mapped());
        if (isErrorFounds(errors)) return res.status(400).json(errors);
        const fileId = req.query.fid? req.query.fid: "nofileId";
        const uploadedBy = req.body.uploadedBy;
        const rpaCheck = req.body.rpaCheck;
        const startDate = req.body.startDate;
        const endDate = req.body.endDate;
        let fusenInfo;

        if(!uploadedBy.length) return res.status(400).json({"message": "uploaded by empty"});
        if(new Date(new Date(startDate).setHours(0,0, 0, 0))> new Date(new Date(endDate)).setHours(23, 59, 59, 999)) return res.status(400).json({"message": "Date range not valid"})
        
        const response = await getFileandNextPrevFileId(fileId, req.user.role, req.user._id, uploadedBy, rpaCheck, { startDate, endDate });
        
        if(fileId !== "nofileId"){
            fusenInfo = await FusenModel.findOne({fileId: fileId});
        }
        return res.status(200).json({
            "data": response?.fileInformation?.fileInfo || response.fileInformation,
            "notStartedFile": response?.totalFiles || response?.totalNotstartedFile,
            "prevCount": response?.currentIn || response?.prevCount,
            "size": response?.fileInformation?.size || response?.fileSize,
            "fuseninfo": fusenInfo ? fusenInfo : "Fusen info not created",
            "next": response?.nextFileId,
            "prev": response?.prevFileId,
            "base64": response?.fileInformation?.fileBase64 || response.fileBase64,
        })
    } catch (err) {
        console.log(err);
        if(err.statusCode === 400) return res.status(400).json({"message": "File not found"})
        
        if(err.code === "ENOENT") return res.status(400).json({"message": "file not in the system"})
        return res.status(400).json({ "message": "Something went wrong" })
    }
}


//file filter for su and general user
module.exports.fileFilter = async (req, res) => {
    try{
        const filter = req.body.filter;
        const startDate = filter?.startDate ? new Date(filter.startDate) : new Date();
        startDate.setHours(0,0,0,0);
        await inProcessToComplete(startDate);

    }catch(err){
        
    }
    try {
        const errors = validationMessages(validationResult(req).mapped());
        if (isErrorFounds(errors)) return res.status(400).json(errors);
        //testing purpose
        // await inProcessToComplete(session);
        
        const page = req.query.page ? parseInt(req.query.page) : 1; //page no
        const limit = req.query.limit ? parseInt(req.query.limit) : 10; //data per page
        const role = req.user.role;
        // console.log("query: ", req.query);
        const filter = req.body.filter;
        let startDate = filter?.startDate ? new Date(filter.startDate) : new Date();
        let endDate = filter?.endDate ? new Date(filter.endDate) : new Date();
        //time zone;

        
       startDate = new Date(startDate).setHours(0, 0,0,0);
       endDate =  new Date(endDate).setHours(23, 59,59,999);
        // console.log("start date end Date", new Date(startDate).toISOString(), new Date(endDate).toISOString());
        if (startDate > endDate) return res.status(400).json({ "message": "invalid date range" });
        // console.log("filter body: ", filter);
        const args = {
            isDeleted: false,
            createdAt: {
                $gte: new Date(startDate).toISOString(),
                $lte: new Date(endDate).toISOString(),
            }
            
        }
        for (let key in filter) {
            if (key === "uploadedBy" && filter?.uploadedBy?.length > 0) {
                args['uploadedBy'] = {
                    $in: filter['uploadedBy']
                }
            }
            if (key === "rpaCheck") {
                if (filter['rpaCheck'] === true) {
                    args['resultCheck'] = "done"
                } else {
                    args['resultCheck'] = {
                        $in: ["raw", "checked", "temp"]
                    }
                }
            }
            
        }
        // console.log("arguments: ",args);
        if (role === 'superadmin') {           
            let totalCount = await FileModel.find(args).count();
            const filesInformation = await FileModel.find(args)
            .populate('uploadedBy', 'userName', 'UserTest')
            .lean()
            .sort({ createdAt: -1, fileName: -1 })
            .limit(limit)
            .skip((page - 1) * limit)
            .select({ updatedAt: 0, __v: 0, fileLink: 0, fileKey: 0 });
            
            
            if (!filesInformation.length) return res.status(400).json({ "message": "data not found" })
            return res.status(200).json({ "total": totalCount, "data": filesInformation })
        }
        else {
            // console.log("in user case");
            const totalCount = await FileModel.find({
                _isDeleted: false,
                uploadedBy: req.user._id,
                ...args
                
            }).count();
            
            // console.log(totalCount);
            const filesInformation = await FileModel.find({
                _isDeleted: false,
                uploadedBy: req.user._id,
                ...args
                
            })
                .lean()
                .sort({ createdAt: "desc" })
                .limit(limit)
                .skip((page - 1) * 10)
                .select({ updatedAt: 0, __v: 0 , fileLink: 0,});
            if (!filesInformation.length) return res.status(400).json({ "message": "data not found" });
            return res.status(200).json({ "total": totalCount, "data": filesInformation })
        }

    } catch (err) {      
        console.log(err);  
        return res.status(400).json({ "message": "Something went wrong" })
    }

}


//file delete controller
module.exports.deleteFile = async( req, res) => {
    try{
        const errors = validationMessages(validationResult(req).mapped());
        if (isErrorFounds(errors)) return res.status(400).json(errors);
        const {fid} = req.body;
        // console.log(fid);
        // if(!uploadedBy && !uploadedBy.length) return res.status(400).json({"message": "uploaded by id required"})
        if(!fid) return res.status(400).json({"message": "Fileid required"});
        const file = await FileModel.findOne({isDeleted: false, _id: fid}).lean();
        if(!file) return res.status(400).json({"message": "file not found"});
        if(req.user.role === "superadmin" || req.user._id === file.uploadedBy.toString()){
            // console.log("success");
            //
            await FileModel.updateMany({_id: {$in : fid} }, {$set: {
                isDeleted: true,
            }})
            return res.status(200).json({"message": "Deleted Successfully"});
        }
        return res.status(400).json({"message": "You cannot delete other users file"})
        
    }catch(err){
        // console.log(err);
        return res.status(400).json({'message': "Something went wrong"})
    }
}


//image api for result page
module.exports.getSingleImage = async(req, res)=> {
    try{
    const errors = validationMessages(validationResult(req).mapped());
    if(isErrorFounds(errors)) return res.status(400).json(errors)
    const fid = req.query.fid;
    // console.log(fid);
    const file = await FileModel.findOne({_id: fid});
    // console.log(file);
    if(!file) return res.status(400).json({"message": "File not found"});
    if(process.env.NODE_ENV === 'development'){
        //local env code
        const baseDir = process.env.FILEPATH;
        const fileDir = path.join(baseDir, "filedir",file.uploadSerial, file.fileName);
        const isFileExist = fs.existsSync(fileDir);
        if(!isFileExist) return res.status(400).message({"message": "file not found"});
        const size = await stat(fileDir)
        
        const base64 = await readFile(fileDir, 'base64');
        return res.status(200).json({"fileSize": size.size, "fileId": file._id, "data": base64 });
    }else{
        //aws production code
        const fileInfo = await fileReadFromS3(file);
        const bufferData = Buffer.from(fileInfo?.Body);
        const base64 = bufferData.toString("base64")
        return res.status(200).json({"fileSize": file.fileSize, "fileId": file._id, "data": base64,
        fileName:file.fileName, fileKey: file.fileKey });
    }

    }catch(err){
        console.log(err);
        // logger.error(err)
        return res.status(500).json({"message": "something went wrong"})
    }
}


