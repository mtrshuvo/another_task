const fetch = require("node-fetch")
const axios = require("axios");
const utf8 = require("utf8");
const { parsingNerData } = require("../helpers/commonHelper");
const NerModel = require("../models/nerItemModel");

const BIZXAPIKEY = process.env.BIZXAPIKEY
const BIZAPIURL = process.env.BIZAPIURL
const BIZAPIURL1 = "http://172.16.15.37:5000";

module.exports.getCategoryNames = async(req, res)=> {
    try {
        let page_size = 10000;
        let { page_no} = req.query;
        const result = await axios.get(`${BIZAPIURL}/category/get-category-names?page_size=${parseInt(page_size)}&page_no=${parseInt(page_no) || 0}`, {
            headers: {
                "x-api-key": BIZXAPIKEY
            }
        });
        
        return res.status(200).json(result?.data);
    } catch (err) {
        return res.status(400).json(err)
    }
}

module.exports.getProtocolNumbers = async(req, res)=> {
    // console.log("Entered in protopcol");
    try {
        let page_size = 10000;
        let { page_no} = req.query;

        const result = await axios.get(`${BIZAPIURL}/protocol-no/get-protocol-numbers?page_size=${parseInt(page_size)}&page_no=${parseInt(page_no )|| 0}`, {
            headers: {
                "x-api-key": BIZXAPIKEY
            }
        });
        if(result.status === 200){
            return res.status(200).json(result?.data);
        }
        return res.status(200).json(result?.data);
    } catch (err) {
        console.log(err);
        return res.status(400).json({"message": 'Fetching error'})
    }
}

module.exports.getSellerNames = async(req, res)=> {
    try {
        let { query} = req.query;
        // console.log(query);
        const result = await fetch(`${process.env.M_AWS_LAMBDA_SELLERHOSPITAL_URL}/suggest_seller_name`, {
        method: "POST" ,   
        headers: {
                "x-api-key": process.env.SELLERANDHOSPITALAPIKEY
            },
        body: JSON.stringify({"query":query})
        });
        // console.log("result: ", result);
        // if(result.status === 200){
            const data = await result.json();
            // console.log('suggest seller name',data);
            return res.status(200).json(data);
        // }
    } catch (err) {
        // console.log(err);
        return res.status(400).json({"message": 'Fetching error'})
    }
}

module.exports.getHospitalNames = async(req, res)=> {
    try {
        // console.log("Req query",req.query);
        // let page_size = 10000;
        let { query} = req.query;
        // console.log(query);
        const result = await fetch(`${process.env.M_AWS_LAMBDA_SELLERHOSPITAL_URL}/suggest_hospital_name`, {
        method: "POST" ,   
        headers: {
                "x-api-key": process.env.SELLERANDHOSPITALAPIKEY
            },
        body: JSON.stringify({"query":query})
        });
        const data = await result.json();
        return res.status(200).json(data);
            
    
    } catch (err) {
        // console.log(err);
        return res.status(400).json({"message": 'Fetching error'})
    }
}


module.exports.getNerInfoFromBizAPi = async(req, res)=> {
        try{
            const reqNerData = req.body.nerData;
            const flag = req.body.fieldName;
            // console.log("req body",reqNerData);
            //seller obj
            let multipleSellerInfo = {};


            //hospital obj
            //protocol obj
            const nerData = await NerModel.findOne({fileId: reqNerData?.fileId}).lean().select({__v: 0, createdAt: 0, updatedAt: 0});
            const {_id, ...restNerData} = nerData;
            const responseNerData = {
                ...reqNerData
            }
    
    
            if(flag === "sellerName"){
                //seller name api

                const sellerName = encodeURI((reqNerData.sellerSelectedIndex[0] === -1 || reqNerData.sellerSelectedIndex[1] === -1 ) ? reqNerData?.sellerCorrectedValues[0] : reqNerData?.sellerName[reqNerData.sellerSelectedIndex[0]])
                // const accountNo = encodeURI(restNerData?.accountNo[2]); 
                
                // let decodeSellerName = decodeURI(sellerName)
                console.log(decodeURI(sellerName));
                /************************** detching seller code need account no and seller code ********************/
            // console.log("biz req url", `${BIZAPIURL}/seller/get-seller-info?seller_name=${decodeURI(sellerName)}&return_all_matches=${false}`);
    
                const result = await fetch(`${BIZAPIURL}/seller/get-seller-info?seller_name=${utf8.decode(sellerName)}&return_all_matches=true`, {
                    method: "GET",
                    headers: {
                        "x-api-key": BIZXAPIKEY
                    }
                });
                // console.log("result",accountInfoRes.data.formatted_text);
                responseNerData.sellerName = [(reqNerData.sellerSelectedIndex[0] === -1 || reqNerData.sellerSelectedIndex[1] === -1 ) ? reqNerData?.sellerCorrectedValues[0] : reqNerData?.sellerName[reqNerData.sellerSelectedIndex[0]]]; 
                // responseNerData.accountNo = reqNerData.accountNo;
                if(result.status === 200){
                    let response = await result.json();
                    let resSellerCode = response.map((c,i)=> c.seller_code);
                    // console.log(resSellerCode);
                    responseNerData.sellerCode = [resSellerCode];
                    responseNerData.sellerSelectedIndex = [0,0]
                    responseNerData.accountNo = response[0].detail_account_info.account_number || "";
                    responseNerData.accountInfo = response[0].formatted_account_info || "";
                    responseNerData.multipleSellerInfo = {...sellerInfoObj(response, decodeURI(sellerName))};
                }else{
                    responseNerData.sellerCode = [[]];
                    responseNerData.accountInfo = "";
                    responseNerData.accountNo = "";
                    
                }
            }
            if(flag === "hospitalName"){
                // console.log("in hospital name");
    
                //hospital code api
                const hospitalName = encodeURI((reqNerData.hospitalSelectedIndex[0] === -1 || reqNerData.hospitalSelectedIndex[1] === -1 )?  reqNerData?.hospitalCorrectedValues[0]: reqNerData?.hospitalName[reqNerData?.hospitalSelectedIndex[0]]);
                const sellerCode = encodeURI(reqNerData?.sellerCode);
    
                responseNerData.hospitalName = [(reqNerData.hospitalSelectedIndex[0] === -1 || reqNerData.hospitalSelectedIndex[1] === -1 )?  reqNerData?.hospitalCorrectedValues[0]: reqNerData?.hospitalName[reqNerData?.hospitalSelectedIndex[0]]];
                // responseNerData.sellerCode = reqNerData.sellerCode;
                // console.log(utf8.decode(hospitalName));
                // console.log("hospital code req",`${BIZAPIURL}/hospital/get-hospital-info?hospital_name=${utf8.decode(hospitalName)}`);
                const result = await fetch(`${BIZAPIURL}/hospital/get-hospital-code?hospital_name=${utf8.decode(hospitalName)}&return_all_matches=true`, {
                    method: "GET",
                    headers: {
                        "x-api-key": BIZXAPIKEY
                    }
                });
                // console.log(result);
                if(result.status === 200){
                    // console.log("hospital code",result.data);
                    let response = await result.json();
                    // console.log("hospital response", response);
                    responseNerData.hospitalCode = [response?.hospital_code] || [""];
                    responseNerData.hospitalSelectedIndex = [0,0]

    
                }else{
                    console.log("nothing");
                }
    
            }
            if(flag === "protocolNo"){
                // console.log("in protocol no", reqNerData?.protocolCorrectedValues[0]) ;
    
                responseNerData.protocolNo = [(reqNerData.protocolSelectedIndex[0] === -1 || reqNerData.protocolSelectedIndex[1] === -1 )? reqNerData?.protocolCorrectedValues[0]: reqNerData?.protocolNo[reqNerData?.protocolSelectedIndex[0]]];
                // protocol name api
                // console.log(`${BIZAPIURL}/protocol-no/get-project-name?protocol_no=${(reqNerData.protocolSelectedIndex[0] === -1 || reqNerData.protocolSelectedIndex[1] === -1 )? reqNerData?.protocolCorrectedValues[0]: reqNerData?.protocolName[reqNerData?.protocolSelectedIndex[0]]}`);
                const result = await axios.get(`${BIZAPIURL}/protocol-no/get-project-name?protocol_no=${(reqNerData.protocolSelectedIndex[0] === -1 || reqNerData.protocolSelectedIndex[1] === -1 )? reqNerData?.protocolCorrectedValues[0]: reqNerData?.protocolNo[reqNerData?.protocolSelectedIndex[0]]}`, {
                    headers: {
                        "x-api-key": BIZXAPIKEY
                    }
                });
                if(result.status === 200){
                    // console.log("protocol no", result.data);
                    responseNerData.protocolName = [result?.data?.project_name ]|| [[""]];
                    responseNerData.protocolCorrectedValues = [responseNerData.protocolNo[0],result?.data?.project_name[0] || "" ];
                    responseNerData.protocolSelectedIndex = [0,0]
                }else{
                    responseNerData.protocolName =  [[""]];
                }
    
            }
            // console.log("rest ner data",responseNerData);
            let nerResponse =  parsingNerData(responseNerData, false);
            // console.log("response data", responseNerData);
            return res.status(200).json({"nerData": responseNerData,  });
                
        }catch(err){
            console.log(err);
            return res.status(400).json({"message": "Something went wrong"})
        }
}

module.exports.getCostCenters = async(req, res)=> {
    try {
        let page_size = 10000;
        let { page_no} = req.query;

        const result = await axios.get(`${BIZAPIURL}/cost-center/get-cost-centers?page_size=${parseInt(page_size)}&page_no=${parseInt(page_no)|| 0}`, {
            headers: {
                "x-api-key": BIZXAPIKEY
            }
        });
        return res.status(200).json(result?.data);
    } catch (err) {
        // console.log(err);
        return res.status(400).json({"message": 'Fetching error'})
    }
}

module.exports.getFirstApprover = async(req, res) => {
    try {
        let { costCenterCode} = req.query;
        let encodeCostCenter = encodeURI(costCenterCode)

        const result = await fetch(`${BIZAPIURL}/cost-center/get-first-approver?cost_center_code=${utf8.decode(encodeCostCenter).split(' ').join('').split('-')[0]}`, {
            headers: {
                "x-api-key": BIZXAPIKEY
            }
        });
        if( result.status === 200){
            const data = await result.json();
            return res.status(200).json(data);
        }else{
            return res.status(400).json({"message": "approver data not found"});

        }
    } catch (err) {
        console.log(err);
        return res.status(400).json({"message": 'Fetching error'})
    }
}

//************************************************ local env *********************************************/
module.exports.getCostCentersLocal = async(req, res)=> {
    // console.log("Entered");
    try {
        let page_size = 10000;
        let { page_no} = req.query;

        const result = await fetch(`${BIZAPIURL}/cost-center/get-cost-centers?page_size=${parseInt(page_size)}&page_no=${parseInt(page_no)|| 0}`, {
            headers: {
                "x-api-key": BIZXAPIKEY
            }
        });
        console.log("reslt",  result);
        if(result.status === 200){
            let response = await result.json();
            // console.log("response", response);
            return res.status(200).json(response?.body)
            // return res.status(200).json(result?.data);
        }
        return res.status(400).json({"message": 'Fetching error'})

    } catch (err) {
        // console.log(err);
        return res.status(400).json({"message": 'Fetching error'})
    }
    
}

/**************** helper function  ***************/

/*******
 * formatting response for single seller name multiple seller code , account info & account no
 * @constructor
 * @param {Array} sellerInfos - seller informations
 * @param {String} sellerName - single seller Name 
 */
function sellerInfoObj (sellerInfos=[], sellerName){
    let obj= {};
    let mainObj = {};
    sellerInfos.map((s, i)=> {
      obj[s.seller_code] = {
        formatted_account_info: s.formatted_account_info,
        account_number: s.detail_account_info.account_number
      }
    });
    mainObj = {[sellerName]: obj}
    // console.log("main obj", mainObj);
    return mainObj
  }

// module.exports.getSellerInfo = async (req, res) => {
//     try{
//         const sellerName = encodeURI(req.query.sellerName);
//         const returnAllMatches = req.query.returnAllMatches || false;
//         const result = await fetch(`${BIZAPIURL}/seller/get-seller-info?seller_name=${utf8.decode(sellerName)}&return_all_matches=${returnAllMatches}`);
//         if(result.status === 200){
//             let response = await result.json();
//             return res.status(200).json(response.body)
//         }else{
//             return res.status(400).json({"message": "Fetching error"});
//         }

//     }catch(err){
//         console.log(err);
//         return res.status(400).send({"message": "Something went wrong"})
//     }
// }

// module.exports.getHospitalInfo = async (req, res) => {
//     try{

//         const hospitalName = encodeURI(req.query.hospitalName);
//         const result = await fetch(`${BIZAPIURL}/hospital/get-hospital-info?hospital_name=${utf8.decode(hospitalName)}`);
//         if(result.status === 200){
//             let response = await result.json();
//             return res.status(200).json(response.body)
//         }else{
//             return res.status(400).json({"message": "Fetching error"});
//         }

//     }catch(err){
//         console.log(err);
//         return res.status(400).send({"message": "Something went wrong"})
//     }
// }

