const fs = require('fs')
const excel = require('excel4node');
const FusenModel = require("../models/fusenModel");
const CategoryTableModel = require("../models/categoryTableModel");
const NerModel = require("../models/nerItemModel");
const FileModel = require("../models/fileModel");
// const { ADDRGETNETWORKPARAMS } = require('dns');
const Encoding = require('encoding-japanese');


// RPA items column number
col_condition = 1
col_request_number = 2
col_request_date = 3
col_pdf = 4
col_seq_by_invoice = 5
col_attachment_file_path = 6
col_requestor_cd = 7
col_requestor_text = 8
col_cost_center_cd = 9
col_cost_center_text = 10
col_action_plan_cd = 11
col_action_plan_text = 12
col_project_code_cd = 13
col_project_code_text = 14
col_usage_purpose = 15
col_seller_cd = 16
col_seller_text = 17
col_seller_jp_text = 18
col_invoice_amount_with_tax = 19
col_current_unit = 20
col_payment_date = 21
col_invoice_no = 22
col_hospital_cd = 23
col_hospital_text = 24
col_service_provision_date = 25
col_approver_cd = 26
col_approver_text = 27
col_notes = 28
col_details_no = 29
col_category_number_cd = 30
col_category_number_text = 31
col_category_amount_with_tax = 32
col_tax_classification = 33
col_category_text = 34
col_category_action_plan_cd = 35
col_category_action_plan_text = 36
col_category_project_code_cd = 37
col_category_project_code_text = 38
col_category_hospital_cd = 39
col_category_hospital_text = 40
col_category_jp_no = 41
col_transfer_type = 42
col_amount_jpy = 43
col_transfer_cost_center_cd = 44
col_transfer_cost_center_text = 45
col_employee_cd = 46
col_employee_text = 47
col_category_project_code_2_cd = 48
col_category_project_code_2_text = 49


function set_header_to_excel(worksheet, text_style) {
    worksheet.cell(1, 1).string("Payment Request Data V1.2");
    worksheet.cell(3, 1, 3, 4, true).string("Item where the processing result from RPA is entered");
    worksheet.cell(3, 5).string("Invoice SEQ (for RPA processing)");
    worksheet.cell(3, 6).string("For operation");
    worksheet.cell(3, 7, 3, 27, true).string("");
    worksheet.cell(3, 28).string("For RPA")
    worksheet.cell(3, 29, 3, 49, true).string("");

    worksheet.cell(5, col_condition, 6, col_condition, true).string("Condition\n(error contents)");
    worksheet.cell(5, col_request_number, 6, col_request_number, true).string("Request Number");
    worksheet.cell(5, col_request_date, 6, col_request_date, true).string("Request Date");
    worksheet.cell(5, col_pdf, 6, col_pdf, true).string("PDF");
    worksheet.cell(5, col_seq_by_invoice, 6, col_seq_by_invoice, true).string("SEQ by invoice");
    worksheet.cell(5, col_attachment_file_path, 6, col_attachment_file_path, true).string("Attachment file path");

    worksheet.cell(5, col_requestor_cd, 5, col_requestor_text, true).string("Requestor");
    worksheet.cell(6, col_requestor_cd).string("CD(社員番号)");
    worksheet.cell(6, col_requestor_text).string("Text").style(text_style);

    worksheet.cell(5, col_cost_center_cd, 5, col_cost_center_text, true).string("Cost Center");
    worksheet.cell(6, col_cost_center_cd).string("CD");
    worksheet.cell(6, col_cost_center_text).string("Text");

    worksheet.cell(5, col_action_plan_cd, 5, col_action_plan_text, true).string("Action plan\nEquipment budget");
    worksheet.cell(6, col_action_plan_cd).string("CD");
    worksheet.cell(6, col_action_plan_text).string("Text");

    worksheet.cell(5, col_project_code_cd, 5, col_project_code_text, true).string("Project Code");
    worksheet.cell(6, col_project_code_cd).string("CD");
    worksheet.cell(6, col_project_code_text).string("Text");

    worksheet.cell(5, col_usage_purpose, 6, col_usage_purpose, true).string("Usage Purpose");

    worksheet.cell(5, col_seller_cd, 5, col_seller_jp_text, true).string("Seller");
    worksheet.cell(6, col_seller_cd).string("CD");
    worksheet.cell(6, col_seller_text).string("Text");
    worksheet.cell(6, col_seller_jp_text).string("手入力Text");

    worksheet.cell(5, col_invoice_amount_with_tax, 6, col_invoice_amount_with_tax, true).string("Invoice Amount\n(With Tax)");
    worksheet.cell(5, col_current_unit, 6, col_current_unit, true).string("Currency Unit");
    worksheet.cell(5, col_payment_date, 6, col_payment_date, true).string("Payment Date");
    worksheet.cell(5, col_invoice_no, 6, col_invoice_no, true).string("Invoice No");

    worksheet.cell(5, col_hospital_cd, 5, col_hospital_text, true).string("Hospital");
    worksheet.cell(6, col_hospital_cd).string("CD");
    worksheet.cell(6, col_hospital_text).string("Text");

    worksheet.cell(5, col_service_provision_date, 6, col_service_provision_date, true).string("Service provision date");

    worksheet.cell(5, col_approver_cd, 5, col_approver_text, true).string("Approver");
    worksheet.cell(6, col_approver_cd).string("CD(Employee No)");
    worksheet.cell(6, col_approver_text).string("Text");

    worksheet.cell(5, col_notes, 6, col_notes, true).string("Notes");
    worksheet.cell(5, col_details_no, 6, col_details_no, true).string("Details No");

    worksheet.cell(5, col_category_number_cd, 5, col_category_number_text).string("Category Number");
    worksheet.cell(6, col_category_number_cd).string("CD");
    worksheet.cell(6, col_category_number_text).string("Text");

    worksheet.cell(5, col_category_amount_with_tax, 6, col_category_amount_with_tax, true).string("Amount \n(With Tax)");
    worksheet.cell(5, col_tax_classification, 6, col_tax_classification, true).string("Tax Classification");
    worksheet.cell(5, col_category_text, 6, col_category_text, true).string("Text");

    worksheet.cell(5, col_category_action_plan_cd, 5, col_category_action_plan_text, true).string("Action plan\n/ Equipment budget");
    worksheet.cell(6, col_category_action_plan_cd).string("CD");
    worksheet.cell(6, col_category_action_plan_text).string("Text");

    worksheet.cell(5, col_category_project_code_cd, 5, col_category_project_code_text, true).string("Project Code");
    worksheet.cell(6, col_category_project_code_cd).string("CD");
    worksheet.cell(6, col_category_project_code_text).string("Text");

    worksheet.cell(5, col_category_hospital_cd, 5, col_category_hospital_text, true).string("Hospital");
    worksheet.cell(6, col_category_hospital_cd).string("CD");
    worksheet.cell(6, col_category_hospital_text).string("Text");

    worksheet.cell(5, col_category_jp_no, 6, col_category_jp_no, true).string("稟議No.");
    worksheet.cell(5, col_transfer_type, 6, col_transfer_type, true).string("Transfer Type");
    worksheet.cell(5, col_amount_jpy, 6, col_amount_jpy, true).string("Amount\n(JPY)");

    worksheet.cell(5, col_transfer_cost_center_cd, 5, col_transfer_cost_center_text, true).string("Transfer\nCost Center/Group Company");
    worksheet.cell(6, col_transfer_cost_center_cd).string("CD");
    worksheet.cell(6, col_transfer_cost_center_text).string("Text");

    worksheet.cell(5, col_employee_cd, 5, col_employee_text, true).string("Employee");
    worksheet.cell(6, col_employee_cd).string("CD");
    worksheet.cell(6, col_employee_text).string("Text");

    worksheet.cell(5, col_category_project_code_2_cd, 5, col_category_project_code_2_text, true).string("Project Code");
    worksheet.cell(6, col_category_project_code_2_cd).string("CD");
    worksheet.cell(6, col_category_project_code_2_text).string("Text");

}


const len = (str) => {
    let size = Buffer.from(str).length;
    return size;
}



function calculate_concanated_string(str, byte_length) {
    concanated_str = ""
    current_length = 0

    for (let i = 1; i <= str.length; i++) {
        current_array = str.slice(0, i);
        const unicodeArray = Encoding.stringToCode(current_array); // Convert string to code array
        const sjisArray = Encoding.convert(unicodeArray, {
            to: 'SJIS',
            from: 'UNICODE'
        });
        current_length = len(sjisArray);
        if (current_length >= byte_length) {
            if (current_length == byte_length) { concanated_str = current_array; }
            else { concanated_str = str.slice(0, i - 1); }
            break;
        }
        else {
            concanated_str = str;
        }
    }
    return concanated_str;
}

const VALUE_INDEX = 2
var START_ROW_INDEX = 7

async function format_date(date) {
    const split_date = date.split("/");
    const month = split_date[0];
    const day = split_date[1];
    const year = '20' + split_date[2];
    return year + '/' + month + '/' + day;
}

async function write_ner_information(worksheet, ner_data, fusen_info) {
    try {
        // worksheet.cell(START_ROW_INDEX, col_cost_center_cd).string(fusen_info['costCenter']);
        worksheet.cell(START_ROW_INDEX, col_project_code_cd).string(ner_data['protocolNo'][VALUE_INDEX]);


        var pop = ner_data['purposeOfPayment'][VALUE_INDEX];
        pop = calculate_concanated_string(pop, 40);
        var notes = fusen_info['description'];
        notes = calculate_concanated_string(notes, 400);
        if (notes) {
            worksheet.cell(START_ROW_INDEX, col_notes).string(notes);
        }
        // worksheet.cell(START_ROW_INDEX, col_approver_cd)
        worksheet.cell(START_ROW_INDEX, col_usage_purpose).string();
        worksheet.cell(START_ROW_INDEX, col_seller_cd).string(ner_data['sellerCode'][VALUE_INDEX]);
        worksheet.cell(START_ROW_INDEX, col_invoice_amount_with_tax).string(['totalAmount'][VALUE_INDEX]);
        worksheet.cell(START_ROW_INDEX, col_current_unit).string(['currencyCode'][VALUE_INDEX]);

        var payment_date = ner_data['paymentDeadline'][VALUE_INDEX];
        payment_date = await format_date(payment_date);
        worksheet.cell(START_ROW_INDEX, col_payment_date).string(payment_date);

        // date formatting

        var issue_date = ner_data['issueDate'][VALUE_INDEX];
        issue_date = await format_date(issue_date);


        if (ner_data['invoiceNumber'][VALUE_INDEX]) {
            worksheet.cell(START_ROW_INDEX, col_invoice_no).string(ner_data['invoiceNumber'][VALUE_INDEX]);
        }
        else { worksheet.cell(START_ROW_INDEX, col_invoice_no).string(ner_data['issue_date'][VALUE_INDEX]); }


        if (ner_data['hospitalCode'][VALUE_INDEX]) {
            worksheet.cell(START_ROW_INDEX, col_hospital_cd).string(ner_data['hospitalCode'][VALUE_INDEX]);
        }
        if (ner_data['hospitalName'][VALUE_INDEX]) {
            worksheet.cell(START_ROW_INDEX, col_hospital_text).string(ner_data['hospitalName'][VALUE_INDEX]);
        }

        console.log(payment_date);
    }
    catch (e) {
        console.log(e.message);
    }

}

async function write_category_information(worksheet, current_file_number, category_row, current_row_number) {
    worksheet.cell(START_ROW_INDEX, col_seq_by_invoice).string(current_file_number.toString());
    worksheet.cell(START_ROW_INDEX, col_details_no).string(current_row_number.toString());
    worksheet.cell(START_ROW_INDEX, col_category_number_cd).string(category_row['categoryNumber'][VALUE_INDEX]);
    worksheet.cell(START_ROW_INDEX, col_category_amount_with_tax).string((category_row['amount'][VALUE_INDEX]).toString());
    worksheet.cell(START_ROW_INDEX, col_tax_classification).string(category_row['taxRate'][VALUE_INDEX].toString());
    var text = category_row['text'][VALUE_INDEX];
    text = calculate_concanated_string(text, 50);
    worksheet.cell(START_ROW_INDEX, col_category_text).string(text);
    START_ROW_INDEX++;

}


async function get_values_from_database(worksheet, file_id, current_file_number) {
    try {
        const ner_data = await NerModel.findOne({ fileId: file_id }).lean();
        const category_table = await CategoryTableModel.find({ fileId: file_id }).lean();
        const fusen_info = await FusenModel.findOne({ fileId: file_id }).lean();
        rows_in_category = category_table.length;
        current_row_number = 1;
        for (let i = 0; i < rows_in_category; i++) {
            if (i == 0) {
                await write_ner_information(worksheet, ner_data, fusen_info);
            }
            if (!category_table[i]['exclude'][VALUE_INDEX]) {
                await write_category_information(worksheet, current_file_number, category_table[i], current_row_number);
                current_row_number++;
            }

        }
    }
    catch (e) {
        console.log(e.message)
    }
}

module.exports.createRPAfile = async (file_ids) => {
    //get the number of files sent for RPA creation
    number_of_file_for_RPA = file_ids.length;

    // set file name
    const current_date = new Date();
    const date = ('0' + current_date.getFullYear()).slice(-4) + ('0' + (current_date.getMonth() + 1)).slice(-2) + ('0' + current_date.getDate()).slice(-2);
    const time = ('0' + current_date.getHours()).slice(-2) + ('0' + current_date.getMinutes()).slice(-2) + ('0' + current_date.getSeconds()).slice(-2);
    const file_name = "支払申請RPAデータ_" + date + time + ".xlsx"
    // const file_name = Encoding.urlEncode(`支払申請RPAデータ_${date}${time}.xlsx`)
    // create new RPA sheet
    const workbook = new excel.Workbook();
    const worksheet = workbook.addWorksheet('Sheet 1');

    // define excel designs
    var text_style = workbook.createStyle({
        fill: {
            type: 'pattern',
            patternType: 'solid',
            bgColor: '#FFFFFF',
            fgColor: '#A9D18E',

        }
    });

    // write the headers to excel file
    set_header_to_excel(worksheet, text_style);

    for (let i = 0; i < number_of_file_for_RPA; i++) {
        await get_values_from_database(worksheet, file_ids[i], i + 1);
    }


    // write excel file
    workbook.write(file_name)
    return file_name;

}