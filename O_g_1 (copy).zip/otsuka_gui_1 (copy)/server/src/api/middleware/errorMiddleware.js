const { logger } = require("../helpers/logger");

module.exports = (error, req, res, next) =>{
    logger.log("error", `${error}`)
    if (req.headersSent){
        return res.status(500).json({"message": "Server Error "});
    }
    
    return res.status(500).json({"message": "Server Error"})
    
}

module.exports.defaultErrorMessageHandler = (err) => {
    const error = new Error(`request url `)
    return res.status
}