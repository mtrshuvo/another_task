const { body, query, check, checkSchema } = require("express-validator");
const { default: mongoose } = require("mongoose");
const { capitalizeFirstLetter } = require("../../helpers/commonHelper");
const errorMessageList = require("../../helpers/errorMessageList");

const BlacklistChar = "";

//first time login input filed validation middleware
module.exports.loginValidation = [
    body("email")
        .notEmpty()
        .withMessage("Required")
        .isEmail()
        .custom((val) => {
            const domainList = ["otsuka", "nextsolutionlab"];
            const domain = val.split("@")[1].split(".")[0];
            if (!domainList.includes(domain)) throw new Error("invalid email");
            return true;
        })
        .withMessage("Please insert valid email address"),
    body("password")
        .notEmpty()
        .withMessage("Required")
        .isLength({ min: 5, max: 15 })
        .withMessage("Password length must be 5 to 15 chararacter"),
];

module.exports.ssoLoginValidation = [
    body("credentials")
        .isObject({ strict: true })
        .withMessage(errorMessageList.invalidReq),
    body("credentials.displayName")
        .notEmpty()
        .isString()
        .withMessage(errorMessageList.invalidReq),
    body("credentials.email")
        .notEmpty()
        .isEmail()
        .custom((val) => {
            const domainList = ["otsuka", "nextsolutionlab"];
            const domain = val.split("@")[1].split(".")[0];
            if (!domainList.includes(domain)) throw new Error("invalid email");
            return true;
        })
        .withMessage("Invalid Email")
        .normalizeEmail(),
    body("credentials.employeeCode")
        .notEmpty()
        .isString()
        .withMessage(errorMessageList.invalidReq)
        .blacklist(BlacklistChar),
    // body("credentials.info").notEmpty().isJWT().withMessage("invalid token")
];

// file upload validation middleware
module.exports.fileuploadingValidation = [
    body("filesInformation")
        .notEmpty()
        .withMessage("File information not be empty")
        .isArray()
        .withMessage("File information must be in list"),
    body("uploadedBy").notEmpty().withMessage("Upload by info is required"),
];

//cost center code
module.exports.costcenterupdateValidation = [
    body("costCenter")
        .notEmpty()
        .withMessage("Cost center code is required")
        .isLength({ min: 4, max: 10 })
        .withMessage("Cost code should be 4 to 10 character long")
        .isNumeric()
        .withMessage("Cost code must be in digit"),
    body("approver").notEmpty().withMessage("Approver name is required"),
    body("employeeCode").notEmpty().withMessage("Employee code is required"),
];

//modify user
module.exports.userModifyValidation = [
    query("u")
        .notEmpty()
        .withMessage("user id required in queary param")
        .isMongoId()
        .withMessage("invalid request"),
];

module.exports.getSingleImgValidation = query("fid")
    .notEmpty()
    .isMongoId()
    .withMessage("File id required");



/********************************************* file filter validation middleware *********************************************************/

module.exports.filFiltermiddleware = [
    body("filter.uploadedBy").custom((val) => {
        if(val.length){
            val.forEach((v, i)=> {
                if(!mongoose.isObjectIdOrHexString(v)) throw new Error(errorMessageList.invalidReq)
            })
        }
        return true;
    }),
    body("filter.startDate").custom(val=> {
        if(!is_date(val)) throw new Error(errorMessageList.invalidReq)
        return true;
    }),
    body("filter.endDate").custom((val, {req})=> {
        if(!is_date(val)) throw new Error(errorMessageList.invalidReq)
        return true;
    }),
    body("filter.rpaCheck").custom((val, {req})=> {
        let typecheck = val;
        if( typeof typecheck !== "boolean") throw new Error(errorMessageList.invalidReq)
        return true
    })
]


module.exports.getSingleFileMiddleware = [
    query("fid").custom((val, {req})=>{
        if(val === "nofileId" || mongoose.isObjectIdOrHexString(val)){
            return true
        }else{
            return false;
        }
    }),
    body("uploadedBy").custom((val) => {
        if(val.length){
            val.forEach((v, i)=> {
                if(!mongoose.isObjectIdOrHexString(v)) throw new Error("error")
            })
        }
        return true;
    }),
    body("startDate").custom(val=> {
        if(!is_date(val)) throw new Error(errorMessageList.invalidReq)
        return true;
    }),
    body("endDate").custom((val, {req})=> {
        if(!is_date(val)) throw new Error(errorMessageList.invalidReq)
        return true;
    }),
    body("rpaCheck").custom((val, {req})=> {
        let typecheck = val;
        if( typeof typecheck !== "boolean") throw new Error(errorMessageList.invalidReq)
        return true
    })
]

module.exports.presignedURLvalidation = body('key').isString().notEmpty().custom(val=> {
    let key = val.split("/");
    if(key[0] === process.env.AWS_ROOT_BUCKET_KEY && key.length === 4){
        return true
    }else{
        return false
    }
})
/****************************************  deepicr request validation middleware *********************** */

module.exports.fidValidation = query("fid")
    .isMongoId()
    .withMessage("invalid id");

module.exports.ocrInfoValidation = [
    body("ocrInfo")
        .isObject({ strict: true })
        .notEmpty()
        .withMessage("invalid request")
        .custom((val, { req }) => {
            let correctKeys = [
                "protocolNo",
                "actualWorkingDate",
                "paymentRequestDate",
                "firstApprover",
                "costCenter",
                "firstApproverCode",
                "description",
            ];
            let keys = Object.keys(val);
            isObjectKeysInCorrectedkeys(correctKeys, keys);
            return true;
        })
        .withMessage(errorMessageList.invalidReq),
    body("ocrInfo.costCenter")
        .notEmpty()
        .isString()
        .withMessage(errorMessageList.invalidReq),
    body("ocrInfo.firstApprover")
        .notEmpty()
        .isString()
        .withMessage(errorMessageList.invalidReq),
    body("ocrInfo.firstApproverCode")
        .notEmpty()
        .isString()
        .withMessage(errorMessageList.invalidReq),
    body("ocrInfo.protocolNo")
        .isString()
        .withMessage(errorMessageList.invalidReq),
    body("ocrInfo.actualWorkingDate")
        .isString()
        .withMessage(errorMessageList.invalidReq),
    body("ocrInfo.paymentRequestDate")
        .isString()
        .withMessage(errorMessageList.invalidReq),
    body("ocrInfo.description")
        .isString()
        .withMessage(errorMessageList.invalidReq),
    body("ocrInfo.*").blacklist(BlacklistChar),
];

/**
 *
 * @param {Date, dateString} dateString
 */

function isDateValue(dateString) {
    // if (new Date(dateString) === "Invalid Date")
}

module.exports.firstApp = check("ocrInfo.firstApprover").blacklist("$");

/******************* json file validation *************************/

module.exports.jsonFileValidation = [
    body("jsonFile")
        .isObject({ strict: true })
        .custom((val) => {
            let correctKeys = [
                "input_bucket_name",
                "img_path",
                "img_file_name",
                "output_bucket_name",
                "output_path",
                "output_json_name",
                "target_type",
                "custom_pages",
                "pdf_pages",
                "pdf_rotations",
                "file_size",
                "selection_info",
            ];
            let keys = Object.keys(val);
            isObjectKeysInCorrectedkeys(correctKeys, keys);
            return true;
        })
        .withMessage(errorMessageList.invalidReq),
    body("jsonFile.input_bucket_name")
        .notEmpty()
        .isString()
        .custom((val) => {
            return val === process.env.AWS_ROOT_BUCKET;
        })
        .withMessage(errorMessageList.invalidReq)
        .blacklist(BlacklistChar)
        .withMessage(errorMessageList.invalidReq),
    body("jsonFile.img_path")
        .notEmpty()
        .isString()
        .custom((val) => {
            return val.split("/")[0] === process.env.AWS_ROOT_BUCKET_KEY;
        })
        .blacklist(BlacklistChar)
        .withMessage(errorMessageList.invalidReq),
    body("jsonFile.img_file_name")
        .notEmpty()
        .isString()
        .withMessage(errorMessageList.invalidReq)
        .blacklist(BlacklistChar),
    body("jsonFile.output_bucket_name")
        .notEmpty()
        .isString()
        .custom((val) => val === process.env.AWS_ROOT_BUCKET)
        .blacklist(BlacklistChar)
        .withMessage(errorMessageList.invalidReq),
    body("jsonFile.output_path")
        .notEmpty()
        .isString()
        .custom((val, { req }) => {
            return val === req.body.jsonFile.img_path;
        })
        .blacklist(BlacklistChar)
        .withMessage(errorMessageList.invalidReq),
    body("jsonFile.output_json_name")
        .notEmpty()
        .isString()
        .withMessage(errorMessageList.invalidReq)
        .blacklist(BlacklistChar),
    body("jsonFile.target_type")
        .notEmpty()
        .isString()
        .withMessage(errorMessageList.invalidReq)
        .blacklist(BlacklistChar),
    body("jsonFile.custom_pages")
        .isArray()
        .custom((val, { req }) => {
            isArrayContainsIntegar(val, "number");
            return true;
        })
        .withMessage(errorMessageList.invalidReq),
    body("jsonFile.pdf_pages")
        .notEmpty()
        .isInt()
        .withMessage(errorMessageList.invalidReq),
    body("jsonFile.pdf_rotations")
        .custom((val) => {
            if (Array.isArray(val)) {
                for (let v of val) {
                    if (typeof v !== "number")
                        throw new Error(errorMessageList.invalidReq);
                }
            } else {
                return false;
            }
            return true;
        })
        .withMessage(errorMessageList.invalidReq),
    body("jsonFile.file_size")
        .isString()
        .notEmpty()
        .withMessage(errorMessageList.invalidReq)
        .blacklist(BlacklistChar),
    // body("jsonFile.selection_info").isObject().withMessage(errorMessageList.invalidReq).blacklist(BlacklistChar),
];

/**
 *
 * @param {Array} arrayValues
 * @param {string} type
 */

function isArrayContainsIntegar(arrayValues, type) {
    arrayValues.forEach((v) => {
        if (typeof v !== type) throw new Error(errorMessageList.invalidReq);
        if (type === "number") {
            return Number.isInteger(v);
        }
    });
}

/**
 *
 * @param {Array} actualKeys
 * @param {Array} keys
 */
function isObjectKeysInCorrectedkeys(actualKeys, keys) {
    keys.forEach((k) => {
        if (!actualKeys.includes(k)) throw new Error(errorMessageList.invalidReq);
        else true;
    });
}

/*********************** delete file validation *******************************/
module.exports.deleteFilesValidation = body("fid")
    .isArray()
    .custom((val) => {
        val.map((v) => {
            if (typeof v !== "string" || v.indexOf("$") > -1) {
                return false;
            }
        });
        return true;
    })
    .withMessage(errorMessageList.invalidReq);

/************************************* file router validation *******************************/

/************************************* ner table data validation ****************************/
module.exports.mongodIdValidation = body("fid")
    .notEmpty()
    .custom((val) => {
        return mongoose.isObjectIdOrHexString(val);
    })
    .withMessage();
module.exports.nerDataValidation = [
    body("nerData.fileId")
        .isMongoId()
        .custom((val, { req }) => {
            return val === req.body.fid || val === req.query.fid;
        })
        .withMessage(errorMessageList.invalidReq),
    // body("nerData.accountNo")
    //     .isString()
    //     .withMessage(errorMessageList.invalidReq)
    //     .blacklist(BlacklistChar),
    // body("nerData.accountInfo")
    //     .isString()
    //     .withMessage(errorMessageList.invalidReq)
    //     .blacklist(BlacklistChar),
    body("nerData.currencyCode")
        .isString()
        .withMessage(errorMessageList.invalidReq)
        .blacklist(BlacklistChar),
    // body("nerData.hospitalName")
    //     .isString()
    //     .withMessage(errorMessageList.invalidReq)
    //     .blacklist(BlacklistChar),
    // body("nerData.hospitalCode")
    //     .isString()
    //     .withMessage(errorMessageList.invalidReq)
    //     .blacklist(BlacklistChar),
    body("nerData.invoiceNumber")
        .isString()
        .withMessage(errorMessageList.invalidReq)
        .blacklist(BlacklistChar),
    // body("nerData.issueDate")
    //     .isString()
    //     .custom((val) => {
    //         if (val) {
    //             let test = is_date(val);
    //             if (test !== true) throw new Error(errorMessageList.invalidReq);
    //         }
    //         return true;
    //     })
    //     .withMessage(errorMessageList.invalidReq),
    // body("nerData.paymentDeadline")
    //     .custom((val) => {
    //         if (val) {
    //             let test = is_date(val);
    //             if (test !== true) throw new Error(errorMessageList.invalidReq);
    //         }
    //         return true;
    //     })
    //     .withMessage(errorMessageList.invalidReq),
    // body("nerData.protocolName")
    //     .isString()
    //     .withMessage(errorMessageList.invalidReq)
    //     .blacklist(BlacklistChar),
    // body("nerData.protocolNo")
    //     .isString()
    //     .withMessage(errorMessageList.invalidReq),
    // body("nerData.sellerName")
    //     .isString()
    //     .withMessage(errorMessageList.invalidReq)
    //     .blacklist(BlacklistChar),
    // body("nerData.sellerCode")
    //     .isString()
    //     .withMessage(errorMessageList.invalidReq)
    //     .blacklist(BlacklistChar),
    body("nerData.totalAmount")
        .custom((val) => {
            return Number(val) !== "NaN";
        })
        .withMessage(errorMessageList.invalidReq),
        
    body("nerData.purposeOfPayment")
        .isString()
        .withMessage(errorMessageList.invalidReq)
        .blacklist(BlacklistChar),
];


/*************************************** item table data validation  && category table data**************************************/
module.exports.itemTableDataValidation = [

    // check().withMessage(errorMessageList.invalidReq),
    check('itemTableData.*.fileId')
        .isMongoId()
        .custom((val, { req }) => {
            return val === req.body.fid || val === req.query.fid;
        }),
    check('itemTableData.*.pageNumber').custom(val => {
        if (val) {
            return Number(val) === val ? true : false
        }
        return true
    }),
    check('itemTableData.*.itemName').custom((val)=> {
        if(val){
            return typeof val === 'string'
        }
        return true;
    }).blacklist(BlacklistChar),
    check('itemTableData.*.itemNameCord').custom(val => {
        if(val){

            val.forEach((vv, ii) => {
                if (vv) {
                    if (typeof vv !== 'number') throw new Error(errorMessageList.invalidReq)
                }
            })
        }

        return true
    }),
    check('itemTableData.*.amountWithOutTax').customSanitizer((val)=> {
        if(val){
            return parseFloat(val)
        }else{
            return 0;
        }
    }).custom((val)=> {
        return checkingNumberValue(val)
    }).withMessage(errorMessageList.invalidReq)
    .customSanitizer(val=> {
        return Number(val)
    }),
    check('itemTableData.*.amountWithOutTaxCord').custom(val => {
        if(val){
            val.forEach((vv, ii) => {
                if (vv) {
                    if (typeof vv !== 'number') throw new Error(errorMessageList.invalidReq)
                }
            })
        }

        return true
    }),
    check('itemTableData.*.consumptionTax').customSanitizer((val)=> {
        if(val){
            return parseFloat(val)
        }else{
            return 0;
        }
    }).custom((val)=> {
        return checkingNumberValue(val)
    }).withMessage(errorMessageList.invalidReq)
    .customSanitizer(val=> {
        return Number(val)
    }),
    check('itemTableData.*.taxRate').isString().withMessage(errorMessageList.invalidReq).blacklist(BlacklistChar),
    check('itemTableData.*.amountWithTax').custom(val=> {
        if(val){
            return checkingNumberValue(val)
        }
        return true
    }).withMessage(errorMessageList.invalidReq),
    check('itemTableData.*.categoryNumber').isString().withMessage(errorMessageList.invalidReq).blacklist(BlacklistChar),
    check('itemTableData.*.categoryName').isString().withMessage(errorMessageList.invalidReq).blacklist(BlacklistChar),
    check('itemTableData.*.subCategory').custom(val=> {
        if(val){
            return typeof val === "string"
        }
        return true
    }).withMessage(errorMessageList.invalidReq).blacklist(BlacklistChar),
    check('itemTableData.*.exclude').custom(val=> {
        if(typeof val !== 'boolean') throw new Error(errorMessageList.invalidReq)
            
        return true
    }).withMessage(errorMessageList.invalidReq),


]

module.exports.categoryTableDataValidation = [
    // check('categoryTableData.*.fileId').custom((val, {req})=>{

    //     if(mongoose.isObjectIdOrHexString(val) && val.toString() === req.query.fid.toString()){
    //         return true
    //     }
    //     return false
    // }).withMessage(errorMessageList.invalidReq),
    check('categoryTableData.*.taxRate').custom((val)=> {
        if(val){
            return typeof val === 'string'
        }
        return true;
    }).withMessage(errorMessageList.invalidReq).blacklist(BlacklistChar),
    check('categoryTableData.*.text').custom((val)=> {
        if(val){
            return typeof val === 'string'
        }
        return true;
    }),
    check('categoryTableData.*.amount').customSanitizer((val)=> {
        if(val){
            return parseFloat(val)
        }else{
            return 0;
        }
    }).custom((val)=> {
        return checkingNumberValue(val)
    }).withMessage(errorMessageList.invalidReq)
    .customSanitizer(val=> {
        return Number(val)
    }),
    check('categoryTableData.*.categoryNumber').custom((val)=> {
        if(val){
            return typeof val === 'string'
        }
        return true;
    }).withMessage(errorMessageList.invalidReq),
    check('categoryTableData.*.categoryName').custom((val)=> {
        if(val){
            return typeof val === 'string'
        }
        return true;
    }).withMessage(errorMessageList.invalidReq),
    check('categoryTableData.*.subCategory').custom(val => {
        if(val){
            return typeof val === 'string'
        }
        return true
    }).withMessage(errorMessageList.invalidReq),
    check('categoryTableData.*.exclude').custom(val=> {
        if(typeof val !== 'boolean') throw new Error(errorMessageList.invalidReq)
        return true
    }).withMessage(errorMessageList.invalidReq),

]
/******************************* rpa validation middleware ****************/
module.exports.rpaCreationValidation = body('fids').custom((val)=> {
    if(val.length){
        val.forEach(v=> {
            if(!mongoose.isObjectIdOrHexString(v)) throw new Error(errorMessageList.invalidReq)
        })
    }
    return true
})
/*****
 * @param {Number} val
 */

function checkingNumberValue(val) {
    if(!val) return true
    if (Number(val) !== 'NaN' && val === Number(val)) {
        return true
    } else {
        return false
    }
}
/********************** helper function ************************/

var is_date = function (input) {
    if (Object.prototype.toString.call(input) === "[object String]") {
        if (isNaN(new Date(input).getTime())) {
            return false;
        } else {
            return true;
        }
    }
    return false;
};

function checkingStringtypeIntvalue(val) {
    return Number(val) === val ? true : false;
}