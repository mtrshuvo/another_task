const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const {validationResult} = require("express-validator");
var jwkToPem = require('jwk-to-pem');

const User = require("../models/userModel");
const {validationMessages, isErrorFounds} = require("../helpers/errorMsgHelper");
const { checkUserSession } = require("../services/userService");
const errorMessageList = require("../helpers/errorMessageList");


module.exports.Authorize = async(req, res, next)=>{
    try {
        const ORIGIN = process.env.ORIGIN.split(",")
        if(!ORIGIN.includes(req.header("Origin"))) throw new Error (errorMessageList.invalidReq)
        let headerToken = req.header("Authorization").split(" ")[1].trim();
        const sid = req.header("sid").trim();
        const sessionToken = await checkUserSession(sid);
        if(headerToken !== sessionToken.jwt) return res.status(401).json({"message": "Authorizaiton failed"})
        const decode = await jwt.verify(headerToken, process.env.JWT_SECRET_KEY);
        req.user = decode;
        next();
    }
    catch(e){
        res.status(401).json({"message": "Authorization failed"});
    }
}


module.exports.isActive = async(req, res, next)=> {
    if(req.user.isActive){

    }else{
        return res.status(400).json({'message': 'Please contact with admin for activate your id'})
    }
}

module.exports.errorsFoundMiddleware = async(req, res, next)=> {
    const errors = validationMessages(validationResult(req).mapped());
    if(isErrorFounds(errors)) return res.status(400).json(errors);
    else next();
}

module.exports.hashedPassword = async(pass)=> {
    return await bcrypt.hash(pass, 10);
}
module.exports.isSuperAdmin = async(req, res, next)=> {
    let user = await User.findOne({_id: req.user._id}).lean();
    if(!user) return res.status(400).json({"message": "User Not found"});
    if(user.role === "superadmin"){
       next();
    }
    else{
      return res.status(403).json({"message": "Access Forbidden"})
   }
}

module.exports.isEmailAlreadyUsed = async(req, res, next)=> {
        const errors = validationMessages(validationResult(req).mapped());
        if (isErrorFounds(errors)) res.status(400).json(errors);
        const {email} = req.body
        const user = await User.findOne({email});
        if (user) return res.status(400).json({"message" : "Email already used"});
        else {
            next()
        }
            
    }

module.exports.passwordVerification = async(req, res, next)=> {
        const {email} = req.user;
        const {password} = req.body;
        const user = await User.findOne({email});
        const isPasswordCorrect = await bcrypt.compare( password, user.password);
        if(!isPasswordCorrect) return res.status(401).json({"message": "Invalid Password"});
        next();
    }

module.exports.cognitTokenVerify = async(req, res, next)=> {
        let accessToken = req.body.info;
        const pem = jwkToPem((jwk.keys[0])); 
        jwt.verify(accessToken, pem, {algorithms: [jwk.keys[1].alg]}, (err, deocdedToken)=>{
            if(err){
                return res.status(401).json("Authorization failed")
            }else{
                req.ssoUser = deocdedToken
                next()
            }
        })

}