import React from 'react';
import { generateMessageFromError } from '../resources/CommonMethods';
import deepICRLogging from './deepICRLogging';

const ErrorComponent = () => {
    const style = {
        main: {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
            height: "100%"
        },
        section: {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
        },
        span: {
            fontSize: "24px",
            fontWeight: 500,
            display: "block",
            borderBottom: "1px solid #EAEAEA",
            textAlign: "center",
            paddingBottom: "20px",
            width: "100px"
        },
        p: {
            fontSize: "14px",
            fontWeight: 400,
            margin: "20px 0 0 0"
        }
    }
    return (
        <main className={style.main}>
            <section className={style.section}>
                <span className={style.span}>404</span>
                <p className={style.p}>Component Not Rendering Correctly, Please try again</p>
            </section>
        </main>
    )
}

class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            hasError: false
        };
    }

    static getDerivedStateFromError(error) {
        return { hasError: true };
    }

    componentDidCatch(error, info) {
        let message = generateMessageFromError(error);
        deepICRLogging(message);
    }
    render() {
        const hasError = this.state.hasError;
        const { children } = this.props;
        return hasError ? <ErrorComponent /> : children;
    }
}
export default ErrorBoundary