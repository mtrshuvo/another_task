import {deepICRNow} from '../deepICRCommon';

// import resource files
import jsonDeepICRContext from '../resources/deepICRContext.json';

const deepICRLogging2 = (message) => {
  
  const url = jsonDeepICRContext.apiUrlBase + '/ops/logging';
  return new Promise((resolve, reject) => {
    const [, unixtime, microsec]  = deepICRNow();
    const headers = {'Authorization': global.accessToken, 'Content-type': 'application/json'};
    const body = {
      'type': 'request',
      'head': {
        'command': 'logging',
        'format_version': jsonDeepICRContext.apiFormatVersion,
        'service_id': jsonDeepICRContext.apiServiceId,
        'transaction_id': jsonDeepICRContext.apiServiceId + '_' + unixtime + "_" + microsec,
        'unix_time': unixtime,
        'micro_seconds': microsec,
        'time_zone': jsonDeepICRContext.apiTimeZone,
      },
      'body': {'message': message},
    };
    fetch(url, {method: 'POST', mode: 'cors', headers: headers, body: JSON.stringify(body),})
    .then(res => res.json()).then(json => resolve(json.body))
    .catch(err => reject(err));
  });
}
const deepICRLogging = (message) => {
	// console.log("Message",message);
  // return new Promise((resolve, reject) => {
  //   fetch('http://172.16.16.130:5000?log=' + JSON.stringify(message), {
  //     method: 'get',
  //     mode: 'cors',
  //   }).then(res => res.json()).then(json => resolve(json.body))
  //   .catch(err => reject(err));
  // });
}

export default deepICRLogging;