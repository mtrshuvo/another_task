
export const reducer = (state,action) =>{

    switch (action.type) {
        case "SET_UPLOADED_FILE":
            state.uploadedFiles = action.payload.data
            // console.log("Context uploaded Filers", state.uploadedFiles);
            return {...state, uploadedFiles:state.uploadedFiles}

        case "UPDATE_UPLOADED_FILE":

            action.payload.data.forEach(selectedValue => {
                state.uploadedFiles = state.uploadedFiles.filter(file=> { return file.name !== selectedValue.name})
            });
            return {...state, uploadedFiles:state.uploadedFiles}
    
        default:
            return {...state}
    }

}
// 