import 'react-app-polyfill/ie9';
import 'react-app-polyfill/stable';
import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from "react-router-dom";
import './index.css';
import './css/style.css'
import App from './App';
import OverallContext from './Context/OverallContext';
import { Provider } from 'react-redux';
import { ToastContainer } from 'react-toastify';
import store from './store'

ReactDOM.render(<BrowserRouter>
<ToastContainer />
<Provider store={store}>
<App />
</Provider>

</BrowserRouter>, document.getElementById('root'));
