import seller from "../seller.json";

import React from 'react'

const load = () => {
const fileReader = new FileReader();

fileReader.readAsDataURL(seller);
fileReader.onload(e=> {
    console.log(e);
})
  return (
    <div>load</div>
  )
}

export default load