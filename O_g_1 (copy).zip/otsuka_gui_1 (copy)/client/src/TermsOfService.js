import React, {useContext} from 'react';
import {makeStyles} from '@material-ui/core';
import {withSnackbar} from 'notistack';
import Typography from '@material-ui/core/Typography';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import Link from '@material-ui/core/Link';

// import resource files
import DeepICRContext from './resources/DeepICRContext';

// Style Sheet
const useStyles = makeStyles(theme => ({
  styleLogin: {
    margin: theme.spacing(0, 0, 0, 0),
    display: 'flex',
    flexDirection: 'column',
  },
  styleDeloitteGreen: {
    color: theme.palette.deepICR.deloitteGreen,
  },
  styleLogo: {
    margin: theme.spacing(1, 0, 0, 4),
  },
  styleTitle: {
    margin: theme.spacing(6, 0, 0, 6),
  },
  styleTermsTitle: {
    margin: theme.spacing(2, 0, 0, 6),
  },
  styleTermsTextarea: {
    margin: theme.spacing(1, 0, 0, 6),
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.backgroundColor,
    width: '800px',
  },
  styleBack: {
    margin: theme.spacing(2, 0, 0, 6),
  },
  styleFooter: {
    margin: theme.spacing(8, 0, 0, 2),
  },
}));

// [React function component]
// Authentication Wrapper component
export const TermsOfService = (props) => {
  const styles = useStyles();
  const [deepICRCTX] = useContext(DeepICRContext);

  return (
    <div className={styles.styleLogin}>
      <header className={styles.styleLogo}>
        <img alt="Deloitte. Logo" src="/DEL_g_SEC_RGB.jpg" width="142" height="44" />
      </header>
      <div>
        <Typography className={styles.styleTitle} component="h1" variant="h4">
          Deep ICRi®
        </Typography>
        <Typography className={styles.styleTermsTitle} component="h1" variant="h4">
          利用規約
        </Typography>
        <TextareaAutosize
          className={styles.styleTermsTextarea}
          aria-label="terms of service"
          rowsMax={15}
          defaultValue={deepICRCTX.termsOfService.join("\n")}
        />
        <Typography className={styles.styleBack}>
          <Link color="inherit" href="/login">ログイン画面へ</Link>
        </Typography>
      </div>
      <footer className={styles.styleFooter}>
        <Typography>
          <Link color="inherit" href="https://deepicr.jp/deepicr_guide.docx">
	    利用ガイド
	  </Link>
	  &nbsp;&nbsp;{'|'}&nbsp;&nbsp;
	  {'利用規程'}
          &nbsp;&nbsp;{'|'}&nbsp;&nbsp;
          <Link color="inherit" href="https://www2.deloitte.com/jp/ja/footerlinks1/cookies/cookies-for-other-sites.html">
            クッキーに関する通知
          </Link>
          &nbsp;&nbsp;{'|'}&nbsp;&nbsp;
          <Link color="inherit" href="https://www2.deloitte.com/jp/ja/footerlinks1/privacy/privacy-for-other-sites.html">
            プライバシーポリシー
          </Link>
          <br />
          <br />
          {'© '}{new Date().getFullYear()}{'.'}&nbsp;{'詳細は'}&nbsp;
          <font className={styles.styleDeloitteGreen}>利用規程</font>
          &nbsp;{'をご覧ください。'}
          <br />
          {'Deloitte（デロイト）とは、デロイト トウシュ トーマツ リミテッド（“DTTL”）、そのグローバルネットワーク組織を構成するメンバーファームおよびそれらの関係法人のひとつまたは複数を指します。'}
          <br />
          {'DTTL（または“Deloitte Global”）ならびに各メンバーファームおよびそれらの関係法人はそれぞれ法的に独立した別個の組織体です。DTTLはクライアントへのサービス提供を行いません。'}
          <br />
          {'詳細は'}&nbsp;
          <Link color="inherit" href="https://www.deloitte.com/jp/about"><font className={styles.styleDeloitteGreen}>www.deloitte.com/jp/about</font></Link>
          &nbsp;{'をご覧ください。'}
        </Typography>
      </footer>
    </div>
  );
}

export default withSnackbar(TermsOfService);
