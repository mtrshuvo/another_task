import React, { useEffect, useContext } from 'react';
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { Route, Routes, Link ,useParams} from 'react-router-dom';
import { makeStyles } from '@material-ui/core';
import { SnackbarProvider } from 'notistack';
import Button from '@material-ui/core/Button';
import { Container } from 'react-simple-resizer';
import { ThemeProvider } from '@material-ui/core';
import 'react-toastify/dist/ReactToastify.css';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import "react-datepicker/dist/react-datepicker.css";
import "rsuite/dist/rsuite.min.css";

// import react components
import MenuBar from './Components/Shared/MenuBar/MenuBar';
import InputViewer from './Components/Grouptwo/InputViewer/InputViewer';
import OutputViewer from './Components/Grouptwo/OutputViewer/OutputViewer';
import Login from './Components/Login/Login';
// import resource files
import deepICRTheme from './resources/deepICRTheme';
import { DeepICRContextProvider } from './resources/DeepICRContext';
import jsonEn from './resources/English.json';
import jsonJa from './resources/Japanese.json';
import DeepICRContext from './resources/DeepICRContext';
import ErrorBoundary from './Logging/ErrorBoundary';
import deepICRLogging from './Logging/deepICRLogging';
import { generateMessageFromError } from './resources/CommonMethods';
import ProtectedRouter from './Components/Protected Router/ProtectedRouter';
import Logout from './Logout/Logout';
import Fileupload from './Components/Grouptwo/Fileupload';
import PdfProcessPage from './Components/Grouptwo/PdfProcessPage/PdfProcessPage';
import Checkstatus from './Components/CheckOCRStatus/Checkstatus';
import UserConfig from './Components/UserConfig/UserConfig';
import UserInfoTable from './Components/UserConfig/UserInfoTable';
import SecondNav from './Components/SecondNav/SecondNav';
import OAuth from './Components/Login/OAuth';

// Global Variable
global.inputViewerBounds = {};
global.inputViewerWidth = 100;
global.inputViewerHeight = 100;
global.documentIdFileNotFound = false;
global.accessToken = "";
global.refreshToken = "";
global.rotation = [];

// Reading resource files of language
i18n.use(initReactI18next).init({
  resources: {
    en: { translation: jsonEn },
    ja: { translation: jsonJa },
  },
  lng: 'ja',         // default language
  fallbackLng: 'ja', // else languagw
  interpolation: { escapeValue: false },
});

// Style Sheet
const useStyles = makeStyles(theme => ({
  styleRoot: {
    backgroundColor: "#EAEAF0",
    color: deepICRTheme.palette.deepICR.backgroundColor,
    boxSizing: "border-box",
    height: "100%",
    display: "flex",
    flexDirection: "column",
    flex: 1,
  },
  styleContainer: {
    boxSizing: "border-box",
    height: "100%",
    flex: 1,
    padding: theme.spacing(1, 1, 1, 1),
    justifyContent: "space-between",
  },
  styleBar: {
    margin: deepICRTheme.spacing(0, 0, 0, 0),
    padding: 4,
  },
}));

// Add dismiss action to snackbars
const notistackRef = React.createRef();
const onClickDismiss = key => () => {
  notistackRef.current.closeSnackbar(key);
}

// Main view
const MainView = (props) => {
  const styles = useStyles();
  const [deepICRCTX] = useContext(DeepICRContext);

  // Set Context Request parameter with Document id
  let documentId = "";
  return (
    <div className={styles.styleRoot}>
      <header>
        {/* <MenuBar /> */}
        {/* <Userinfo /> */}
        {/* {documentId === "" ? <ToolBar /> : <ToolBar documentId={documentId} />} */}
        <SecondNav />
      </header>
      <Container className={styles.styleContainer}>
        {documentId === "" ? <InputViewer /> : <InputViewer documentId={documentId} />}
        <div className={styles.styleBar} />
        <OutputViewer />
      </Container>
      {/* <ThumbnailView /> */}
    </div>
  );
}

// const SharedView = () => {
//   user = localStorage.getItem("userData")
//   console.log(user);
//   return (
//     <>
//       {user && user ? <MenuBar /> :null}
//       {user && user ? <Userinfo /> : null}
//     </>
//   )

// }


// [React function component]
// Main component
const App = () => {
  const styles = useStyles();
  useEffect(() => {
    window.onerror = function (msg, src, lineno, colno, error) {
      var string = msg.toLowerCase();
      var substring = "script error";
      if (string.indexOf(substring) > -1) {
        // console.log('Script Error: See Browser Console for Detail');
      } else {
        let message = generateMessageFromError(error);
        deepICRLogging(message);
      }
      return false;
    }
    //  user = localStorage.getItem("userData")
  }, [])
  return (
    <>
      {/* <MenuBar /> */}
      <ThemeProvider theme={deepICRTheme}>
        <SnackbarProvider
          maxSnack={deepICRTheme.palette.deepICR.maxSnack}
          dense
          preventDuplicate
          ref={notistackRef}
          action={(key) => (
            <Button
              onClick={onClickDismiss(key)}
              style={{ color: deepICRTheme.palette.deepICR.dismissColor }}>
              ✕
            </Button>
          )}>

          {/* <MenuBar/> */}
          {/* <SecondNav/> */}
          {/* <Userinfo/> */}
          {/* <SharedView/> */}

          <DeepICRContextProvider>
            <Routes>
              <Route path="/resultpage" element={<ProtectedRouter><OutputViewer /></ProtectedRouter>} />
              <Route path="/fileupload" element={<ProtectedRouter><Fileupload /></ProtectedRouter>} />
              {/* <Route path="/" element={<ProtectedRouter><Userinfo/></ProtectedRouter>} /> */}
              <Route path='/login' element={<Login />} />
              <Route path='/logout' element={<Logout />} />

              {/* first time login input page */}
              {/* <Route path='/employeeinfo' element={<UserConfig />} /> */}
              <Route path='/users' element={<ProtectedRouter><UserInfoTable /></ProtectedRouter>} />
              <Route path='/pdfprocess' element={<ProtectedRouter><PdfProcessPage/></ProtectedRouter> }/> 
              <Route path='/deepICR' element={<ProtectedRouter><Checkstatus/></ProtectedRouter>} />
              <Route path='/' element={<OAuth />}/>
            </Routes>
            {/* <Link from="/" to="/deepICR" /> */}
          {/* <Link from="/" to="/deepICR" /> */}
          </DeepICRContextProvider>
        </SnackbarProvider>
      </ThemeProvider>
      {/* <ToastContainer /> */}
    </>
  );
}

export default App;
