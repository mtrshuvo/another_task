import { combineReducers } from 'redux'
import reducer from './fileReducers'
import filterReducer from './filterReducer'
import resultReducer from './resultReducer'

const rootReducer = combineReducers({
    reducer,
    filterReducer,
    resultReducer
})

export default rootReducer
