let initialState = {
    resultTotalFiles: 0,
    resultCurrentFile: 0,
    loadingImage: false,
    prop: {
        memo: false,
        text: false,
        pop: false,
        invoice: false
    },
    trackSingleValue:{
        sellerField:false,
        hospitalField:false,
        protocolField:false
    }
}
const resultReducer = (state = initialState, action) => {

    switch (action.type) {
        case "RESULT_MULTIPLE_FIELD":
            if (action.payload.field==='seller') {
                state.trackSingleValue = { ...state.trackSingleValue, sellerField: action.payload.data }
            }
            if (action.payload.field==='hospital') {
                state.trackSingleValue = { ...state.trackSingleValue, hospitalField: action.payload.data }
            }
            if (action.payload.field==='protocol') {
                state.trackSingleValue = { ...state.trackSingleValue, protocolField: action.payload.data }
            }
            return { ...state, trackSingleValue: state.trackSingleValue }
        case "RESULT_INVOICE_CHANGE":
            state.prop = { ...state.prop, invoice: action.payload.data }
            return { ...state, prop: state.prop }
        case "RESULT_TEXT_CHANGE":
            state.prop = { ...state.prop, text: action.payload.data }
            return { ...state, prop: state.prop }
        case "RESULT_MEMO_CHANGE":
            state.prop = { ...state.prop, memo: action.payload.data }
            return { ...state, prop: state.prop }
        case "RESULT_POP_CHANGE":
            state.prop = { ...state.prop, pop: action.payload.data }
            return { ...state, prop: state.prop }
        case "RESULT_TOTAL_FILE":
            state.resultTotalFiles = action.payload.data.totalCompletedFile
            state.resultCurrentFile = action.payload.data.currentFileNo
            // console.log("from result redux",state.resultTotalFiles,state.resultCurrentFile);
            return { ...state, resultTotalFiles: state.resultTotalFiles, resultCurrentFile: state.resultCurrentFile }
        case "SET_LOADING_IMAGE":
            state.loadingImage = action.payload.data
            // console.log(state.loadingImage);
            return { ...state, loadingImage: state.loadingImage }

        default:
            return { ...state }
    }

}
export default resultReducer