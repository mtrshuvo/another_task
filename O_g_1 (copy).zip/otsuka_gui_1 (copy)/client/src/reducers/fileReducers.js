import Cookies from 'js-cookie'
import jwt_decode from "jwt-decode";

let initialState = {
    uploadedFiles: [],
    jwt: "",
    isSuperAdmin: false,
    isAuthenticate: false,
    saveResponse: "",
    sessionId: "",
    userName: "",
    role: "",
    employeeCode: "",
    email:"",
    _id: "",
    pageData: [],
    page: "",
    currPageNumber: 1,
    totalFile: 0,
    currentNumber: 0,
    isFileUpload: false,
    isFileUploadPage:false,
    isChangesHappened:false

}


const reducer = (state = initialState, action) => {

    switch (action.type) {
        case "SET_UPLOADED_FILE":
            state.uploadedFiles = action.payload.data
            // console.log("Context uploaded Filers", state.uploadedFiles);
            return { ...state, uploadedFiles: state.uploadedFiles }

        case "UPDATE_UPLOADED_FILE":
            action.payload.data.forEach(selectedValue => {
                state.pageData = state.pageData.filter(file => { return file._id !== selectedValue })
            });
            return { ...state, pageData: state.pageData }

        case "SAVE_RESPONSE":
            state.saveResponse = action.payload.data
            return { ...state, saveResponse: state.saveResponse }

        case "GET_COOKIE":
            state.jwt = Cookies.get("jwtooken")
            if (state.jwt) {
                // console.log("Reducer jwt",state.jwt);
                const userInfo = jwt_decode(state.jwt)
                if (userInfo.role === 'user') {
                    state.isSuperAdmin = false
                } else {
                    state.isSuperAdmin = true
                }
                state.isAuthenticate = true
                state.email = userInfo.email
                state._id = userInfo._id
                state.sessionId = userInfo.sessionId
                state.userName = userInfo.userName
                state.employeeCode = userInfo.employeeCode
                state.role = userInfo.role
            }

            return { ...state, jwt: state.jwt, isSuperAdmin: state.isSuperAdmin, isAuthenticate: state.isAuthenticate, _id: state._id, sessionId: state.sessionId, userName: state.userName, employeeCode: state.employeeCode, role: state.role }

        case "RESET_COOKIE":
            // ,domain:'otsuka.deepicr.jp'
            Cookies.remove('jwtooken', { path: '/'})
            localStorage.removeItem('language')
            return {
                ...state, uploadedFiles: [],
                jwt: "",
                isSuperAdmin: false,
                isAuthenticate: false,
                saveResponse: "",
                sessionId: "",
                userName: "",
                role: "",
                employeeCode: "",
                _id: "",
                pageData: [],
                page: "",
                currPageNumber: 1
            }

        case "SAVE_PAGE_DATA":
            state.pageData = action.payload.data
            state.totalFile = action.payload
            // console.log("From Context", state.pageData);
            return { ...state, pageData: state.pageData }
        case "FILE_UPLOAD_ACTIVE":
            state.isFileUpload = action.payload.data
            return { ...state, isFileUpload: state.isFileUpload }
        case "FILE_UPLOAD_ACTIVE_PAGE":
            state.isFileUploadPage = action.payload.data
            return { ...state, isFileUploadPage: state.isFileUploadPage }
        case "TOTAL_FILE":
            if (action.payload.data.notStartedFile) {
                state.totalFile = action.payload.data.notStartedFile
                state.currentNumber = action.payload.data.prevCount
            } else {
                state.page = Math.ceil(action.payload.data / 10)
            }

            // console.log("tOTALfILE",state.totalFile);
            return { ...state, page: state.page, totalFile: state.totalFile, currentNumber: state.currentNumber }
        case "CURRENT_NUMBER":
            state.currPageNumber = action.payload.data + 1
            // console.log("Load Data",action.payload.data);
            // console.log("Current Page Number redux reducer", state.currPageNumber);
            return { ...state, currPageNumber: state.currPageNumber }
        case "SET_BOOLEAN_CHANGES":
            state.isChangesHappened = action.payload.data
            return {...state,isChangesHappened:state.isChangesHappened}

        default:
            return { ...state }
    }

}
export default reducer