let initialState = {
    startDate: new Date(),
    endDate: new Date(),
    selectedId: [],
    selected:[],
    rpaCheck: false,
    selectBool: false
}

const filterReducer = (state = initialState, action) => {

    switch (action.type) {
        case "SAVE_START_DATE":
            state.startDate = action.payload.data
            return { ...state, startDate: state.startDate }
        case "SAVE_END_DATE":
            state.endDate = action.payload.data
            return { ...state, endDate: state.endDate }
        case "SAVE_SELECTED_ID":
            state.selectedId = action.payload.data
            // console.log("context selected id", state.selectedId);
            return { ...state, selectedId: state.selectedId }
        case "SET_SELECTED":
            state.selected = action.payload.data
            return { ...state, selected: state.selected }
        case "RPA_CHECKED":
            state.rpaCheck = action.payload.data
            return { ...state, rpaCheck: state.rpaCheck }
        case "SET_SELECT_BOOL":
            state.selectBool = action.payload.data
            return { ...state, selectBool: state.selectBool }
        case "RESET_DATE":
            state.startDate = new Date()
            state.endDate = new Date()
            state.selectedId= []
            state.rpaCheck = false
            state.selectBool = false
            return {...state,startDate:state.startDate,endDate:state.endDate,selectedId:state.selectedId,rpaCheck:state.rpaCheck,selectBool:state.selectBool}
        default:
            return { ...state }
    }

}

export default filterReducer