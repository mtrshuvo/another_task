import React, {createContext, useState} from 'react';

// import resource files
import jsonDeepICRContext from './deepICRContext.json';

// const DeepICRContext =()=>{
//   const [DeepICRContext] = useState(jsonDeepICRContext)
// }

// const [DeepICRContext] = useState(jsonDeepICRContext)

// // Context for Deep ICR
const DeepICRContext = createContext([
  jsonDeepICRContext,
  () => {}
]);

// Context Provider for Deep ICR Context
export const DeepICRContextProvider = (props) => {
  const [value, setValue] = useState(jsonDeepICRContext);

  return (
    <DeepICRContext.Provider value={[value, setValue]}>
      {props.children}
    </DeepICRContext.Provider>
  );
}

export default DeepICRContext;
