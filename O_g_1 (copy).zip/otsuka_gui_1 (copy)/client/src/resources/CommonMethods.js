import { useRef, useEffect } from 'react';

export function useEventListener(eventName, handler, element = window) {
    const savedHandler = useRef();
    useEffect(() => {
        savedHandler.current = handler;
    }, [handler]);

    useEffect(() => {
        const isSupported = element && element.addEventListener;
        if (!isSupported) return;
        const eventListener = event => savedHandler.current(event);
        element.addEventListener(eventName, eventListener);
        return () => {
            element.removeEventListener(eventName, eventListener);
        };
    }, [eventName, element]);
}

export const getUserAuth = ()=>{
    const id = localStorage.getItem('userData')
    if(id){
        const jsonConv = JSON.parse(id)
        return jsonConv
    }
}

// export function useDidUpdate(callback, deps) {
//     const hasMount = useRef(false)

//     useEffect(() => {
//         if (hasMount.current) {
//             callback()
//         } else {
//             hasMount.current = true
//         }
//     }, deps)
// }

export function generateMessageFromError(error){
	// console.log([error]);
    var caller_line = error.stack.split("\n")[1];
    var src_ln_col = caller_line.match(/\(([^)]+)\)/)[1];
    var src_ln_col_arr = src_ln_col.split(":");
    
    let colno = src_ln_col_arr.pop();
    let lineno = src_ln_col_arr.pop();
    let src = src_ln_col_arr.join(":");
    let type = error.stack.split("\n")[0].split(":")[0];
    let msg = error.message;

    let message = {
        "LogType": "ERROR",
        "ErrType": type,
        "Message": msg,
        "Src"    : src,
        "Line"   : lineno,
        "Column" : colno,
        "Stack"  : error.stack,
    }

    return message
}

export function orderShapeSelectionLayer(shapeList, image_id, shape_id) {
    for (let i in shapeList) {
        if (parseInt(i) === image_id) {
            let temp = {};
            let filter = {}
            for (let s in shapeList[i]) {
                if (s === shape_id) {
                    temp[s] = shapeList[i][s];
                }
                else {
                    filter[s] = shapeList[i][s];
                }
            }
            shapeList[i] = Object.assign(temp, filter);
        }
    }
    return shapeList;
}

export function getPointsFromShape(shape) {
    if(shape === undefined || shape === null || !("type" in shape)){
        // Error: shape must not be undefined or null, there will be type properties in shape
        return []
    }
    let points = [];
    if (shape.type === 'rect') {
        let x = shape['x'];
        let y = shape['y'];
        let w = x + shape['width'];
        let h = y + shape['height'];
        points = [[x, y], [w, y], [w, h], [x, h]];
    }
    else if (shape.type === 'ellipse') {
        let cx = shape['cx'];
        let cy = shape['cy'];
        let rx = shape['rx'];
        let ry = shape['ry'];
        points = [[cx - rx, cy], [cx, cy - ry], [cx + rx, cy], [cx, cy + ry]];
    }
    else if (shape.type === 'polygon') {
        let s_points = shape['points'].split(" ");
        for (let i = 0; i < s_points.length; i++) {
            points.push(s_points[i].split(","));
        }
    }
    return points;
}

// Deep copy of javascript object
export function deepCopy(obj) {
    return JSON.parse(JSON.stringify(obj));
}

// Get size of any javascript object
export function objectSize(obj) {
    var size = 0,
        key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
}
export function sortObjectByKeys(obj) {
    return Object.keys(obj).sort().reduce((acc, key) => {
        acc[parseInt(key)] = obj[parseInt(key)];
        return acc;
    }, {});
}

export function getImage(path) {
    return new Promise(function (resolve, reject) {
        let image = new Image();
        image.crossOrigin = 'Anonymous';
        image.onload = resolve(image);
        image.onerror = reject;
        image.src = path;
    });
}

export function cropImage(path, shape,) {
    return new Promise(function (resolve, reject) {
        let image = new Image();
        image.crossOrigin = 'Anonymous';
        image.onload = function(){
            var canvas = document.createElement('canvas');
            canvas.width = this.width;
            canvas.height = this.height;

            const ctx = canvas.getContext('2d');
            ctx.strokeStyle = '#BADA55';
            ctx.fillStyle = "#ffffff"; //HERE, use HEX format in 6 digits

            ctx.fillRect(0, 0, canvas.width, canvas.height); //HERE

            

            let x = Infinity,
                y = Infinity,
                w = -Infinity,
                h = -Infinity;

            ctx.beginPath();

            if (shape.type === "rect") {
                let points = [
                    { "x": shape.x, "y": shape.y },
                    { "x": shape.x + shape.w, "y": shape.y },
                    { "x": shape.x + shape.w, "y": shape.y + shape.h },
                    { "x": shape.x, "y": shape.y + shape.h }
                ]

                ctx.moveTo(points[0].x, points[0].y);
                for (var i = 1; i < points.length; i++) {
                    if (x > points[i].x) x = points[i].x;
                    if (w < points[i].x) w = points[i].x;
                    if (y > points[i].y) y = points[i].y;
                    if (h < points[i].y) h = points[i].y;

                    ctx.lineTo(points[i].x, points[i].y);
                }
            }
            else if (shape.type === "polygon") {
                let points = shape.points;

                ctx.moveTo(points[0].x, points[0].y);
                for (let i = 1; i < points.length; i++) {
                    if (x > points[i].x) x = points[i].x;
                    if (w < points[i].x) w = points[i].x;
                    if (y > points[i].y) y = points[i].y;
                    if (h < points[i].y) h = points[i].y;

                    ctx.lineTo(points[i].x, points[i].y);
                }
            }
            else if (shape.type === "ellipse") {
                x = shape.x;
                y = shape.y;
                w = x + shape.w;
                h = y + shape.h;

                let cx = shape.x + shape.w / 2;
                let cy = shape.y + shape.h / 2;
                let rx = shape.w * 2 / 3;
                let ry = shape.h / 2;

                ctx.moveTo(cx, cy - ry);
                ctx.bezierCurveTo(cx + rx, cy - ry, cx + rx, cy + ry, cx, cy + ry);
                ctx.bezierCurveTo(cx - rx, cy + ry, cx - rx, cy - ry, cx, cy - ry);
            }

            ctx.closePath();
            ctx.clip();
            ctx.drawImage(this, 0, 0);

            // create a new canvas 
            var c = document.createElement('canvas');
            var cx = c.getContext('2d');
            cx.fillStyle = "white";
            cx.fillRect(0, 0, c.width, c.height);
            // resize the new canvas to the size of the clipping area
            c.width = w - x;
            c.height = h - y;

            // draw the clipped image from the main canvas to the new canvas
            cx.drawImage(canvas, x, y, w - x, h - y, 0, 0, w - x, h - y);
            let dataURL = c.toDataURL("image/png");
            resolve(dataURL);
        }
        image.onerror = reject;
        image.src = path;
    });
}

export function cropImageFromCanvas(src, shape, callBack) {
    if (objectSize(shape) > 0) {
        getImage(src).then(img => {
            if (img.width === 0 || img.height === 0) return;
            var canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            ctx.strokeStyle = '#BADA55';
            ctx.fillStyle = "#ffffff"; //HERE, use HEX format in 6 digits
            ctx.fillRect(0, 0, canvas.width, canvas.height); //HERE

            canvas.width = img.width;
            canvas.height = img.height;

            let x = Infinity,
                y = Infinity,
                w = -Infinity,
                h = -Infinity;

            ctx.beginPath();

            if (shape.type === "rect") {
                let points = [
                    { "x": shape.x, "y": shape.y },
                    { "x": shape.x + shape.w, "y": shape.y },
                    { "x": shape.x + shape.w, "y": shape.y + shape.h },
                    { "x": shape.x, "y": shape.y + shape.h }
                ]

                ctx.moveTo(points[0].x, points[0].y);
                for (var i = 1; i < points.length; i++) {
                    if (x > points[i].x) x = points[i].x;
                    if (w < points[i].x) w = points[i].x;
                    if (y > points[i].y) y = points[i].y;
                    if (h < points[i].y) h = points[i].y;

                    ctx.lineTo(points[i].x, points[i].y);
                }
            }
            else if (shape.type === "polygon") {
                let points = shape.points;

                ctx.moveTo(points[0].x, points[0].y);
                for (let i = 1; i < points.length; i++) {
                    if (x > points[i].x) x = points[i].x;
                    if (w < points[i].x) w = points[i].x;
                    if (y > points[i].y) y = points[i].y;
                    if (h < points[i].y) h = points[i].y;

                    ctx.lineTo(points[i].x, points[i].y);
                }
            }
            else if (shape.type === "ellipse") {
                x = shape.x;
                y = shape.y;
                w = x + shape.w;
                h = y + shape.h;

                let cx = shape.x + shape.w / 2;
                let cy = shape.y + shape.h / 2;
                let rx = shape.w * 2 / 3;
                let ry = shape.h / 2;

                ctx.moveTo(cx, cy - ry);
                ctx.bezierCurveTo(cx + rx, cy - ry, cx + rx, cy + ry, cx, cy + ry);
                ctx.bezierCurveTo(cx - rx, cy + ry, cx - rx, cy - ry, cx, cy - ry);
            }

            ctx.closePath();
            ctx.clip();
            ctx.drawImage(img, 0, 0);

            // create a new canvas 
            var c = document.createElement('canvas');
            var cx = c.getContext('2d');
            cx.fillStyle = "white";
            cx.fillRect(0, 0, c.width, c.height);
            // resize the new canvas to the size of the clipping area
            c.width = w - x;
            c.height = h - y;

            // draw the clipped image from the main canvas to the new canvas
            cx.drawImage(canvas, x, y, w - x, h - y, 0, 0, w - x, h - y);
            let dataURL = c.toDataURL("image/png");
            callBack(dataURL);
            // resolve(dataURL)
        });

    }
}