import React, { useReducer, createContext,useEffect } from 'react'
import App from '../App'
import Cookies from 'js-cookie'
import { reducer } from '../reducer/reducer'
export const ProjectContext = createContext()

let initialState = {
   uploadedFiles:[]
}

const OverallContext = () => {
    const [state, dispatch] = useReducer(reducer, initialState);


    // Saving Uploaded files to context
    const setUploadedFiles = (data)=>{
        return dispatch({
            type:"SET_UPLOADED_FILE",
            payload:{
                data:data
            }
        })
    }

    // Delete Selected files from status table
    const updateUploadedFiles = (data)=>{
        return dispatch({
            type:"UPDATE_UPLOADED_FILE",
            payload:{
                data:data
            }
        })
    }

    const setTotalFile = (data) => {
        return dispatch({
            type: 'SET_PROGRESS_VALUE',
            payload: {
                data: data
            }
        })
    }
    const setTotalFileUploadCount = (data) =>{
        return dispatch({
            type: 'SET_UPLOAD_COUNT',
            payload: {
                data: data
            }
        })
    }
    const setTotalDownload = (data) => {
        return dispatch({
            type: 'SET_DOWNLOAD_VALUE',
            payload: {
                data: data
            }
        })
    }

    const setStartTriggered = (data)=>{
        return dispatch({
            type: 'SET_ABORT_TRACK',
            payload: {
                data: data
            }
        })
    }

    const setProgressValue = (data)=>{
        return dispatch({
            type: 'SET_PROGRESS_BAR_VALUE',
            payload: {
                data: data
            }
        })
    }

    useEffect(()=>{

    },[])


    return (
        <ProjectContext.Provider value={{ ...state, setUploadedFiles,updateUploadedFiles}}>
            <App />
        </ProjectContext.Provider>
    )
}

export default OverallContext