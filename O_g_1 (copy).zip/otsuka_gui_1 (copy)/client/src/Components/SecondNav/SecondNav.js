import React, { useContext, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { makeStyles, withStyles } from '@material-ui/core';
import { withSnackbar } from 'notistack';
import { useNavigate, useLocation } from 'react-router-dom'
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { useSelector, useDispatch } from 'react-redux'

import Button from '@material-ui/core/Button';
import { pdfjs } from 'react-pdf';


// import resource files
import DeepICRContext from '../../resources/DeepICRContext';


// pdfjs Setting
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;


// Style Sheet
const useStyles = makeStyles(theme => ({
    styleToolBar: {
        flexGrow: 1,
        backgroundColor: theme.palette.deepICR.color,
        padding: "4px 0",
    },
    styleDivider: {
        margin: theme.spacing(1),
    },
    styleSpacer: { flexGrow: 1 },
    styleFileUpload: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,
    },
    stylePageNumberInputRoot: {
        color: 'inherit',
        backgroundColor: theme.palette.deepICR.input,
        fontSize: "0.9rem",
    },
    stylePageNumberInput: {
        padding: theme.spacing(1, 1, 1, 2),
        transition: theme.transitions.create('width'),
        width: '100%',
        [theme.breakpoints.up('sm')]: {
            width: theme.palette.deepICR.pageNumberInputSize,
            '&:focus': {
                width: theme.palette.deepICR.pageNumberInputSizeFocus,
                backgroundColor: theme.palette.deepICR.input,
            },
        },
    },
    styleConvert: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,
    },
    styleFormat: {},
    styleType: {},
    styleExport: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,
    },
}));
const CustomButton = withStyles({
    outlined: {
        '&$disabled': {
            color: "#ffffff",
            backgroundColor: "#888888",
        },
    },
    disabled: {},
})(Button);



// [React function component]
// Tool bar component
const SecondNav = ({ showNextFile, showPrevFile, prevNext, resultPrevNext, showResultPrev, showResultNext,setOthersClicked,toggleThree }) => {
    const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
    const navigate = useNavigate()
    const location = useLocation()
    const [t] = useTranslation(); // for multiple language
    const styles = useStyles();   // for metarial ui theme


    const isChangesHappened = useSelector((state) => state.reducer.isChangesHappened)
    const totalFile = useSelector((state) => state.reducer.totalFile)
    const currentNumber = useSelector((state) => state.reducer.currentNumber)
    const isFileUpload = useSelector((state)=>state.reducer.isFileUpload)

    const resultTotalFiles = useSelector((state) => state.resultReducer.resultTotalFiles)
    const resultCurrentFile = useSelector((state) => state.resultReducer.resultCurrentFile)

    // console.log("prevNext",prevNext);
    // console.log("Result Page ",resultPrevNext);
    if (deepICRCTX.debug === true) { console.log('ToolBar'); }

    // console.log("SECOND NAV TOTAL FILE",totalFile);
    //-------------------------------------------------------------------------------------------------
    // return
    //-------------------------------------------------------------------------------------------------
    return (
        <div className={styles.styleToolBar} data-id={deepICRCTX.isImage}>
            <Toolbar style={{ paddingLeft: 10, paddingRight: 10, }}>
                {/* For fileupload page second nav will be blank */}

                {
                    (location.pathname === '/fileupload' || location.pathname === '/users') ? "" : (location.pathname === '/pdfprocess' || location.pathname === '/resultpage') ?
                        <Button
                            className={styles.styleFileUpload}
                            variant="outlined"
                            component="span"
                            // onClick={() => {navigate('/fileupload')}}
                            onClick={(location.pathname==='/resultpage' && isChangesHappened===true)?()=>{
                                setOthersClicked('upload')
                                toggleThree()
                            }:() => {navigate('/fileupload')}}
                            style={{ marginLeft: "6px" }}
                        >
                            <Typography variant="h6">
                                {t('stringUploadNewFiles')}
                            </Typography>
                        </Button> :
                        <Button
                            className={styles.styleFileUpload}
                            variant="outlined"
                            component="span"
                            onClick={() => navigate('/fileupload')}
                            style={{ marginLeft: "29px" }}
                        >
                            <Typography variant="h6">
                            {t('stringUploadNewFiles')}
                            </Typography>
                        </Button>

                }
                {/* For pdf process page Pagination will be in second layer */}
                {
                    
                    location.state && location.state.page? "" : location.pathname === '/pdfprocess' ? 
                        <>
                            <div>

                            </div>
                            <div className="pdfProcess__select" style={{ marginLeft: "150px" }}>
                                <div
                                    className="row"
                                    style={{
                                        // border: "1px solid",
                                        fontSize: "1.2rem",
                                    }}
                                >
                                    <p className="col-12 col-md-3">{t('stringPdfSelect')}</p>
                                    {/* ${totalFile} */}
                                    <p className="col-12 col-md-3">{totalFile > 0 ? `${currentNumber}/${totalFile}` : `${t('stringNoFile')} `}</p>

                                    <CustomButton
                                        className={`${styles.styleFileUpload} col-12 col-md-2 `}
                                        variant="outlined"
                                        component="span"
                                        onClick={showPrevFile}
                                        disabled={prevNext.prev?.length === 0 ? true : false}
                                        style={{ marginRight: "20px" }}

                                    >
                                        <Typography variant="h6" >{t('stringPrev')}</Typography>
                                    </CustomButton>
                                    <CustomButton
                                        className={`${styles.styleFileUpload} col-12 col-md-2`}
                                        variant="outlined"
                                        component="span"
                                        onClick={showNextFile}
                                        disabled={prevNext.next?.length === 0 ? true : false}

                                    >
                                        <Typography variant="h6" >{t('stringNext')}</Typography>
                                    </CustomButton>
                                </div>
                            </div>
                        </>:  ""

                       
                }
                {/* For Result Page */}
                {
                    location.pathname === '/resultpage' ?
                        <>

                            <Typography className={styles.styleSpacer}></Typography>
                            {/* <div style={{border:"2px solid red",width:"20%"}}> */}
                            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "20%" }}>
                                <p className="col-12 col-md-3">{t('stringPdfSelect')}</p>
                                {/* ${totalFile} */}
                                <p className="col-12 col-md-3">{resultTotalFiles > 0 ? `${resultCurrentFile}/${resultTotalFiles}` : `${t('stringNoFile')} `}</p>
                            </div>
                            <Typography className={styles.styleSpacer}></Typography>

                            <CustomButton
                                className={`${styles.styleFileUpload} col-12 col-md-2 `}
                                variant="outlined"
                                component="span"
                                style={{ marginRight: "20px", maxWidth: "200px", minWidth: "50px" }}
                                // onClick={showResultPrev}
                                onClick={()=>{
                                    setOthersClicked('prev')
                                    isChangesHappened?toggleThree():showResultPrev()
                                    
                                }}
                                disabled={resultPrevNext.prev?.length === 0 ? true : false}

                            >
                                <Typography variant="h6" >{t('stringPrev')}</Typography>
                            </CustomButton>
                            <CustomButton
                                className={`${styles.styleFileUpload} col-12 col-md-2`}
                                variant="outlined"
                                component="span"
                                style={{ maxWidth: "200px", minWidth: "50px", marginRight: "150px" }}
                                onClick={()=>{
                                    setOthersClicked('next')
                                    isChangesHappened?toggleThree():showResultNext()
                                }}
                                disabled={resultPrevNext.next?.length === 0 ? true : false}

                            >
                                <Typography variant="h6" >{t('stringNext')}</Typography>
                            </CustomButton>
                            {/* </div> */}

                            <Typography className={styles.styleSpacer}></Typography>
                        </>
                        : ""
                }

            </Toolbar>
        </div>
    );
}

export default withSnackbar(SecondNav);
