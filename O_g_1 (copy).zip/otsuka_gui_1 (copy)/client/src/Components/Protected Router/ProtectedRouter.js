import React,{useEffect} from 'react'
import { Navigate } from 'react-router-dom'

// Redux
import { getCookie,resetCredentials} from "../../action/index";
import { useSelector, useDispatch } from "react-redux";

const ProtectedRouter = ({children}) => {
    const dispatch = useDispatch()
    dispatch(getCookie())
    const jwt = useSelector((state)=>state.reducer.jwt)
    if(jwt){
        return children
    }
    else {
        // dispatch(resetCredentials())
        return <Navigate to={"/login"}/>
    }
 
}

export default ProtectedRouter