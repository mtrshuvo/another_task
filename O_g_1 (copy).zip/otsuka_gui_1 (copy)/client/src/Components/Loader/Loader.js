import React from 'react'
// import HashLoader from "react-spinners/HashLoader";
import MoonLoader from 'react-spinners/MoonLoader'

const Loader = ({ loading }) => {
    return (
        <div style={{height:'100vh',width:"100vw",display:"flex",justifyContent:"center",alignItems:"center"}}>
            <MoonLoader color={'#36D7B7'} loading={loading} size={100} />
        </div>

    )
}

export default Loader