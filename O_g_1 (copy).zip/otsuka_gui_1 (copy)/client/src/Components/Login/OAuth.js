import {
    useMemo,
    useContext,
    useState,
    useEffect,
    useCallback,
    useRef,
} from "react";
import * as React from 'react';
import { Navigate, useLocation } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { CircularProgress } from "@material-ui/core";
import { withSnackbar } from "notistack";
import { makeStyles } from "@material-ui/core";

import DeepICRContext from "../../resources/DeepICRContext";
import { deepICRNow } from "../../deepICRCommon";
import deepICRLogging from "../../Logging/deepICRLogging";
import jsonDeepICRContext from "../../resources/deepICRContext.json";
import jwt_decode from "jwt-decode";
import { useDispatch } from 'react-redux'
import { getCookie } from "../../action";
import { toast } from "react-toastify";
import Cookies from 'js-cookie'

const useStyles = makeStyles((theme) => ({
    styleLogo: {
        margin: theme.spacing(1, 0, 0, 4),
    },
}));

const useQuery = () => {
    const { search } = useLocation();

    return useMemo(() => new URLSearchParams(search), [search]);
};

const OAuth = (props) => {
    const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
    const [t, i18n] = useTranslation();
    const dispatch = useDispatch()

    const styles = useStyles();
    const isMounted = useRef(false);
    const [isLoading, setIsLoading] = useState(false);
    const { code } = props;

    const authorize = useCallback(async () => {
        const [, unixtime, microsec] = deepICRNow();
        localStorage.removeItem('language')
        // console.log("entered");
        const requestJson = {
            type: "request",
            head: {
                command: "authentication",
                format_version: deepICRCTX.apiFormatVersion,
                service_id: deepICRCTX.apiServiceId,
                transaction_id:
                    deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
                unix_time: unixtime,
                micro_seconds: microsec,
                time_zone: deepICRCTX.apiTimeZone,
            },
            body: {
                code,
            },
        };
        await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiOAuthToken, {
            method: "POST",
            mode: "cors",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(requestJson),
        })
            .then((res) => res.json())
            .then(async (json) => {

                if (json.body.status !== "OK") {
                    props.enqueueSnackbar(t("errorLogin"), {
                        variant: "error",
                        anchorOrigin: { vertical: "top", horizontal: "right" },
                    });
                    deepICRLogging({
                        LogType: "ERROR",
                        ErrType: "LoginError",
                        Message: t("errorOAuthError"),
                        Src: "OAuth.js",
                        Line: 0,
                        Column: 0,
                        Stack: "",
                    });

                    return;
                }
                i18n.changeLanguage("ja");
                localStorage.setItem('language', 'ja')
                const {
                    accessToken,
                    idToken,
                    refreshToken,
                    displayName,
                    email,
                    employeeId,
                    folder,
                    username,
                } = json.body.result;


                const decodedToken = jwt_decode(idToken)
                // console.log("accessToken", accessToken,"idToken",idToken);

                const credentials = {
                    employeeCode: employeeId,
                    displayName: displayName,
                    auth_time: decodedToken.auth_time,
                    email: email,
                    info:idToken
                }

                const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/users/signin`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Accept: "application/json",
                    },
                    body: JSON.stringify({
                        credentials,
                        isSSO: true
                    }),
                    credentials: 'include'
                })

                const data = await res.json()
                if (res.status === 400) {
                    // console.log("error Login");
                    // console.log(data.message);
                    toast.warning(data.message, {
                        position: toast.POSITION.TOP_CENTER,
                        autoClose: 2000,
                        pauseOnHover: false,
                    });
                    // setAlertData({message:data.message, code:"danger"})
                    // setLoading(false)
                } else {
                    // console.log(data)
                    // Cookies.set('jwtooken', data.data.token)
                    dispatch(getCookie())
                    toast.success("ログインが成功しました", {
                        position: toast.POSITION.TOP_CENTER,
                        autoClose: 1500,
                        pauseOnHover: false,
                    });
                    // localStorage.setItem("userData", JSON.stringify(data))
                    // getUserData()
                    // setAlertData({message: "Login Successfully", code: "success"})
                    // setLoading(false)
                    // setLoadingContext()

                }

                // console.log("verified Data",data);
                //--------------------------------------------------------------------------------------------------
                // The displayName and employeeId are stored in 'json.body.result'. Please use them as needed.
                //--------------------------------------------------------------------------------------------------

                // TODO: set global value
                global.accessToken = accessToken;
                global.refreshToken = refreshToken;

                const userData = { Username: email };
                setDeepICRCTX({
                    ...jsonDeepICRContext,
                    isLogin: true,
                    cognitoUser: userData,
                });
                global.md5hash = folder;
                // console.log("body result", json.body.result);

            })
            .catch((err) => {
                // console.log(err);
                props.enqueueSnackbar(t("errorLoginSystemError"), {
                    variant: "error",
                    anchorOrigin: { vertical: "top", horizontal: "right" },
                });
                deepICRLogging({
                    LogType: "ERROR",
                    ErrType: "OAuthError",
                    Message: t("errorOAuthError"),
                    Src: "OAuth.jsx",
                    Line: 0,
                    Column: 0,
                    Stack: "",
                });
                // setUser({ ...user, data: "", digits: "" });
                return;
            });
        setIsLoading(false);
    }, [
        code,
        deepICRCTX.apiFormatVersion,
        deepICRCTX.apiOAuthToken,
        deepICRCTX.apiServiceId,
        deepICRCTX.apiTimeZone,
        deepICRCTX.apiUrlBase,
        i18n,
        props,
        setDeepICRCTX,
        t,
    ]);

    useEffect(() => {
        // console.log("OAuth Called");
        if (!isMounted.current) {

            isMounted.current = true;
            authorize();
        }
        return () => {
            isMounted.current = false;
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // if (isLoading) {
    //   return (
    //     <div>
    //       <header className={styles.styleLogo}>
    //         <img
    //           alt="Deloitte. Logo"
    //           src="/DEL_g_SEC_RGB.jpg"
    //           width="142"
    //           height="44"
    //         />
    //       </header>{" "}
    //       <CircularProgress />
    //     </div>
    //   );
    // }
    // if (!isMounted.current) {
    //     return <Navigate to="/deepICR" />;
    // }else{
    //     return <Navigate to="/login" />;
    // }
    return <Navigate to="/deepICR" />;

};

const OAuthWrapper = (props) => {
    let query = useQuery();

    const code = query.get("code");
    if (code === null || code === undefined || typeof code !== "string") {
        return <Navigate to="/login" />;
    }

    return <OAuth code={code} {...props} />;
};

export default withSnackbar(OAuthWrapper);
