// Dependencies
import React, { useContext, useState, useEffect, useRef } from 'react'
import { makeStyles } from '@material-ui/core';

// Context
import DeepICRContext from '../../../resources/DeepICRContext';
import { useTranslation } from 'react-i18next';

// Components
import PopupDialog from './PopupDialog';
import { useEventListener, getPointsFromShape, deepCopy, objectSize } from '../../../resources/CommonMethods';

// Making stylesheet
const useStyles = makeStyles(theme => ({
    handle: {
        stroke: "orange",
        strokeWidth: "1",
        fill: "orange",
        cursor: "crosshair",
    },
    rect: {
        stroke: "#f06",
        strokeWidth: "2",
        // fill: "transparent",
        fill: "#ff00660f",
    },
    ellipse: {
        stroke: "#f06",
        strokeWidth: "2",
        // fill: "transparent",
        fill: "#ff00660f",
    },
    polygon: {
        stroke: "#f06",
        strokeWidth: "2",
        // fill: "transparent",
        fill: "#ff00660f",
    },
    circle: {
        stroke: "orange",
        strokeWidth: "1",
        fill: "orange",
    },
}));

// Render rectenguler handle from selected shape
const SelectedShape = () => {
    const [deepICRCTX] = useContext(DeepICRContext);
    const styles = useStyles();

    let items = [];
    let padding = 3;
    let distance = 6;
    let shape = deepICRCTX.selectedShape;

    let image_id = "";
    let shape_id = "";
    let points = [];

    if ((shape !== null || shape !== undefined) && shape.length > 0) {
        image_id = shape[0]['image_id'];
        shape_id = shape[0]['shape_id'];
        points = getPointsFromShape(shape[0]);
    }

    for (var p = 0; p < points.length; p++) {
        let x = parseInt(points[p][0] * deepICRCTX.imageScale);
        let y = parseInt(points[p][1] * deepICRCTX.imageScale);
        items.push(<rect data-id="handle" key={"sp_" + p} id={"sp_" + p + "," + image_id + "," + shape_id} x={x - padding} y={y - padding} width={distance} height={distance} className={styles.handle} />)
    }
    return items;
}

const AllShapes = (props) => {
    const styles = useStyles();
    const [deepICRCTX] = useContext(DeepICRContext);
    const [t] = useTranslation();

    let shapes = []
    const items = [];

    let fontsize = 72 * deepICRCTX.imageScale * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale;
    if (fontsize > 20) fontsize = 20;

    let page_index = "p_" + props.width + "_" + props.height + "_" + (props.imageIndex + 1);

    if (deepICRCTX.shapeList !== undefined && page_index in deepICRCTX.shapeList) {
        shapes = deepICRCTX.shapeList[page_index];
    }

    for (const key in shapes) {
        let item = shapes[key];
        let label = " " + key.split("_")[1] + ". ";

        if ("label" in item && item.label !== undefined && item.label !== "") {
            if (item.label === "Blank") { label += t("stringBlank") }
            else if (item.label === "Single Line") { label += t("stringSingleLine") }
            else if (item.label === "Multi Line") { label += t("stringMultiline") }
            else if (item.label === "Table") { label += t("stringTable") }
            else if (item.label === "Image") { label += t("stringImage") }
            else if (item.label === "Handwritten") { label += t("stringHandwritten") }
        }

        if ("meta" in item && item.meta !== undefined && item.meta !== "") {
            label += " : " + item.meta;
        }

        if (label.length > 50) {
            label = label.substr(0, 50) + "...";
        }

        if (item.type === 'rect') {
            let x = parseInt(item.x * deepICRCTX.imageScale);
            let y = parseInt(item.y * deepICRCTX.imageScale);
            let w = parseInt(item.width * deepICRCTX.imageScale);
            let h = parseInt(item.height * deepICRCTX.imageScale);

            items.push(<rect key={key} id={key} x={x} y={y} width={w} height={h} className={styles.rect} />)
            if (y < fontsize)
                items.push(<text key={"t" + key} filter="url(#solid)" x={x} y={fontsize} textAnchor="start" fill="white" fontSize={fontsize}>{label}</text>)
            else
                items.push(<text key={"t" + key} filter="url(#solid)" x={x} y={y - 4} textAnchor="start" fill="white" fontSize={fontsize}>{label}</text>)
        }
        else if (item.type === 'ellipse') {
            let cx = parseInt(item.cx * deepICRCTX.imageScale);
            let cy = parseInt(item.cy * deepICRCTX.imageScale);
            let rx = parseInt(item.rx * deepICRCTX.imageScale);
            let ry = parseInt(item.ry * deepICRCTX.imageScale);

            items.push(<ellipse key={key} id={key} cx={cx} cy={cy} rx={rx} ry={ry} className={styles.ellipse} />)

            if (cy - ry < fontsize)
                items.push(<text key={"t" + key} filter="url(#solid)" x={cx} y={fontsize} textAnchor="middle" fill="white" fontSize={fontsize}>{label}</text>)
            else
                items.push(<text key={"t" + key} filter="url(#solid)" x={cx} y={cy - ry - 4} textAnchor="middle" fill="white" fontSize={fontsize}>{label}</text>)
        }
        else if (item.type === "polygon") {
            let points = item.points.split(" ");
            let points_str = '';
            let x, y, textAnchor = "middle";
            let min_y = Infinity, min_x = Infinity, max_x = -Infinity;

            for (let j = 0; j < points.length; j++) {
                let point = points[j].split(",");
                let pointX = point[0] * deepICRCTX.imageScale;
                let pointY = point[1] * deepICRCTX.imageScale;
                if (pointY < min_y) {
                    min_y = pointY;
                    x = pointX;
                    y = pointY;
                }
                if (pointX < min_x) min_x = pointX;
                if (pointX > max_x) max_x = pointX;

                if (j === points.length - 1) {
                    points_str += pointX + "," + pointY;
                }
                else {
                    points_str += pointX + "," + pointY + " ";
                }
            };

            if (x < parseInt(min_x + (max_x - min_x) / 3)) textAnchor = "start";
            if (x > parseInt(max_x - (max_x - min_x) / 3)) textAnchor = "end";

            items.push(<polygon key={key} id={key} points={points_str} className={styles.polygon} />);
            if (y < fontsize)
                items.push(<text key={"t" + key} filter="url(#solid)" x={x} y={fontsize} textAnchor={textAnchor} fill="white" fontSize={fontsize}>{label}</text>)
            else
                items.push(<text key={"t" + key} filter="url(#solid)" x={x} y={y} textAnchor={textAnchor} fill="white" fontSize={fontsize}>{label}</text>)
        }
    }
    return items;
}

const CurrentShape = (props) => {
    const [deepICRCTX] = useContext(DeepICRContext);
    let shapes = deepICRCTX.currentShape;
    let items = [];

    const styles = useStyles();

    let i = 0;

    for (let shape in shapes) {
        let item = shapes[shape];
        if (item.type === 'rect') {
            let x = parseInt(item.x);
            let y = parseInt(item.y);
            let w = parseInt(item.width);
            let h = parseInt(item.height);
            items.push(<rect key={i} x={x} y={y} width={w} height={h} className={styles.rect} />);
        }
        else if (item.type === 'ellipse') {
            let cx = parseInt(item.cx);
            let cy = parseInt(item.cy);
            let rx = parseInt(item.rx);
            let ry = parseInt(item.ry);
            items.push(<ellipse key={i} cx={cx} cy={cy} rx={rx} ry={ry} className={styles.rect} />);
        }
        else if (item.type === "polygon") {
            let points = item.points.split(" ");
            let points_str = [];
            let handle = [];
            for (let j = 0; j < points.length; j++) {
                let point = points[j].split(",");
                let pointX = point[0] * deepICRCTX.imageScale;
                let pointY = point[1] * deepICRCTX.imageScale;
                handle.push(<circle key={"c_" + j} cx={pointX} cy={pointY} r={3} className={styles.circle} />);
                points_str.push(pointX + "," + pointY);
            }
            if (item.handle !== "" || item.handle !== undefined) {
                points_str.push(item.handle);
            }
            points_str = points_str.join(" ");

            items.push(<polygon key={i} points={points_str} className={styles.polygon} />);
            items.push.apply(items, handle);
        }
        i++;
    }
    return items;
}

const SvgImage = (props) => {
    
    const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
    const [isStart, setIsStart] = useState(false);
    const [isHandle, setIsHandle] = useState(false);
    const [isSelected, setIsSelected] = useState(false);
    const [handleId, setHandleId] = useState();
    const [startX, setStartX] = useState(0);
    const [startY, setStartY] = useState(0);
    const [clickX, setClickX] = useState(0);
    const [clickY, setClickY] = useState(0);
    const [prevPosX, setPrevPosX] = useState(0);
    const [prevPosY, setPrevPosY] = useState(0);
    const [currentTarget,setCurrentTarget] = useState(null);

    // const [prevToolId, setPrevToolId] = useState(null);
    // const [isDown, setIsDown] = useState(false);

    // Define reference
    const svgRef = useRef();
    const timerRef = useRef(null);

    useEffect(() => {
        if (deepICRCTX.croppingToolId === 1) {
            document.getElementById('imgViewer').style.cursor = 'grab';
        }
        else {
            document.getElementById('imgViewer').style.cursor = 'default';
        }
        
    }, [deepICRCTX.croppingToolId])
    
    let height = props.height;
    let width = props.width;
    console.log("Height Width svg Image",height,width,deepICRCTX.imageScale);
    let image_id = props.imageIndex;
    let page_index = "p_" + width + "_" + height + "_" + (image_id + 1);
    useEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.keyCode === 13) {
            e.preventDefault();
            if (deepICRCTX.croppingToolId === 2) {
                let shapes = deepICRCTX.shapeList;
                let counter = objectSize(shapes[page_index]) + 1;
                let current_shape = deepICRCTX.currentShape;


                let points = "";

                if (current_shape.length > 0) {
                    points = getPointsFromShape(current_shape[0]);
                }

                if (points.length > 3) {
                    points = current_shape[0].points;
                    let shape_index = "s_" + counter;

                    if (shapes.hasOwnProperty(page_index)) {
                        shapes[page_index][shape_index] = { type: "polygon", points: points, label: "Blank", meta: "" };
                    }
                    else {
                        shapes[page_index] = {}
                        shapes[page_index][shape_index] = { type: "polygon", points: points, label: "Blank", meta: "" };
                    }


                    let shape = shapes[page_index][shape_index];
                    shape['image_id'] = page_index;
                    shape['shape_id'] = shape_index;

                    let topVal = clickY;
                    if (topVal + 240 > window.innerHeight) {
                        topVal = topVal - 240;
                    }

                    setDeepICRCTX({
                        ...deepICRCTX,
                        currentShape: [],
                        selectedShape: [shape],
                        shapeList: shapes,
                        shapeCounter: counter,
                        popUpDialog: {
                            image_id: page_index,
                            shape_id: shape_index,
                            label: "Blank",
                            meta: "",
                            left: clickX,
                            top: topVal,
                            show: true,
                        },
                    });
                    setClickX(0);
                    setClickY(0);
                }
                else {
                    setDeepICRCTX({
                        ...deepICRCTX,
                        selectedShape:[],
                        currentShape: [],
                    });
                }
            }
        }
        else if (e.key === "Escape") {
            e.preventDefault();
            if (deepICRCTX.croppingToolId === 2 && deepICRCTX.currentShape.length > 0 && deepICRCTX.currentShape[0].type === "polygon") {
                let points = "";

                if (deepICRCTX.currentShape.length > 0) {
                    points = deepICRCTX.currentShape[0].points;
                    points = points.split(" ");
                    if (points.length > 1) {
                        points.pop();
                        points = points.join(" ");
                        setDeepICRCTX({
                            ...deepICRCTX,
                            pointCounter: deepICRCTX.pointCounter - 1,
                            currentShape: [{ type: "polygon", points: points }],
                        });
                    }
                    else {
                        setDeepICRCTX({
                            ...deepICRCTX,
                            pointCounter: 0,
                            currentShape: [],
                        });
                    }

                }
                else {
                    setDeepICRCTX({
                        ...deepICRCTX,
                        pointCounter: 0,
                        currentShape: [],
                    });
                }
            }
            else {
                setDeepICRCTX({
                    ...deepICRCTX,
                    pointCounter: 0,
                    currentShape: [],
                });
            }

        }
 
        else if (e.ctrlKey && (e.key === "M" || e.key === "m")) {
            e.preventDefault();
            if(deepICRCTX.popUpDialog.show === false && (deepICRCTX.currentShape === undefined || deepICRCTX.currentShape.length === 0)){
                console.log("Yes")
                setDeepICRCTX({
                    ...deepICRCTX,
                    isThumbnailOpen: !deepICRCTX.isThumbnailOpen,
                })
            }
        }
        else if (e.ctrlKey && (e.key === "H" || e.key === "h")) {
            e.preventDefault();
            if(deepICRCTX.popUpDialog.show === false && (deepICRCTX.currentShape === undefined || deepICRCTX.currentShape.length === 0)){
                setDeepICRCTX({
                    ...deepICRCTX,
                    croppingToolId: 1,
                })
            }
        }
        else if (e.ctrlKey && (e.key === "S" || e.key === "s")) {
            e.preventDefault();
            if(deepICRCTX.popUpDialog.show === false && (deepICRCTX.currentShape === undefined || deepICRCTX.currentShape.length === 0)){
                setDeepICRCTX({
                    ...deepICRCTX,
                    croppingToolId: 6,
                })
            }
        }
        else if (e.ctrlKey && (e.key === "P" || e.key === "p")) {
            e.preventDefault();
            if(deepICRCTX.popUpDialog.show === false && (deepICRCTX.currentShape === undefined || deepICRCTX.currentShape.length === 0)){
                setDeepICRCTX({
                    ...deepICRCTX,
                    croppingToolId: 2,
                })
            }
        }
        else if (e.ctrlKey && (e.key === "R" || e.key === "r")) {
            e.preventDefault();
            if(deepICRCTX.popUpDialog.show === false && (deepICRCTX.currentShape === undefined || deepICRCTX.currentShape.length === 0)){
                setDeepICRCTX({
                    ...deepICRCTX,
                    croppingToolId: 3,
                })
            }
        }
        else if (e.ctrlKey && (e.key === "E" || e.key === "e")) {
            e.preventDefault();
            if(deepICRCTX.popUpDialog.show === false && (deepICRCTX.currentShape === undefined || deepICRCTX.currentShape.length === 0)){
                setDeepICRCTX({
                    ...deepICRCTX,
                    croppingToolId: 4,
                })
            }
        }
        else if (e.key === "Delete") {
            
            if (deepICRCTX.popUpDialog.show === false){
                
                if(deepICRCTX.selectedShape.length > 0) {
                    e.preventDefault();
                    let image_id = deepICRCTX.selectedShape[0].image_id;
                    let shape_id = deepICRCTX.selectedShape[0].shape_id;
                    let pages = deepICRCTX.shapeList;
    
                    for (let page in pages) {
                        if (page === image_id) {
                            let shapes = pages[page];
                            delete shapes[shape_id];
                            let temp_shapes = {};
                            let i = 1;
                            for (let shape in shapes) {
                                temp_shapes["s_" + i] = shapes[shape];
                                i++;
                            }
                            pages[page] = temp_shapes;
                        }
                    }
                    setDeepICRCTX({
                        ...deepICRCTX,
                        shapeList: pages,
                        selectedShape: [],
                        popUpDialog: { "image_id": "", "shape_id": "", "label": "", "meta": "", "left": 0, "top": 0, "show": false },
                    });
                }
                setDeepICRCTX({
                    ...deepICRCTX,
                    currentShape: [],
                    selectedShape: [],
                });
            } 
        }
        else{
            let shape = deepICRCTX.selectedShape;
            if (deepICRCTX.popUpDialog.show === false && (shape !== null || shape !== undefined) && shape.length > 0) {
                if (e.ctrlKey && e.key === 'ArrowUp') {
                    e.preventDefault();
                    moveShape([-5, 0]);
                }
                else if (e.ctrlKey && e.key === 'ArrowDown') {
                    e.preventDefault();
                    moveShape([5, 0]);
                }
                else if (e.ctrlKey && e.key === 'ArrowLeft') {
                    e.preventDefault();
                    moveShape([0, -5]);
                }
                else if (e.ctrlKey && e.key === 'ArrowRight') {
                    e.preventDefault();
                    moveShape([0, 5]);
                }
                else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    moveShape([-1, 0]);
                }
                else if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    moveShape([1, 0]);
                }
                else if (e.key === 'ArrowLeft') {
                    e.preventDefault();
                    moveShape([0, -1]);
                }
                else if (e.key === 'ArrowRight') {
                    e.preventDefault();
                    moveShape([0, 1]);
                }
            }
        }
    });

    function moveShape(direction) {
        let shapes = deepICRCTX.selectedShape;
        let wh = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
        let ht = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

        for (let s in shapes) {
            let shape = shapes[s];
            let shp_type = shape.type;
            if (shp_type === "rect") {
                if (parseInt(shapes[s].x + direction[1]) >= 0 && parseInt(shapes[s].x + direction[1] + shapes[s].width) < wh) {
                    shapes[s].x = parseInt(shapes[s].x + direction[1]);
                }
                if (parseInt(shapes[s].y + direction[0]) >= 0 && parseInt(shapes[s].y + direction[0] + shapes[s].height) < ht) {
                    shapes[s].y = parseInt(shapes[s].y + direction[0]);
                }
            }
            else if (shp_type === "ellipse") {
                if (parseInt(shapes[s].cx - shapes[s].rx + direction[1]) >= 0 && parseInt(shapes[s].cx + shapes[s].rx + direction[1]) < wh) {
                    shapes[s].cx = parseInt(shapes[s].cx + direction[1]);
                }
                if (parseInt(shapes[s].cy - shapes[s].ry + direction[0]) >= 0 && parseInt(shapes[s].cy + shapes[s].ry + direction[0]) < ht) {
                    shapes[s].cy = parseInt(shapes[s].cy + direction[0]);
                }
            }
            else if (shp_type === "polygon") {
                let pts_str = [];
                let pts = shape.points.split(" ");
                let isOutside = false;

                for (let i = 0; i < pts.length; i++) {
                    let pt = pts[i].split(",");
                    let pt1 = parseInt(pt[0]);
                    let pt2 = parseInt(pt[1]);
                    let pt_str = parseInt((pt1 + direction[1])) + "," + parseInt((pt2 + direction[0]));

                    if (parseInt(pt1 + direction[1]) < 0 || parseInt(pt1 + direction[1]) > wh) {
                        isOutside = true;
                    }
                    else if (parseInt(pt2 + direction[0]) < 0 || parseInt(pt2 + direction[0]) > ht) {
                        isOutside = true;
                    }
                    else {
                        pts_str.push(pt_str);
                    }
                }
                if (isOutside === false) {
                    shapes[s].points = pts_str.join(" ");
                }

            }
        }
        setDeepICRCTX({
            ...deepICRCTX,
            selectedShape: shapes,
        })
    }

    function orderShapeSelectionLayer(shapeList, image_id, shape_id) {
        for (let i in shapeList) {
            if (i === image_id) {
                let temp = {};
                let filter = {}
                for (let s in shapeList[i]) {
                    if (s === shape_id) {
                        temp[s] = shapeList[i][s];
                    }
                    else {
                        filter[s] = shapeList[i][s];
                    }
                }
                shapeList[i] = Object.assign(temp, filter);
            }
        }
        return shapeList;
    }
    function isTwoLineIntersect(a, b, c, d, p, q, r, s) {
        var det, gamma, lambda;
        det = (c - a) * (s - q) - (r - p) * (d - b);
        if (det === 0) {
            return false;
        }
        else {
            lambda = ((s - q) * (r - a) + (p - r) * (s - b)) / det;
            gamma = ((b - d) * (r - a) + (c - a) * (s - b)) / det;
            return (0 < lambda && lambda < 1) && (0 < gamma && gamma < 1);
        }
    }

    function handleMouseClick(e) {
        e.persist();
        e.preventDefault();
        // For Single Click
        if (e.detail === 1) {
            const timer = setTimeout(() => {
                if (deepICRCTX.croppingToolId === 6) {
                    if (e.target.tagName === "rect" || e.target.tagName === "ellipse" || e.target.tagName === "polygon") {
                        let shape_index = e.target.getAttribute("id");
                        if (shape_index) {
                            if (shape_index.split(",").length === 3) {
                                shape_index = shape_index.split(",")[2];
                            }

                            let shape = deepICRCTX.shapeList[page_index][shape_index];
                            shape['image_id'] = page_index;
                            shape['shape_id'] = shape_index;

                            let shapes = orderShapeSelectionLayer(deepICRCTX.shapeList, page_index, shape_index);
                            setDeepICRCTX({
                                ...deepICRCTX,
                                shapeList: shapes,
                                selectedShape: [shape],
                            });
                        }
                    }
                    else {
                        setDeepICRCTX({
                            ...deepICRCTX,
                            selectedShape: [],
                        });
                    }
                }
            }, 300);
            timerRef.current = timer;
        }
        // For double click
        else if (e.detail === 2) {
            clearTimeout(timerRef.current);
            let x = e.nativeEvent.offsetX / deepICRCTX.imageScale;
            let y = e.nativeEvent.offsetY / deepICRCTX.imageScale;
            let wx = e.nativeEvent.clientX;
            let wy = e.nativeEvent.clientY;

            let shape = deepICRCTX.selectedShape;

            let image_id = "";
            let shape_id = "";

            let points = [];

            let epx = 9999; // Extreame x point 
            let intersectCounter = 0;


            if ((shape !== null || shape !== undefined) && shape.length > 0) {
                image_id = shape[0]['image_id'];
                shape_id = shape[0]['shape_id'];

                let label = shape[0]['label'];
                let meta = shape[0]['meta'];


                points = getPointsFromShape(shape[0]);

                if (shape[0].type === "rect") {
                    let inside = false;
                    for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
                        let xi = points[i][0], yi = points[i][1];
                        let xj = points[j][0], yj = points[j][1];

                        let intersect = ((yi > y) !== (yj > y))
                            && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
                        if (intersect) inside = !inside;
                    }
                    if (inside === true) {
                        if (wy + 240 > window.innerHeight) {
                            wy = wy - 240;
                        }
                        setDeepICRCTX({
                            ...deepICRCTX,
                            popUpDialog: {
                                image_id: image_id,
                                shape_id: shape_id,
                                label: label,
                                meta: meta,
                                left: wx,
                                top: wy,
                                show: true,
                            },
                        });
                    }
                    else {
                        setDeepICRCTX({
                            ...deepICRCTX,
                            selectedShape: [],
                            popUpDialog: {
                                image_id: "",
                                shape_id: "",
                                label: "",
                                meta: "",
                                left: 0,
                                top: 0,
                                show: false,
                            },
                        });
                    }
                }
                else if (shape[0].type === "ellipse") {
                    let cx = parseInt(shape[0]['cx']);
                    let cy = parseInt(shape[0]['cy']);
                    let rx = parseInt(shape[0]['rx']);
                    let ry = parseInt(shape[0]['cy']);
                    let p = (parseInt(Math.pow((x - cx), 2) / Math.pow(rx, 2)) + parseInt(Math.pow((y - cy), 2) / Math.pow(ry, 2)));

                    if (p > 1) {
                        setDeepICRCTX({
                            ...deepICRCTX,
                            selectedShape: [],
                            popUpDialog: {
                                image_id: "",
                                shape_id: "",
                                label: "",
                                meta: "",
                                left: 0,
                                top: 0,
                                show: false,
                            },
                        });
                    }
                    else {
                        if (wy + 240 > window.innerHeight) {
                            wy = wy - 240;
                        }
                        setDeepICRCTX({
                            ...deepICRCTX,
                            popUpDialog: {
                                image_id: image_id,
                                shape_id: shape_id,
                                label: label,
                                meta: meta,
                                left: wx,
                                top: wy,
                                show: true,
                            },
                        });
                    }
                }
                else if (shape[0].type === "polygon") {

                    for (let i = 0; i < points.length - 1; i++) {
                        let p = parseInt(points[i][0]);
                        let q = parseInt(points[i][1]);
                        let r = parseInt(points[i + 1][0]);
                        let s = parseInt(points[i + 1][1]);
                        if (isTwoLineIntersect(x, y, epx, y, p, q, r, s) === true) {
                            intersectCounter += 1;
                        }
                    }

                    if (intersectCounter % 2 === 1) {
                        if (wy + 240 > window.innerHeight) {
                            wy = wy - 240;
                        }
                        setDeepICRCTX({
                            ...deepICRCTX,
                            currentShape: [],
                            popUpDialog: {
                                image_id: image_id,
                                shape_id: shape_id,
                                label: label,
                                meta: meta,
                                left: wx,
                                top: wy,
                                show: true,
                            },
                        });
                    }
                    else {
                        setDeepICRCTX({
                            ...deepICRCTX,
                            selectedShape: [],
                            popUpDialog: {
                                image_id: "",
                                shape_id: "",
                                label: "",
                                meta: "",
                                left: 0,
                                top: 0,
                                show: false,
                            },
                        });
                    }
                }
            }
            if (deepICRCTX.croppingToolId === 2) {
                let shapes = deepICRCTX.shapeList;
                let counter = objectSize(shapes[page_index]) + 1;
                let current_shape = deepICRCTX.currentShape;

                let points = "";

                if (current_shape.length > 0) {
                    points = getPointsFromShape(current_shape[0]);
                }

                if (points.length > 3) {
                    points = current_shape[0].points;
                    points = points.split(" ");
                    points.pop();
                    points = points.join(" ");
                    let shape_index = "s_" + counter;

                    if (shapes.hasOwnProperty(page_index)) {
                        shapes[page_index][shape_index] = { type: "polygon", points: points, label: "Blank", meta: "" };
                    }
                    else {
                        shapes[page_index] = {}
                        shapes[page_index][shape_index] = { type: "polygon", points: points, label: "Blank", meta: "" };
                    }


                    let shape = shapes[page_index][shape_index];
                    shape['image_id'] = page_index;
                    shape['shape_id'] = shape_index;

                    let topVal = clickY;
                    if (topVal + 240 > window.innerHeight) {
                        topVal = topVal - 240;
                    }

                    setDeepICRCTX({
                        ...deepICRCTX,
                        currentShape: [],
                        selectedShape: [shape],
                        shapeList: shapes,
                        shapeCounter: counter,
                        popUpDialog: {
                            image_id: page_index,
                            shape_id: shape_index,
                            label: "Blank",
                            meta: "",
                            left: clickX,
                            top: topVal,
                            show: true,
                        },
                    });
                    setClickX(0);
                    setClickY(0);
                }
            }
        }
    }
    
    function handleMouseDown(e) {
        e.preventDefault();
        if (isStart === false) {
            setIsStart(true);
            setStartX(e.nativeEvent.offsetX);
            setStartY(e.nativeEvent.offsetY);

            let shp_id = "";
            let shape = deepICRCTX.selectedShape;
            if ((shape !== null || shape !== undefined) && shape.length > 0) {
                shp_id = shape[0]['shape_id'];
            }

            if (e.target.tagName === "rect" && e.target.getAttribute('data-id') === "handle") {
                let shape_id = e.target.getAttribute("id").split(",")[0];
                let index = shape_id.split("_")[1];
                setIsHandle(true);
                setHandleId(index);
                setStartX(e.nativeEvent.offsetX);
                setStartY(e.nativeEvent.offsetY);
            }
            else if (deepICRCTX.croppingToolId !== 1 && e.target.getAttribute("id") === shp_id && (e.target.tagName === 'rect' || e.target.tagName === 'ellipse' || e.target.tagName === 'polygon')) {
                setIsSelected(true);
                setPrevPosX(e.nativeEvent.offsetX);
                setPrevPosY(e.nativeEvent.offsetY);
                e.target.style.cursor = 'grab';
                setCurrentTarget(e.target);
                // currentTarget.style.cursor = "grab";
            }
            else if (isSelected === true && deepICRCTX.croppingToolId === 3) {
                document.getElementById('imgViewer').style.cursor = 'default';
                setDeepICRCTX({
                    ...deepICRCTX,
                    currentShape: [{ type: "rect", x: startX, y: startY, width: 0, height: 0 }],
                });
            }
            else if (deepICRCTX.croppingToolId === 4) {
                document.getElementById('imgViewer').style.cursor = 'default';
                setDeepICRCTX({
                    ...deepICRCTX,
                    currentShape: [{ type: "ellipse", cx: startX, cy: startY, rx: 0, ry: 0 }],
                });
            }
        }
    }

    function handleMouseMove(e) {
        e.stopPropagation();
        if (deepICRCTX.croppingToolId === 2 && deepICRCTX.currentShape.length > 0) {
            let endX = parseInt(e.nativeEvent.offsetX);
            let endY = parseInt(e.nativeEvent.offsetY);
            let points = "";

            if (deepICRCTX.currentShape.length > 0) {
                points = deepICRCTX.currentShape[0].points;
            }
            setDeepICRCTX({
                ...deepICRCTX,
                selectedShape: [],
                currentShape: [{ type: "polygon", points: points, handle: endX + "," + endY }],
            });

        }
        if (isStart === true && isHandle === true) {
            let endX = parseInt(e.nativeEvent.offsetX);
            let endY = parseInt(e.nativeEvent.offsetY);

            let shapeList = deepICRCTX.shapeList;
            let shape = deepICRCTX.selectedShape;

            let points = getPointsFromShape(shape[0]);
            points[handleId] = [parseInt(endX / deepICRCTX.imageScale), parseInt(endY / deepICRCTX.imageScale)];

            let image_id = shape[0]['image_id'];
            let shape_id = shape[0]['shape_id'];

            if (shape[0]['type'] === "polygon") {
                let s_points = '';
                for (var p = 0; p < points.length; p++) {
                    if (p !== 0) {
                        s_points += " ";
                    }
                    s_points += points[p][0] + "," + points[p][1];
                }
                shapeList[image_id][shape_id]["points"] = s_points;
                shape[0]['points'] = s_points;
            }
            else if (shape[0]['type'] === "rect") {
                if (handleId !== null) {
                    if (handleId === "0") {
                        points[3][0] = parseInt(endX / deepICRCTX.imageScale);
                        points[1][1] = parseInt(endY / deepICRCTX.imageScale);
                    }
                    else if (handleId === "1") {
                        points[2][0] = parseInt(endX / deepICRCTX.imageScale);
                        points[0][1] = parseInt(endY / deepICRCTX.imageScale);
                    }

                    else if (handleId === "2") {
                        points[1][0] = parseInt(endX / deepICRCTX.imageScale);
                        points[3][1] = parseInt(endY / deepICRCTX.imageScale);
                    }

                    else if (handleId === "3") {
                        points[0][0] = parseInt(endX / deepICRCTX.imageScale);
                        points[2][1] = parseInt(endY / deepICRCTX.imageScale);
                    }

                    let x = points[0][0];
                    let y = points[0][1];
                    let w = Math.abs(points[2][0] - points[0][0]);
                    let h = Math.abs(points[2][1] - points[0][1]);

                    if (points[0][1] + 6 < points[2][1] && points[0][0] + 6 < points[2][0]) {
                        shapeList[image_id][shape_id]["x"] = x;
                        shapeList[image_id][shape_id]["y"] = y;
                        shapeList[image_id][shape_id]["width"] = w;
                        shapeList[image_id][shape_id]["height"] = h;

                        shape[0]["x"] = x;
                        shape[0]["y"] = y;
                        shape[0]["width"] = w;
                        shape[0]["height"] = h;
                    }
                }
                else {
                    if (deepICRCTX.debug === true) console.log("handle:", handleId);
                }
            }
            else if (shape[0]['type'] === "ellipse") {
                if (handleId !== null) {
                    let rx, ry, cx, cy;
                    if (handleId === "0" || handleId === "1") {
                        rx = parseInt((points[2][0] - points[0][0]) / 2);
                        ry = parseInt((points[3][1] - points[1][1]) / 2);
                        cx = parseInt(points[2][0]) - rx;
                        cy = parseInt(points[3][1]) - ry;
                    }
                    else {
                        rx = parseInt((points[2][0] - points[0][0]) / 2);
                        ry = parseInt((points[3][1] - points[1][1]) / 2);
                        cx = parseInt(points[0][0]) + rx;
                        cy = parseInt(points[1][1]) + ry;
                    }

                    if (rx > 6 && ry > 6) {
                        shapeList[image_id][shape_id]["cx"] = cx;
                        shapeList[image_id][shape_id]["cy"] = cy;
                        shapeList[image_id][shape_id]["rx"] = rx;
                        shapeList[image_id][shape_id]["ry"] = ry;

                        shape[0]["cx"] = cx;
                        shape[0]["cy"] = cy;
                        shape[0]["rx"] = rx;
                        shape[0]["ry"] = ry;
                    }
                }
                else {
                    if (deepICRCTX.debug === true) console.log("handle:", handleId);
                }
            }
            setDeepICRCTX({
                ...deepICRCTX,
                shapeList: shapeList,
                selectedShape: shape,
            })

        }
        else if (deepICRCTX.croppingToolId !== 1 && isStart === true && isSelected === true) {
            let endX = e.nativeEvent.offsetX;
            let endY = e.nativeEvent.offsetY;

            let dx = endX - prevPosX;
            let dy = endY - prevPosY;

            setPrevPosX(endX);
            setPrevPosY(endY);
            moveShape([dy / deepICRCTX.imageScale, dx / deepICRCTX.imageScale]);
            if(currentTarget !== null || currentTarget !== undefined){
                currentTarget.style.cursor = "grabbing";
            }
        }
        else if (isStart === true) {
            let endX = e.nativeEvent.offsetX;
            let endY = e.nativeEvent.offsetY;

            var x = Math.min(startX, endX);
            var y = Math.min(startY, endY);
            var w = Math.abs(endX - startX);
            var h = Math.abs(endY - startY);



            if (deepICRCTX.croppingToolId === 1) {
                document.getElementById('imgDiv').scrollLeft += startX - endX;
                document.getElementById('imgDiv').scrollTop += startY - endY;
                document.getElementById('imgViewer').style.cursor = 'grabbing';
            }
            else if (deepICRCTX.croppingToolId === 3) {
                setDeepICRCTX({
                    ...deepICRCTX,
                    currentShape: [{ type: "rect", x: x, y: y, width: w, height: h }],
                });
            }
            else if (deepICRCTX.croppingToolId === 4) {
                var wh = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width * deepICRCTX.imageScale;
                var ht = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height * deepICRCTX.imageScale;

                x = startX;
                y = startY;

                if (x - w < 0) w = x;
                if (y - h < 0) h = y;
                if (x + w > wh) w = Math.abs(wh - x);
                if (y + h > ht) h = Math.abs(ht - y);

                setDeepICRCTX({
                    ...deepICRCTX,
                    currentShape: [{ type: "ellipse", cx: x, cy: y, rx: w, ry: h }],
                });
            }
        }
    }

    function handleMouseUp(e) {
        e.stopPropagation();
        if (isStart === true && isHandle === true) {
            setIsHandle(false);
            setIsStart(false);
            setHandleId(null);

        }
        else if (deepICRCTX.croppingToolId !== 1 && isStart === true && isSelected === true) {
            let endX = e.nativeEvent.offsetX;
            let endY = e.nativeEvent.offsetY;

            let dx = endX - prevPosX;
            let dy = endY - prevPosY;

            setPrevPosX(endX);
            setPrevPosY(endY);
            moveShape([dy / deepICRCTX.imageScale, dx / deepICRCTX.imageScale]);
            setIsStart(false);
            setIsSelected(false);
            if(currentTarget !== null || currentTarget !== undefined){
                setCurrentTarget(null);
                currentTarget.style.cursor = "default";
            }
        }
        else if (isStart) {
            setIsStart(false);
            setIsSelected(false);
            let endX = e.nativeEvent.offsetX;
            let endY = e.nativeEvent.offsetY;
            let wx = e.nativeEvent.clientX;
            let wy = e.nativeEvent.clientY;

            var x = Math.min(startX, endX) / deepICRCTX.imageScale;
            var y = Math.min(startY, endY) / deepICRCTX.imageScale;
            var w = Math.abs(endX - startX) / deepICRCTX.imageScale;
            var h = Math.abs(endY - startY) / deepICRCTX.imageScale;

            if (deepICRCTX.croppingToolId === 1) {
                document.getElementById('imgDiv').scrollLeft += startX - endX;
                document.getElementById('imgDiv').scrollTop += startY - endY;
                document.getElementById('imgViewer').style.cursor = 'grab';
            }
            else if (deepICRCTX.croppingToolId === 2) {
                let pointX = e.nativeEvent.offsetX / deepICRCTX.imageScale;
                let pointY = e.nativeEvent.offsetY / deepICRCTX.imageScale;

                if (wx > clickX) {
                    setClickX(wx);
                    setClickY(wy);
                }

                let points = "";
                if (deepICRCTX.currentShape.length > 0) {
                    points = deepICRCTX.currentShape[0].points;
                    points += " " + pointX + "," + pointY;
                }
                else {
                    points = pointX + "," + pointY;
                }
                let pointCounter = points.split(" ").length;
                setDeepICRCTX({
                    ...deepICRCTX,
                    pointCounter: pointCounter,
                    currentShape: [{ type: "polygon", points: points, handle: "" }],
                });

            }
            else if (deepICRCTX.croppingToolId === 3) {
                if (w > 5 && h > 5) {
                    let shapes = deepICRCTX.shapeList;
                    let counter = objectSize(shapes[page_index]) + 1;
                    let shape_index = "s_" + counter;

                    if (page_index in shapes) {
                        shapes[page_index][shape_index] = { type: "rect", x: x, y: y, width: w, height: h, label: "Blank", meta: "" };
                    }
                    else {
                        shapes[page_index] = {}
                        shapes[page_index][shape_index] = { type: "rect", x: x, y: y, width: w, height: h, label: "Blank", meta: "" };
                    }

                    let shape = deepCopy(shapes[page_index][shape_index]);
                    shape['image_id'] = page_index;
                    shape['shape_id'] = shape_index;
                    shape['label'] = "Blank";

                    if (wy + 240 > window.innerHeight) {
                        wy = wy - 240;
                    }

                    setDeepICRCTX({
                        ...deepICRCTX,
                        shapeCounter: counter,
                        currentShape: [],
                        selectedShape: [shape],
                        shapeList: shapes,
                        popUpDialog: {
                            image_id: page_index,
                            shape_id: shape_index,
                            label: "Blank",
                            meta: "",
                            left: wx,
                            top: wy,
                            show: true
                        },
                    });
                }
                else {
                    setDeepICRCTX({
                        ...deepICRCTX,
                        currentShape: [],
                    });
                }
            }
            else if (deepICRCTX.croppingToolId === 4) {
                let wh = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
                let ht = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

                x = startX / deepICRCTX.imageScale;
                y = startY / deepICRCTX.imageScale;

                if (x - w < 0) w = x;
                if (y - h < 0) h = y;
                if (x + w > wh) w = Math.abs(wh - x);
                if (y + h > ht) h = Math.abs(ht - y);

                if (w > 5 && h > 5) {
                    let shapes = deepICRCTX.shapeList;
                    let counter = objectSize(shapes[page_index]) + 1;
                    let shape_index = "s_" + counter;

                    if (page_index in shapes) {
                        shapes[page_index][shape_index] = { type: "ellipse", cx: x, cy: y, rx: w, ry: h, label: "Blank", meta: "" };
                    }
                    else {
                        shapes[page_index] = {}
                        shapes[page_index][shape_index] = { type: "ellipse", cx: x, cy: y, rx: w, ry: h, label: "Blank", meta: "" };
                    }

                    let shape = deepCopy(shapes[page_index][shape_index]);
                    shape['image_id'] = page_index;
                    shape['shape_id'] = shape_index;
                    shape['label'] = "Blank";
                    shape['meta'] = "";

                    if (wy + 240 > window.innerHeight) {
                        wy = wy - 240;
                    }


                    setDeepICRCTX({
                        ...deepICRCTX,
                        shapeCounter: counter,
                        currentShape: [],
                        selectedShape: [shape],
                        shapeList: shapes,
                        popUpDialog: {
                            image_id: page_index,
                            shape_id: shape_index,
                            label: "Blank",
                            meta: "",
                            left: wx,
                            top: wy,
                            show: true
                        },
                    });
                } else {
                    setDeepICRCTX({
                        ...deepICRCTX,
                        currentShape: [],
                    });
                }
            }
        }


    }

    return (
        <>
            <svg
                id={'imgViewer'}
                style={{boxShadow: "0px 0px 0px 1px #e3e3e3",border:"2px solid red"}}
                ref={svgRef}
                height={height * deepICRCTX.imageScale}
                width={width * deepICRCTX.imageScale}
                >

                <image
                // deepICRCTX.fileBase64[deepICRCTX.pdfPage - 1]
                    xlinkHref={deepICRCTX.fileBase64[deepICRCTX.pdfPage - 1]}
                    x="0"
                    y="0"
                    height={height *deepICRCTX.imageScale}
                    width="100%" />
                <defs>
                    <filter x="0" y="0" width="1" height="1" id="solid">
                        <feFlood floodColor="#ff0066a8" result="bg" />
                        <feMerge>
                            <feMergeNode in="bg" />
                            <feMergeNode in="SourceGraphic" />
                        </feMerge>
                    </filter>
                </defs>

                <AllShapes {...props} />
                <CurrentShape imageIndex={props.imageIndex} />
                <SelectedShape imageIndex={props.imageIndex} />
            </svg>
            <PopupDialog />
        </>
    )
}

export default SvgImage
