import React, { useContext, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

import { makeStyles, withStyles } from '@material-ui/core';
import { withSnackbar } from 'notistack';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import ZoomIn from '@material-ui/icons/ZoomIn';
import ZoomOut from '@material-ui/icons/ZoomOut';
import ZoomOutMap from '@material-ui/icons/ZoomOutMap';
import NavigateBefore from '@material-ui/icons/NavigateBefore';
import NavigateNext from '@material-ui/icons/NavigateNext';
import RotateLeft from '@material-ui/icons/RotateLeft';
import RotateRight from '@material-ui/icons/RotateRight';
import Typography from '@material-ui/core/Typography';
import Measure from 'react-measure';
// import {pdfjs} from 'react-pdf';
import Button from '@material-ui/core/Button';
import { deepICRRotate } from '../../../deepICRCommon';
// import { setLoadingImage } from '../../../action/index.js'

// import resource files
import DeepICRContext from '../../../resources/DeepICRContext';

// pdfjs Setting
// pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

// Style Sheet
const useStyles = makeStyles(theme => ({
  styleInputViewer: {
    backgroundColor: theme.palette.deepICR.color,
    color: theme.palette.deepICR.backgroundColor,
    boxSizing: "border-box",
    height: "99.5%",
    display: "flex",
    flexDirection: "column",
    flex: 1,
    overflow: "hidden",
  },
  styleImage: {
    display: "flex",
    flexDirection: "column",
    flexGrow: 1,
    backgroundColor: theme.palette.deepICR.imageBackground,
    margin: theme.spacing(0, 0, 0, 0),
    boxSizing: "border-box",
    height: "100%",
    overflow: "hidden",
  },
  toolBtn: {
    padding: 8,
  },
  button: {
    padding: "3px 6px",
    fontSize: "0.9rem",
  },
  menuItem: {
    padding: "3px 32px 3px 32px",
    fontSize: "0.9rem",
  },

  styleFileUpload: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2
  }
}));
const CustomButton = withStyles({
  outlined: {
    '&$disabled': {
      color: "#ffffff",
      backgroundColor: "#888888",
    },
  },
  disabled: {},
})(Button);

// [React function component]
// Document viewer component
const DocumentViewer = ({ b64, fileSize, currentPageNumber }) => {

  const [deepICRCTX] = useContext(DeepICRContext);
  // if (deepICRCTX.file.type === 'application/pdf' || deepICRCTX.file.type === 'image/jpeg') {
  let width = fileSize[currentPageNumber - 1].width;
  let height = fileSize[currentPageNumber - 1].height;
  // console.log("Image height width",width,height);

  global.inputViewerWidth = width;
  global.inputViewerHeight = height;
  // console.log("Height Width input Viewer", height, width, deepICRCTX.imageScale);
  // console.log(" GlobalHeight Width input Viewer", global.inputViewerHeight, global.inputViewerWidth, deepICRCTX.imageScale);
  return (
    <>
      < div className='PdfProcessPageImageViewer__main' style={{ height: "100%", backgroundColor: "white", overflowX: "auto" }}>
        {
          <img id='image'
            height={fileSize[currentPageNumber - 1].height * deepICRCTX.imageScale}
            width={fileSize[currentPageNumber - 1].width * deepICRCTX.imageScale}
            // {fileSize[currentPageNumber - 1].width * deepICRCTX.imageScale}
            // className='img-fluid'
            src={b64[currentPageNumber - 1]}
          />
        }
      </div >

    </>

  );
}

// [React function component]
// Input viewer component

const InputViewer = ({ fileName, pages, currentPageNumber, setCurrentPageNumber, b64, rotation, setRotation }) => {
  const styles = useStyles();
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  if (deepICRCTX.debug === true) { console.log('inputViewer'); }

  // console.log("Locatiuon state in input viewer",location.state.fid);
  // console.log("File ID",fileId);
  const [measureWidth, setMeasureWidth] = useState({ width: 0 })
  let width = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
  let height = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

  // console.log(measureWidth,deepICRCTX.inputViewerBounds.bounds.width);

  // for multiple language
  const [t] = useTranslation();


  return (
    <div className={styles.styleInputViewer}>
      <Toolbar style={{ paddingLeft: 0, paddingRight: 0, borderBottom: "1px solid #EAEAF0" }}>
        <div style={{ width: "70%", overflowWrap: "break-word" }}>
          <Typography variant="h6" align="left" style={{ paddingLeft: 8 }}>
            {t('stringInputViewerTitle')}
            {fileName}
          </Typography>
        </div>

        <div style={{ width: "30%",display:"flex" }}>
          <div>
            {/* Zoom IN */}
            <IconButton
              className={styles.toolBtn}
              // disabled={(typeof deepICRCTX.file.name === "undefined") || (deepICRCTX.file.name === "")}
              onClick={() => {
                if (deepICRCTX.imageScale < 2) {
                  setDeepICRCTX({
                    ...deepICRCTX,
                    imageScale: deepICRCTX.imageScale + 0.1,
                  });
                  // console.log("clicked deepICRTX", deepICRCTX.imageScale);
                }
              }}
            >
              <ZoomIn />
            </IconButton>
            {/* ZOom OUT */}
            <IconButton
              className={styles.toolBtn}
              // disabled={(typeof deepICRCTX.file.name === "undefined") || (deepICRCTX.file.name === "")}
              onClick={() => {
                if (deepICRCTX.imageScale > 0.15) {
                  setDeepICRCTX({
                    ...deepICRCTX,
                    imageScale: deepICRCTX.imageScale - 0.1,
                  });
                  // console.log("clicked deepICRTX", deepICRCTX.imageScale);
                }
              }}
            >
              <ZoomOut />
            </IconButton>
            {/* Full Width */}
            <IconButton
              className={styles.toolBtn}
              // disabled={(typeof deepICRCTX.file.name === "undefined") || (deepICRCTX.file.name === "")}
              onClick={() => {
                setDeepICRCTX({
                  ...deepICRCTX,
                  // imageScale: 1,
                  imageScale: deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.fileSize[0].width,
                });
                // console.log("clicked deepICRTX",deepICRCTX.fileSize[0].width, deepICRCTX.imageScale);
              }}
            >
              <ZoomOutMap />
            </IconButton>
            {/* Left Rotate */}
            <IconButton
              className={styles.toolBtn}
              onClick={() => {

                const dataUrls = b64

                dataUrls[currentPageNumber - 1] = deepICRRotate(b64[currentPageNumber - 1], -90, deepICRCTX.fileSize[currentPageNumber - 1]);
                const fileSizes = deepICRCTX.fileSize;
                fileSizes[currentPageNumber - 1] = { "height": deepICRCTX.fileSize[currentPageNumber - 1].width, "width": deepICRCTX.fileSize[currentPageNumber - 1].height };

                // console.log("fileSize",fileSizes[currentPageNumber - 1]);

                global.rotation[currentPageNumber - 1] = global.rotation[currentPageNumber - 1] - 90;
                // console.log("Rotation Value",global.rotation);
                if (global.rotation[currentPageNumber - 1] === -360) { global.rotation[currentPageNumber - 1] = 0; }

                rotation.splice((currentPageNumber - 1), 1, global.rotation[currentPageNumber - 1])
                setRotation(rotation)

                setDeepICRCTX({
                  ...deepICRCTX,
                  // imageScale: 1,
                  fileBase64: dataUrls,
                  fileSize: fileSizes,
                  // imageScale: deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.fileSize[0].width,
                });
              }}
            >
              <RotateLeft />
            </IconButton>
            {/* Right Rotate */}
            <IconButton
              // data-id={(objectSize(deepICRCTX.shapeList) > 0)+" "+ (deepICRCTX.shapeList["p_" + width + "_" + height + "_" + (deepICRCTX.pdfPage)] !== undefined )+" "+ (objectSize(deepICRCTX.shapeList["p_" + width + "_" + height + "_" + (deepICRCTX.pdfPage)]) > 0)}
              className={styles.toolBtn}

              onClick={() => {
                const dataUrls = b64
                // console.log("Right rotation b64", dataUrls);
                // console.log("cuur Page",currentPageNumber);
                dataUrls[currentPageNumber - 1] = deepICRRotate(b64[currentPageNumber - 1], 90, deepICRCTX.fileSize[currentPageNumber - 1]);
                const fileSizes = deepICRCTX.fileSize;
                fileSizes[currentPageNumber - 1] = { "height": deepICRCTX.fileSize[currentPageNumber - 1].width, "width": deepICRCTX.fileSize[currentPageNumber - 1].height };
                // console.log("image height,width: ", deepICRCTX.fileSize[currentPageNumber - 1].height, deepICRCTX.fileSize[currentPageNumber - 1].width);
                // console.log("fileSize",fileSizes[currentPageNumber - 1]);

                global.rotation[currentPageNumber - 1] = global.rotation[currentPageNumber - 1] + 90;
                // console.log("Global Rotation Value", global.rotation);
                if (global.rotation[currentPageNumber - 1] === 360) { global.rotation[currentPageNumber - 1] = 0; }

                // update individual page's rotate value
                rotation.splice((currentPageNumber - 1), 1, global.rotation[currentPageNumber - 1])
                setRotation(rotation)
                // console.log("rotation",rotation);
                setDeepICRCTX({
                  ...deepICRCTX,
                  // imageScale: 1,
                  fileBase64: dataUrls,
                  fileSize: fileSizes,
                  // imageScale: deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.fileSize[0].width,
                });
              }}
            >
              <RotateRight />
            </IconButton>
          </div>
          <div style={{ align: 'right' }}>
            <IconButton
              className={styles.toolBtn}
              onClick={() => {
                currentPageNumber > 1 && setCurrentPageNumber(prev => prev - 1)
              }
              }>
              <NavigateBefore />
            </IconButton>
          </div>
          <div style={{display:"flex",alignItems:"center"}}>
            <Typography variant="h6" style={{ whiteSpace: 'nowrap' }}>{currentPageNumber} {'/'} {pages}</Typography>
          </div>
          <div>

            <IconButton
              className={styles.toolBtn}
              onClick={() => {
                // let pageNumber = deepICRCTX.pdfPage + 1;
                // if (pageNumber <= deepICRCTX.pdfPages) {
                //   setDeepICRCTX({
                //     ...deepICRCTX,
                //     pdfPage: pageNumber,
                //     selectedShape: [],
                //   });
                // }
                currentPageNumber < pages && setCurrentPageNumber(prev => prev + 1)

              }
              }>
              <NavigateNext />
            </IconButton>
          </div>
        </div>

      </Toolbar>
      <Measure
        bounds
        onResize={(contentRect) => {
          // console.log("Contentrect",contentRect);
          contentRect.bounds.height = parseInt(contentRect.bounds.height) - 0;
          contentRect.bounds.width = parseInt(contentRect.bounds.width) - 0;
          global.inputViewerBounds = contentRect;
          setMeasureWidth({ width: contentRect.bounds.width })
          setDeepICRCTX({
            ...deepICRCTX,
            inputViewerBounds: contentRect,
          });
        }}
      >
        {({ measureRef }) =>
          <div className={styles.styleImage} ref={measureRef}>
            {<DocumentViewer b64={b64} fileSize={deepICRCTX.fileSize} currentPageNumber={currentPageNumber} />}
          </div>
        }
      </Measure>

    </div>
  );
}

export default withSnackbar(InputViewer);
