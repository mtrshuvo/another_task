import React, { useState, useContext, useRef, useEffect } from 'react';

import { useTranslation } from 'react-i18next';
import { Button, makeStyles } from '@material-ui/core';
import DeepICRContext from '../../../resources/DeepICRContext';

const useStyles = makeStyles(theme => ({
    dialogContainer: {
        width: 256,
        height: "auto",
        background: "#fff",
        position: "absolute",
        borderRadius: 2,
        padding: 12,
        top: 100,
        left: 100,
        zIndex: 999,
        textAlign: "left",
        boxSizing: "border-box",
        fontSize: 14,
        boxShadow: "0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23)",
    },
    labelTitle: {
        width: 75,
    },
    dialogBody: {
        width: "100%",
        height: 200,
    },
    userSelect: {
        outline: "none",
        border: "none",
        borderBottom: "1px solid #d1d1d1",
    },
    textArea: {
        width: "100%",
        height: 64,
        fontSize: 14,
        resize: "none",
        backgroundColor: "#EAEAF0",
        padding: 5,
        boxSizing: "border-box",
    },
    modalAction: {
        textAlign: 'right',
    },
    btnCancel: {
        backgroundColor: "tomato",
        marginRight: 8,
    },
    btnSave: {
        backgroundColor: theme.palette.deepICR.blue4,
    },
}));

export default function PopupDialog() {
    const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
    const [charCount, setCharCount] = useState(255);

    const [label, setLabel] = useState("Blank");
    const [meta, setMeta] = useState("");

    const [t] = useTranslation();
    const styles = useStyles();

    const labelRef = useRef(null);
    const metaRef = useRef(null);

    useEffect(() => {
        setLabel(deepICRCTX.popUpDialog.label);
        setMeta(deepICRCTX.popUpDialog.meta);
    }, [deepICRCTX.popUpDialog])

    function updateLabelData(e) {
        setLabel(labelRef.current.value);
    }

    function updateMetaData(e) {
        let str = metaRef.current.value;
        if (str.length > 255) {
            str = str.substring(0, 255);
            metaRef.current.value = str;
            setCharCount(255 - str.length);
            setMeta(str);
        }
        else {
            setCharCount(255 - str.length);
            setMeta(str);
        }
    }

    function handleCancel() {
        let shapeList = deepICRCTX.shapeList;
        const imageId = deepICRCTX.popUpDialog.image_id;
        const shapeId = deepICRCTX.popUpDialog.shape_id;
        shapeList[imageId][shapeId]['image_id'] = imageId;
        shapeList[imageId][shapeId]['shape_id'] = shapeId;
        
        setDeepICRCTX({
            ...deepICRCTX,
            shapeList: shapeList,
            selectedShape:[shapeList[imageId][shapeId]],
            popUpDialog: {
                image_id: "",
                shape_id: "",
                label: "Cancel",
                meta: "",
                left: 0,
                top: 0,
                show: false,
            },
        });
        setCharCount(255);
    }


    function handleSave() {
        const imageId = deepICRCTX.popUpDialog.image_id;
        const shapeId = deepICRCTX.popUpDialog.shape_id;

        let shapeList = deepICRCTX.shapeList;
        shapeList[imageId][shapeId]['label'] = label;
        shapeList[imageId][shapeId]['meta'] = meta;
        shapeList[imageId][shapeId]['image_id'] = imageId;
        shapeList[imageId][shapeId]['shape_id'] = shapeId;

        setLabel(shapeList[imageId][shapeId]['label']);
        setMeta(shapeList[imageId][shapeId]['meta']);

        setDeepICRCTX({
            ...deepICRCTX,
            shapeList: shapeList,
            selectedShape:[shapeList[imageId][shapeId]],
            popUpDialog: {
                image_id: "",
                shape_id: "",
                label: "Save",
                meta: "",
                left: 0,
                top: 0,
                show: false,
            },
        });
        setCharCount(255);
    }

    return (
        <>
            { deepICRCTX.popUpDialog.show &&
                <div style={{ position: "absolute",zIndex:99999, left: 0, right: 0, top: 0, bottom: 0,background:"none" }}>
                    <div className={styles.dialogContainer} style={{ left: deepICRCTX.popUpDialog.left, top: deepICRCTX.popUpDialog.top }}>
                        <form onSubmit={() => handleSave()}>
                            <table className={styles.dialogBody}>
                                <tbody>
                                    <tr>
                                        <td className={styles.labelTitle}>{t("stringLabelId")}</td>
                                        <td>:</td>
                                        <td>{deepICRCTX.popUpDialog.shape_id.split("_")[1]}</td>
                                    </tr>
                                    <tr>
                                        <td className={styles.labelTitle}>{t("stringLabelType")}</td>
                                        <td>:</td>
                                        <td>
                                            <select className={styles.userSelect} ref={labelRef} value={label} onChange={(e) => updateLabelData(e)} >
                                                <option key={1} value="Blank">{t("stringBlank")}</option>
                                                <option key={3} value="Single Line">{t("stringSingleLine")}</option>
                                                <option key={4} value="Multi Line">{t("stringMultiline")}</option>
                                                <option key={2} value="Table">{t("stringTable")}</option>
                                                <option key={5} value="Image">{t("stringImage")}</option>
                                                <option key={6} value="Handwritten">{t("stringHandwritten")}</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td className={styles.labelTitle}>{t("stringMetaInfo") + "*"}</td>
                                        <td>:</td>
                                        <td><small>{"(" + charCount + " " + t("stringRemainChar") + ")"}</small></td>
                                    </tr>
                                    <tr>
                                        <td colSpan={3}>
                                            <textarea className={styles.textArea} ref={metaRef} value={meta} onChange={(e) => updateMetaData(e)} />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colSpan={3} className={styles.modalAction}>
                                            <Button
                                                onClick={(e) => handleCancel(e)}
                                                className={styles.btnCancel}>
                                                {t("stringCancel")}
                                            </Button>
                                            <Button
                                                onClick={(e) => handleSave(e)}
                                                className={styles.btnSave}>
                                                {t("stringSave")}
                                            </Button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </form>
                    </div >
                </div>
            }
        </>
    )
}
