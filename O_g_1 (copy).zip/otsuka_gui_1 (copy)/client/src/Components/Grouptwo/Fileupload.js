import React, { useContext, useState, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom'


import axios from 'axios'
import _, { reject } from 'lodash'
import { toast } from 'react-toastify';
import AWS from 'aws-sdk'
import md5 from 'md5'
import { uploadFile } from 'react-s3';

import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core';
import { setUploadedFiles, fileUploadActivePage } from '../../action/index';
import SecondNav from '../SecondNav/SecondNav';
import Loader from '../Loader/Loader'
import MenuBar from '../Shared/MenuBar/MenuBar';


// Style Sheet
const useStyles = makeStyles(theme => ({

    styleFileUpload: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,
        overflowY: 'hidden',
        marginBottom: 5,
        marginTop: 3
    },
    styleUpload: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,
        overflowY: 'hidden',
        marginBottom: 5,
        marginTop: 3,
        marginLeft: 10
    }
}));
// {t('stringInputViewerTitle')} 


const Fileupload = () => {


    const navigate = useNavigate()
    const styles = useStyles()
    const dispatch = useDispatch()
    // for multiple language
    const [t] = useTranslation();

    //Logged in User Object Id from redux
    const jwt = useSelector((state) => state.reducer.jwt);
    // Logged inUser Session Id from redux
    const sessionId = useSelector((state) => state.reducer.sessionId);
    const reduxUserName = useSelector((state) => state.reducer.userName)
    const reduxEmail = useSelector((state) => state.reducer.email)
    // Uploader Id
    const id = useSelector((state) => state.reducer._id);

    const uploadedFiles = useSelector((state) => state.reducer.uploadedFiles)

    // Use States
    const [selectedFile, setSelectedFile] = useState([])
    // File or folder selection state 
    const [option, setOption] = useState("Folder")
    // saving file info which will go to backend to save to file info
    const [filesInformation, setFileInfo] = useState([])
    // loading State
    const [loading, setLoading] = useState(false)
    //    Set File Info for sending data to s3 and server
    const [uploadedFileInfo, setUploadedFileInfo] = useState([])
    // let formData 
    const getFile = (e) => {
        var selectedArrFiles = []
        var arrayFiles = Array.from(e.target.files)
        for (let i = 0; i < arrayFiles.length; i++) {
            if ((arrayFiles[i].type === 'application/pdf' || arrayFiles[i].type === 'image/jpeg' || arrayFiles[i].type === 'image/png' || arrayFiles[i].type === 'image/jpg') && arrayFiles[i].size !== 0) {
                selectedArrFiles.push(arrayFiles[i])
            }

        }
        setSelectedFile(selectedArrFiles)
        // console.log("selected Files", selectedArrFiles);
        dispatch(setUploadedFiles(selectedArrFiles))
    }

    // With AWS Secret Key and access key
    // const uploadFiles = async (e) => {
    //     if (uploadedFiles.length === 0) {
    //         toast.warning(t('stringNoFileSelected'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
    //         setLoading(false)
    //     } else {
    //         setLoading(true)
    //         dispatch(fileUploadActivePage(true))
    //         uploadedFiles.forEach(async (element, ind) => {

    //             var fileInfo = {}
    //             const params = {
    //                 Body: element,
    //                 Bucket: `${process.env.REACT_APP_S3_BUCKET}`,
    //                 Key: `files/${userHash}/${test()}/${element.name}`
    //             };
    //             const res = await S3.upload(params).promise()
    //             // console.log("Response AWS", res);
    //             if (res?.Location) {
    //                 fileInfo.fileName = element?.name
    //                 fileInfo.fileSize = element?.size
    //                 fileInfo.key = encodeURI(res?.Key)
    //                 fileInfo.fileLink = res?.Location
    //                 fileInfo.arraySize = ind + 1
    //                 // test()
    //                 const response = await fetch(`${process.env.REACT_APP_URL}/api/v1/file/fileupload`, {
    //                     method: "POST",
    //                     headers: {
    //                         "Content-Type": "application/json",
    //                         Accept: "application/json",
    //                         "Authorization": "Bearer " + jwt,
    //                         "sid": sessionId
    //                     },
    //                     body: JSON.stringify({
    //                         fileInfo: fileInfo
    //                     })
    //                 })
    //                 const data = await response.json()
    //                 if (response.status === 200) {
    //                     if (ind === uploadedFiles.length - 1) {
    //                         toast.success(t('stringFileUploadMessage'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
    //                     }

    //                     setLoading(false)
    //                     dispatch(setUploadedFiles([]))
    //                     dispatch(fileUploadActivePage(false))
    //                 } else {
    //                     toast.warning(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
    //                     setLoading(false)
    //                     dispatch(fileUploadActivePage(false))
    //                 }

    //             } else {
    //                 setLoading(false)
    //                 dispatch(fileUploadActivePage(false))
    //             }
    //         });
    //     }

    // }


    // WIth presigned url
    const uploadFiles = async (e) => {
        if (uploadedFiles.length === 0) {
            toast.warning(t('stringNoFileSelected'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
            setLoading(false)
        } else {
            setLoading(true)
            dispatch(fileUploadActivePage(true))
            let awsKey = `files/${userHash}/${test()}`
            uploadedFiles.forEach(async (element, ind) => {

                const formData = new FormData()

                const response = await fetch(`${process.env.REACT_APP_URL}/api/v1/file/getpresignedurl`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Accept: "application/json",
                        "Authorization": "Bearer " + jwt,
                        "sid": sessionId
                    },
                    body: JSON.stringify({
                        key: `${awsKey}/${element.name}`
                    })
                })

                const data = await response.json()
                // console.log(data);
                // formData.append('Content-Type', element.type);
                Object.entries(data.fields).forEach(([k, v]) => {
                    if (k === 'bucket') {
                        // console.log("bucket key check", k, v);
                    } else {
                        formData.append(k, v);
                    }

                });

                formData.append('file', element);

                // console.log("URL",data.url);
                const uploadToAws = await axios.post(data.url, formData, {
                    headers: { 'Content-Type': 'multipart/form-data' },
                });

                // console.log("Aws uploaded response", uploadToAws);
                const fileInfo = {}
                if (uploadToAws.status === 204) {
                    fileInfo.fileName = element?.name
                    fileInfo.fileSize = element?.size
                    fileInfo.key = encodeURI(`${awsKey}/${element.name}`)
                    fileInfo.arraySize = ind + 1
                    const response = await fetch(`${process.env.REACT_APP_URL}/api/v1/file/fileupload`, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            Accept: "application/json",
                            "Authorization": "Bearer " + jwt,
                            "sid": sessionId
                        },
                        body: JSON.stringify({
                            fileInfo: fileInfo
                        })
                    })
                    const data = await response.json()
                    if (response.status === 200) {
                        if (ind === uploadedFiles.length - 1) {
                            toast.success(t('stringFileUploadMessage'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
                            setLoading(false)
                            dispatch(setUploadedFiles([]))
                            dispatch(fileUploadActivePage(false))
                        }

                    } else {
                        toast.warning(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
                        setLoading(false)
                        dispatch(fileUploadActivePage(false))
                    }
                } else {
                    toast.warning(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
                    setLoading(false)
                    dispatch(fileUploadActivePage(false))
                }
            });
        }

    }

    var userHash
    var date
    var dates
    const test = () => {
        date = new Date()
        dates = date.getFullYear() + ("0" + (date.getMonth() + 1)).slice(-2) + ("0" + date.getDate()).slice(-2) + ("0" + date.getHours()).slice(-2) + ("0" + date.getMinutes()).slice(-2) + ("0" + date.getSeconds()).slice(-2)
        return dates
    }

    // For Local Update
    // const uploadFiles = (e) => {

    //     setLoading(true)
    //     const formData = new FormData()


    //     // _.forEach(selectedFile, file => {
    //     //     setSelectedFile(...selectedFile, encodeURIComponent(file.name))
    //     //     // console.log("in loop ", selectedFile);
    //     // })
    //     // console.log("After encoding", selectedFile);

    //     _.forEach(selectedFile, file => {
    //         formData.append('file', file)
    //     })


    //     if (selectedFile.length === 0) {
    //         toast.warning("No file Selected", { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
    //         setLoading(false)
    //     }
    //     else {
    //         dispatch(fileUploadActivePage(true))
    //         axios.post(`${process.env.REACT_APP_URL}/api/v1/file/fileupload`, formData, {
    //             headers: {
    //                 "Content-Type": "multipart/form-data",
    //                 "Authorization": "Bearer " + jwt,
    //                 "sid": sessionId
    //             }
    //         })
    //             .then((res) => {
    //                 // console.log(res)
    //                 toast.success("File Uploaded successfully", { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
    //                 // setTimeout(() => {
    //                 //     setLoading(false)
    //                 // }, 3000);
    //                 setLoading(false)
    //                 dispatch(setUploadedFiles([]))
    //                 dispatch(fileUploadActivePage(false))
    //             })
    //             .catch(err => {
    //                 toast.warning("Something Went Wrong", { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
    //                 console.log(err)
    //                 setLoading(false)
    //                 dispatch(fileUploadActivePage(false))
    //             })
    //     }

    // }

    //For Handling file upload get File useState 
    //Always gave prev state value resolved

    useEffect(() => {
        dispatch(setUploadedFiles(uploadedFiles))
        userHash = md5(reduxEmail)
    }, [uploadedFiles])


    return (
        <>
            <MenuBar />
            {
                loading ? <Loader loading={loading} /> :
                    <>
                        <SecondNav />
                        {/* <Userinfo /> */}
                        <div className='file-upload-head'>
                            <span className='text-label'>{t('selectFileOrFolder')}</span>
                            <select className="selectpicker mx-5" data-width="fit" onChange={(e) => { setOption(e.target.value) }}>
                                <option value="Folder" selected={option === 'Folder' ? true : false}>{t('stringFolder')}</option>
                                <option value="File" selected={option === 'File' ? true : false}>{t('stringFile')}</option>
                            </select>
                            <input type="text" className="form__input" readOnly placeholder={uploadedFiles.length > 0 ? `${uploadedFiles.length} ${t('stringFileSelected')}` : ""} />
                            {
                                option === 'Folder' ?
                                    <>
                                        <input
                                            type="file"
                                            name="file"
                                            style={{ display: "none" }}
                                            id="folderUploadInputButton"
                                            directory=""
                                            multiple
                                            webkitdirectory=""
                                            encType="multipart/form-data"
                                            onChange={getFile}
                                            onClick={(event) => {
                                                event.target.value = null
                                                setFileInfo([])
                                            }}
                                        />
                                        <label htmlFor="folderUploadInputButton">
                                            <Button
                                                className={styles.styleFileUpload}
                                                variant="outlined"
                                                component="span">
                                                <Typography variant="h6">
                                                    {t('stringBrowse')}
                                                </Typography>
                                            </Button>
                                        </label>
                                    </>
                                    :
                                    <>
                                        <input
                                            type="file"
                                            accept="*"
                                            style={{ display: "none" }}
                                            id="fileUploadInputButton"
                                            multiple
                                            onChange={getFile}
                                            onClick={(event) => {
                                                event.target.value = null
                                                setFileInfo([])
                                            }}
                                        />
                                        <label htmlFor="fileUploadInputButton">
                                            <Button
                                                className={styles.styleFileUpload}
                                                variant="outlined"
                                                component="span">
                                                <Typography variant="h6">
                                                    {t('stringBrowse')}
                                                </Typography>
                                            </Button>
                                        </label>
                                    </>
                            }
                            <Button
                                className={styles.styleUpload}
                                variant="outlined"
                                component="span"
                                onClick={(e) => uploadFiles()}
                            >
                                <Typography variant="h6" >
                                    {t('stringUpload')}
                                </Typography>
                            </Button>
                        </div>

                        <div className='file-upload-bottom-btn' >
                            <Button
                                className={styles.styleFileUpload}
                                variant="outlined"
                                component="span"
                                onClick={() => navigate('/pdfprocess')}
                            >
                                <Typography variant="h6">
                                    {t('stringCheckPdfFile')}
                                </Typography>

                            </Button>
                        </div>

                    </>
            }

        </>


    )
}

export default Fileupload
