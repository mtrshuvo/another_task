import React, { useEffect, useState, useContext } from 'react'
// import {Page, Document, pdfjs} from "react-pdf/dist/entry.webpack"
import 'react-pdf/dist/Page/AnnotationLayer.css'
import { pdfjs,Document, Page } from 'react-pdf';
import invoice from "../../../images/invoice.pdf"
import gui from "../../../images/jp.pdf"
import masterpdf from "../../../images/01_01_Master.pdf"
import DeepICRContext from '../../../resources/DeepICRContext'

pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

const PdfProcessPageImageViewer = (props) => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);

  const [pages, setNumpages] = useState(null);
  const [pageNumber, setPageNumber] = useState(1);
  const [b64, setb64] = useState(null)

  const getFile = (uploadedFiles) => {
		// console.log("Pdf File uploaded",e.target.files[0]);
		// if (typeof e.target.files[0] === 'undefined') { return; }

		

		// convert pdf file to jpeg images
		const pdfToJpeg = async (dataUrl) => {
			const tmpBase64 = dataUrl.split(',', 2)[1];
			// console.log(tmpBase64);
			// setb64(tmpBase64)
			const dataUrls = [];
			const fileSizes = [];
			const pdf = await pdfjs.getDocument({
				data: atob(tmpBase64),
				cMapUrl: `//cdn.jsdelivr.net/npm/pdfjs-dist@${pdfjs.version}/cmaps/`,
				cMapPacked: true
			}).promise;
			
			let page;
			for (let i = 0; i < pdf.numPages; i++) {
				page = await pdf.getPage(i + 1);
				const oList = await page.getOperatorList();
				let j;
				
				let scale = 1;
				let canvasHeight = 0;
				let canvasWidth = 0;
				// Not jpeg file in pdf
				const viewportPdf = await page.getViewport({ scale: 1 });
				if (viewportPdf.height > viewportPdf.width) {
					scale = deepICRCTX.pdfDefaultHeight / viewportPdf.height;
					canvasHeight = deepICRCTX.pdfDefaultHeight;
					canvasWidth = Math.ceil(viewportPdf.width * scale);
				} else {
					scale = deepICRCTX.pdfDefaultHeight / viewportPdf.width;
					canvasWidth = deepICRCTX.pdfDefaultHeight;
					canvasHeight = Math.ceil(viewportPdf.height * scale);
				}
				// }
				const canvas = document.createElement("canvas");
				const viewport = await page.getViewport({ scale: scale });
				canvas.height = canvasHeight;
				canvas.width = canvasWidth;
				const context = canvas.getContext("2d");
				const task = page.render({
					canvasContext: context,
					viewport: viewport,
				})
				// console.log("pdf",task);
				try {
					await task.promise;
				}
				catch (e) { console.log(e); };
				dataUrls.push(canvas.toDataURL('image/jpeg'))
				fileSizes.push({ height: canvasHeight, width: canvasWidth });
			}
			setb64(dataUrls[0]);
			// console.log(dataUrls);
			return ([dataUrls, fileSizes, pdf.numPages]);
		}

		const file = uploadedFiles
		// e.target.files[0];
		
		const reader = new FileReader();
		reader.readAsDataURL(file);
		reader.onload = (e) => {
			// if(file.type === 'image/jpeg' || file.type === 'image/png') {
			if (file.type === 'image/jpeg') {
				const img = new Image();
				img.onload = () => {
					global.rotation = [0];
					setDeepICRCTX({
						...deepICRCTX,
						isContract: false,
						documentId: "",
						imageScale: deepICRCTX.inputViewerBounds.bounds.width / img.width,
						file: file,
						requestedFile: "",
						fileBase64: [reader.result],
						fileSize: [{ height: img.height, width: img.width }],
						pdfBase64: "",
						pdfPage: 1,
						pdfPages: 1,
						targetPages: "",
						size: 12,
						originalOutputFontScale: 1,
						originalOutputSize: { height: 0, width: 0 },
						originalOutputData: { data: [] },
						originalOutputTable: { data: [] },
						extractedOutputData: { data: [] },
						extractedOutputTable: { data: [] },
						searchText: "",
						outputSw: false,
						croppingToolId: 6,
						shapeList: {},
						currentShape: [],
						selectedShape: [],
						shapeCounter: 0,
						pointCounter: 0,
						selectionPoints: [],
						popUpDialog: { "image_id": "", "shape_id": "", "label": "", "meta": "", "left": 0, "top": 0, "show": false },
					});
				};
				img.src = e.target.result;
			} else if (file.type === 'application/pdf') {
				Promise.resolve()
					.then(() => {
						return new Promise((resolve, reject) => {
							resolve(pdfToJpeg(reader.result));
						});
					})
					.then(([dataUrls, fileSizes, pdfPages]) => {
						global.rotation = [];
						for (let i = 0; i < pdfPages; i++) {
							global.rotation.push(0);
						}
						setDeepICRCTX({
							...deepICRCTX,
							isContract: false,
							documentId: "",
							imageScale: deepICRCTX.inputViewerBounds.bounds.width / fileSizes[0].width,
							file: file,
							requestedFile: "",
							fileBase64: dataUrls,
							fileSize: fileSizes,
							pdfBase64: reader.result,
							pdfPage: 1,
							pdfPages: pdfPages,
							targetPages: "",
							size: 12,
							originalOutputFontScale: 1,
							originalOutputSize: { height: 0, width: 0 },
							originalOutputData: { data: [] },
							originalOutputTable: { data: [] },
							extractedOutputData: { data: [] },
							extractedOutputTable: { data: [] },
							searchText: "",
							outputSw: false,
							croppingToolId: 6,
							shapeList: {},
							currentShape: [],
							selectedShape: [],
							shapeCounter: 0,
							pointCounter: 0,
							selectionPoints: [],
							popUpDialog: { "image_id": "", "shape_id": "", "label": "", "meta": "", "left": 0, "top": 0, "show": false },
						});
					})
					.catch((e) => {
						if (deepICRCTX.debug === true) console.log(e);
						// props.enqueueSnackbar(
						// 	t('errorPdfToJpegProcess'),
						// 	{ variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
						// );
					});
			}
		}
	}
  // const onDocumentLoadSuccess = ({numPages})=> {
    
  //   setNumpages(numPages);
  //   setPageNumber(1);
  // }


  
  // const changePage = (offset)=> {
  //   setPageNumber(prevPageNumber => prevPageNumber + offset)
  // }

  // const previousButton = () => changePage(-1) ;
  
  // const nextButton = () => changePage(1);

  // document.addEventListener("contextmenu", (event) => {
  //   event.preventDefault();
  // });

useEffect(()=> {
	if (props.uploadedFiles) {
		getFile(props.uploadedFiles)
	}
 	
  // const fileUrl = new URL(gui, );
})


  return (
	<>
	{/* <input type='file' onChange={getFile}/> */}
	<div className='PdfProcessPageImageViewer__main'>
	 {b64 === null ? <></>:<img id='image' width={'70%'} src={b64} />}
        {/* <img className='img-fluid' src={invoice} /> */}
        {/* onLoadSuccess={onDocumentLoadSuccess} */}
        {/* <Document  file={gui}   >
          <Page width="700" pageNumber={1}/>
        </Document> */}
        {/* <p>{pageNumber} / {pages}</p>
        {pageNumber > 1 && <button >back</button>}
        {pages > pageNumber && <button>Next</button>} */}


    </div>
	</>
    
  )
}

export default PdfProcessPageImageViewer