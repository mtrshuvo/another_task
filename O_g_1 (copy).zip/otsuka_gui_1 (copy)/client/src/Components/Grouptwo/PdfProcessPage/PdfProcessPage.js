import React, { useState, useContext, useEffect } from "react";
import { useLocation, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux'


import { totalFile,resetCredentials } from "../../../action/index";

import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import { makeStyles, withStyles } from "@material-ui/core";
import { Tabs, Tab } from '@material-ui/core';
import AWS from 'aws-sdk'

import { useTranslation } from 'react-i18next';
import { toast } from 'react-toastify';
import { pdfjs, } from 'react-pdf';
import {
    Modal, ModalFooter,
    ModalHeader, ModalBody
} from "reactstrap"


import DeepICRContext from '../../../resources/DeepICRContext'
import deepICRTheme from '../../../resources/deepICRTheme';
import { deepICRRotate } from '../../../deepICRCommon';
import MemoInput from "./MemoInput";
import SecondNav from "../../SecondNav/SecondNav";
import Loader from "../../Loader/Loader";
import MenuBar from "../../Shared/MenuBar/MenuBar";


const useStyles = makeStyles((theme) => ({
    styleFileUpload: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2
    },
    styleOutputs: {
        margin: theme.spacing(0, 0, 0, 0),
        boxSizing: "border-box",
        height: "100%",
    },
    styleOutput: {
        display: "flex",
        flexDirection: "column",
        flexGrow: 1,
        backgroundColor: theme.palette.deepICR.outputBackground,
        boxSizing: "border-box",
        height: "100%",
    },
}));

const CustomButton = withStyles({
    outlined: {
        '&$disabled': {
            color: "#ffffff",
            backgroundColor: "#888888",
        },
    },
    disabled: {},
})(Button);

const CustomTabs = withStyles({
    indicator: {
        backgroundColor: deepICRTheme.palette.deepICR.blue4,
    },
})(Tabs);



// Set Tab Property
const retProps = (value, index) => {
    if (value === index) {
        return {
            id: `tabpanel-${index}`,
            style: {
                minHeight: "auto",
                backgroundColor: 'inherit',
                color: deepICRTheme.palette.deepICR.blue4,
                // fontSize: deepICRTheme.palette.deepICR.tabFontSize,
                fontSize: "0.9rem",
            },
        };
    } else {
        return {
            id: `tabpanel-${index}`,
            style: {
                // fontSize: deepICRTheme.palette.deepICR.tabFontSize,
                minHeight: "auto",
                fontSize: "0.9rem",
            },
        };
    }
}


const PdfProcessPage = () => {
    const location = useLocation()
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const styles = useStyles();
    // for multiple language
    const [t] = useTranslation();

    const S3 = new AWS.S3({
        accessKeyId: process.env.REACT_APP_ACCESS_KEY,
        secretAccessKey: process.env.REACT_APP_SECRET_ACCESS_KEY,
        region: process.env.REACT_APP_REGION,
        httpOptions: {
            connectTimeout: 2 * 1000, // time succeed in starting the call
            timeout: 5 * 1000, // time to wait for a response
        },
    })



    const [deepICRCTX, setDeepICRCTX, pdfBase64] = useContext(DeepICRContext);
    // Getting all uploaded files from redux store
    const uploadedFiles = useSelector((state) => state.reducer.uploadedFiles)
    const rpaCheck = useSelector((state) => state.filterReducer.rpaCheck);
    // Total Pages of pdf
    const [pages, setNumpages] = useState(1);
    // Current page number of pdf
    const [currentPageNumber, setCurrentPageNumber] = useState(1);
    // storing the base 64 value of all pages of a pdf
    const [b64, setb64] = useState([]);
    // Next previous image count track from uploaded Files
    const [tableFileSeq, setTableFileSeq] = useState(0)
    // To save Rotation value of individual pages
    // the array will be like [0->page1,90->page2,0->page3]
    const [rotation, setRotation] = useState([])
    // loading State
    const [loading, setLoading] = useState(false)
    //Storing OCR pages number
    const [ocrPageInfo, setOcrPageInfo] = useState('')
    // ocr input number page input error tracking
    const [ocrPageErr, setOcrPageErr] = useState(false)
    // ocr page array
    const [ocrPageArr, setOcrPageArr] = useState([])
    const [value, setValue] = useState(0);
    const [approver, setApprover] = useState([])
    // Single File Previous next object Id saving state
    const [prevNext, setPrevNext] = useState({
        prev: [],
        next: []
    })
    // Modal open state
    const [modal, setModal] = useState(false);

    // Tracking if the click from delete or start ocr
    const [clickedBtn, setClickedBtn] = useState("")

    // Toggle for Modal
    const toggle = () => setModal(!modal);

    // memoInput Value state
    const [memoInput, setMemoInput] = useState({
        protocolNo: "",
        actualWorkingDate: "",
        paymentRequestDate: "",
        firstApprover: [],
        costCenter: "",
        description: ""

    })
    // set file Id
    const [fid, setFid] = useState('')
    // if(location.state!==null){
    //      setFid(location.state.fid)
    // }else{
    //      setFid('nofileId')
    // }

    // set currentfile  objct id,filename,file Size to send in start OCR
    const [ocrInfo, setOcrInfo] = useState({
        _id: "",
        fileName: "",
        fileSize: "",
        fileKey: ""
    })

    // set filename
    const [fileName, setFileName] = useState('')

    // Credentials from redux fileReducer
    const isSuperAdmin = useSelector((state) => state.reducer.isSuperAdmin)
    const jwt = useSelector((state) => state.reducer.jwt)
    const sessionId = useSelector((state) => state.reducer.sessionId)
    // Uploader Id
    const id = useSelector((state) => state.reducer._id);
    const totalFiles = useSelector((state) => state.reducer.totalFile)
    // Filtered Value from filter Reducer Redux
    const startDate = useSelector((state) => state.filterReducer.startDate);
    const endDate = useSelector((state) => state.filterReducer.endDate);
    const selectedId = useSelector((state) => state.filterReducer.selectedId);



    const changeOffset = (offset) => {
        setCurrentPageNumber(prev => prev + offset);
    }

    const prevPdfBtn = () => changeOffset(-1)
    const nextPdfBtn = () => changeOffset(+1)

    const rightRotation = () => {

        const dataUrls = b64
        // console.log("Right rotation b64", dataUrls);
        // console.log("cuur Page",currentPageNumber);
        dataUrls[currentPageNumber - 1] = deepICRRotate(b64[currentPageNumber - 1], 90, deepICRCTX.fileSize[currentPageNumber - 1]);
        const fileSizes = deepICRCTX.fileSize;
        fileSizes[currentPageNumber - 1] = { "height": deepICRCTX.fileSize[currentPageNumber - 1].width, "width": deepICRCTX.fileSize[currentPageNumber - 1].height };
        // console.log("image height,width: ", deepICRCTX.fileSize[currentPageNumber - 1].height, deepICRCTX.fileSize[currentPageNumber - 1].width);
        // console.log("fileSize",fileSizes[currentPageNumber - 1]);

        global.rotation[currentPageNumber - 1] = global.rotation[currentPageNumber - 1] + 90;
        // console.log("Global Rotation Value", global.rotation);
        if (global.rotation[currentPageNumber - 1] === 360) { global.rotation[currentPageNumber - 1] = 0; }

        // update individual page's rotate value
        rotation.splice((currentPageNumber - 1), 1, global.rotation[currentPageNumber - 1])
        setRotation(rotation)
        // console.log("rotation",rotation);
        setDeepICRCTX({
            ...deepICRCTX,
            // imageScale: 1,
            fileBase64: dataUrls,
            fileSize: fileSizes,
            imageScale: deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.fileSize[0].width,
        });
    }
    // rotateimage(-90)
    const leftRotation = () => {
        const dataUrls = b64

        dataUrls[currentPageNumber - 1] = deepICRRotate(b64[currentPageNumber - 1], -90, deepICRCTX.fileSize[currentPageNumber - 1]);
        const fileSizes = deepICRCTX.fileSize;
        fileSizes[currentPageNumber - 1] = { "height": deepICRCTX.fileSize[currentPageNumber - 1].width, "width": deepICRCTX.fileSize[currentPageNumber - 1].height };

        // console.log("fileSize",fileSizes[currentPageNumber - 1]);

        global.rotation[currentPageNumber - 1] = global.rotation[currentPageNumber - 1] - 90;
        // console.log("Rotation Value",global.rotation);
        if (global.rotation[currentPageNumber - 1] === -360) { global.rotation[currentPageNumber - 1] = 0; }

        rotation.splice((currentPageNumber - 1), 1, global.rotation[currentPageNumber - 1])
        setRotation(rotation)

        setDeepICRCTX({
            ...deepICRCTX,
            // imageScale: 1,
            fileBase64: dataUrls,
            fileSize: fileSizes,
            imageScale: deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.fileSize[0].width,
        });
    }

    // Getting base 64 value api from database
    // Getting the file id from useLocation
    const getSingleFile = async (fids) => {
        // console.log("Location State",location.state.fid,location.state.fName);
        // console.log("Paginated fid", fids);
        setLoading(true)
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/file?fid=${fids}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                "Authorization": "Bearer " + jwt,
                "sid": sessionId
            },
            mode: 'cors',
            body: JSON.stringify({
                uploadedBy: selectedId.length > 0 ? selectedId : [id],
                startDate: startDate,
                endDate: endDate,
                rpaCheck: rpaCheck
            })
        })
        const data = await res.json()
        // console.log("Getting data",data);
        if (res.status === 200 && data) {
            setPrevNext({
                prev: data.prev,
                next: data.next
            })
            setFid(data?.data._id)
            dispatch(totalFile(data))
            // dispatch(totalFile(data.notStartedFile))
            // console.log("Getting single file data", data);
            setFileName(data?.data.fileName)
            setOcrInfo({
                _id: data?.data._id,
                fileName: data.data.fileName,
                // data.size is for local development
                fileSize: data.size || data.data.fileSize,
                fileKey: data.data.fileKey
            })
            const fileType = data.data.fileName.split('.')
            if (fileType[fileType.length - 1] === 'png' || fileType[fileType.length - 1] === 'jpg' || fileType[fileType.length - 1] === 'jpeg') {
                imageConvert(data).then(success => {
                    // console.log("success",success);
                    setLoading(false)

                }).catch((err => {
                    // console.log("Error",err);
                    setLoading(false)
                    toast.error(t('stringImageConversion'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
                }))
            } else {
                if (data.base64) {
                     pdfToJpeg(data.base64).then(success =>{
                        setLoading(false)
                     }).catch((err => {
                        // console.log("Error",err);
                        setLoading(false)
                        toast.error(t('stringImageConversion'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
                    }))
                }
                // else{
                //     setLoading(false)
                //     toast.error(t('stringImageConversion'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
                // }

            }
        }
        else if(res.status===401){
            toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
            dispatch(resetCredentials())
            navigate('/login', { state: { isLoading: false } })
          }
        else {
            setLoading(false)
            toast.error(t('stringFileNotFound'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
        }

    }
    // console.log("base64", b64);

    // For image the base 64 conversion
    const imageConvert = (data) => {

        return new Promise(function (resolve, reject) {
            setb64([]);
            setNumpages(1)
            var img = new Image()
            img.src = 'data:image/png;base64,' + data.base64

            img.onload = function () {
                setb64(['data:image/png;base64,' + data.base64]);
                resolve(b64)
                global.rotation = [0];
                setDeepICRCTX({
                    ...deepICRCTX,
                    isContract: false,
                    documentId: "",
                    imageScale: deepICRCTX.inputViewerBounds.bounds.width / img.width,
                    // file: file,
                    requestedFile: "",
                    fileBase64: [data.base64],
                    fileSize: [{ height: img.height, width: img.width }],
                    pdfBase64: "",
                    pdfPage: 1,
                    pdfPages: 1,
                    targetPages: "",
                    size: 12,
                    originalOutputFontScale: 1,
                    originalOutputSize: { height: 0, width: 0 },
                    originalOutputData: { data: [] },
                    originalOutputTable: { data: [] },
                    extractedOutputData: { data: [] },
                    extractedOutputTable: { data: [] },
                    searchText: "",
                    outputSw: false,
                    croppingToolId: 6,
                    shapeList: {},
                    currentShape: [],
                    selectedShape: [],
                    shapeCounter: 0,
                    pointCounter: 0,
                    selectionPoints: [],
                    popUpDialog: { "image_id": "", "shape_id": "", "label": "", "meta": "", "left": 0, "top": 0, "show": false },
                });
            }
            img.onerror = function () {
                reject(b64)
            }

        })


    }


    // image conversion from base64
    const pdfToJpeg = async (dataUrl) => {
        // console.log("data URL",dataUrl);
        const tmpBase64 = dataUrl
        // setb64(tmpBase64)
        const dataUrls = [];
        const fileSizes = [];
        const pdf = await pdfjs.getDocument({
            data: atob(tmpBase64),
            cMapUrl: `https://unpkg.com/pdfjs-dist@${pdfjs.version}/cmaps/`,
            cMapPacked: true
        }).promise;

        let page;
        for (let i = 0; i < pdf.numPages; i++) {
            page = await pdf.getPage(i + 1);
            const oList = await page.getOperatorList();
            let j;

            let scale = 1;
            let canvasHeight = 0;
            let canvasWidth = 0;
            // Not jpeg file in pdf
            const viewportPdf = await page.getViewport({ scale: 1 });
            if (viewportPdf.height > viewportPdf.width) {
                scale = deepICRCTX.pdfDefaultHeight / viewportPdf.height;
                canvasHeight = deepICRCTX.pdfDefaultHeight;
                canvasWidth = Math.ceil(viewportPdf.width * scale);
            } else {
                scale = deepICRCTX.pdfDefaultHeight / viewportPdf.width;
                canvasWidth = deepICRCTX.pdfDefaultHeight;
                canvasHeight = Math.ceil(viewportPdf.height * scale);
            }
            // }
            const canvas = document.createElement("canvas");
            const viewport = await page.getViewport({ scale: scale });
            canvas.height = canvasHeight;
            canvas.width = canvasWidth;
            const context = canvas.getContext("2d");
            const task = page.render({
                canvasContext: context,
                viewport: viewport,
            })
            // console.log("pdf",task);
            try {
                await task.promise;
            }
            catch (e) {
                setLoading(false)
                toast.error(t('stringFailPdfProcess'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
            };
            dataUrls.push(canvas.toDataURL('image/jpeg'))
            fileSizes.push({ height: canvasHeight, width: canvasWidth });
        }
        setb64([...dataUrls]);
        setNumpages(pdf.numPages)
        setRotation(new Array(pdf.numPages).fill(0))
        // console.log(b64);
        // console.log(dataUrls);
        global.rotation = [];
        for (let i = 0; i < pdf.numPages; i++) {
            global.rotation.push(0);
        }
        setDeepICRCTX({
            ...deepICRCTX,
            isContract: false,
            documentId: "",
            imageScale: deepICRCTX.inputViewerBounds.bounds.width / fileSizes[0].width,
            // file: file,
            requestedFile: "",
            fileBase64: dataUrls,
            fileSize: fileSizes,
            // pdfBase64: reader.result,
            pdfPage: 1,
            // pdfPages: pdfPages,
            targetPages: "",
            size: 12,
            originalOutputFontScale: 1,
            originalOutputSize: { height: 0, width: 0 },
            originalOutputData: { data: [] },
            originalOutputTable: { data: [] },
            extractedOutputData: { data: [] },
            extractedOutputTable: { data: [] },
            searchText: "",
            outputSw: false,
            croppingToolId: 6,
            shapeList: {},
            currentShape: [],
            selectedShape: [],
            shapeCounter: 0,
            pointCounter: 0,
            selectionPoints: [],
            popUpDialog: { "image_id": "", "shape_id": "", "label": "", "meta": "", "left": 0, "top": 0, "show": false },
        });
        setLoading(false)
        return ([dataUrls, fileSizes, pdf.numPages]);
    }

    // For S3

    const startOcr = async () => {
        toggle()
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/deepicr/startocr?fid=${ocrInfo._id}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                "Authorization": "Bearer " + jwt,
                "sid": sessionId
            },
            body: JSON.stringify({
                key: encodeURI(ocrInfo.fileKey),
                ocrInfo: {
                    protocolNo: memoInput.protocolNo,
                    actualWorkingDate: memoInput.actualWorkingDate,
                    paymentRequestDate: memoInput.paymentRequestDate,  
                    firstApprover: Array.isArray(memoInput.firstApprover)?  memoInput.firstApprover[0]:memoInput.firstApprover.split(',')[0],
                    firstApproverCode: Array.isArray(memoInput.firstApprover)?  memoInput.firstApprover[1]:memoInput.firstApprover.split(',')[1],
                    costCenter: memoInput.costCenter,
                    description: memoInput.description
                },
                jsonFile: {
                    "input_bucket_name": `${process.env.REACT_APP_S3_BUCKET}`,
                    "img_path": `${ocrInfo.fileKey.split('/')[0].concat('/').concat(ocrInfo.fileKey.split('/')[1]).concat('/').concat(ocrInfo.fileKey.split('/')[2])}`,
                    "img_file_name": encodeURI(ocrInfo.fileName),
                    "output_bucket_name": `${process.env.REACT_APP_S3_BUCKET}`,
                    "output_path": `${ocrInfo.fileKey.split('/')[0].concat('/').concat(ocrInfo.fileKey.split('/')[1]).concat('/').concat(ocrInfo.fileKey.split('/')[2])}`,
                    "output_json_name": encodeURI(ocrInfo.fileName.match(/(.*)(?:\.([^.]+$))/)[1] + '_out.json'),
                    "target_type": "invoice",
                    "custom_pages": ocrPageArr,
                    "pdf_pages": pages,
                    "pdf_rotations": rotation,
                    "file_size": ocrInfo.fileSize,
                    "selection_info": {}
                }
            })
        })
        // console.log(ocrPageArr);
        const data = await res.json()
        // console.log("input json log", data);
        if (res.status === 200) {
            toast.success(t('stringInProgress'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
            if (prevNext.next.length > 0) {
                setFid(prevNext.next[0]._id)
                getSingleFile(prevNext.next[0]._id)
                setMemoInput({
                    protocolNo: "",
                    actualWorkingDate: "",
                    paymentRequestDate: "",
                    firstApprover: "",
                    costCenter: "",
                    description: ""
                })
                setb64([])
                setApprover([])
                setCurrentPageNumber(1)
                setNumpages(1)
            } else {
                toast.success(t('stringLastPdf'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
                navigate('/')
            }
            setOcrPageInfo("")
        }
        else if(res.status===401){
            toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
            dispatch(resetCredentials())
            navigate('/login', { state: { isLoading: false } })
          }
        else {
            toast.warning(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
        }
        // } else {
        //     toast.warning('Not Uploaded to S3 ', { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
        // }
        // }

    }
    // For Local
    // const startOcr = async () => {
    //     toggle()
    //     if (ocrPageErr === true) {
    //         toast.warning('Page Input Format is Wrong', { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
    //     }
    //     else if (memoInput.firstApprover === '' || memoInput.costCenter === '') {
    //         toast.warning('Fill Up the Mandatory Field', { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
    //     }
    //     else {
    //         const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/deepicr/startocr?fid=${ocrInfo._id}`, {
    //             method: "POST",
    //             headers: {
    //                 "Content-Type": "application/json",
    //                 Accept: "application/json",
    //                 "Authorization": "Bearer " + jwt,
    //                 "sid": sessionId
    //             },
    //             body: JSON.stringify({
    //                 ocrInfo: {
    //                     protocolNo: memoInput.protocolNo,
    //                     actualWorkingDate: memoInput.actualWorkingDate,
    //                     paymentRequestDate: memoInput.paymentRequestDate,
    //                     firstApprover: memoInput.firstApprover.split(',')[0],
    //                     firstApproverCode :memoInput.firstApprover.split(',')[1],
    //                     costCenter: memoInput.costCenter,
    //                     description: memoInput.description
    //                 },
    //                 jsonFile: {
    //                     "input_bucket_name": "sftp-server-input-bucket",
    //                     "img_path": "subfolder/subfolder",
    //                     "img_file_name": encodeURI(ocrInfo.fileName),
    //                     "output_bucket_name": "sftp-server-output-bucket",
    //                     "output_path": "subfolder/subfolder",
    //                     "output_json_name": ocrInfo.fileName.match(/(.*)(?:\.([^.]+$))/)[1] + '_input.json',
    //                     "target_type": "invoice",
    //                     "custom_pages": ocrPageArr,
    //                     "pdf_pages": pages,
    //                     "pdf_rotations": rotation,
    //                     "file_size": ocrInfo.fileSize,
    //                     "selection_info": {}
    //                 }
    //             })
    //         })

    //         const data = await res.json()
    //         console.log("input json log", data);
    //         if (res.status === 200) {
    //             toast.success('In Process', { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
    //             if (prevNext.next.length > 0) {
    //                 setFid(prevNext.next[0]._id)
    //                 getSingleFile(prevNext.next[0]._id)
    //                 setMemoInput({
    //                     protocolNo: "",
    //                     actualWorkingDate: "",
    //                     paymentRequestDate: "",
    //                     firstApprover: "",
    //                     costCenter: "",
    //                     description: ""
    //                 })
    //                 setApprover([])
    //                 setCurrentPageNumber(1)
    //             } else {
    //                 navigate('/')
    //             }
    //             setOcrPageInfo("")
    //         } else {
    //             toast.warning('Something went wrong ', { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
    //         }
    //     }

    // }

    // Input ocr pages validation 

    const validatePdfPages = (e) => {
        setOcrPageErr(false)
        const inputText = e.target.value;
        // console.log("error test",pages);
        var currFile = fileName.split('.')
        setOcrPageInfo(e.target.value)
        if (inputText !== '') {
            if (typeof currFile[currFile.length - 1] === 'undefined') {
                e.target.value = '';
                setOcrPageErr(true)

            } else if (currFile[currFile.length - 1] !== 'pdf') {
                e.target.value = '';
                setOcrPageErr(true)

            } else {
                if (!(/^[0-9,-]+$/.test(inputText))) {
                    e.target.value = '';
                    setOcrPageErr(true)
                } else {
                    let checkArray1 = []
                    let checkArray2 = {};
                    const inputTextArray = inputText.split(',');
                    inputTextArray.forEach(item => {
                        if (/^[1-9]\d*-[1-9]\d*$/.test(item)) {
                            const [start, end] = item.split('-');
                            if (Number(start) >= Number(end)) {
                                e.target.value = '';
                                setOcrPageErr(true)
                            }
                            for (let i = Number(start); i <= Number(end); i++) {
                                checkArray1.push(i);
                                checkArray2[i] = '';
                            }
                        } else {
                            if (!(/^[1-9]\d*$/.test(item))) {
                                e.target.value = '';
                                setOcrPageErr(true)

                            } else {
                                // setOcrPageErr(false)
                                checkArray1.push(Number(item));
                                checkArray2[Number(item)] = '';
                            }
                        }
                    })
                    // console.log("Check array",checkArray1);
                    setOcrPageArr(checkArray1)

                    if (e.target.value !== '') {

                        const newCheckArray2 = Object.keys(checkArray2);
                        if (checkArray1.length !== newCheckArray2.length) {
                            e.target.value = '';

                        } else {

                            checkArray1.sort((a, b) => { return a - b; });
                            let checkArray = [];
                            let addText = '';
                            checkArray1.forEach((n) => {
                                if (n > pages) {
                                    setOcrPageErr(true)
                                    if (checkArray.length < 10) {
                                        checkArray.push(n)
                                    } else {
                                        addText = '...';
                                    }
                                }
                            });
                            if (checkArray.length !== 0) {
                                if (addText !== '') { checkArray.push(addText) }
                                e.target.value = '';


                            } else {

                                setDeepICRCTX({ ...deepICRCTX, targetPages: checkArray1.join(',') });
                                // console.log(deepICRCTX.targetPages);
                            }
                        }
                    }
                }
            }
        }
    }

    // fetching next file from table
    const showNextFile = () => {

        setFid(prevNext.next[0]._id)
        setMemoInput({
            protocolNo: "",
            actualWorkingDate: "",
            paymentRequestDate: "",
            firstApprover: "",
            costCenter: "",
            description: ""
        })
        setOcrPageInfo("")
        getSingleFile(prevNext.next[0]._id)
        setCurrentPageNumber(1)
        setApprover([])
        setb64([])
        setNumpages(1)

    }

    const showPrevFile = () => {

        // Getting from database
        setFid(prevNext.prev[0]._id)
        setMemoInput({
            protocolNo: "",
            actualWorkingDate: "",
            paymentRequestDate: "",
            firstApprover: "",
            costCenter: "",
            description: ""
        })
        getSingleFile(prevNext.prev[0]._id)
        setCurrentPageNumber(1)
        setOcrPageInfo("")
        setApprover([])
        setb64([])
        setNumpages(1)
        // console.log("Prev Value",fid);

    }

    // Delete PDF
    const deletePdf = async () => {
        toggle()
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/file/delete`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                "Authorization": "Bearer " + jwt,
                "sid": sessionId
            },
            body: JSON.stringify({
                fid: [fid]
            })
        })
        const data = await res.json()

        if (res.status === 200) {
            toast.success(t('stringFileDelete'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
            if (prevNext.next.length > 0) {
                setFid(prevNext.next[0]._id)
                getSingleFile(prevNext.next[0]._id)
            } else {
                toast.success(t('stringLastPdf'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
                navigate('/')
            }
            setOcrPageInfo("")

        }
        else if(res.status===401){
            toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
            dispatch(resetCredentials())
            navigate('/login', { state: { isLoading: false } })
          } 
        else {
            toast.warning(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false });
        }


    }

    // Get image from result Page
    const getRedoFileImage = async (fids) => {
        setLoading(true)
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/file/getimg?fid=${fids}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                "Authorization": "Bearer " + jwt,
                "sid": sessionId
            }
        })

        const data = await res.json()
        // console.log(data);
        // Now this API Only sending base64
        // After getting Other information should get the file Name from response instead of location state
        if (res.status === 200) {
            setFid(fids)
            // await pdfToJpeg(data.data)
            setOcrInfo({
                _id: data.fileId,
                fileName: location.state.fname,
                fileSize: data.fileSize,
                fileKey: data.fileKey
            })
            setFileName(location.state?.fname)
            const fileType = location.state.fname.split('.')
            if (fileType[fileType.length - 1] === 'png' || fileType[fileType.length - 1] === 'jpg' || fileType[fileType.length - 1] === 'jpeg') {
                imageConvert(data.data).then(success => {
                    // console.log("success",success);
                    setLoading(false)
                }).catch((err => {
                    // console.log("Error",err);
                    setLoading(false)
                }))
            } else {
                await pdfToJpeg(data.data)
            }
        }
        else if(res.status===401){
            toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
            dispatch(resetCredentials())
            navigate('/login', { state: { isLoading: false } })
          }
          else {
            setLoading(false)
            toast.error(t('stringFileNotFound'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
        }
    }

    // Call the function if comes from resultpage
    const getFusenInfo = async (fids) => {
        setApprover([])
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/deepicr/redoOCR?fid=${fids}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                "Authorization": "Bearer " + jwt,
                "sid": sessionId
            }
        })

        const data = await res.json()
        // console.log("fusen Data", data);
        if (res.status === 200) {
            const tempArr =  [data.fusen.firstApprover,data.fusen.firstApproverCode]
            setMemoInput({
                protocolNo: data.fusen.protocolNo ? data.fusen.protocolNo : "",
                actualWorkingDate: data.fusen.actualWorkingDate ? data.fusen.actualWorkingDate : "",
                paymentRequestDate: data.fusen.paymentRequestDate ? data.fusen.paymentRequestDate : "",
                firstApprover: data.fusen.firstApprover ? tempArr : "",
                costCenter: data.fusen.costCenter ? data.fusen.costCenter : "",
                description: data.fusen.description ? data.fusen.description : ""
            })
        }
    }


    // console.log("ocrInfo",ocrInfo);

    useEffect(() => {
        if (location.state !== null) {
            // console.log("location state exist", location.state.fid);

            // if Location state is not null there is state value
            // if state value has page that means it comes from result page
            // if no page info that means it comes from status page
            if (location.state.page) {
                getRedoFileImage(location.state.fid)
                getFusenInfo(location.state.fid)
            }
            // Triggered when comes from status page
            else {
                getSingleFile(location.state.fid)
            }

        } else {
            getSingleFile("nofileId")
        }
    }, [])


    // useEffect(() => {
    //     // setFid(fid)
    //     getSingleFile(fid)
    //     // console.log("Paginated fid",fid);
    // }, [fid])

    useEffect(() => {
        setOcrPageInfo(ocrPageInfo)
    }, [ocrPageInfo])


    return (
        <>
        <MenuBar/>
            {
                loading ? <Loader loading={loading} /> :
                    <>
                        <SecondNav showPrevFile={showPrevFile} showNextFile={showNextFile} tableFileSeq={tableFileSeq} prevNext={prevNext} />
                        {/* <Userinfo /> */}
                        <div className="pdfProcess__start">


                            {/* pdfProcess__main__content */}
                            <div className="row" style={{ width: "100%", margin: "auto" }}>
                                {/* pdfProcess__pdfviwer */}
                                <div className="col-12 col-md-6 ">
                                    {/* upper navbar of Imageviewr section */}
                                    <div className="pdfProcess__file__table " style={{ width: '100%' }}>
                                        <div className="row p-1 text-center" style={{ alignItems: "center" }}>
                                            <div className="col-12 col-md-4 col-lg-6 p-2" style={{ alignItems: "center", backgroundColor: "#FFFFFF",overflowWrap: 'break-word',textAlign:"left"}}>{t('stringFileName')}: {fileName || ocrInfo.fileName}</div>
                                            <div className="col-12 col-md-4 col-lg-2 p-2" style={{
                                                alignItems: "center",
                                                backgroundColor: "#FFFFFF",
                                                display: "flex",
                                                justifyContent: "space-around",
                                                alignItems: "center"
                                            }}>
                                                {t('stringPageSelect')}{" "}
                                                <span>
                                                    {currentPageNumber > 1 && <>

                                                        <i className={`fa-solid fa-chevron-left`}
                                                            onClick={prevPdfBtn}></i>
                                                    </>}
                                                </span>{" "}
                                                {currentPageNumber}/{pages}{" "}
                                                <span>
                                                    {currentPageNumber < pages && <><i className="fa-solid fa-chevron-right"
                                                        onClick={nextPdfBtn}></i></>}
                                                    {/* <i className="fa-solid fa-chevron-right"
                                 onClick={nextPdfBtn}></i> */}
                                                </span>{" "}
                                            </div>
                                            <div className="col-12 col-md-2 col-lg-3 p-2" style={{
                                                alignItems: "center",
                                                backgroundColor: "#FFFFFF"
                                            }}>
                                                {/* validatePdfPages */}
                                                <input placeholder={`${t('stringOcrPages')}`} onChange={validatePdfPages} value={ocrPageInfo} style={{
                                                    width: "100%",
                                                    border: "1px solid black",
                                                    outline: "black",
                                                    background: "#ffffff"

                                                }} />
                                            </div>
                                            <div className="col-12 col-md-2 col-lg-1 p-2" style={{
                                                alignItems: "center", backgroundColor: "#FFFFFF"
                                            }}>
                                                <div style={{
                                                    display: "flex",
                                                    justifyContent: "space-around",
                                                    alignItems: "center"

                                                }}>

                                                    <span>
                                                        <i className="fa-solid fa-rotate-left" onClick={leftRotation}></i>
                                                    </span>
                                                    <span >
                                                        <i className="fa-solid fa-rotate-right" onClick={rightRotation}></i>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {/* <PdfProcessPageImageViewer /> */}
                                    {/* ************************************* pdf to image viwer start ************************** */}

                                    <>
                                        {/* <input type='file' onChange={getFile} /> */}
                                        <div className='PdfProcessPageImageViewer__main' style={{ height: "750px", backgroundColor: "white", overflowX: "auto" }}>
                                            <img id='image' width={'100%'}
                                                className='img-fluid'
                                                src={b64[currentPageNumber - 1]}
                                            // style={{
                                            //     transform: `rotate(${imageRotation}deg)`
                                            // }}
                                            />
                                        </div>
                                    </>


                                    {/* ************************************* pdf to image viwer end ************************** */}

                                </div>
                                <div className="col-12 col-md-6">
                                    <div className="pdfProcess__file__table " style={{ width: '100%' }}>
                                        <div className="row p-1 text-center" style={{ alignItems: "center" }}>
                                            <CustomTabs value={value} aria-label="output tabs" style={{ minHeight: "auto", backgroundColor: "#FFFFFF" }}>
                                                <Tab label={`${t('stringMemoInput')}`} {...retProps(value, 0)} />
                                            </CustomTabs>
                                        </div>
                                    </div>

                                    <MemoInput startOcr={startOcr} setMemoInput={setMemoInput} memoInput={memoInput} toggle={toggle} deletePdf={deletePdf} setClickedBtn={setClickedBtn} jwt={jwt} sessionId={sessionId} approver={approver} setApprover={setApprover} ocrPageErr={ocrPageErr} resetCredentials={resetCredentials} />
                                </div>
                            </div>
                        </div>

                        <Modal isOpen={modal} toggle={toggle}>

                            <ModalBody>
                            {clickedBtn === 'start' ? `${t('stringPdfStartOcr')}` : `${t('stringPdfDelete')}` }
                            </ModalBody>
                            <ModalFooter>
                                <Button
                                    className={`${styles.styleFileUpload} col-12 col-md-5 `}
                                    variant="outlined"
                                    component="span"
                                    onClick={() => {
                                        // console.log("Button Status",clickedBtn)
                                        clickedBtn === 'start' ? startOcr() : deletePdf()
                                    }

                                    }
                                >{t('stringYes')}
                                </Button>
                                <Button
                                    className={`${styles.styleFileUpload} col-12 col-md-5 `}
                                    variant="outlined"
                                    component="span"
                                    onClick={toggle}
                                >{t('stringNo')}
                                </Button>
                            </ModalFooter>
                        </Modal>
                    </>
            }

        </>
    );
};

export default PdfProcessPage;
