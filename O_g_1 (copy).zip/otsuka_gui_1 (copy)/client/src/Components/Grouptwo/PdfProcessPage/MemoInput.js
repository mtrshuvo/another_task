import React, { memo, useState, useEffect } from 'react';

import { useLocation, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux'


import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import { makeStyles, withStyles } from "@material-ui/core";


import { useTranslation } from 'react-i18next';
import { DatePicker } from "rsuite";
import { toast } from 'react-toastify';

const useStyles = makeStyles((theme) => ({
    styleFileUpload: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,

    },
}));


const MemoInput = ({ setMemoInput, memoInput, toggle, setClickedBtn, jwt, sessionId, approver, setApprover, ocrPageErr, resetCredentials }) => {
    const [t] = useTranslation();
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const handleChange = (e) => {
        // console.log(e.target.name, e.target.value);
        setMemoInput({
            ...memoInput,
            [e.target.name]: e.target.value
        })
    }

    // console.log("Payment Req Date",memoInput.paymentRequestDate);
    // Call the function if comes from resultpage
    // const getFusenInfo = async (fids) => {
    //     const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/deepicr/redoOCR?fid=${fids}`, {
    //         method: "GET",
    //         headers: {
    //             "Content-Type": "application/json",
    //             Accept: "application/json",
    //             "Authorization": "Bearer " + jwt,
    //             "sid": sessionId
    //         }
    //     })

    //     const data = await res.json()
    //     // console.log("fusen Data", data);

    //     if (res.status === 200) {
    //         setMemoInput({
    //             protocolNo: data.fusen.protocolNo ? data.fusen.protocolNo : "",
    //             actualWorkingDate: data.fusen.actualWorkingDate ? data.fusen.actualWorkingDate : "",
    //             paymentRequestDate: data.fusen.paymentRequestDate ? data.fusen.paymentRequestDate : "",
    //             firstApprover: data.fusen.costCenter ? data.fusen.costCenter : "",
    //             costCenter: data.fusen.costCenter ? data.fusen.costCenter : "",
    //             description: data.fusen.description ? data.fusen.description : ""
    //         })
    //     }
    // }

    const styles = useStyles();
    const location = useLocation()

    // Getting first Approver List according to cost center
    const firstApprover = async (costCenter) => {
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/biz-logic/get-first-approver?costCenterCode=${costCenter}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                "Authorization": "Bearer " + jwt,
                "sid": sessionId
            }
        })

        const data = await res.json()
        // console.log("First Approver Data", data);
        if (res.status === 200) {
            setApprover(data.first_approver_employee_code)
        }
        else if (res.status === 401) {
            toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
            dispatch(resetCredentials())
            navigate('/login', { state: { isLoading: false } })
        }
        // else {
        //     toast.success(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
        // }

    }

    // useEffect(() => {
    //     if (location.state !== null) {
    //         if (location.state.page) {
    //             getFusenInfo(location.state.fid)
    //         }
    //     }
    // }, [])

    // console.log("Memo Input",memoInput);
    // console.log(approver.length)

    return (
        <>
            <div style={{ backgroundColor: "white", height: "750px", padding: "20px" }}>
                {/* <p style={{ fontSize: "1.2rem", fontWeight: "600" }}>Memo Input</p> */}
                <div className='memo__form' >
                    <div className="mb-3 row">
                        <label htmlFor="protocolNo" className="col-sm-4 col-form-label">{t('stringProtocolNo')}</label>
                        <div className="col-sm-8">
                            {/* memoInput.protocolNo */}
                            {/* <input type="text" className="form-control" name='protocolNo' placeholder='請求書上に番号がない場合、入力してください' value={memoInput.protocolNo} style={{ border: "1px solid black" }} id="protocolNo" onChange={handleChange} /> */}

                            <input class="form-control" list="datalistOptions2" name="protocolNo" autocomplete="off" placeholder={`${t('stringProtocolNoPlaceholder')}`} value={memoInput.protocolNo} id="protocolNo" onChange={(e) => {
                                handleChange(e)
                            }
                            }
                                style={{ border: "1px solid black" }} />
                            <datalist id="datalistOptions2">
                                {
                                    JSON.parse(sessionStorage.getItem('get-protocol-numbers'))?.map(val => {
                                        return (
                                            <option value={val} />
                                        )
                                    })
                                }
                            </datalist>
                        </div>
                    </div>
                    <div className="mb-3 row">
                        <label htmlFor="paymentRequestDate" className="col-sm-4 col-form-label">{t('stringPaymentReqDate')}</label>
                        <div className="col-sm-8">
                            {/* <input type="date" className="form-control" style={{ border: "1px solid black" }} id="paymentRequestDate" /> */}
                            <DatePicker
                                format="yyyy/MM/dd"
                                placeholder={`${t('stringPaymentRequestPlaceholder')}`}
                                style={{ border: "1px solid black", width: "100%", borderRadius: "10px" }}
                                name="paymentRequestDate"
                                value={memoInput.paymentRequestDate ? new Date(memoInput.paymentRequestDate) : null}
                                // {memoInput.paymentRequestDate !== "" ? new Date(memoInput.paymentRequestDate) : null}
                                // defaultValue={memoInput.paymentRequestDate}
                                onChange={(date) => {
                                    setMemoInput({
                                        ...memoInput,
                                        paymentRequestDate: date
                                    })

                                }}
                            />
                        </div>
                    </div>
                    <div className="mb-3 row" >
                        <label htmlFor="description" className="col-sm-4 col-form-label">{t('stringDescription')}</label>
                        <div className="col-sm-8">
                            <textarea type="text" name='description' placeholder={`${t('stringDescriptionPlaceholder')}`} value={memoInput.description} className="form-control" style={{ border: "1px solid black" }} id="description" onChange={handleChange} />
                        </div>
                    </div>
                    <div className="mb-3 row">
                        <label htmlFor="paymentRequestDate" className="col-sm-4 col-form-label">{t('stringActualDate')}</label>
                        <div className="col-sm-8">
                            <input type="text" name='actualWorkingDate' value={memoInput.actualWorkingDate} className="form-control" style={{ border: "1px solid black" }} id="actualWorkingDate" placeholder={t('stringActualWorkingDatePlaceholder')} onChange={handleChange} />
                            {/* <DatePicker
                                format="yyyy/MM/dd"
                                placeholder="yyyy/mm/dd"
                                style={{ border: "1px solid black", width: "100%", borderRadius: "10px" }}
                                value={memoInput.actualWorkingDate !== '' ? new Date(memoInput.actualWorkingDate) : null}
                                onChange={(date) => {
                                    console.log(date);
                                    setMemoInput({
                                        ...memoInput,
                                        actualWorkingDate: date
                                    })
                                }}
                            /> */}
                        </div>
                    </div>
                </div>
                {/* Cost Center */}
                <div>
                    <div className="mb-3 mt-5 row" style={{
                        fontSize: "1.2rem",
                    }}>
                        <label htmlFor="costCenter" className="col-sm-4 col-form-label">{t('stringCostCenter')} *</label>
                        <div className="col-sm-8">

                            <input class="form-control" list="datalistOptions3" name="costCenter" value={memoInput.costCenter} id="exampleDataList" placeholder={`${t('stringTypeSearch')}`} autocomplete="off" onChange={(e) => {
                                handleChange(e)
                                firstApprover(e.target.value)
                            }
                            } style={{ width: "270px", border: "1px solid black" }} />
                            <datalist id="datalistOptions3">
                                {
                                    JSON.parse(sessionStorage.getItem('get-cost-center'))?.map(val => {
                                        return (
                                            <option value={val} />
                                        )
                                    })
                                }
                            </datalist>
                        </div>
                    </div>
                </div>
                {/* First Approver list */}
                <div>
                    <div className="mb-3 mt-3 row" style={{
                        fontSize: "1.2rem",

                    }}>
                        <label htmlFor="costCenter" className="col-sm-4 col-form-label">{t('stringFirstApprover')} *</label>
                        <div className="col-sm-4">
                            <select
                                labelid="demo-simple-select-filled-label"
                                id="demo-simple-select-filled"
                                className="form-select" aria-label="Default select example"
                                name="firstApprover"
                                // value={memoInput.firstApprover}
                                onChange={handleChange}
                            >

                                <option defaultValue value={''} selected={(Array.isArray(memoInput.firstApprover) && memoInput.firstApprover.length===0) || (approver && approver.length > 0) || (Array.isArray(approver) && memoInput.firstApprover === '')} disabled>{t('stringSelectApprover')}</option>
                                {
                                    // memoInput.firstApprover.length!==0 &&approver&&approver.length&&
                                    // Now it should be in condition
                                    // &&  approver && approver.length&& approver.length===0
                                    memoInput.firstApprover !== '' && (approver && approver.length === 0) ?
                                        // console.log("entered")
                                        <option value={memoInput.firstApprover && memoInput.firstApprover}>{memoInput.firstApprover && memoInput.firstApprover}</option>
                                        :
                                        approver && approver.length > 0 && approver.map(val => {
                                            // console.log("testValue",val);
                                            return (
                                                val[0] && <option value={val}>{val[0]}</option>
                                            )

                                        })
                                }
                            </select>
                        </div>
                    </div>
                </div>
                <div className='pdfProcess__btns' style={{

                    textAlign: "right",
                    marginTop: "10rem"
                }}>
                    <div className="mb-3">

                        <Button
                            className={`${styles.styleFileUpload} col-12 col-md-5 `}
                            variant="outlined"
                            component="span"
                            onClick={() => {
                                if (ocrPageErr === true) {
                                    toast.warning(t('stringOcrPageErr'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
                                }
                                else if (memoInput.firstApprover.length <= 0 || memoInput.costCenter === '') {
                                    toast.warning(t('stringFillMandatory'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
                                } else {
                                    toggle()
                                    setClickedBtn('start')
                                }

                            }}
                        >
                            <Typography variant="h6">{t('stringStartOcr')}</Typography>
                        </Button>
                    </div>
                    <div className="">

                        <Button
                            className={`${styles.styleFileUpload} col-12 col-md-5 `}
                            variant="outlined"
                            component="span"
                            onClick={() => {
                                toggle()
                                setClickedBtn('delete')
                            }}
                        >
                            <Typography variant="h6">{t('stringDeletePdf')}</Typography>
                        </Button>
                    </div>

                </div>
            </div>
        </>

    )
}
// 2020-05-02
export default MemoInput