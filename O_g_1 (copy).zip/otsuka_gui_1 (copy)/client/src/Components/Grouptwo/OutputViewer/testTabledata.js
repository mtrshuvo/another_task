export const testData = [
    {
      _id:1,
      itemname: "研究費",
      amntWithoutText: "120,000",
      consumptionTax: "12,000",
      taxRate:"10%",
      amntWithTax:"132,000",
      categoryNnumber:"340000000",
      categoryName:"未払金-10%"
    },
    {
      _id:2,
      itemname: "研究費",
      amntWithoutText: "120,000",
      consumptionTax: "12,000",
      taxRate:"10%",
      amntWithTax:"132,000",
      categoryNnumber:"340000000",
      categoryName:"未払金-10%"
    },
    {
      _id:3,
      itemname: "研究費",
      amntWithoutText: "120,000",
      consumptionTax: "12,000",
      taxRate:"10%",
      amntWithTax:"132,000",
      categoryNnumber:"340000000",
      categoryName:"未払金-10%"
    },
    {
      _id:4,
      itemname: "研究費",
      amntWithoutText: "120,000",
      consumptionTax: "12,000",
      taxRate:"10%",
      amntWithTax:"132,000",
      categoryNnumber:"340000000",
      categoryName:"未払金-10%"
    }
  ]