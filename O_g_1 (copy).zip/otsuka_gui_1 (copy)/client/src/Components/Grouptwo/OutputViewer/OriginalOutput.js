import React, {useContext, useEffect, useState } from 'react';
import {useTranslation} from 'react-i18next';
import { objectSize, deepCopy, cropImage } from '../../../resources/CommonMethods';

// import react components
import DeepICRContext from '../../../resources/DeepICRContext';

// [React function component]
// Original output component
const OriginalOutput = () => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [selectionOutput, setSelectionOutput] = useState({});
  const [checkChange, setCheckChange] = useState(false);
  const [cropImages, setCropImages] = useState({});

  // for multiple language
  const [t] = useTranslation();

  function formatOutputJson() {
    let isSel = false;
    if (objectSize(deepICRCTX.originalOutputData.data) > 0) {

      for (let i in deepICRCTX.originalOutputData.data) {
        let textData = deepICRCTX.originalOutputData.data[i].data;
        let tableData = deepICRCTX.originalOutputTable.data[i].data;
        let selOutput = {};

        for (let ti in textData) {
          let td = textData[ti];
          if ("shape_id" in td && td["shape_id"] !== undefined) {
            let shape_id = td["shape_id"];
            if (td.type === "Image") {
              let key = td.key;

              if (key in deepICRCTX.croppedImages) {
                let shape_info = deepICRCTX.croppedImages[key];
                let page_number = key.split("-")[0];
                let image = deepICRCTX.fileBase64[page_number];

                cropImage(image, shape_info).then(dataUrl => {
                  let temp = cropImages;
                  temp[key] = dataUrl;
                  setCropImages({ ...cropImages, temp });
                  deepICRCTX.croppedImages[key]["data"] = dataUrl;
                }).catch(error => {
                  // Error: Can not crop shape from image
                  if (deepICRCTX.debug === true) console.error(error)
                })

                // cropImageFromCanvas(image, shape_info, function (dataUrl) {
                //   let temp = cropImages;
                //   temp[key] = dataUrl;
                //   setCropImages({ ...cropImages, temp });
                //   deepICRCTX.croppedImages[key]["data"] = dataUrl;
                // });
              }
            }
            if (shape_id in selOutput && "text" in selOutput[shape_id]) {
              selOutput[shape_id].text.push(td);
            }
            else if (shape_id in selOutput && !("text" in selOutput[shape_id])) {
              selOutput[shape_id]["text"] = [td];
            }
            else {
              selOutput[shape_id] = {};
              selOutput[shape_id]["text"] = [td];
            }

            isSel = true;
          }
        }

        for (let tj in tableData) {
          let td = tableData[tj];
          if ("shape_id" in td && td["shape_id"] !== undefined) {
            let shape_id = td["shape_id"];
            if (shape_id in selOutput && "cell" in selOutput[shape_id]) {
              selOutput[shape_id].cell.push(td);
            }
            else if (shape_id in selOutput && !("cell" in selOutput[shape_id])) {
              selOutput[shape_id]["cell"] = [td];
            }
            else {
              selOutput[shape_id] = {};
              selOutput[shape_id]["cell"] = [td];
            }
            isSel = true;
          }
        }
        if (isSel === true) {
          for (let key in selOutput) {
            let selection = selOutput[key];
            let x = Infinity, y = Infinity, w = -Infinity, h = -Infinity;
            let meta = "";
            if ("text" in selection) {
              let texts = selection['text'];
              for (let i = 0; i < texts.length; i++) {
                if (x > texts[i].x) x = texts[i].x;
                if (w < (texts[i].x + texts[i].width)) w = texts[i].x + texts[i].width;
                if (y > texts[i].y) y = texts[i].y;
                if (h < (texts[i].y + texts[i].height)) h = texts[i].y + texts[i].height;
                meta = texts[i].meta;
              }
            }
            if ("cell" in selection) {
              let cells = selection["cell"];
              for (let i = 0; i < cells.length; i++) {
                if (x > cells[i].x) x = cells[i].x;
                if (w < (cells[i].x + cells[i].width)) w = cells[i].x + cells[i].width;
                if (y > cells[i].y) y = cells[i].y;
                if (h < (cells[i].y + cells[i].height)) h = cells[i].y + cells[i].height;
                meta = cells[i].meta;
              }
            }
            selOutput[key]['x'] = x;
            selOutput[key]['y'] = y;
            selOutput[key]['width'] = w - x;
            selOutput[key]['height'] = h - y;
            selOutput[key]['height'] = h - y;
            selOutput[key]['meta'] = meta;
          }
          var sortable = [];
          for (var shape_id in selOutput) {
            sortable.push([shape_id, selOutput[shape_id]]);
          }

          sortable.sort(function (a, b) {
            return a[0].split("_")[1] - b[0].split("_")[1];
          });

          var output = {};
          for (var x = 0; x < sortable.length; x++) {
            output["" + sortable[x][0]] = deepCopy(sortable[x][1]);
          }
          selectionOutput[i] = output;
        }
      }
    }
    if (isSel) {
      setSelectionOutput(selectionOutput);
      setDeepICRCTX({
        ...deepICRCTX,
        isSelection: true,
      })
    }
    else {
      setDeepICRCTX({
        ...deepICRCTX,
        isSelection: false,
      })
    }
    setCheckChange(!checkChange);
  }

  useEffect(
    formatOutputJson,
    [
      JSON.stringify(deepICRCTX.croppedImages),
      JSON.stringify(deepICRCTX.originalOutputData),
      JSON.stringify(deepICRCTX.originalOutputTable)
    ]
  );
  if ((deepICRCTX.outputSw === false) && (deepICRCTX.documentId === "")) {
    return (
      <div style={{fontSize: `${deepICRCTX.size}px`}} />
    );
  }
  let pageNumber = 1;
  if(deepICRCTX.file.type === 'application/pdf') {
    pageNumber = deepICRCTX.pdfPage;
  }

  if(typeof deepICRCTX.originalOutputData.data[pageNumber] === 'undefined') {
    return (
      <div style={{fontSize: deepICRCTX.defaultSize * deepICRCTX.originalOutputFontScale}}>
        {t('infoNotSpecified')}
      </div>
    );
  } else {
    let ratio = deepICRCTX.imageScale;
    let width = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
    let height = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

    if (pageNumber in deepICRCTX.originalOutputData.data) {
      ratio = width * deepICRCTX.imageScale / deepICRCTX.originalOutputData.data[pageNumber].width;
    }

    global.inputViewerWidth = width;
    global.inputViewerHeight = height;
    let fontsize = 72 * deepICRCTX.imageScale * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale;
    if (fontsize > 20) fontsize = 20;
    return (
      <div
        key={deepICRCTX.isImage}
        data-status={checkChange}
        id={'originalOutputDiv'}
        style={{
          width: deepICRCTX.inputViewerBounds.bounds.width,
          height: deepICRCTX.inputViewerBounds.bounds.height,
          overflow: 'auto',
        }}
        onScroll={(e) => {
          if (deepICRCTX.outputSw === true && deepICRCTX.isSelection === false) {
            document.getElementById('imgDiv').scrollLeft = document.getElementById('originalOutputDiv').scrollLeft;
            document.getElementById('imgDiv').scrollTop = document.getElementById('originalOutputDiv').scrollTop;
          }
        }}
        data-change={checkChange}
      >
        <div
          id={'originalOutputViewer'}
          style={{
            position: 'relative',
            width: width * deepICRCTX.imageScale,
            minHeight: height * deepICRCTX.imageScale,
          }}>

          {deepICRCTX.isSelection === true && pageNumber in selectionOutput && Object.keys(selectionOutput[pageNumber]).map((key) =>
            <React.Fragment key={"fr" + key}>
              <div key={"memo" + key} style={{ boxShadow: "0px 0px 0px 1px #e3e3e3", background: "#e3e3e3", fontWeight: "bold", padding: "4px 10px", color: "#26890d", fontSize: fontsize, position: "relative", display: "block", width: "100%", height: "auto" }}>{key.split("_")[1] + ". " + selectionOutput[pageNumber][key]['meta']}</div>
              {/* <div key={"memo" + key} style={{ background: "#eaffe6", fontWeight: "bold", padding: 10, color: "#f06", fontSize: fontsize, position: "relative", display: "block", width: "100%", height: "auto" }}>{key.split("_")[1] + ". " + selectionOutput[pageNumber][key]['meta']}</div> */}
              
              <div key={"aaa" + key} id={"aaa" + key} style={{ margin: "0 0 1px 0", position: "relative",boxShadow: "0px 0px 0px 1px #e3e3e3", display: "block", width: "100%", height: (selectionOutput[pageNumber][key]['height'] * ratio) + 20 + "px" }}>
                {Object.keys(selectionOutput[pageNumber][key]).map((item) =>
                  <div key={item} id={"sss" + item} style={{ display: "block" }}>
                    {item === "cell" && selectionOutput[pageNumber][key][item].map((table, i) =>
                      <div
                        style={{
                          position: 'absolute',
                          left: 10 + table.x * ratio - selectionOutput[pageNumber][key]['x'] * ratio,
                          top: 10 + table.y * ratio - selectionOutput[pageNumber][key]['y'] * ratio,
                          width: table.width * ratio,
                          height: table.height * ratio,
                          border: '1px solid #e0e0e0',
                          zIndex: 1,
                        }}
                        key={table.key}
                        id={table.uniqueKey}
                      >
                        {''}
                      </div>)
                    }
                    {item === "text" && selectionOutput[pageNumber][key][item].map((data, i) =>
                      <div
                        style={{
                          position: 'absolute',
                          left: 10 + data.x * ratio - selectionOutput[pageNumber][key]['x'] * ratio,
                          top: 10 + data.y * ratio - selectionOutput[pageNumber][key]['y'] * ratio,
                          width: data.width * ratio,
                          height: data.height * ratio,
                          fontSize: data.type === "Blank" ? 16 : data.height * ratio * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale,
                          whiteSpace: 'nowrap',
                          color: deepICRCTX.searchText !== "" && data.text !== undefined && data.text.indexOf !== undefined && data.text.indexOf(deepICRCTX.searchText) >= 0 ? "#000" : data.color,
                          padding: 0,
                          margin: 0,
                          zIndex: 2,
                          backgroundColor: deepICRCTX.searchText !== "" && data.text !== undefined && data.text.indexOf !== undefined && data.text.indexOf(deepICRCTX.searchText) >= 0 ? "#F5FF5B" : "inherit",
                        }}
                        key={data.key}
                        id={data.uniqueKey}
                        contentEditable={data.type !== "Image" && 'true'}
                        suppressContentEditableWarning
                        onBlur={(e) => {
                          if (e.currentTarget.innerText !== deepICRCTX.originalOutputData.data[pageNumber].data[e.currentTarget.id].text) {
                            const oData = deepICRCTX.originalOutputData;
                            
                            if (oData.data[pageNumber].data[e.currentTarget.id].originalText === '') {
                              oData.data[pageNumber].data[e.currentTarget.id].originalText = oData.data[pageNumber].data[e.currentTarget.id].text;
                            }
                            oData.data[pageNumber].data[e.currentTarget.id].text = e.currentTarget.innerText;
                            e.currentTarget.innerText = oData.data[pageNumber].data[e.currentTarget.id].text;

                            if (e.target.innerText !== oData.data[pageNumber].data[e.target.id].originalText) {
                              oData.data[pageNumber].data[e.target.id].color = 'blue';
                            } else {
                              oData.data[pageNumber].data[e.target.id].color = oData.data[pageNumber].data[e.target.id].confidence < 0.9 ? 'red' : 'black';
                            }
                            setDeepICRCTX({
                              ...deepICRCTX,
                              originalOutputData: oData,
                            });
                          }
                        }}
                      >
                        {data.type === "Image" &&
                          <img src={cropImages[data.key]} style={{ width: "100%" }} alt="" />
                        }
                        {data.type === "dataFromLine" &&
                          data.text
                        }
                        {data.type === "dataFromTable" &&
                          data.text
                        }
                      </div>
                    )
                    }
                  </div>
                )
                }
              </div>
            </React.Fragment>)
          }

          {deepICRCTX.isSelection === false && <div
            style={{
              position: 'absolute',
              left: 0,
              top: 0,
              width: width * deepICRCTX.imageScale,
              height: height * deepICRCTX.imageScale,
              border: '1px solid #ddd',
            }}>

            {deepICRCTX.originalOutputTable.data[pageNumber].data.map((table) =>
              <div
                style={{
                  position: 'absolute',
                  left: table.x * ratio,
                  top: table.y * ratio,
                  width: table.width * ratio,
                  height: table.height * ratio,
                  border: '1px solid #272727',
                }}
                key={table.key}
                id={table.uniqueKey}
              >
                {''}
              </div>
            )}
            {deepICRCTX.originalOutputData.data[pageNumber].data.map((data) =>
              <div
                style={{
                  position: 'absolute',
                  left: data.x * ratio,
                  top: data.y * ratio,
                  width: data.width * ratio,
                  height: data.height * ratio,
                  fontSize: data.height * ratio * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale,
                  whiteSpace: 'nowrap',
                  color: deepICRCTX.searchText !== "" && data.text !== undefined && data.text.indexOf !== undefined && data.text.indexOf(deepICRCTX.searchText) >= 0 ? "#000" : data.color,
                  padding: 0,
                  margin: 0,
                  backgroundColor: deepICRCTX.searchText !== "" && data.text !== undefined && data.text.indexOf !== undefined && data.text.indexOf(deepICRCTX.searchText) >= 0 ? "#F5FF5B" : "inherit",
                }}
                key={data.key}
                id={data.uniqueKey}
                contentEditable={'true'}
                suppressContentEditableWarning
                onBlur={(e) => {
                  if(e.target.innerText
                    // !== deepICRCTX.originalOutputData.data[pageNumber].data[e.target.id].text) {
                    !== deepICRCTX.originalOutputData.data[pageNumber].data[e.target.id].text) {
                    const oData = deepICRCTX.originalOutputData;
                    if(oData.data[pageNumber].data[e.target.id].originalText === '') {
                      oData.data[pageNumber].data[e.target.id].originalText
                      = oData.data[pageNumber].data[e.target.id].text;
                    }
                    oData.data[pageNumber].data[e.target.id].text = e.target.innerText;
                    e.target.innerText = oData.data[pageNumber].data[e.target.id].text;
                    if(e.target.innerText !== oData.data[pageNumber].data[e.target.id].originalText) {
                      oData.data[pageNumber].data[e.target.id].color = 'blue';
                    } else {
                      oData.data[pageNumber].data[e.target.id].color
                        = oData.data[pageNumber].data[e.target.id].confidence < 0.9 ? 'red' : 'black';
                    }
                    setDeepICRCTX({
                      ...deepICRCTX,
                      originalOutputData: oData,
                    });
                  }
                }}
              >
                {data.text}
              </div>
              )}
          </div>
          }
        </div>
      </div>
    );
  }
}

export default OriginalOutput;
