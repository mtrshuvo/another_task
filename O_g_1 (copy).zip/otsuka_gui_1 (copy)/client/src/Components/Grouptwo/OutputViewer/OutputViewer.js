import React, { useContext, useState, useRef, useEffect, useLayoutEffect } from 'react';
import { useTranslation } from 'react-i18next';
import Encoding from 'encoding-japanese';
import { makeStyles, withStyles } from '@material-ui/core';
import { withSnackbar } from 'notistack';
import { Tabs, Tab } from '@material-ui/core';
import Toolbar from '@material-ui/core/Toolbar';
import Divider from '@material-ui/core/Divider';
import Typography from '@material-ui/core/Typography';
import InputBase from '@material-ui/core/InputBase';
import IconButton from '@material-ui/core/IconButton';
import WarningIcon from '@material-ui/icons/Warning';
import Search from '@material-ui/icons/Search';
import Button from '@material-ui/core/Button';
import DateRange from "@material-ui/icons/DateRange";
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import { Container } from 'react-simple-resizer';
import InputViewer from '../InputViewer/InputViewer.js';
import { toast } from 'react-toastify';
import {
  Modal, ModalFooter,
  ModalBody
} from "reactstrap"

import { useSelector, useDispatch } from "react-redux";
import { resultTotalFile, fileUploadActive } from '../../../action/index.js'

import { DatePicker } from "rsuite";

// import react components
import deepICRTheme from '../../../resources/deepICRTheme';
import ButtonEnlargeFont from './ButtonEnlargeFont';
import ButtonShrinkFont from './ButtonShrinkFont';
import ButtonResetFont from './ButtonResetFont';
import ExtractedOutput from './ExtractedOutput';
import OriginalOutput from './OriginalOutput';

// import resource files
import DeepICRContext from '../../../resources/DeepICRContext';
import { taxRate } from './Master File/dummy'
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import SecondNav from '../../SecondNav/SecondNav.js';
import Loader from '../../Loader/Loader.js';

import { pdfjs, } from 'react-pdf';
import { setLoadingImage, resetCredentials, trackChangeInResultPage, setInvoiceChange, setTextChange, setMemoChange, setPopChange, setTrackSingleValue } from '../../../action/index.js'
import MenuBar from '../../Shared/MenuBar/MenuBar.js';


// Style Sheet
const useStyles = makeStyles(theme => ({
  styleOutputViewer: {
    // border: "2px solid " + theme.palette.deepICR.borderColor,
    backgroundColor: theme.palette.deepICR.color,
    // backgroundColor: "red",
    color: theme.palette.deepICR.backgroundColor,
    // margin: theme.spacing(1, 1, 0, 0),
    // padding: theme.spacing(0, 0, 0, 0),
    boxSizing: "border-box",
    height: "99.5%",
    display: "flex",
    flexDirection: "column",
    flex: 1,
  },
  styleRoot: {
    backgroundColor: "#EAEAF0",
    color: deepICRTheme.palette.deepICR.backgroundColor,
    boxSizing: "border-box",
    height: "100%",
    display: "flex",
    flexDirection: "column",
    flex: 1,
  },
  styleContainer: {
    boxSizing: "border-box",
    height: "100%",
    flex: 1,
    padding: theme.spacing(1, 1, 1, 1),
    justifyContent: "space-between",
  },
  styleOutputs: {
    margin: theme.spacing(0, 0, 0, 0),
    boxSizing: "border-box",
    height: "100%",
  },
  styleOutput: {
    display: "flex",
    flexDirection: "column",
    flexGrow: 1,
    backgroundColor: theme.palette.deepICR.outputBackground,
    boxSizing: "border-box",
    height: "100%",
  },

  styleToolbar: {
    paddingLeft: 0,
    paddingRight: 0,
    borderBottom: "1px solid #EAEAF0",
    backgroundColor: "#B9B9B9",
    overflowY: 'hidden'
  },
  styleDivider: {
    height: theme.palette.deepICR.dividerHeight,
    margin: theme.palette.deepICR.deviderMargin,
  },
  styleSearchInputRoot: {
    // border: '2px solid ' + theme.palette.deepICR.borderColor,
    color: 'inherit',
    backgroundColor: theme.palette.deepICR.input,
  },
  styleSearchInput: {
    padding: theme.spacing(1, 1, 1, 2),
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      width: theme.palette.deepICR.searchInputSize,
      '&:focus': {
        width: theme.palette.deepICR.searchInputSizeFocus,
        backgroundColor: theme.palette.deepICR.input,
      },
    },
  },
  styleSearchIcon: { padding: theme.spacing(1) },
  styleSpacer: { flexGrow: 0.5 },
  styleFileUpload: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4, //90DA85
    borderRadius: 2,
    fontSize: "0.8rem"
  },
  toolBarBtn: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4, //90DA85
    borderRadius: 2,
    // fontSize: "0.8rem",
    width: "20%"
  },
  styleUpdatePayment: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4, //90DA85
    borderRadius: 2,
    fontSize: "0.8rem",
    marginRight: "0"
  },
  styleDataList: {
    width: "100%"
  },
  styleBar: {
    margin: deepICRTheme.spacing(0, 0, 0, 0),
    padding: 4,
  },
}));
const CustomButton = withStyles({
  outlined: {
    '&$disabled': {
      color: "#ffffff",
      backgroundColor: "#888888",
    },
  },
  disabled: {},
})(Button);
const CustomTabs = withStyles({
  indicator: {
    backgroundColor: deepICRTheme.palette.deepICR.blue4,
  },
})(Tabs);

// Output Tab Panel
const TabPanel = (props) => {
  const styles = useStyles();
  const { children, value, index, ...other } = props;

  return (
    <div
      className={styles.styleOutputs}
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      {...other}
    >
      <div className={styles.styleOutput}>{children}</div>
    </div>
  );
}

// Set Tab Property
const retProps = (value, index) => {
  if (value === index) {
    return {
      id: `tabpanel-${index}`,
      style: {
        minHeight: "auto",
        backgroundColor: 'inherit',
        color: deepICRTheme.palette.deepICR.blue4,
        // fontSize: deepICRTheme.palette.deepICR.tabFontSize,
        fontSize: "0.9rem",
      },
    };
  } else {
    return {
      id: `tabpanel-${index}`,
      style: {
        // fontSize: deepICRTheme.palette.deepICR.tabFontSize,
        minHeight: "auto",
        fontSize: "0.9rem",
      },
    };
  }
}

// [React function component]
// Output viewer component
const OutputViewer = (props) => {
  const inputRef = useRef(null)
  const styles = useStyles();
  const location = useLocation()
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [value, setValue] = useState(0);
  const dispatch = useDispatch()
  const navigate = useNavigate()
  // Modal open state
  const [modal, setModal] = useState(false);
  // Toggle for Modal
  const toggle = () => setModal(!modal);
  // Modal open state
  const [modalTwo, setModalTwo] = useState(false);
  // For All buttons
  // Except,Delete Invoice,SaveDraft,Done
  const [modalThree, setModalThree] = useState(false)
  // Toggle for Modal
  const toggleTwo = () => setModalTwo(!modalTwo);
  const toggleThree = () => setModalThree(!modalThree);

  // Credentials from redux
  const jwt = useSelector((state) => state.reducer.jwt)
  const sessionId = useSelector((state) => state.reducer.sessionId)

  const startDate = useSelector((state) => state.filterReducer.startDate);
  const endDate = useSelector((state) => state.filterReducer.endDate);
  const selectedId = useSelector((state) => state.filterReducer.selectedId);
  const isFileUpload = useSelector((state) => state.reducer.isFileUpload)
  const loadingImage = useSelector((state) => state.resultReducer.loadingImage);
  const invoiceChange = useSelector((state) => state.resultReducer.prop);
  const trackSingleValue = useSelector((state) => state.resultReducer.trackSingleValue);

  // Uploader Id
  const id = useSelector((state) => state.reducer._id);
  const rpaCheck = useSelector((state) => state.filterReducer.rpaCheck);

  // Output Viewer data info save 
  const [outputData, setOutputData] = useState([])
  // For extracted table add line
  const [noOfRows, setNoOfRows] = useState('');
  const [tableData, setTableData] = useState('')
  // For auto generated /category table add line
  const [cRows, setCRows] = useState('')
  const [cTableData, setCTableData] = useState('')
  // for ner Data
  const [nerData, setNerData] = useState('')
  // for fusen data
  const [fusen, setFusen] = useState('')

  // set File Id
  const [fid, setFid] = useState('')

  // for updated input field of ner data and fusen data
  // For now there is only total AMount of ner data
  const [invoiceInfo, setInvoiceInfo] = useState({
    totalAmount: ''
  })


  // For show and hide div classname defined
  const [slideClass, setSlideClass] = useState('')
  // For selected curency
  const [currency, setCurrency] = useState('')

  // For loading state tracking the inmage and exttracted data boolean
  const [loadingExtracted, setLoadingExtracted] = useState(true)
  // const [loadingImage, setLoadingImage] = useState(false)

  // for done or draft button clicked boolean value tracking
  const [btnClicked, setBtnClicked] = useState('')
  // For Others Button of modal three selected button
  const [othersClicked, setOthersClicked] = useState('')
  // Setting First Approver
  const [approver, setApprover] = useState([])

  const [fileName, setFileName] = useState("")
  // All currency
  // Importing from master file
  const currencyArr = ["JPY 日本円",
    "USD アメリカドル",
    "EUR EMU 通貨 (ユーロ)",
    "CAD 力ナダドル",
    "AUD オーストラリアドル",
    "AED アラブ首長国連邦ディルハム",
    "CHF スイスフラン",
    "CZK チエコクローナ",
    "DKK デンマーククローネ",
    "EGP エジプトボンド",
    "GBP イギリスボンド",
    "HKD 香港ドル",
    "IDR インドネシアルビー",
    "INR インドルビー",
    "KRW South Korean Won",
    "PHP フィリピンペソ",
    "PKR パキスタンルピー",
    "RMB 人民元",
    "SAR サウジリヤル",
    "SEK スウェーデンクローネ",
    "SGD シンガポールドル",
    "THB タイバーツ",
    "TRY トルコリラ",
    "TWD 新台湾ドル",
    "VND Vietnamese Dong",
    "MYR マレーシアリンギット",
    "MXN メキシコペソ",
    "BRL ブラジルレアル"
  ]
  const [selectedCheckedFile, setSelectedCheckedFile] = useState([]);
  const [selectedCheckedFileItem, setSelectedCheckedFileItem] = useState([]);

  const [sellerNameCode, setSellerNameCode] = useState({ sellerName: "", sellerCode: "" })
  const [hospitalNameCode, setHospitalNameCode] = useState({ hospitalName: "", hospitalCode: "" })
  const [protocolNameCode, setProtocolNameCode] = useState({ protocolName: "", protocolCode: "" })
  const [isSellerUserInput, setIsSellerUserInput] = useState(false)
  const [isHospitalUserInput, setIsHospitalUserInput] = useState(false)
  const [isProtocolUserInput, setIsProtocolUserInput] = useState(false)
  // For showing multiple popup 
  // For tracking wheather the dropdown should be shiwn or not
  // const [trackSingleValue,setTrackSingleValue] = useState({sellerField:false,hospitalField:false,protocolField:false})
  // console.log(trackSingleValue);

  // Prev next value save
  // Single File Previous next object Id saving state
  const [resultPrevNext, setResultPrevNext] = useState({
    prev: [],
    next: []
  })
  // Seller code ,Seller name changes Real time

  let targetId


  //State Copy from input viewer


  // For image the base 64 conversion
  const imageConvert = (data) => {

    return new Promise(function (resolve, reject) {
      setb64([]);
      setNumpages(1)
      var img = new Image()
      img.src = 'data:image/png;base64,' + data

      img.onload = function () {
        setb64(['data:image/png;base64,' + data]);
        resolve(b64)
        global.rotation = [0];
        setDeepICRCTX({
          ...deepICRCTX,
          isContract: false,
          documentId: "",
          imageScale: deepICRCTX.inputViewerBounds.bounds.width / img.width,
          // file: file,
          requestedFile: "",
          fileBase64: [data.base64],
          fileSize: [{ height: img.height, width: img.width }],
          pdfBase64: "",
          pdfPage: 1,
          pdfPages: 1,
          targetPages: "",
          size: 12,
          originalOutputFontScale: 1,
          originalOutputSize: { height: 0, width: 0 },
          originalOutputData: { data: [] },
          originalOutputTable: { data: [] },
          extractedOutputData: { data: [] },
          extractedOutputTable: { data: [] },
          searchText: "",
          outputSw: false,
          croppingToolId: 6,
          shapeList: {},
          currentShape: [],
          selectedShape: [],
          shapeCounter: 0,
          pointCounter: 0,
          selectionPoints: [],
          popUpDialog: { "image_id": "", "shape_id": "", "label": "", "meta": "", "left": 0, "top": 0, "show": false },
        });
      }
      img.onerror = function () {
        reject(b64)
      }

    })


  }


  // `https://unpkg.com/pdfjs-dist@${pdfjs.version}/cmaps/`
  // `//cdn.jsdelivr.net/npm/pdfjs-dist@2.1.266/cmaps/`
  // image conversion from base64

  const pdfToJpeg = async (dataUrl) => {
    const tmpBase64 = dataUrl
    // setb64(tmpBase64)
    const dataUrls = [];

    const pdf = await pdfjs.getDocument({
      data: atob(tmpBase64),
      cMapUrl: `https://unpkg.com/pdfjs-dist@${pdfjs.version}/cmaps/`,
      cMapPacked: true
    }).promise;
    const fileSizes = [];
    let page;
    for (let i = 0; i < pdf.numPages; i++) {
      page = await pdf.getPage(i + 1);
      const oList = await page.getOperatorList();
      let j;

      let scale = 1;
      let canvasHeight = 0;
      let canvasWidth = 0;
      // Not jpeg file in pdf
      const viewportPdf = await page.getViewport({ scale: 1 });
      if (viewportPdf.height > viewportPdf.width) {
        scale = deepICRCTX.pdfDefaultHeight / viewportPdf.height;
        canvasHeight = deepICRCTX.pdfDefaultHeight;
        canvasWidth = Math.ceil(viewportPdf.width * scale);
      } else {
        scale = deepICRCTX.pdfDefaultHeight / viewportPdf.width;
        canvasWidth = deepICRCTX.pdfDefaultHeight;
        canvasHeight = Math.ceil(viewportPdf.height * scale);
      }
      // }
      const canvas = document.createElement("canvas");
      const viewport = await page.getViewport({ scale: scale });
      canvas.height = canvasHeight;
      canvas.width = canvasWidth;
      const context = canvas.getContext("2d");
      const task = page.render({
        canvasContext: context,
        viewport: viewport,
      })
      try {
        await task.promise;
      }
      catch (e) {
        dispatch(setLoadingImage(false))
      };
      dataUrls.push(canvas.toDataURL('image/jpeg'))
      fileSizes.push({ height: canvasHeight, width: canvasWidth });
    }
    setb64([...dataUrls]);
    setNumpages(pdf.numPages)
    setRotation(new Array(pdf.numPages).fill(0))

    global.rotation = [];
    for (let i = 0; i < pdf.numPages; i++) {
      global.rotation.push(0);
    }
    setDeepICRCTX({
      ...deepICRCTX,
      isContract: false,
      documentId: "",
      imageScale: deepICRCTX.inputViewerBounds.bounds.width / fileSizes[0].width,
      // file: file,
      requestedFile: "",
      fileBase64: dataUrls,
      fileSize: fileSizes,
      // pdfBase64: reader.result,
      pdfPage: 1,
      // pdfPages: pdfPages,
      targetPages: "",
      size: 12,
      originalOutputFontScale: 1,
      originalOutputSize: { height: 0, width: 0 },
      originalOutputData: { data: [] },
      originalOutputTable: { data: [] },
      extractedOutputData: { data: [] },
      extractedOutputTable: { data: [] },
      searchText: "",
      outputSw: false,
      croppingToolId: 6,
      shapeList: {},
      currentShape: [],
      selectedShape: [],
      shapeCounter: 0,
      pointCounter: 0,
      selectionPoints: [],
      popUpDialog: { "image_id": "", "shape_id": "", "label": "", "meta": "", "left": 0, "top": 0, "show": false },
    });

    // dispatch(setLoadingImage(false))

    return ([dataUrls, fileSizes, pdf.numPages]);
  }

  const [pages, setNumpages] = useState(1);
  // Current page number of pdf
  const [currentPageNumber, setCurrentPageNumber] = useState(1);
  // storing the base 64 value of all pages of a pdf
  const [b64, setb64] = useState([]);

  // To save Rotation value of individual pages
  // the array will be like [0->page1,90->page2,0->page3]
  const [rotation, setRotation] = useState([])

  // If Byte Size exceeds make the field read Only
  const [inputReadOnlyPop, setInputReadOnlyPop] = useState({
    memo: false,
    pop: false,
    text: false,
    invoice: 'false'
  })

  const [mandatoryCheck, setMandatoryCheck] = useState(true)

  // Getting Image of that file 
  const resultImage = async (fids, fName) => {
    setCurrentPageNumber(1)
    dispatch(setLoadingImage(true))
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/file/getimg?fid=${fids}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      }
    })

    const data = await res.json()

    // Now this API Only sending base64
    // After getting Other information should get the file Name from response instead of location state
    if (res.status === 200) {

      const fileType = fName && fName.split('.')
      if (fileType[fileType.length - 1] === 'png' || fileType[fileType.length - 1] === 'jpg' || fileType[fileType.length - 1] === 'jpeg') {
        imageConvert(data.data).then(success => {
          dispatch(setLoadingImage(false))
          // console.log("success",success);
        }).catch((err => {
          dispatch(setLoadingImage(false))
          // console.log("Error",err);
        }))
      } else {
        await pdfToJpeg(data.data)
        dispatch(setLoadingImage(false))
      }
    }
    else if (res.status === 401) {
      toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
      dispatch(resetCredentials())
      navigate('/login', { state: { isLoading: false } })
    }
    else {
      toast.success(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
    }

    // console.log(data);
  }

  // setting Hospital name suggestion
  const [hospitalSuggestion, setHospitalSuggestion] = useState([])
  // Setting Seller Name Suggestion
  const [sellerSuggestion, setSellerSuggestion] = useState([])
  // Account info Mapping Value
  const [accountInfo, setAccountInfo] = useState('')

  useEffect(() => {
    if (fid) {
      resultImage(fid, fileName)
    }
    else if (location.state) {
      setFileName(location.state.fname)
      resultImage(location.state.fid, location.state.fname)
    }
    else {
      //console.log("Nothing");
    }
  }, [fid])
  // Ends Here

  // Getting first Approver List according to cost center
  const firstApprover = async (costCenter) => {
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/biz-logic/get-first-approver?costCenterCode=${costCenter}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      }
    })

    const data = await res.json()
    // console.log(data);
    if (res.status === 200) {
      setApprover(data.first_approver_employee_code)
    }
    else if (res.status === 401) {
      toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
      dispatch(resetCredentials())
      navigate('/login', { state: { isLoading: false } })
    }
    // else {
    //   toast.success(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
    // }

  }

  // Update Extracted table data info Function
  const updateTableData = (e) => {
    // For prototype pollution
    Object.setPrototypeOf(tableData, null);

    dispatch(trackChangeInResultPage(true))
    targetId = e.target
    const fieldName = e.target.id.split('_')[1]
    const indexNo = e.target.id.split('_')[2]
    if (fieldName === 'taxRate') {
      var index = e.target.selectedIndex;
      var optionElement = e.target.childNodes[index]
      var tValue = optionElement.getAttribute('data');
      // console.log(tValue);
      // setCaret()
    } else if (fieldName === 'categoryName') {
      tValue = e.target.value
      const catNumber = JSON.parse(sessionStorage.getItem('get-category-names'))?.find((catNameInfo) => {
        if (catNameInfo[0] === tValue) return catNameInfo[1]
      })

      const newArr = [...tableData]
      Object.setPrototypeOf(newArr, null);

      newArr[indexNo]['categoryNumber'] = catNumber[1]
      setTableData(newArr)
    }
    else if (fieldName === 'amountWithOutTax') {
      var tempTax = tableData[indexNo]['taxRate']
      // Finding OnChange input field's tax Rate value serching on key on taxRate mapping file
      var taxRateValue = taxRate[tempTax]

      var tValue
      e.target.value === '' ? tValue = '' : tValue = e.target.value
      const newArr = [...tableData]
      Object.setPrototypeOf(newArr, null);
      newArr[indexNo]['consumptionTax'] = (taxRateValue * parseFloat(tValue === '' ? 0 : tValue)) / 100
      newArr[indexNo]['amountWithTax'] = Math.round(newArr[indexNo]['consumptionTax']) + Math.round(tValue === '' ? 0 : tValue)
      setTableData(newArr)
    }
    else if (fieldName === 'exclude') {
      var tValue = e.target.checked
    }
    else {
      var tValue = e.target.value
    }

    const newArr = [...tableData]

    newArr[indexNo][fieldName] = tValue
    setTableData(newArr)
  }

  // Makking Amount Without text blank string.ex: ''
  // if the input value is zero
  const changeZeroToBlank = (e) => {
    const newArr = [...tableData]
    const indexNo = e.target.id.split('_')[2]
    newArr[indexNo]['amountWithOutTax'] = ''
    setTableData(newArr)
  }

  // Makking Amount Without text blank string.ex: ''
  // if the input value is zero
  // For Category Table
  const changeZeroToBlankCat = (e) => {
    const newArr = [...cTableData]
    const indexNo = e.target.id.split('_')[2]
    newArr[indexNo]['amount'] = ''
    setCTableData(newArr)
    checkCategoryMandatoField(newArr, selectedCheckedFile)
  }

  // According to tax Rate COnsumption Tax value change function
  // amount with tax = consumption Tax + amount without tax
  const changeAmountWithTax = (e) => {
    // const fieldName = e.target.id.split('_')[1]

    const tValue = e.target.value
    const indexNo = e.target.id.split('_')[2]
    targetId = e.target

    const newArr = [...tableData]
    newArr[indexNo]['consumptionTax'] = (tValue * parseFloat(newArr[indexNo]['amountWithOutTax'] === '' ? 0 : newArr[indexNo]['amountWithOutTax'])) / 100
    newArr[indexNo]['amountWithTax'] = Math.round(newArr[indexNo]['consumptionTax']) + Math.round(newArr[indexNo]['amountWithOutTax'] === '' ? 0 : newArr[indexNo]['amountWithOutTax'])
    setTableData(newArr)
    // console.log("newArr", newArr);
  }

  // Update auto generated/category table info function
  // console.log("From cat table mandatory check",mandatoryCheck);
  const updateCatTable = (e) => {
    // setMandatoryCheck(checkCategoryMandatoField())
    setMandatoryCheck(true)
    dispatch(trackChangeInResultPage(true))
    const fieldName = e.target.id.split('_')[1]
    const indexNo = e.target.id.split('_')[2]
    targetId = e.target
    var tValue
    if (fieldName === 'amount') {
      tValue = e.target.value
      // e.target.value === '' ? tValue = 0 : tValue = e.target.innerHTML.replaceAll("&nbsp;", "").replaceAll("&amp;", " ").replaceAll("<br>", "").replaceAll("&lt;br&gt;", " ");
      e.target.value === '' ? tValue = '' : tValue = e.target.value
      // if (e.target.innerHTML !== "") {
      //   setCaret()
      // }
    }
    else if (fieldName === 'taxRate') {
      var index = e.target.selectedIndex;
      var optionElement = e.target.childNodes[index]
      tValue = optionElement.getAttribute('data');

      // setCaret()
    } else if (fieldName === 'exclude') {
      var tValue = e.target.checked
    } else if (fieldName === 'text') {
      // tValue = e.target.innerHTML.replaceAll("&nbsp;", " ").replaceAll("&amp;", "").replaceAll("<br><br>", "").replaceAll("<br>", "");
      tValue = e.target.value

      // if (e.target.innerHTML !== "") {
      //   setCaret()
      // }
    }
    else {
      tValue = e.target.value
      const catNumber = JSON.parse(sessionStorage.getItem('get-category-names'))?.find((catNameInfo) => {
        if (catNameInfo[0] === tValue) return catNameInfo[1]
      })

      const newArr = [...cTableData]
      newArr[indexNo]['categoryNumber'] = catNumber[1]
      setCTableData(newArr)
      // setCaret()
    }

    // testing to Get character position
    const newArr = [...cTableData]
    newArr[indexNo][fieldName] = tValue
    setCTableData(newArr)
    checkMandatoryField()
    checkCategoryMandatoField(newArr, selectedCheckedFile)
    //  setTableData([...tableData,{...updateDataInfo,[fieldName]:tValue}])
    // console.log("updated Table", cTableData);
    // setCaret()
  }

  if (deepICRCTX.debug === true) { console.log('OutputViewer'); }

  const handleChange = (event, newValue) => {
    setValue(newValue);
    setDeepICRCTX({ ...deepICRCTX, outputTab: newValue });
  }

  const inputsChange = (e) => {
    setInvoiceInfo({ ...invoiceInfo, [e.target.name]: e.target.value })
  }

  if (deepICRCTX.outputTab === 0 && value === 1) {
    setValue(0);
  }

  // for multiple language
  const [t] = useTranslation();

  // Hide and show div classname tracking function
  const divClicked = () => {
    if (slideClass === '') {
      setSlideClass('hide-div')
    } else {
      setSlideClass('')
    }
  }


  // Getting data for output viewer
  // Ner Info, Extracted table ,item table
  const getOutputViewData = async (fids) => {
    dispatch(trackChangeInResultPage(false))
    setLoadingExtracted(true)
    // console.log("RPA Check", rpaCheck);
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/deepicr/extracted?fid=${fids}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      },
      body: JSON.stringify({
        uploadedBy: selectedId.length > 0 ? selectedId : [id],
        startDate: startDate,
        endDate: endDate,
        rpaCheck: rpaCheck
      })
    })

    const data = await res.json()
    dispatch(resultTotalFile(data))
    // setFileName(data.fileInfo.fileName)
    // console.log("Output viewer  filename", fileName);
    console.log("data", data);
    if (res.status === 200) {
      dispatch(setInvoiceChange(false))
      dispatch(setPopChange(false))
      dispatch(setMemoChange(false))
      // setInputReadOnlyPop({memo:false,pop:false,text:false,invoice:'false'})     
      setMandatoryCheck(true)
      setLoadingExtracted(false)
      setOutputData(data)
      setNoOfRows(data.itemTableData && data.itemTableData.length)
      setTableData(data.itemTableData && data.itemTableData)
      setCRows(data.categoryTableData && data.categoryTableData.length)
      setCTableData(data.categoryTableData && data.categoryTableData)
      setNerData(data.nerData && data.nerData)
      setFusen(data.fusen && data.fusen)
      setInvoiceInfo({ ...invoiceInfo, totalAmount: data.nerData && data.nerData.totalAmount || "" })
      setResultPrevNext({
        prev: data.prevId,
        next: data.nextId
      })

      currencyArr.map(val => {
        if (val.substring(0, 3) === data.nerData.currencyCode.substring(0, 3)) {
          return setCurrency(val)
        }
      })
      // setCurrency(data.nerData.currencyCode)
      if (data.fileInfo.resultCheck === 'done') {
        toast.error(`${t('stringRpaDownloaded')}`, { position: toast.POSITION.TOP_CENTER, autoClose: false, pauseOnHover: false })
      }

      const initialTempSelectedFile = []
      const initialTempSelectedFileItem = []
      for (const val of data.itemTableData) {
        if (val.exclude === true) {
          // setSelectedCheckedFile(prevArr =>  [...prevArr, val._id] )
          initialTempSelectedFileItem.push(val._id)
        }
      }

      for (const val of data.categoryTableData) {
        if (val.exclude === true) {
          initialTempSelectedFile.push(val._id)
        }
      }

      if (data.nerData?.invoiceNumber) {
        const convertedPop = new TextEncoder().encode(data.nerData.invoiceNumber)
        // Then Coverting into Shift Jis
        const convertedShiftJisPop = Encoding.convert(convertedPop, 'SJIS');

        const textByteSizePop = convertedShiftJisPop.length
        // setInputReadOnlyPop({...inputReadOnlyPop,pop:true})
        if (textByteSizePop > process.env.REACT_APP_INVOICE_BYTE) {
          dispatch(setInvoiceChange(true))
        }
        else {
          dispatch(setInvoiceChange(false))
        }
      }

      if (data.fusen?.description) {
        const convertedPop = new TextEncoder().encode(data.fusen?.description)
        // Then Coverting into Shift Jis
        const convertedShiftJisPop = Encoding.convert(convertedPop, 'SJIS');

        const textByteSizePop = convertedShiftJisPop.length
        // setInputReadOnlyPop({...inputReadOnlyPop,pop:true})
        if (textByteSizePop > process.env.REACT_APP_MEMO_BYTE) {
          dispatch(setMemoChange(true))
        }
        else {
          dispatch(setMemoChange(false))
        }
      }

      if (data.nerData?.purposeOfPayment) {
        const convertedPop = new TextEncoder().encode(data.nerData.purposeOfPayment)
        // Then Coverting into Shift Jis
        const convertedShiftJisPop = Encoding.convert(convertedPop, 'SJIS');

        const textByteSizePop = convertedShiftJisPop.length
        // setInputReadOnlyPop({...inputReadOnlyPop,pop:true})
        if (textByteSizePop > process.env.REACT_APP_POP_BYTE) {
          dispatch(setPopChange(true))
          // setInputReadOnlyPop({...inputReadOnlyPop,pop:true})
        } else {
          dispatch(setPopChange(false))
          // setInputReadOnlyPop({...inputReadOnlyPop,pop:false})
        }
      }

      if (data.nerData?.sellerName.length > 1) {
        dispatch(setTrackSingleValue(true, 'seller'))
      } else if (data.nerData?.sellerCode[0]?.length > 1) {
        dispatch(setTrackSingleValue(true, 'seller'))
      } else {
        dispatch(setTrackSingleValue(false, 'seller'))
      }

      if (data.nerData?.hospitalName.length > 1) {
        dispatch(setTrackSingleValue(true, 'hospital'))
      } else if (data.nerData?.hospitalCode[0]?.length > 1) {
        dispatch(setTrackSingleValue(true, 'hospital'))
      } else {
        dispatch(setTrackSingleValue(false, 'hospital'))
      }

      if (data.nerData?.protocolNo.length > 1 && !data.nerData.protocolSelectedIndex.includes(-1)) {
        dispatch(setTrackSingleValue(true, 'protocol'))
      } else if (data.nerData?.protocolName[0]?.length > 1 && !data.nerData.protocolSelectedIndex.includes(-1)) {
        dispatch(setTrackSingleValue(true, 'protocol'))
      } else {
        dispatch(setTrackSingleValue(false, 'protocol'))
      }

      if (data.nerData.hospitalName?.length > 1) {
        setTrackSingleValue({ ...trackSingleValue, hospitalField: true })
      } else if (data.nerData.hospitalCode[0]?.length > 1) {
        setTrackSingleValue({ ...trackSingleValue, hospitalField: true })
      } else {
        setTrackSingleValue({ ...trackSingleValue, hospitalField: false })
      }

      // Here will be checked wheather the selected index value all positive or negative
      //  If Negative then will set value from corrected value

      if (data.nerData.sellerSelectedIndex.includes(-1)) {
        setSellerNameCode({
          sellerName: data.nerData?.sellerCorrectedValues[0],
          sellerCode: data.nerData?.sellerCorrectedValues[1]
        })
        setAccountInfo(data.nerData?.sellerCorrectedValues[2])
      } else {
        setSellerNameCode({
          sellerName: data.nerData?.sellerName.length ? data.nerData?.sellerName[data.nerData?.sellerSelectedIndex[0]] : "",
          sellerCode: data.nerData?.sellerCode[data.nerData?.sellerSelectedIndex[0]].length?data.nerData?.sellerCode[data.nerData?.sellerSelectedIndex[0]][data.nerData?.sellerSelectedIndex[1]]:""
        })
        setAccountInfo(data.nerData?.sellerCode[data.nerData?.sellerSelectedIndex[0]].length?Object.keys(data.nerData.multipleSellerInfo).length ? data.nerData.multipleSellerInfo[data.nerData.sellerName[data.nerData.sellerSelectedIndex[0]]][data.nerData.sellerCode[data.nerData.sellerSelectedIndex[0]][data.nerData.sellerSelectedIndex[1]]]['formatted_account_info'] : '':"")
      }

      if (data.nerData.hospitalSelectedIndex.includes(-1)) {
        setHospitalNameCode({
          hospitalName: data.nerData?.hospitalCorrectedValues[0],
          hospitalCode: data.nerData?.hospitalCorrectedValues[1]
        })
      } else {
        setHospitalNameCode({
          hospitalName: data.nerData?.hospitalName.length ? data.nerData?.hospitalName[data.nerData?.hospitalSelectedIndex[0]] : "",
          hospitalCode: data.nerData?.hospitalCode[data.nerData?.hospitalSelectedIndex[0]].length?data.nerData?.hospitalCode[data.nerData?.hospitalSelectedIndex[0]][data.nerData?.hospitalSelectedIndex[1]]:""
        })
      }

      if (data.nerData.protocolSelectedIndex.includes(-1)) {
        setProtocolNameCode({
          protocolName: data.nerData?.protocolCorrectedValues[1],
          protocolCode: data.nerData?.protocolCorrectedValues[0]
        })
      } else {
        setProtocolNameCode({
          protocolCode: data.nerData?.protocolNo.length ? data.nerData?.protocolNo[data.nerData?.protocolSelectedIndex[0]] : "",
          protocolName: data.nerData?.protocolName[data.nerData?.protocolSelectedIndex[0]].length?data.nerData?.protocolName[data.nerData?.protocolSelectedIndex[0]][data.nerData?.protocolSelectedIndex[1]]:""
        })
      }

      // checkByteInitial(data.nerData)
      setSelectedCheckedFileItem(initialTempSelectedFileItem)
      setSelectedCheckedFile(initialTempSelectedFile)
      setIsSellerUserInput(data.nerData.isSellerUserInput)
      setIsHospitalUserInput(data.nerData.isHospitalUserInput)
      setIsProtocolUserInput(data.nerData.isProtocolUserInput)
      checkCategoryMandatoField(data.categoryTableData && data.categoryTableData, selectedCheckedFile, data.nerData)

      var trackPopUp = false
      // For showing pop of warning multiple value
      if (!data.nerData.isSellerUserInput) {
        if (data.nerData.sellerName.length > 1 || data.nerData.sellerCode[0].length > 1) {
          trackPopUp = true
        }
      }
      if (!data.nerData.isHospitalUserInput) {
        if (data.nerData.hospitalName.length > 1 || data.nerData.hospitalCode[0].length > 1) {
          trackPopUp = true
        }
      }
      if (!data.nerData.isProtocolUserInput) {
        if ((data.nerData.protocolNo.length > 1 && !data.nerData.protocolSelectedIndex.includes(-1)) || (data.nerData.protocolName[0].length > 1 && !data.nerData.protocolSelectedIndex.includes(-1))) {
          trackPopUp = true
        }
      }
      if (trackPopUp) {
        toast.warning(t('stringMultipleValuePopUp'), { position: toast.POSITION.TOP_CENTER, autoClose: 5000, pauseOnHover: false })
      }
    }
  }


  // Update Table to generate new Table
  const updatetable = async () => {

    // console.log("itemTable Data", fid, tableData);
    setMandatoryCheck(true)
    dispatch(setLoadingImage(true))
    const newTableData = tableData.filter(val => { return val.itemName !== '' && val.amountWithOutTax !== '' })
    // setTableData(newTableData)
    // console.log("Filterred Table Data", newTableData);
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/deepicr/tableupdate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      },
      body: JSON.stringify({
        itemTableData: newTableData,
        nerData: outputData.nerData,
        fid: fid
      })
    })
    setSlideClass('')
    const data = await res.json()
    if (res.status === 200) {
      var newNer = data.nerData
      setTableData(data.itemTableData)
      setCTableData(data.categoryTableData)
      setOutputData({ ...outputData, nerData: newNer })
      toast.success(`${t('stringConfigUpdatedPopUp')}`, { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
      dispatch(setLoadingImage(false))
    }
    else if (res.status === 401) {
      toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
      dispatch(resetCredentials())
      navigate('/login', { state: { isLoading: false } })
    }
    else {
      dispatch(setLoadingImage(false))
      toast.warning(`${t('stringSomethingWentWrong')}`, { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
    }
    // console.log("Updated Table Data", data, "Output Data", outputData);
  }

  // Auto generated table total amount calculation
  const totalAmountCat = () => {
    const sum = cTableData && cTableData.reduce((acc, currVal) => {
      if (selectedCheckedFile.includes(currVal._id)) {
        return acc + 0
      }
      if (currVal.amount === '' || currVal.amount === null) {
        return acc + 0
      } else {
        return acc + parseFloat(currVal.amount)
      }
    }, 0)

    // console.log("Reduce method sum",sum);
    return sum
  }

  // Total Amount calculation of extracted table
  const totalAmountExt = () => {
    // console.log("Total amount selected File",selectedCheckedFile);
    const sum = tableData && tableData.reduce((acc, currVal) => {
      if (selectedCheckedFileItem.includes(currVal._id)) {
        return acc + 0
      }
      if (currVal.amountWithOutTax === '') {
        return acc + 0
      } else {
        return acc + parseFloat(currVal.amountWithTax)
      }
    }, 0)

    // console.log("Reduce method sum",sum);
    return sum
  }

  //Checkbox clicked Data stored and unstored Category Table
  const SelectedCheckedData = (e, val) => {
    if (e.target.checked) {
      setSelectedCheckedFile([...selectedCheckedFile, val]);
      // console.log("select Checked File", selectedCheckedFile);
    } else {
      setSelectedCheckedFile(
        selectedCheckedFile.filter((file) => { return file !== val }));

      // console.log("unselect Checked File", selectedCheckedFile);
    }
    // checkCategoryMandatoField(cTableData,[...selectedCheckedFile, val])

    // checkCategoryMandatoField()
  };

  //Checkbox clicked Data stored and unstored Item Table
  const SelectedCheckedDataItem = (e, val) => {
    if (e.target.checked) {
      setSelectedCheckedFileItem([...selectedCheckedFileItem, val]);
      // console.log("select Checked File", selectedCheckedFile);
    } else {
      setSelectedCheckedFileItem(
        selectedCheckedFileItem.filter((file) => { return file !== val }));

      // console.log("unselect Checked File", selectedCheckedFile);
    }
    // checkCategoryMandatoField(cTableData,[...selectedCheckedFile, val])

    // checkCategoryMandatoField()
  };

  // Pagination for Completed File show
  // Result PAge second nav pagination
  const showResultNext = () => {
    setMandatoryCheck(true)
    setSlideClass('')
    setApprover([])
    setFid(resultPrevNext.next[0]._id)
    setFileName(resultPrevNext.next[0].fileName)
    getOutputViewData(resultPrevNext.next[0]._id)
    setSelectedCheckedFile([])
    // if (checkMandatoryField()) {
    //   setFid(resultPrevNext.next[0]._id)

    //   getOutputViewData(resultPrevNext.next[0]._id)
    //   setSelectedCheckedFile([])
    // } else {
    //   toast.warning("Fill All Mandatory Fields", { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
    // }
    // checkMandatoryField()

  }

  const showResultPrev = () => {

    setMandatoryCheck(true)
    setSlideClass('')
    setApprover([])
    setFid(resultPrevNext.prev[0]._id)
    setFileName(resultPrevNext.prev[0].fileName)
    getOutputViewData(resultPrevNext.prev[0]._id)
    setSelectedCheckedFile([])
    // if (checkMandatoryField()) {
    //   setFid(resultPrevNext.prev[0]._id)

    //   getOutputViewData(resultPrevNext.prev[0]._id)
    //   setSelectedCheckedFile([])
    // } else {
    //   toast.warning("Fill All Mandatory Fields", { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
    // }
    // Getting from database

  }

  // Updating NER Data and fusen data
  const updateNerFusen = (e) => {
    dispatch(trackChangeInResultPage(true))

    const field = e.target.id.split('_')[0]
    const keyName = e.target.id.split('_')[1]
    // console.log("fieldName keyName",field,keyName);
    if (keyName !== 'description') {
      e.target.style.color = 'red'
    }

    if (field === 'fusen') {
      const newArr = outputData.fusen

      if (keyName === 'firstApprover') {
        //console.log("Entered");
        newArr[keyName] = e.target.value.split(',')[0]
        newArr['firstApproverCode'] = e.target.value.split(',')[1]
      } else {
        newArr[keyName] = e.target.value
      }

      setOutputData({ ...outputData, newArr })
      // console.log("outputDta Fusen", outputData);
      checkMandatoryField()
    }
    if (field === 'nerData') {

      if (keyName === 'sellerName') {
        const newArr = outputData.nerData
        newArr['sellerSelectedIndex'] = [-1, -1]
        newArr['sellerCorrectedValues'] = [e.target.value, sellerNameCode.sellerCode, accountInfo]
        setOutputData({ ...outputData, newArr })

      }
      if (keyName === 'hospitalName') {
        const newArr = outputData.nerData
        newArr['hospitalSelectedIndex'] = [-1, -1]
        newArr['hospitalCorrectedValues'] = [e.target.value, hospitalNameCode.hospitalCode]
        setOutputData({ ...outputData, newArr })
      }
      if (keyName === 'protocolNo') {
        const newArr = outputData.nerData
        newArr['protocolSelectedIndex'] = [-1, -1]
        newArr['protocolCorrectedValues'] = [e.target.value, protocolNameCode.protocolName]
        setOutputData({ ...outputData, newArr })
      }
      if (keyName === 'sellerCode') {
        const newArr = outputData.nerData
        newArr['sellerSelectedIndex'] = [-1, -1]
        newArr['sellerCorrectedValues'] = [sellerNameCode.sellerName, e.target.value]
        setOutputData({ ...outputData, newArr })
      }
      if (keyName === 'hospitalCode') {
        const newArr = outputData.nerData
        newArr['hospitalSelectedIndex'] = [-1, -1]
        newArr['hospitalCorrectedValues'] = [hospitalNameCode.hospitalName, e.target.value]
        setOutputData({ ...outputData, newArr })
      }
      if (keyName === 'accountInfo') {
        const newArr = outputData.nerData
        newArr['multipleSellerInfo'][sellerNameCode.sellerName][sellerNameCode.sellerCode]['formatted_account_info'] = e.target.value
        setOutputData({ ...outputData, newArr })
      }
      if (keyName === 'totalAmount' || keyName === 'invoiceNumber' || keyName === 'issueDate' || keyName === 'paymentDeadline' || keyName === 'purposeOfPayment' || keyName === 'currencyCode') {
        const newArr = outputData.nerData
        newArr[keyName] = e.target.value
        setOutputData({ ...outputData, newArr })
      }
      checkMandatoryField()
    }

  }

  // For Next prev Upload SaveDraft functionality
  const saveDraftPage = async (done) => {
    // setMandatoryCheck(true)

    setSlideClass('')
    // if item name and amount without tax field is empty that row will be eleminated
    const newTableData = tableData.filter(val => { return val.itemName !== '' && val.amountWithOutTax !== '' })
    // setTableData(newTableData)
    // console.log("Filterred Table Data",newTableData);
    // console.log("Filterred Table Data2",tableData);
    if (checkMandatoryField() && parseFloat(invoiceInfo.totalAmount) === totalAmountCat()) {
      if (outputData.nerData.invoiceNumber === '' && (outputData.nerData.issueDate === null || outputData.nerData.issueDate === '')) {
        return toast.warning(t('stringMismatch'), { position: toast.POSITION.TOP_CENTER, autoClose: 3000, pauseOnHover: false })
      }
      else {
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/deepicr/extracted?fid=${fid}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "Authorization": "Bearer " + jwt,
            "sid": sessionId
          },
          body: JSON.stringify({
            isDone: done,
            nerData: outputData.nerData,
            fusen: outputData.fusen,
            itemTableData: newTableData,
            categoryTableData: cTableData
          })

        })
        const data = await res.json()
        if (res.status === 200 && data.message) {
          // console.log("ENtered");
          if (checkMandatoryField() && parseFloat(invoiceInfo.totalAmount) === totalAmountCat()) {

            setApprover([])
            if (othersClicked === 'next') {
              setFileName(resultPrevNext.next[0].fileName)
              setFid(resultPrevNext.next[0]._id)
              getOutputViewData(resultPrevNext.next[0]._id)
            }
            if (othersClicked === 'prev') {
              setFileName(resultPrevNext.prev[0].fileName)
              setFid(resultPrevNext.prev[0]._id)
              getOutputViewData(resultPrevNext.prev[0]._id)
            }
            if (othersClicked === 'upload') {
              navigate('/fileupload')
            }
            toast.success(t('stringSavedSuccessfully'), { position: toast.POSITION.TOP_CENTER, autoClose: 3000, pauseOnHover: false })

          } else {
            toast.warning(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 5000, pauseOnHover: false })

          }
        }
        else if (res.status === 401) {
          toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
          dispatch(resetCredentials())
          navigate('/login', { state: { isLoading: false } })
        }
        else {
          toast.success(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
        }
      }

    }
    else {
      toast.warning(t('stringMismatch'), { position: toast.POSITION.TOP_CENTER, autoClose: 5000, pauseOnHover: false })
    }
  }

  // SaveDraft functionility
  const saveDraft = async (done) => {
    // setMandatoryCheck(true)
    setSlideClass('')
    // if item name and amount without tax field is empty that row will be eleminated
    const newTableData = tableData.filter(val => { return val.itemName !== '' && val.amountWithOutTax !== '' })
    // setTableData(newTableData)
    // console.log("Filterred Table Data",newTableData);
    // console.log("Filterred Table Data2",tableData);
    if (checkMandatoryField() && parseFloat(invoiceInfo.totalAmount) === totalAmountCat()) {
      if (outputData.nerData.invoiceNumber === '' && (outputData.nerData.issueDate === null || outputData.nerData.issueDate === '')) {
        !done && toggle()
        return toast.warning(t('stringMismatch'), { position: toast.POSITION.TOP_CENTER, autoClose: 3000, pauseOnHover: false })
      }
      else {
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/deepicr/extracted?fid=${fid}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "Authorization": "Bearer " + jwt,
            "sid": sessionId
          },
          body: JSON.stringify({
            isDone: done,
            nerData: outputData.nerData,
            fusen: outputData.fusen,
            itemTableData: newTableData,
            categoryTableData: cTableData
          })

        })
        const data = await res.json()
        if (res.status === 200 && data.message) {

          if (resultPrevNext.next.length > 0) {
            if (checkMandatoryField() && parseFloat(invoiceInfo.totalAmount) === totalAmountCat()) {
              // setMandatoryCheck(true)
              setFileName(resultPrevNext.next[0].fileName)
              setApprover([])
              setFid(resultPrevNext.next[0]._id)
              toast.success(t('stringSavedSuccessfully'), { position: toast.POSITION.TOP_CENTER, autoClose: 3000, pauseOnHover: false })
              getOutputViewData(resultPrevNext.next[0]._id)
              !done && toggle()
            } else {
              toast.warning(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 20000, pauseOnHover: false })
              !done && toggle()
            }

          } else {
            if (checkMandatoryField() && parseFloat(invoiceInfo.totalAmount) === totalAmountCat()) {
              setApprover([])
              toast.success(`${t('stringSavedSuccessfully')}`, { position: toast.POSITION.TOP_CENTER, autoClose: false, pauseOnHover: false })
              toast.success(t('stringLastPdf'), { position: toast.POSITION.TOP_CENTER, autoClose: 4000, pauseOnHover: false })
              navigate('/deepICR')
            } else {
              toast.warning(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 20000, pauseOnHover: false })
              !done && toggle()
            }

          }
        }
        else if (res.status === 401) {
          toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
          dispatch(resetCredentials())
          navigate('/login', { state: { isLoading: false } })
        }
        else {
          toast.success(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 20000, pauseOnHover: false })
        }
      }

    }
    else {
      // console.log("Error Done", done);
      !done && toggle()
      toast.warning(t('stringMismatch'), { position: toast.POSITION.TOP_CENTER, autoClose: 5000, pauseOnHover: false })
    }
  }

  var checkIndex = true
  // To track mandatory field 
  // return boolean
  // if false do not allow to change the page
  const checkMandatoryField = () => {
    if (outputData.fusen.costCenter && outputData.fusen.firstApprover && sellerNameCode.sellerName && sellerNameCode.sellerCode && accountInfo !== '' && protocolNameCode.protocolCode && protocolNameCode.protocolName && outputData.nerData.paymentDeadline && invoiceInfo.totalAmount && outputData.nerData.currencyCode && outputData.nerData.purposeOfPayment) {
      const fileredCTable = cTableData.filter(element => { return !selectedCheckedFile.includes(element._id) })
      // console.log("Filtered C table Data", fileredCTable);
      fileredCTable.forEach(element => {
        if (element.categoryName !== "" && element.amount !== "" && element?.text !== "") {
          if (element.amount !== null) {
            dispatch(fileUploadActive(false))
          } else {
            dispatch(fileUploadActive(true))
            checkIndex = false
          }
        } else {
          dispatch(fileUploadActive(true))
          checkIndex = false
        }
      })
      return checkIndex

    }
    else {
      dispatch(fileUploadActive(true))
      return false
    }
  }

  // For tracking the object id which fields are over the byte size limnit
  // from those id give the border color
  const [borderId, setBorderId] = useState([])

  // For show warning sign 
  // if any mandatory field of category table is blank show warning sign
  // Also checking the byte limit of text field
  var checkMandatoryIndex = true
  const checkCategoryMandatoField = (catTable, selectedFile, nerData) => {
    const borderColorId = []

    if (catTable.length <= 0) {
      setMandatoryCheck(false)
    }

    const filteringSelectedFile = []
    catTable && catTable.forEach(excludedFile => {
      if (excludedFile.exclude === true) {
        filteringSelectedFile.push(excludedFile._id)
      }
    })
    const fileredCTable = catTable && catTable.filter(element => { return !filteringSelectedFile.includes(element._id) })


    // Checking Each text field byte size
    //text fields are stored in an array which exceed byte limnit
    // using the array text field border will be red in useLayoutEffect
    var checkTextByteSize = false
    fileredCTable && fileredCTable.forEach((element, ind) => {
      if (element?.text) {
        // Coverting to unit8Array 
        const converted = new TextEncoder().encode(element.text)
        // Then Coverting into Shift Jis
        const convertedShiftJis = Encoding.convert(converted, 'SJIS');

        const textByteSize = convertedShiftJis.length

        if (textByteSize > process.env.REACT_APP_TEXT_BYTE) {
          borderColorId.push(`${element._id}_text_${ind}`)
          checkTextByteSize = true
          dispatch(setTextChange(true))
          // setInputReadOnlyPop({...inputReadOnlyPop,text:true})
        }
      }

      if (element?.categoryName !== "" && element?.categoryNumber
        !== "" && element.amount !== null && element?.text !== "") {
        if (element.amount !== "") {
          dispatch(fileUploadActive(false))
        } else {
          dispatch(fileUploadActive(true))
          checkMandatoryIndex = false
          return setMandatoryCheck(false)
        }
      } else {
        // console.log("should be false ");
        dispatch(fileUploadActive(true))
        checkMandatoryIndex = false
        return setMandatoryCheck(false)
      }
    });

    if (!checkTextByteSize) {
      dispatch(setTextChange(false))
      // setInputReadOnlyPop({...inputReadOnlyPop,text:false})
    }
    setBorderId(borderColorId)
    return mandatoryCheck
  }

  const deleteInvoice = async () => {
    // if (checkMandatoryField()) {
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/file/delete`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      },
      body: JSON.stringify({
        fid: [fid]
      })
    })
    const data = await res.json()

    if (res.status === 200) {
      toast.success(t('stringFileDelete'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
      setApprover([])
      setMandatoryCheck(true)
      toggleTwo()
      setFid(resultPrevNext.next[0]._id)
      getOutputViewData(resultPrevNext.next[0]._id)
    }
    else if (res.status === 401) {
      toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
      dispatch(resetCredentials())
      navigate('/login', { state: { isLoading: false } })
    }
    else {
      toast.success(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
    }
    // } else {
    //   toast.warning(t('stringFillMandatory'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
    // }

  }

  // onChange Event Auto intellegance code change
  // Api for Seller Name,Hospital Name,Protocol No
  const changeCode = async (fieldName) => {
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/biz-logic/bizinfoupdate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      },
      body: JSON.stringify({
        nerData: outputData.nerData,
        fieldName
      })

    })
    const data = await res.json()
    if (res.status === 200) {
      setNerData(data.nerData && data.nerData)

      setIsProtocolUserInput(false)
      const newData = data.nerData

      setProtocolNameCode({ ...protocolNameCode, protocolName: data.nerData?.protocolName[0][0]?.length ? data.nerData.protocolName[0][0] : "" })

      newData['isProtocolUserInput'] = true
      newData['protocolSelectedIndex'] = [0, 0]

      setOutputData({ ...outputData, nerData: newData })

      if (data.nerData?.protocolNo.length > 1) {
        dispatch(setTrackSingleValue(true, 'protocol'))
      } else if (data.nerData?.protocolName[0].length > 1) {
        dispatch(setTrackSingleValue(true, 'protocol'))
      } else {
        dispatch(setTrackSingleValue(false, 'protocol'))
      }

      // Here will be checked wheather the selected index value all positive or negative
      //  If Negative then will set value from corrected value
      setProtocolNameCode({
        protocolCode: data.nerData?.protocolNo[data.nerData.protocolSelectedIndex[0]],
        protocolName: data.nerData?.protocolName[data.nerData?.protocolSelectedIndex[0]][data.nerData?.protocolSelectedIndex[1]]
      })
    }
    else if (res.status === 401) {
      toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
      dispatch(resetCredentials())
      navigate('/login', { state: { isLoading: false } })
    }
    else {
      toast.warning(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
    }
  }

  // Getting Hospitalname suggestion from lambda
  // Onchange event triggerrred

  const hospitalNameSearch = async (e) => {
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/biz-logic/get-hospital-names?query=${e.target.value}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      },
      // body: JSON.stringify({
      //   "query":'d'
      // })
    })
    const data = await res.json()
    if (res.status === 200 && data) {
      setHospitalSuggestion(data.key)
    }
    else if (res.status === 401) {
      toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
      dispatch(resetCredentials())
      navigate('/login', { state: { isLoading: false } })
    }
    else {
      toast.success(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
    }
  }

  const sellerNameSearch = async (e) => {
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/biz-logic/get-seller-names?query=${e.target.value}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      },
    })
    const data = await res.json()
    if (res.status === 200 && data) {
      setSellerSuggestion(data.key)
    }
    else if (res.status === 401) {
      toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
      dispatch(resetCredentials())
      navigate('/login', { state: { isLoading: false } })
    }
    else {
      toast.success(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
    }
  }

  // For hospitalname calling 
  const hospitalCode = async (e, fieldName) => {
    if (e.key === 'Enter') {
      const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/biz-logic/bizinfoupdate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "Authorization": "Bearer " + jwt,
          "sid": sessionId
        },
        body: JSON.stringify({
          nerData: outputData.nerData,
          fieldName: fieldName
        })

      })
      const data = await res.json()
      if (res.status === 200) {
        setNerData(data.nerData && data.nerData)
        if (fieldName === 'sellerName') {
          setIsSellerUserInput(false)
          const newData = data.nerData

          newData['isSellerUserInput'] = true
          newData['sellerSelectedIndex'] = [0, 0]

          setOutputData({ ...outputData, nerData: newData })

          if (data.nerData?.sellerName.length > 1) {
            dispatch(setTrackSingleValue(true, 'seller'))
          } else if (data.nerData?.sellerCode[0].length > 1) {
            dispatch(setTrackSingleValue(true, 'seller'))
          } else {
            dispatch(setTrackSingleValue(false, 'seller'))
          }

          setSellerNameCode({
            sellerName: data.nerData?.sellerName[data.nerData?.sellerSelectedIndex[0]],
            sellerCode: data.nerData?.sellerCode[data.nerData?.sellerSelectedIndex[0]][data.nerData?.sellerSelectedIndex[1]]
          })

          setAccountInfo(Object.keys(data.nerData.multipleSellerInfo).length ? data.nerData.multipleSellerInfo[data.nerData.sellerName[data.nerData.sellerSelectedIndex[0]]][data.nerData.sellerCode[data.nerData.sellerSelectedIndex[0]][data.nerData.sellerSelectedIndex[1]]]['formatted_account_info'] : "")
        }

        if (fieldName === 'hospitalName') {

          setIsHospitalUserInput(false)
          const newData = data.nerData

          newData['isHospitalUserInput'] = true
          newData['hospitalSelectedIndex'] = [0, 0]

          setOutputData({ ...outputData, nerData: newData })

          if (data.nerData?.hospitalName.length > 1) {
            dispatch(setTrackSingleValue(true, 'hospital'))
          } else if (data.nerData?.hospitalCode[0].length > 1) {
            dispatch(setTrackSingleValue(true, 'hospital'))
          } else {
            dispatch(setTrackSingleValue(false, 'hospital'))
          }

          setHospitalNameCode({
            hospitalName: data.nerData?.hospitalName[data.nerData?.hospitalSelectedIndex[0]],
            hospitalCode: data.nerData?.hospitalCode[data.nerData?.hospitalSelectedIndex[0]][data.nerData?.hospitalSelectedIndex[1]]
          })
        }

      }
      else if (res.status === 401) {
        toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
        dispatch(resetCredentials())
        navigate('/login', { state: { isLoading: false } })
      }
      else {
        toast.warning(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
      }

    }
  }

  // Detecting Byte size 
  // POP-40 Byte
  //Text-50 Byte
  // Description- 400 Byte
  // Invoice - 30 Byte

  const byteSize = (str, id) => {
    // Coverting to unit8Array 
    const converted = new TextEncoder().encode(str)
    // Then Coverting into Shift Jis
    const convertedShiftJis = Encoding.convert(converted, 'SJIS');

    const textByteSize = convertedShiftJis.length
    // console.log("textSize",textByteSize);

    if (id === 'nerData_purposeOfPayment') {
      if (textByteSize > process.env.REACT_APP_POP_BYTE) {
        dispatch(setPopChange(true))
        // setInputReadOnlyPop({...inputReadOnlyPop,pop:true})
      } else {
        dispatch(setPopChange(false))
        // setInputReadOnlyPop({...inputReadOnlyPop,pop:false})
      }
    }

    if (id === 'nerData_invoiceNumber') {
      if (textByteSize > process.env.REACT_APP_INVOICE_BYTE) {
        dispatch(setInvoiceChange(true))
        // setInputReadOnlyPop(prevState=>({...prevState,invoice:'true'}))
      } else {
        dispatch(setInvoiceChange(false))
        // setInputReadOnlyPop(prevState=>({...prevState,invoice:'false'}))
      }
    }

    if (id === 'fusen_description') {
      if (textByteSize > process.env.REACT_APP_MEMO_BYTE) {
        dispatch(setMemoChange(true))
        // setInputReadOnlyPop({...inputReadOnlyPop,memo:true})
      } else {
        dispatch(setMemoChange(false))
        // setInputReadOnlyPop({...inputReadOnlyPop,memo:false})
      }
    }

    if (id.indexOf('text') > -1) {
      if (textByteSize > process.env.REACT_APP_TEXT_BYTE) {
        document.getElementById(id).parentElement.style.border = '2px solid red'
      } else {
        document.getElementById(id).parentElement.style.border = '1px solid #DDDDDD'
      }
    }

  }

  const makingMultipleSellerList = (field) => {
    if (field === 'seller') {
      const newSellerList = []
      for (var i = 0; nerData.sellerName && nerData.sellerName.length > i; i++) {
        if(nerData.sellerCode[i]?.length===0){newSellerList.push(`${nerData?.sellerName[i]} + `)} 
        for (let j = 0; nerData.sellerCode && nerData.sellerCode[i].length > j; j++) {
          newSellerList.push(`${nerData?.sellerName[i]} + ${nerData?.sellerCode[i][j]}`)
        }
      }
      return newSellerList
    }
    if (field === 'hospital') {
      const newHospitalList = []
      for (var i = 0; nerData.hospitalName && nerData.hospitalName.length > i; i++) {
        if(nerData.hospitalCode[i]?.length===0){newHospitalList.push(`${nerData?.hospitalName[i]} + `)}
        for (let j = 0; nerData.hospitalCode && nerData.hospitalCode[i].length > j; j++) {
          newHospitalList.push(`${nerData?.hospitalName[i]} + ${nerData?.hospitalCode[i][j]}`)
        }
      }
      return newHospitalList
    }
    if (field === 'protocol') {
      const newProtocolList = []
      for (var i = 0; nerData.protocolNo && nerData.protocolNo.length > i; i++) {
        if(nerData.protocolName[i]?.length===0){newProtocolList.push(`${nerData?.protocolNo[i]} + `)}
        for (let j = 0; nerData.protocolName && nerData.protocolName[i].length > j; j++) {
          newProtocolList.push(`${nerData?.protocolNo[i]} + ${nerData?.protocolName[i][j]}`)
        }
      }
      return newProtocolList
    }

  }

  // OnChangeSellerName from multiple option 
  const changeValueToSingleName = (e, field) => {
    dispatch(trackChangeInResultPage(true))
    if (field === 'seller') {
      const splitNameCode = e.target.value.split(' + ')
      const seperateIndex = splitNameCode[1].split('_')
      setSellerNameCode({
        sellerName: splitNameCode[0],
        sellerCode: seperateIndex[0]
      })
      if(seperateIndex[0] === ''){
        setAccountInfo('')
      }else{
        setAccountInfo(nerData.multipleSellerInfo[splitNameCode[0]][seperateIndex[0]]['formatted_account_info'])
      }
     
      const sellerNameIndex = nerData.sellerName.indexOf(splitNameCode[0])
      const sellerCodeIndex = nerData.sellerCode[sellerNameIndex].indexOf(seperateIndex[0])
      const newArr = outputData.nerData
      newArr['sellerSelectedIndex'] = [sellerNameIndex, sellerCodeIndex]
      newArr['isSellerDropdownchanged'] = true
      setOutputData({ ...outputData, newArr })
      e.target.value = ''
    }

    if (field === 'hospital') {
      const splitNameCode = e.target.value.split(' + ')
      const seperateIndex = splitNameCode[1].split('_')
      // console.log("Split Name",splitNameCode);
      setHospitalNameCode({
        hospitalName: splitNameCode[0],
        hospitalCode: seperateIndex[0]
      })
      const hospitalNameIndex = nerData.hospitalName.indexOf(splitNameCode[0])
      const hospitalCodeIndex = nerData.hospitalCode[hospitalNameIndex].indexOf(seperateIndex[0])
      const newArr = outputData.nerData
      newArr['hospitalSelectedIndex'] = [hospitalNameIndex, hospitalCodeIndex]
      newArr['isHospitalDropdownchanged'] = true
      setOutputData({ ...outputData, newArr })

      e.target.value = ''
    }

    if (field === 'protocol') {
      const splitNameCode = e.target.value.split(' + ')
      const seperateIndex = splitNameCode[1].split('_')
      // console.log("Split Name",splitNameCode);
      setProtocolNameCode({
        protocolName: seperateIndex[0],
        protocolCode: splitNameCode[0]
      })
      const protocolCodeIndex = nerData.protocolNo.indexOf(splitNameCode[0])
      const protocolNameIndex = nerData.protocolName[protocolCodeIndex].indexOf(seperateIndex[0])
      const newArr = outputData.nerData
      newArr['protocolSelectedIndex'] = [protocolCodeIndex, protocolNameIndex]
      newArr['isProtocolDropdownchanged'] = true
      setOutputData({ ...outputData, newArr })

      e.target.value = ''
    }
  }

  useEffect(() => {
    if (location.state) {
      setFid(location.state.fid)
      getOutputViewData(location.state.fid)
    }
  }, [])


  // after rendering the html getting the byte esxceeding field and make border red
  useLayoutEffect(() => {
    borderId.map((val, ind) => {
      const getId = document.getElementById(val)
      if (getId !== null) {
        getId.parentElement.style.border = '2px solid red'
      }
    })
  })

  useEffect(() => {
    setSelectedCheckedFile(selectedCheckedFile)
  }, [selectedCheckedFile])

  return (
    <>
      <MenuBar checkMandatoryField={checkMandatoryField} invoiceInfo={invoiceInfo} totalAmountCat={totalAmountCat} tableData={tableData} fid={fid} outputData={outputData} cTableData={cTableData} inputReadOnlyPop={inputReadOnlyPop} />
      {
        loadingImage ?
          <Loader loading={loadingImage} /> :
          <>
            <div className={styles.styleRoot}>
              <header>
                <SecondNav resultPrevNext={resultPrevNext} showResultNext={showResultNext} showResultPrev={showResultPrev} setOthersClicked={setOthersClicked} toggleThree={toggleThree} />
              </header>
              <Container className={styles.styleContainer}>
                <InputViewer fileId={fid} fileName={fileName} pages={pages} setNumpages={setNumpages} currentPageNumber={currentPageNumber} setCurrentPageNumber={setCurrentPageNumber} b64={b64} setb64={setb64} rotation={rotation} setRotation={setRotation} imageConvert={imageConvert} pdfToJpeg={pdfToJpeg} setLoadingImage={setLoadingImage} resultImage={resultImage} />
                <div className={styles.styleBar} />
                <div className={styles.styleOutputViewer}>

                  <Toolbar className={styles.styleToolbar}>

                    <CustomTabs value={value} onChange={handleChange} aria-label="output tabs" style={{ minHeight: "auto" }}>
                      <Tab label={`${t('stringOcrResultConfirmation')}`} {...retProps(value, 0)} />
                    </CustomTabs>

                    <Typography className={styles.styleSpacer}></Typography>
                    <div style={{ width: "80%", display: 'flex', justifyContent: "flex-end" }}>
                      <CustomButton className={styles.toolBarBtn}
                        style={{
                          marginLeft: ".2rem"
                        }}
                        onClick={() => {
                          toggleThree()
                          setOthersClicked('redo')
                        }}
                      >{t('stringRedoOcr')}</CustomButton>

                      <CustomButton className={styles.toolBarBtn}
                        onClick={() => { toggleTwo() }}
                        style={{
                          marginLeft: "0.2rem",
                        }}
                      >{t('stringDeleteInvoice')}</CustomButton>
                    </div>

                    <div style={{ display: 'none' }}>
                      <Divider orientation="vertical" className={styles.styleDivider} />
                      <ButtonEnlargeFont value={value} />
                      <ButtonShrinkFont value={value} />
                      <ButtonResetFont value={value} />
                    </div>
                  </Toolbar>

                  {/* *****************************result page design <invoice issuer information*****************/}
                  <div className='resultPage-issuer-information'>
                    <p className='issuer-title' style={{ fontWeight: "bolder" }}>{t('stringInvoiceIsuuerInfo')}</p>
                    {/* Master file and fusen info part */}
                    <div className='information'>
                      <form>
                        {/* cost center */}
                        <div className='form-control'>
                          <label htmlFor='costCenter'>{t('stringCostCenter')} *</label>

                          <input type={'text'} list="datalistOptions3" id='fusen_costCenter' autoComplete='false' value={outputData.fusen && outputData.fusen.costCenter || ""} style={{ color: "black !important", border: outputData.fusen && outputData.fusen.costCenter === '' ? "2px solid red" : "1px solid black" }} onChange={(e) => {
                            firstApprover(e.target.value)
                            updateNerFusen(e)
                          }

                          } />
                          <datalist id="datalistOptions3">
                            {
                              JSON.parse(sessionStorage.getItem('get-cost-center'))?.map(val => {
                                return (
                                  <option value={val} />
                                )
                              })
                            }
                          </datalist>
                          {outputData.fusen && outputData.fusen.costCenter === '' ? <WarningIcon style={{ fill: "#FF0000", marginLeft: "10px" }} titleAccess={t('stringMandatoryMessage')} /> : ""}
                        </div>
                        {/* First Approver */}
                        <div className='form-control'>
                          <label htmlFor='firstApprover'>{t('stringFirstApprover')}: *</label>

                          <select
                            labelid="demo-simple-select-filled-label"
                            id="fusen_firstApprover"
                            className="form-select" aria-label="Default select example"
                            style={{ width: '30%', border: outputData.fusen && outputData.fusen.firstApprover === "" ? "2px solid red" : "1px solid black" }}
                            onChange={updateNerFusen}
                          >
                            {
                              approver && approver.length && approver.length > 0 ? approver.map(val => {
                                return (
                                  <option value={val}>{val[0]}</option>
                                )
                              }) : <option value={outputData.fusen && outputData.fusen.firstApprover}>{outputData.fusen && outputData.fusen.firstApprover || ''}</option>
                            }

                          </select>
                          {outputData.fusen && outputData.fusen.firstApprover === "" ? <WarningIcon style={{ fill: "#FF0000", marginRight: "10px" }} titleAccess={t('stringMandatoryMessage')} /> : ""}
                        </div>

                        {/* seller code/ name */}
                        <div className='form-control' style={{ marginTop: "20px" }}>
                          <label htmlFor='sellerCode'>{t('stringSellerCodeName')}</label>
                          <div>
                            {
                              sellerSuggestion && sellerSuggestion.length > 0 ?
                                <>
                                  <input class="form-control" list={"datalistOptions"} name="costCenter" autoComplete='false' value={sellerNameCode.sellerName} id="nerData_sellerName" placeholder={`${t('stringTypeSearch')}`} onChange={(e) => {
                                    setSellerNameCode({ ...sellerNameCode, sellerName: e.target.value })
                                    updateNerFusen(e)
                                    sellerNameSearch(e)
                                  }
                                  }
                                    onKeyPress={(e) => { hospitalCode(e, 'sellerName') }}
                                    style={{ minWidth: "265px", maxWidth: "270px", border: sellerNameCode.sellerName === '' ? "2px solid red" : "1px solid black" }} />

                                  <datalist id="datalistOptions">
                                    {
                                      sellerSuggestion.map(val => {
                                        return (
                                          <option value={val} >{val}</option>
                                        )
                                      })

                                    }
                                  </datalist>
                                </>
                                :
                                <>

                                  <input class="form-control" list={"datalistOptions11"} name="costCenter" autoComplete='false' value={sellerNameCode.sellerName} id="nerData_sellerName" placeholder={`${t('stringTypeSearch')}`} onChange={(e) => {
                                    setSellerNameCode({ ...sellerNameCode, sellerName: e.target.value })
                                    updateNerFusen(e)
                                    sellerNameSearch(e)
                                  }
                                  }
                                    onKeyPress={(e) => { hospitalCode(e, 'sellerName') }}
                                    style={{ minWidth: "265px", maxWidth: "270px", border: sellerNameCode.sellerName === '' ? "2px solid red" : "1px solid black" }} />

                                  <datalist id="datalistOptions11">
                                    <option value={sellerNameCode.sellerName} readOnly>{t('stringSellerNameNotFound')}</option>
                                  </datalist>
                                </>
                            }

                          </div>
                          {/* For Multiple SellerName and Code */}
                          {
                            !isSellerUserInput && trackSingleValue.sellerField === true ?
                              <select style={{ marginLeft: "10px", marginRight: "10px", minWidth: "30px", maxWidth: "30px", height: "40px" }}
                                aria-label="Default select example"
                                className='select-box'
                                onChange={(e) => { changeValueToSingleName(e, 'seller') }}
                              >
                                <option selected disabled></option>
                                {
                                  makingMultipleSellerList('seller').map((val, ind) => {
                                    return (
                                      <option value={`${val}_${ind}`} >{val}</option>
                                    )
                                  })
                                }
                              </select> : ""
                          }


                          <input type={'text'} id='nerData_sellerCode' style={sellerNameCode.sellerCode === '' ? { border: "2px solid red" } : {}} value={sellerNameCode.sellerCode} onChange={(e) => {
                            setSellerNameCode({ ...sellerNameCode, sellerCode: e.target.value })
                            updateNerFusen(e)
                          }
                          } />
                          {(sellerNameCode.sellerCode === '') || (sellerNameCode.sellerName === '') ? <WarningIcon style={{ fill: "#FF0000", marginLeft: "10px" }} titleAccess={t('stringMandatoryMessage')} /> : ""}
                          {/* Danger Icon Condition */}


                        </div>
                        {/* Account Info */}
                        <div className='form-control accountInfo'>
                          <label htmlFor='accoutInfo'>{t('stringAccountInfo')}*</label>
                          <input type={'text'} id='nerData_accountInfo' value={accountInfo} autoComplete='false' onChange={(e) => {
                            setAccountInfo(e.target.value)
                            updateNerFusen(e)
                          }
                          }
                            style={{ border: accountInfo === "" ? "2px solid red" : "1px solid black" }} />
                          {accountInfo === "" ? <WarningIcon style={{ fill: "#FF0000", marginLeft: "10px" }} titleAccess={t('stringMandatoryMessage')} /> : ""}
                        </div>
                        {/* Hospital code/name Info */}
                        <div className='form-control' style={{ marginTop: "20px" }}>
                          <label htmlFor='hospitalCode'>{t('stringHospitalCodeName')}</label>

                          {
                            hospitalSuggestion && hospitalSuggestion.length > 0 ?
                              <>
                                <input list="datalistOptions8" name="costCenter" autoComplete='false' style={{ color: "black !important", border: hospitalNameCode.hospitalName === '' ? "2px solid orange" : "1px solid black" }} type={'text'} id='nerData_hospitalName' value={hospitalNameCode.hospitalName} onChange={(e) => {
                                  setHospitalNameCode({ ...hospitalNameCode, hospitalName: e.target.value })
                                  updateNerFusen(e)
                                  hospitalNameSearch(e)
                                }
                                } onKeyPress={(e) => { hospitalCode(e, 'hospitalName') }} />
                                <datalist id="datalistOptions8">
                                  {
                                    hospitalSuggestion && hospitalSuggestion.map(val => {
                                      return (
                                        <option value={val} >{val}</option>
                                      )
                                    })
                                  }
                                </datalist>
                              </> :
                              <>
                                <input list="datalistOptions13" name="costCenter" autoComplete='false' style={{ color: "black !important", border: hospitalNameCode.hospitalName === '' ? "2px solid orange" : "1px solid black" }} type={'text'} id='nerData_hospitalName' value={hospitalNameCode.hospitalName} onChange={(e) => {
                                  setHospitalNameCode({ ...hospitalNameCode, hospitalName: e.target.value })
                                  updateNerFusen(e)
                                  hospitalNameSearch(e)
                                }
                                } onKeyPress={(e) => { hospitalCode(e, 'hospitalName') }} />
                                <datalist id="datalistOptions13">
                                  <option value={hospitalNameCode.hospitalName} readOnly>{t('stringHospitalNameNotFound')}</option>
                                </datalist>
                              </>
                          }

                          {/* For Multiple HospitalName and Code */}
                          {
                            !isHospitalUserInput && trackSingleValue.hospitalField === true ?
                              <select style={{ marginLeft: "10px", marginRight: "10px", minWidth: "30px", maxWidth: "30px", height: "40px" }}
                                aria-label="Default select example"
                                className='select-box'
                                onChange={(e) => { changeValueToSingleName(e, 'hospital') }}
                              >
                                <option selected disabled></option>
                                {
                                  makingMultipleSellerList('hospital').map((val, ind) => {
                                    return (
                                      <option value={`${val}_${ind}`} >{val}</option>
                                    )
                                  })
                                }
                              </select> : ""
                          }

                          <input type={'text'} id='nerData_hospitalCode' value={hospitalNameCode.hospitalCode} style={{ border: hospitalNameCode.hospitalCode === "" ? "2px solid orange" : "1px solid black" }} onChange={(e) => {
                            setHospitalNameCode({ ...hospitalNameCode, hospitalCode: e.target.value })
                            updateNerFusen(e)
                          }
                          } />
                          {(hospitalNameCode.hospitalCode === "") || (hospitalNameCode.hospitalCode === "") ? <WarningIcon style={{ fill: "#FFA500", marginLeft: "10px" }} titleAccess={t('stringNonMandatoryMessage')} /> : ""}
                        </div>

                        {/* protocol no */}
                        <div className='form-control'>
                          <label htmlFor='protocolNo'>{t('stringProtocolNoProjectCode')}</label>

                          <input class="form-control" list="datalistOptions2" autoComplete='false' name="costCenter" value={protocolNameCode.protocolCode} id="nerData_protocolNo" placeholder="Type to search..." onChange={(e) => {
                            setProtocolNameCode({ ...protocolNameCode, protocolCode: e.target.value })
                            updateNerFusen(e)
                            changeCode('protocolNo')
                          }
                          }
                            style={{ width: "270px", border: (protocolNameCode.protocolCode === "") || (protocolNameCode.protocolCode === null) ? "2px solid red" : "1px solid black" }} />
                          <datalist id="datalistOptions2">
                            {
                              JSON.parse(sessionStorage.getItem('get-protocol-numbers'))?.map(val => {

                                return (
                                  <option value={val} />
                                )
                              })
                            }
                          </datalist>

                          {/* For Multiple ProtocolName and Code */}
                          {
                            !isProtocolUserInput && trackSingleValue.protocolField === true ?
                              <select style={{ marginLeft: "10px", marginRight: "10px", minWidth: "30px", maxWidth: "30px", height: "40px" }}
                                aria-label="Default select example"
                                className='select-box'
                                onChange={(e) => { changeValueToSingleName(e, 'protocol') }}
                              >
                                <option selected disabled></option>
                                {
                                  makingMultipleSellerList('protocol').map((val, ind) => {
                                    return (
                                      <option value={`${val}_${ind}`} >{val}</option>
                                    )
                                  })
                                }
                              </select> : ""
                          }

                          <input type={'text'} readOnly style={{ backgroundColor: "#EAEAF0", border: (protocolNameCode.protocolName === '') || (protocolNameCode.protocolName === undefined) || (protocolNameCode.protocolName === null) ? "2px solid red" : "1px solid black" }} value={protocolNameCode.protocolName} />
                          {((protocolNameCode.protocolCode === "") || (protocolNameCode.protocolCode === null)) || (protocolNameCode.protocolName === "") || (protocolNameCode.protocolName === undefined) || (protocolNameCode.protocolName === null) ? <WarningIcon style={{ fill: "#FF0000", marginLeft: "10px" }} titleAccess={t('stringMandatoryMessage')} /> : ""}
                        </div>

                        {/* Invoice no */}
                        <div className='form-control' style={{ marginTop: "20px" }}>
                          <label htmlFor='protocolNo'>{t('stringInvoiceNo')}</label>
                          <input type={'text'} id='nerData_invoiceNumber' value={outputData.nerData && outputData.nerData.invoiceNumber} onChange={(e) => {
                            updateNerFusen(e)
                            byteSize(e.target.value, e.target.id)
                          }

                          } style={{ border: outputData.nerData && outputData.nerData.invoiceNumber === '' ? "2px solid orange" : "1px solid black" }} />
                          {outputData.nerData && outputData.nerData.invoiceNumber === '' ? <WarningIcon style={{ fill: "#FFA500", marginLeft: "10px" }} titleAccess={t('stringNonMandatoryMessage')} /> : ""}
                        </div>
                        {invoiceChange.invoice === true ? <p style={{ marginLeft: "280px", color: 'red' }}>{t('stringByteInvoice')}</p> : ""}
                        {/* issue Date */}
                        <div className='form-control'>
                          <label htmlFor='issueDate'>{t('stringIsuueDate')}</label>
                          <DatePicker
                            id='nerData_issueDate'
                            format="yyyy/MM/dd"

                            style={{ border: outputData.nerData && (outputData.nerData.issueDate === "" || outputData.nerData.issueDate === null) ? "2px solid orange" : "1px solid black", width: "30%", borderRadius: "10px", width: "30%", borderRadius: "10px" }}
                            onChange={(date) => {
                              dispatch(trackChangeInResultPage(true))
                              const newArr = outputData.nerData
                              newArr['issueDate'
                              ] = date
                              setOutputData({ ...outputData, newArr })
                            }}
                            value={(outputData.nerData && outputData.nerData.issueDate && new Date(outputData.nerData.issueDate)) || null}
                          />
                          {outputData.nerData && (outputData.nerData.issueDate === "" || outputData.nerData.issueDate === null) ? <WarningIcon style={{ fill: "#FFA500", marginLeft: "10px" }} titleAccess={t('stringNonMandatoryMessage')} /> : ""}
                        </div>
                        {/* Payment Date */}
                        <div className='form-control' style={{ marginTop: "20px" }}>
                          <label htmlFor='paymentDate'>{t('stringPaymentDate')}*</label>

                          <DatePicker
                            format="yyyy/MM/dd"
                            id={"nerData_paymentDeadline"}
                            style={{ border: outputData.nerData && (outputData.nerData.paymentDeadline === "" || outputData.nerData.paymentDeadline === null) ? "2px solid red" : "1px solid black", width: "30%", borderRadius: "10px" }}
                            value={(outputData.nerData && outputData.nerData.paymentDeadline && new Date(outputData.nerData.paymentDeadline)) || null}
                            onChange={(date) => {
                              dispatch(trackChangeInResultPage(true))
                              var newArr
                              if (outputData.nerData && outputData.nerData.paymentDeadline) {
                                newArr = outputData.nerData
                                newArr['paymentDeadline'] = date
                                setOutputData({ ...outputData, newArr })
                              } else {
                                newArr = outputData.nerData
                                newArr['paymentDeadline'] = date
                                setOutputData({ ...outputData, newArr })
                              }
                            }}
                          />
                          {outputData.nerData && (outputData.nerData.paymentDeadline === "" || outputData.nerData.paymentDeadline === null) ? <WarningIcon style={{ fill: "#FF0000", marginLeft: "10px" }} titleAccess={t('stringMandatoryMessage')} /> : ""}
                        </div>

                        {/* Fusen Memo */}
                        <div className='form-control' style={{ marginTop: "20px" }}>
                          <label htmlFor='fusionMemo'>{t('stringFusen')}</label>
                          <textarea style={{ width: "63.5%" }} id='fusen_description' value={outputData.fusen && outputData.fusen.description || ""} onChange={(e) => {
                            updateNerFusen(e)
                            byteSize(e.target.value, e.target.id)
                          }} />
                        </div>
                        {invoiceChange.memo ? <p style={{ marginLeft: "280px", color: 'red' }}>{t('stringByteMemo')}</p> : ""}

                        {/* Total Amount */}
                        <div className='form-control'>
                          <label htmlFor='totalAmount' style={{ fontWeight: "bolder" }}>{t('stringTotalAmount')}*</label>
                          <input type={'text'} id='nerData_totalAmount' style={{ fontWeight: "bolder", textAlign: "right", border: invoiceInfo.totalAmount === "" ? "2px solid red" : "1px solid black" }} name={'totalAmount'} value={Math.round(invoiceInfo.totalAmount)} onChange={(e) => {
                            inputsChange(e)
                            updateNerFusen(e)
                          }} />
                          {invoiceInfo.totalAmount === '' ? <WarningIcon style={{ fill: "#FF0000" }} titleAccess={t('stringMandatoryMessage')} /> : ""}
                          <span style={{ marginLeft: "15px" }}>
                            <select
                              style={{ fontWeight: "bolder" }}
                              id="nerData_currencyCode"
                              className="form-select" aria-label="Default select example"
                              onChange={(e) => {
                                setCurrency(e.target.value)
                                updateNerFusen(e)
                              }}
                            >

                              {currencyArr.map((val) => {
                                return (
                                  <option selected={val === currency} value={val}>{val}</option>
                                )
                              })}
                            </select>
                          </span>
                          *
                        </div>

                      </form>
                    </div>

                    {/* Auto generated table */}

                    <div style={{ overflowX: 'auto', marginTop: "50px", marginBottom: "50px" }}>
                      <label style={{ fontWeight: "bolder", marginBottom: "10px" }}>{t('stringPaymentReqContent')}</label>
                      {!mandatoryCheck ? <WarningIcon style={{ fill: "#FF0000", marginLeft: "10px", marginBottom: "25px" }} titleAccess={t('stringMandatoryMessage')} /> : ""}
                      <table className='auto-table'>
                        <thead>
                          <tr>
                            <th className='auto-header'>{t('stringExclude')}</th>
                            <th className='auto-header'>{t('stringCategoryNumber')}</th>
                            <th className='auto-header'>{t('stringCategoryName')}</th>
                            <th className='auto-header' >{t('stringAmount')}</th>
                            <th className='auto-header'>{t('stringTax')}</th>
                            <th className='auto-header'>{t('stringText')} {invoiceChange.text ? <WarningIcon style={{ fill: "#FF0000", marginLeft: "10px" }} titleAccess={t('stringByteText')} /> : ""}</th>
                          </tr>
                        </thead>
                        <tbody>
                          {
                            cTableData && cTableData.map((val, ind) => {
                              return (
                                <tr style={{ backgroundColor: selectedCheckedFile.includes(val._id) ? "#F5F4F2" : "#ffffff" }} key={ind}>
                                  <td className='auto-data'><input className="form-check-input" type="checkbox" id={`${val._id}_exclude_${ind}`} checked={val.exclude} onChange={(e) => {
                                    SelectedCheckedData(e, val._id)
                                    updateCatTable(e)
                                  }} /></td>
                                  <td className='auto-data' id={`${val._id}_categoryNumber_${ind}`} style={{ textAlign: "right" }}>{val.categoryNumber}</td>
                                  <td className='auto-data' id={`${val._id}_categoryName_${ind}`}>
                                    <select
                                      labelid="demo-simple-select-filled-label"
                                      id={`${val._id}_categoryName_${ind}`}
                                      className="form-select" aria-label="Default select example"
                                      onChange={updateCatTable}
                                    >
                                      <option selected disabled>{t('stringSelectDrop')}</option>
                                      {
                                        JSON.parse(sessionStorage.getItem('get-category-names'))?.map(data => {
                                          return (
                                            <option selected={val.categoryName === data[0]} value={data[0]}> {data[0]}</option>
                                          )
                                        })
                                      }
                                    </select>
                                  </td>
                                  {/* <td className='auto-data' style={{ textAlign: "right" }} id={`${val._id}_amount_${ind}`} onInput={updateCatTable} suppressContentEditableWarning={true} contentEditable>{val.amount}</td> */}
                                  <td className='auto-data' > <input id={`${val._id}_amount_${ind}`} style={{ border: "none", outline: "none", textAlign: "right", backgroundColor: selectedCheckedFile.includes(val._id) ? "#F5F4F2" : "#ffffff" }} onFocus={(val.amount === 0 || val.amount === '0') ? changeZeroToBlankCat : () => { }} onChange={updateCatTable} value={Math.round(val.amount)} /></td>

                                  <td className='auto-data' style={{ display: "flex", justifyContent: "space-between" }} id={`${val._id}_taxRate_${ind}`}>
                                    <select
                                      labelid="demo-simple-select-filled-label"
                                      id={`${val._id}_taxRate_${ind}`}
                                      className="form-select" aria-label="Default select example"
                                      onChange={(e) => {
                                        updateCatTable(e)
                                      }}
                                    >
                                      {
                                        Object.keys(taxRate).map((value, ind) => {
                                          // console.log("taxRate",taxRate[value]);
                                          return (
                                            <option key={ind} selected={value === val.taxRate} value={taxRate[value]} data={value} >{value}</option>
                                          )
                                        })
                                      }
                                    </select>
                                  </td>
                                  {/* <td className='auto-data pre-line inline-block' onInput={updateCatTable} id={`${val._id}_text_${ind}`} suppressContentEditableWarning={true} contentEditable >{val.text}</td> */}
                                  <td className='auto-data pre-line inline-block' ><input id={`${val._id}_text_${ind}`} style={{ border: "none", outline: "none", backgroundColor: selectedCheckedFile.includes(val._id) ? "#F5F4F2" : "#ffffff" }} onChange={
                                    (e) => {
                                      updateCatTable(e)
                                      byteSize(e.target.value, e.target.id)
                                    }

                                  } value={val.text} /></td>
                                </tr>
                              )

                            })
                          }
                        </tbody>
                      </table>
                      <button type="button" className="btn btn-primary" style={{ marginTop: "10px", marginLeft: "auto" }} onClick={
                        () => {
                          setCRows(cRows + 1)
                          setCTableData([...cTableData, { _id: cRows + 1, taxRate: "10%", amount: '', categoryNumber: '', exclude: false, fileId: fid, categoryName: '', text: "" }])
                          setMandatoryCheck(false)
                        }
                      }>+ {t('stringAddLine')}</button>
                    </div>

                    <div className='information'>
                      <form>
                        <div className='form-control'>
                          <label htmlFor='detailsTotalPayment' id='payment-request' style={{ fontWeight: "bolder" }}>{t('stringPaymentReqTotal')}</label>
                          <input style={{ fontWeight: "bolder", backgroundColor: "#EAEAF0", textAlign: "right", border: parseFloat(invoiceInfo.totalAmount) !== totalAmountCat() ? "2px solid red" : "1px solid black" }} readOnly type={'text'} id='detailsTotalPayment' value={totalAmountCat()} />
                          <p style={{ marginLeft: "10px", fontWeight: "bolder", marginRight: "10px" }}>{currency}</p>
                          {parseFloat(invoiceInfo.totalAmount) !== totalAmountCat() ? <WarningIcon style={{ fill: "#FF0000" }} titleAccess={t('stringTotalMatch')} /> : ""}

                          <CustomButton className={styles.styleUpdatePayment} style={{ marginLeft: "auto" }} onClick={updatetable}>{t('stringUpdatePaymentReq')}</CustomButton>
                        </div>
                        {/* Purpose of payment */}
                        <div className='form-control'>
                          <label htmlFor='purposePayment' id='payment-request' >{t('stringPurposePayment')}*</label>
                          <input type={'text'} id='nerData_purposeOfPayment' style={{ width: "80%", border: (outputData.nerData && outputData.nerData.purposeOfPayment === '') || (outputData.nerData && outputData.nerData.purposeOfPayment === null) ? "2px solid red" : "1px solid black" }} onChange={(e) => {
                            updateNerFusen(e)
                            byteSize(e.target.value, e.target.id)
                          }
                          }
                            value={outputData.nerData && outputData.nerData.purposeOfPayment} />

                          {(outputData.nerData && outputData.nerData.purposeOfPayment === '') || (outputData.nerData && outputData.nerData.purposeOfPayment === null) ? <WarningIcon style={{ fill: "#FF0000" }} titleAccess={t('stringMandatoryMessage')} /> : ""}
                        </div>
                        {/* || checkByteInitialPop(outputData?.nerData) */}
                        {invoiceChange.pop ? <p style={{ marginLeft: "200px", color: "red" }}>{t('stringBytePop')}</p> : ""}
                      </form>
                    </div>


                    {/* Extracted Table */}
                    <div style={{ overflowX: 'auto', marginTop: "50px", marginBottom: "50px" }}>

                      <label style={{ fontWeight: "bolder", marginBottom: "10px", cursor: "pointer" }} data-bs-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1" onClick={divClicked}>{slideClass === 'hide-div' ? `[-] ${t('stringDetails')}` : `[+] ${t('stringDetails')}`}</label>

                      <div className="collapse multi-collapse" id="multiCollapseExample1" style={{ overflowX: "auto" }}>

                        <table className='auto-table'>
                          <thead>
                            <tr>
                              <th className='auto-header'>{t('stringExclude')}</th>
                              <th className='auto-header'>{t('stringCategoryNumber')}</th>
                              <th className='auto-header'>{t('stringCategoryName')}</th>
                              <th className='auto-header'>{t('stringItemName')}</th>
                              <th className='auto-header'>{t('stringAmountWithoutTax')}</th>
                              <th className='auto-header'>{t('stringTax')}</th>
                              <th className='auto-header'>{t('stringConsumptionTax')}</th>
                              <th className='auto-header'>{t('stringAmountWithTax')}</th>
                            </tr>
                          </thead>
                          <tbody>
                            {tableData && tableData.map((elementInArray, index) => {
                              return (
                                <tr key={index} style={{ backgroundColor: selectedCheckedFileItem.includes(elementInArray._id) ? "#F5F4F2" : "#ffffff" }}>
                                  <td className='auto-data'><input className="form-check-input" id={`${elementInArray._id}_exclude_${index}`} type="checkbox" checked={elementInArray.exclude} onChange={(e) => {
                                    updateTableData(e)
                                    SelectedCheckedDataItem(e, elementInArray._id)
                                  }} /></td>
                                  <td id={`${elementInArray._id}_categoryNnumber_${index}`} style={{ textAlign: "right" }} >{elementInArray.categoryNumber}</td>
                                  <td style={{ width: '50%' }} >
                                    <select
                                      labelid="demo-simple-select-filled-label"
                                      id={`${elementInArray._id}_categoryName_${index}`}
                                      className="form-select" aria-label="Default select example"
                                      onChange={updateTableData}
                                      style={{ width: '80px' }}
                                    >
                                      <option selected disabled>{t('stringSelectDrop')}</option>
                                      {
                                        JSON.parse(sessionStorage.getItem('get-category-names'))?.map(val => {
                                          return (
                                            <option selected={elementInArray.categoryName === val[0]} value={val[0]}> {val[0]}</option>
                                          )
                                        })
                                      }

                                    </select>
                                  </td>

                                  <td  ><input id={`${elementInArray._id}_itemName_${index}`} style={{ border: "none", outline: "none", backgroundColor: selectedCheckedFileItem.includes(elementInArray._id) ? "#F5F4F2" : "#ffffff" }} onChange={updateTableData} value={elementInArray.itemName} /> </td>

                                  <td  ><input id={`${elementInArray._id}_amountWithOutTax_${index}`} style={{ border: "none", outline: "none", textAlign: "right", backgroundColor: selectedCheckedFileItem.includes(elementInArray._id) ? "#F5F4F2" : "#ffffff" }} onFocus={(elementInArray.amountWithOutTax === 0 || elementInArray.amountWithOutTax === '0') ? changeZeroToBlank : () => { }} onChange={updateTableData} value={elementInArray.amountWithOutTax} /></td>

                                  <td id={`${elementInArray._id}_taxRate_${index}`} style={{ textAlign: "right", width: "40%" }} >
                                    <select
                                      labelid="demo-simple-select-filled-label"
                                      id={`${elementInArray._id}_taxRate_${index}`}
                                      className="form-select" aria-label="Default select example"
                                      style={{ width: '80px' }}
                                      onChange={(e) => {
                                        changeAmountWithTax(e)
                                        updateTableData(e)
                                      }}
                                    >
                                      {
                                        Object.keys(taxRate).map((val, ind) => {
                                          return (
                                            <option key={ind} selected={val === elementInArray.taxRate} value={taxRate[val]} data={val} >{val}</option>
                                          )
                                        })
                                      }

                                    </select>
                                  </td>

                                  <td id={`${elementInArray._id}_consumptionTax_${index}`} onInput={updateTableData} style={{ textAlign: "right" }} >{elementInArray.consumptionTax}</td>

                                  <td id={`${elementInArray._id}_amountWithTax_${index}`} onInput={updateTableData} style={{ textAlign: "right" }} >{elementInArray.amountWithTax}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                        <button type="button" className="btn btn-primary" style={{ marginTop: "10px", marginLeft: "auto" }} onClick={() => {
                          setNoOfRows(noOfRows + 1)
                          setTableData([...tableData, { _id: noOfRows + 1, itemName: "", amountWithOutTax: '', consumptionTax: '', exclude: false, taxRate: "10%", amountWithTax: '', categoryNumber: '', categoryName: '', fileId: fid || location.state.fid }])
                        }}>+ {t('stringAddLine')}</button>
                        {/* Total Amount */}
                        <div className='form-control' style={{ marginTop: "15px" }}>
                          <label htmlFor='totalAmount' style={{ fontWeight: "bolder" }}>{t('stringDetailsTotal')}</label>
                          <input type={'text'} readOnly id='totalAmount' style={{ fontWeight: "bolder", marginLeft: "15px", textAlign: "right", backgroundColor: "#EAEAF0" }} value={totalAmountExt()} />
                          <span style={{ marginLeft: "15px" }}>
                            <p> {currency}</p>
                          </span>
                        </div>

                      </div>
                      
                    </div>
                    <div style={{ display: "flex", justifyContent: "center", flexDirection: "column", width: "25%", marginLeft: "auto" }}>
                      <CustomButton className={styles.styleUpdatePayment} style={{ marginBottom: "20px" }} onClick={() => {

                        toggle()
                      }}>{t('stringSaveDraftBtn')}</CustomButton>

                      <CustomButton className={styles.styleUpdatePayment} onClick={() => {
                        saveDraft(true)
                        setBtnClicked('done')
                      }
                      }>{t('stringDone')}</CustomButton>
                    </div>

                  </div>

                </div>
              </Container>
            </div>

            <Modal isOpen={modal} toggle={toggle}>
              <ModalBody>
                {t('stringSaveDraftMessage')}
              </ModalBody>
              <ModalFooter>
                <Button
                  className={`${styles.styleFileUpload} col-12 col-md-4 `}
                  variant="outlined"
                  component="span"
                  onClick={() => {
                    saveDraft(false)
                  }

                  }
                >{t('stringSaveDraft')}
                </Button>
                <Button
                  className={`${styles.styleFileUpload} col-12 col-md-4 `}
                  variant="outlined"
                  component="span"
                  onClick={() => {
                    toggle()
                    if (resultPrevNext.next.length > 0) {
                      showResultNext()
                    } else {
                      toast.success(t('stringLastPdf'), { position: toast.POSITION.TOP_CENTER, autoClose: 4000, pauseOnHover: false })
                      navigate('/deepICR')
                    }

                  }}
                >{t('stringDontSaveDraft')}
                </Button>
                <Button
                  className={`${styles.styleFileUpload} col-12 col-md-4 `}
                  variant="outlined"
                  component="span"
                  onClick={toggle}
                >{t('stringNo')}
                </Button>
              </ModalFooter>
            </Modal>
            {/* For Delete Invoice */}
            <Modal isOpen={modalTwo} toggle={toggleTwo}>

              <ModalBody>
                {t('stringDelete')}
              </ModalBody>
              <ModalFooter>
                <Button
                  className={`${styles.styleFileUpload} col-12 col-md-5 `}
                  variant="outlined"
                  component="span"
                  onClick={() => {
                    if (resultPrevNext.next.length > 0) {
                      deleteInvoice()
                    } else {
                      toast.success(t('stringLastPdf'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
                      deleteInvoice()
                      navigate('/deepICR')
                      toggleTwo()
                      // if (checkMandatoryField()) {
                      //   navigate('/deepICR')
                      //   toggleTwo()
                      // } else {
                      //   toggleTwo()
                      // }

                    }
                  }

                  }
                >{t('stringYes')}
                </Button>
                <Button
                  className={`${styles.styleFileUpload} col-12 col-md-5 `}
                  variant="outlined"
                  component="span"
                  onClick={toggleTwo}
                >{t('stringNo')}
                </Button>
              </ModalFooter>
            </Modal>
            {/* For Others Button */}
            <Modal isOpen={modalThree} toggle={toggleThree}>

              <ModalBody>
                {
                  othersClicked === 'redo' ? `${t('stringDiscardOcrResult')}` : `${t('stringSaveDraftMessage')}`
                }

              </ModalBody>
              <ModalFooter>
                {
                  othersClicked === 'redo' ?
                    <>
                      <Button
                        className={`${styles.styleFileUpload} col-12 col-md-4 `}
                        variant="outlined"
                        component="span"
                        onClick={() => {
                          toggleThree()
                          navigate('/pdfprocess', { state: { page: "result", fid: fid, fname: location.state.fname } })
                        }
                        }

                      >{t('stringYes')}
                      </Button>
                      <Button
                        className={`${styles.styleFileUpload} col-12 col-md-4 `}
                        variant="outlined"
                        component="span"
                        onClick={toggleThree}
                      >{t('stringNo')}
                      </Button>
                    </> :
                    <>
                      <Button
                        className={`${styles.styleFileUpload} col-12 col-md-4 `}
                        variant="outlined"
                        component="span"
                        onClick={() => {
                          toggleThree()
                          if (othersClicked === 'redo') {
                            navigate('/pdfprocess', { state: { page: "result", fid: fid, fname: location.state.fname } })
                          }
                          if (othersClicked === 'prev') {
                            // showResultPrev()
                            saveDraftPage(false)
                          }
                          if (othersClicked === 'next') {
                            // showResultNext()
                            saveDraftPage(false)
                          }
                          if (othersClicked === 'upload') {
                            saveDraftPage(false)
                          }
                        }
                        }
                      >{t('stringSaveDraft')}
                      </Button>
                      <Button
                        className={`${styles.styleFileUpload} col-12 col-md-4 `}
                        variant="outlined"
                        component="span"
                        onClick={() => {
                          toggleThree()
                          if (othersClicked === 'redo') {
                            navigate('/pdfprocess', { state: { page: "result", fid: fid, fname: location.state.fname } })
                          }
                          if (othersClicked === 'prev') {
                            showResultPrev()
                            // saveDraftPage(false)
                          }
                          if (othersClicked === 'next') {
                            showResultNext()
                            // saveDraftPage(false)
                          }
                          if (othersClicked === 'upload') {
                            navigate('/fileupload')
                            // saveDraftPage(false)
                          }
                        }
                        }

                      >{t('stringDontSaveDraft')}
                      </Button>
                      <Button
                        className={`${styles.styleFileUpload} col-12 col-md-4 `}
                        variant="outlined"
                        component="span"
                        onClick={toggleThree}
                      >{t('stringNo')}
                      </Button>
                    </>
                }

              </ModalFooter>
            </Modal>
          </>
      }



    </>

  );
}

export default withSnackbar(OutputViewer);
