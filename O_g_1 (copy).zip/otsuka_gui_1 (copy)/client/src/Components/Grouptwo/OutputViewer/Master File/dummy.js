export const sellerMap = [
    {
        name: 'ABC-Hospital',
        code: '1234562'
    },
    {
        name: 'rets-Hospital',
        code: '15876'
    },
    {
        name: 'lkol-Hospital',
        code: '15877'
    },
    {
        name: 'pqx-Hospital',
        code: '15872'
    },
    {
        name: 'lamcn-Hospital',
        code: '15871'
    },
    {
        name: 'hte-Hospital',
        code: '15870'
    },
    {
        name: 'powr-Hospital',
        code: '15869'
    },
    {
        name: 'bnd-Hospital',
        code: '15868'
    },
    {
        name: 'xew-Hospital',
        code: '15867'
    },


]

export const taxRate = {
    "10%": 10,
    "軽減8%": 8,
    "海外取引（仕入0％）":0,
    "非課税": 0,
    "不課税": 0,
    "8%": 8,
    "5%": 5,
    "輸入10%": 10,
    "輸入8%": 8,
    "売上10%": 10,
    "不課税売上": 0,
    "売上軽減8%":8,
    "免税売上（輸出0%）":0
}

