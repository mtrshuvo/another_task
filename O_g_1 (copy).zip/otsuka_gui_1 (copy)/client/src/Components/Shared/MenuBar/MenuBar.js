import React, { useContext, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { makeStyles } from '@material-ui/core';
import Toolbar from '@material-ui/core/Toolbar';
import HomeIcon from '@material-ui/icons/Home';
import Divider from '@material-ui/core/Divider';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import AccountCircle from '@material-ui/icons/AccountCircle';
import MenuItem from '@material-ui/core/MenuItem';
import Menu from '@material-ui/core/Menu';
import Typography from '@material-ui/core/Typography';
import { deepICRNow } from '../../../deepICRCommon';
import deepICRTheme from '../../../resources/deepICRTheme';
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify';
import Cookies from 'js-cookie'
import {
  Modal, ModalFooter,
  ModalHeader, ModalBody
} from "reactstrap"
// import react components
import ButtonSwitchLang from './ButtonSwitchLang';

// import resource files
import DeepICRContext from '../../../resources/DeepICRContext';

// import from redux
// Redux
import { resetCredentials } from '../../../action/index'
import { useSelector, useDispatch } from "react-redux";

// Style Sheet
const useStyles = makeStyles(theme => ({
  styleMenuBar: {
    flexGrow: 1,
    backgroundColor: '#DCDCDC',
    margin: theme.spacing(0, 0, 0, 0),
    padding: theme.spacing(1, 0, 1, 0)
  },
  styleMenuBarFirst: {
    flexGrow: 1,
    backgroundColor: 'black',
    margin: theme.spacing(0, 0, 0, 0),
    padding: theme.spacing(1, 0, 1, 0)
  },
  styleDivider: {
    height: deepICRTheme.palette.deepICR.dividerHeight,
    margin: deepICRTheme.palette.deepICR.dividerMargin,
  },
  styleLogout: {
    color: deepICRTheme.palette.deepICR.color,
    cursor: "pointer",
    '&:hover': { textDecoration: "underline" },
  },
  styleSpacer: { flexGrow: 1 },
  styleFileUpload: {
    color: theme.palette.deepICR.color,
    backgroundColor: '#00b050',
    borderRadius: 2,
    overflowY: 'hidden',
    marginBottom: 5,
    marginTop: 3,
    '&:hover': { backgroundColor: "white" }
  },
  button: {
    width: 50, height: 50,
    padding: 0,
    marginRight: 20,
    marginLeft: 10
  },
  icon: {
    width: 50, height: 50,
    backgroundColor: 'white',
    borderRadius: '50%'

  },
  menuItemText: {
    fontSize: "18px"
  },
  verticle: {
    borderLeft: '2px solid white',
    height: '50px',
    marginRight: '10px',
    marginLeft: "10px",

  },
  homeIcon: {
    marginRight: "100px"
  }
}));

// [React function component]
// Menu bar component
const MenuBar = ({checkMandatoryField,invoiceInfo,totalAmountCat,tableData,fid,cTableData,outputData,inputReadOnlyPop}) => {
  // User information from redux
  const isChangesHappened = useSelector((state) => state.reducer.isChangesHappened)
  const isAuthenticate = useSelector((state) => state.reducer.isAuthenticate)
  const isFileUploadPage = useSelector((state) => state.reducer.isFileUploadPage)
  const isSuperAdmin = useSelector((state) => state.reducer.isSuperAdmin)
  const reduxEmployeeCode = useSelector((state) => state.reducer.employeeCode)
  const reduxUserName = useSelector((state) => state.reducer.userName)
  const reduxRole = useSelector((state) => state.reducer.role)
  const id = useSelector((state) => state.reducer._id)
  //Logged in User Object Id from redux
  const jwt = useSelector((state) => state.reducer.jwt);
  // Logged inUser Session Id from redux
  const sessionId = useSelector((state) => state.reducer.sessionId);

  const dispatch = useDispatch()
  const navigate = useNavigate()
  const location = useLocation()
  const styles = useStyles();
  const [t] = useTranslation();

  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  if (deepICRCTX.debug === true) { console.log('MenuBar'); }

  const [employeeCode, setEmployeeCode] = useState("")
  const [doubleClickBool, setDoubleClickBool] = useState(false)
  const [modal, setModal] = useState(false)
  const toggle = () => {
    setModal(!modal)
  }

  const [anchorEl, setAnchorEl] = React.useState(null);

  const isMenuOpen = Boolean(anchorEl);

  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);

  };

  // Delete Session from database
  const deleteSession = async () => {
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/users/signout`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      }

    })
  }

  const menuId = 'primary-search-account-menu';

  const renderMenu = (
    <Menu
      anchorEl={anchorEl}
      anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      id={menuId}
      keepMounted
      transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      open={isMenuOpen}
      onClose={handleMenuClose}

    >
      <MenuItem className={styles.menuItemText}><ButtonSwitchLang className={styles.styleButtonSwithLang} /></MenuItem>
      {/* navigate('/users') */}
      {isSuperAdmin ?
        <MenuItem onClick={() => {
          navigate('/users')
          handleMenuClose()
        }} className={styles.menuItemText}>{t('stringConfig')}</MenuItem> : ""}
      <MenuItem onClick={() => {
        // Cookies.remove('jwtooken', { path: '/' })
        dispatch(resetCredentials())
        deleteSession()
        setDeepICRCTX({ ...deepICRCTX, isLogin: false })
        navigate('/login', { state: { isLoading: false } })
        handleMenuClose()
      }} className={styles.menuItemText}>{t('stringLogOut')}</MenuItem>
    </Menu>
  );


  const logOut = () => {
    toast.error("Signing Out", { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
    navigate("/logout")
  }


  // Debug
  const debug = () => {
    const json = { ...deepICRCTX, termsOfService: [] };
    // console.log(JSON.stringify(json, null, 1));
  }

  //After update, saving the data
  const saveUpdate = async () => {
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/users?u=${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      },
      body: JSON.stringify({
        role: reduxRole, userName: reduxUserName, employeeCode
      })
    })
    const updatedData = await res.json()
    if (res.status === 200) {
      // toast.success("Updated Successfully", { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
      setDoubleClickBool(false)
      // setUpdateState("")
      // getAllUser()
    }
    if (res.status === 400) {
      toast.warning(updatedData.message, { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
      setDoubleClickBool(false)
    }

  }

  // Handle Double Click Event
  const handleDoubleClick = () => {
    setDoubleClickBool(true)
    setEmployeeCode(reduxEmployeeCode)
  }
  // update Employee Code 
  const handleEmployeeUpdate = (e) => {
    if (e.key === 'Enter') {
      saveUpdate()
    }
  }


  // From Result page save the file 
   // SaveDraft functionility
   const saveDraft = async (done) => {
    const allFalse = Object.values(inputReadOnlyPop).every(
      value => value === false
    );
    // if item name and amount without tax field is empty that row will be eleminated
    const newTableData = tableData.filter(val => { return val.itemName !== '' && val.amountWithOutTax !== '' })
    // setTableData(newTableData)
    // console.log("Filterred Table Data",newTableData);
    // console.log("Filterred Table Data2",tableData);
    if (checkMandatoryField() && parseFloat(invoiceInfo.totalAmount) === totalAmountCat()) {
      if (outputData.nerData.invoiceNumber === '' && (outputData.nerData.issueDate === null || outputData.nerData.issueDate === '')) {
        !done && toggle()
        return toast.warning(t('stringMismatch'), { position: toast.POSITION.TOP_CENTER, autoClose: 3000, pauseOnHover: false })
      }
      // else if(!allFalse){
      //   toggle()
      //   return toast.warning(t("Byte Size Exceeds"), { position: toast.POSITION.TOP_CENTER, autoClose: 3000, pauseOnHover: false })
      // }
       else {
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/deepicr/extracted?fid=${fid}`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "Authorization": "Bearer " + jwt,
            "sid": sessionId
          },
          body: JSON.stringify({
            isDone: done,
            nerData: outputData.nerData,
            fusen: outputData.fusen,
            itemTableData: newTableData,
            categoryTableData: cTableData
          })

        })
        const data = await res.json()
        if (res.status === 200 && data.message) {
            if (checkMandatoryField() && parseFloat(invoiceInfo.totalAmount) === totalAmountCat()) {
              toast.success(`${t('stringSavedSuccessfully')}`, { position: toast.POSITION.TOP_CENTER, autoClose: 5000, pauseOnHover: false })
              navigate('/deepICR')
              toggle()
            } else {
              toast.warning(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 5000, pauseOnHover: false })
              !done && toggle()
            }

        }
      }

    }
    else {
      // console.log("Error Done", done);
      !done && toggle()
      toast.warning(t('stringMismatch'), { position: toast.POSITION.TOP_CENTER, autoClose: 5000, pauseOnHover: false })
    }
  }

  // const user = localStorage.getItem("userData")
  // console.log("pelette checking",isFileUpload);
  return (
    <>
      {

        isAuthenticate ?

          // First Navbar show
          <>
            <div className={styles.styleMenuBarFirst}>
              <Toolbar style={{ paddingLeft: 10, paddingRight: 10, }}>
                <img alt="Deloitte. Logo" src="/DEL_g_SEC_RGB.jpg" width="142" height="44" />
                <h5 className='text-white' style={{ marginLeft: "50px", cursor: "pointer" }} onClick={(location.pathname === '/resultpage' && isChangesHappened===true) ? () => { toggle() } : location.pathname === '/fileupload' && isFileUploadPage === true ? "" : () => { navigate('/deepICR') }}>Deep ICR<sup className='text-white'>®</sup></h5>
                <Typography className={styles.styleSpacer}></Typography>
                <Typography variant='h5' style={{ color: "white", cursor: "pointer" }} onClick={(location.pathname === '/resultpage' && isChangesHappened===true) ? () => { toggle() } : location.pathname === '/fileupload' && isFileUploadPage === true ? "" : () => { navigate('/deepICR') }} >{t('stringHome')}</Typography>


                {/* <Typography className={styles.styleSpacer}></Typography> */}
                <Typography className={styles.verticle}></Typography>
                {/* {doubleClickBool ?
                  <input type={'text'} name="employeeCode" value={employeeCode} onChange={(e) => setEmployeeCode(e.target.value)} onKeyPress={handleEmployeeUpdate}>
                  </input>
                  :
                  <><Typography variant='h5' style={{ color: "white" }} onDoubleClick={handleDoubleClick} >{reduxEmployeeCode}</Typography></>

                } */}
                <><Typography variant='h5' style={{ color: "white" }} >{reduxEmployeeCode}</Typography></>

                <Typography className={styles.verticle}></Typography>
                <Typography variant='h5' style={{ color: "white" }}>{reduxUserName}</Typography>

                <IconButton
                  edge="end"
                  aria-label="account of current user"
                  aria-controls={menuId}
                  aria-haspopup="true"
                  onClick={handleProfileMenuOpen}
                  color="inherit"
                  className={`${styles.button}`}
                >
                  <AccountCircle className={styles.icon} />
                </IconButton>
              </Toolbar>
              {renderMenu}
            </div>

            <Modal isOpen={modal} toggle={toggle}>
              <ModalBody>
              {t('stringSaveDraftMessage')}
              </ModalBody>
              <ModalFooter>
              <Button
                  className={`${styles.styleFileUpload} col-12 col-md-4 `}
                  variant="outlined"
                  component="span"
                  onClick={() => {
                    saveDraft(false)
                  }
                  }
                >{t('stringSaveDraft')}
                </Button>
                <Button
                  className={`${styles.styleFileUpload} col-12 col-md-4 `}
                  variant="outlined"
                  component="span"
                  onClick={() => {
                    navigate('/deepICR')
                    toggle()
                  }}
                >{t('stringDontSaveDraft')}
                </Button>
                <Button
                  className={`${styles.styleFileUpload} col-12 col-md-4 `}
                  variant="outlined"
                  component="span"
                  onClick={toggle}
                >{t('stringReturnHomeCancel')}
                </Button>
              </ModalFooter>
            </Modal>

          </> : null



      }
    </>


  );
}

export default MenuBar;
