import React,{useState} from 'react'

// Additional Package
import { DatePicker } from "rsuite";

import Checkbox from "@material-ui/core/Checkbox";
import InputLabel from "@material-ui/core/InputLabel";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";

// Mui
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import { makeStyles, withStyles } from "@material-ui/core";

// Style Sheet
const useStyles = makeStyles((theme) => ({
    styleFileUpload: {
      color: theme.palette.deepICR.color,
      backgroundColor: theme.palette.deepICR.blue4,
      borderRadius: 2,
      overflowY: "hidden",
      marginBottom: 5,
      width: '12%'
    },
    styleFilter: {
      color: theme.palette.deepICR.color,
      backgroundColor: theme.palette.deepICR.blue4,
      borderRadius: 2,
      overflowY: "hidden",
      marginTop: 20,
      width: '25%',
      marginLeft: "40px"
      // height:"50%"
    },
    formControl: {
      margin: theme.spacing(1),
      width: 300
    },
    indeterminateColor: {
      color: "#f50057"
    },
    selectAllText: {
      fontWeight: 500
    },
    selectedAll: {
      backgroundColor: "rgba(0, 0, 0, 0.08)",
      "&:hover": {
        backgroundColor: "rgba(0, 0, 0, 0.08)"
      }
    }
  }));
const Filter = ({isSuperAdmin}) => {
  const styles = useStyles()
  
  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 200
      }
    },
    getContentAnchorEl: null,
    anchorOrigin: {
      vertical: "bottom",
      horizontal: "center"
    },
    transformOrigin: {
      vertical: "top",
      horizontal: "center"
    },
    variant: "menu"
  };

  const options = [
    "Sato taro",
    "sato Hanako",
    "Suzuki Jiro",
    "Suzuki Yumi",
    "Tanaka Subaro",
    "Tanaka Saki",
    "Yamada Akira",
    "Yamada Mina"
  ];

  const [selected, setSelected] = useState([]);
  const isAllSelected =
    options.length > 0 && selected.length === options.length;

  const handleChange = (event) => {
    const value = event.target.value;
    if (value[value.length - 1] === "all") {
      setSelected(selected.length === options.length ? [] : options);
      return;
    }
    setSelected(value);
  };

    return (
        <>
            <div style={{}} className='row'>
                {/* RPA File Download filter */}
                {/* rgba(107, 107, 186, 0.04) */}
                <div className="rpa-file-filter p-4 col-md-6" style={{ backgroundColor: "#A1A2A6", width: "60%", marginLeft: "2.5%" }}>
                    <div className="date-filter p-2 d-flex align-items-center justify-content-between" style={{ flexWrap: 'wrap' }}>
                        <span>Upload Date Filter</span>
                        <div style={{ display: "flex", justifyContent: "center", alignItems: 'center' }}>
                            <label style={{ marginRight: "10px" }}>
                                Start Date:
                            </label>
                            {/* <input id="startDate" className="form-check-input p-4" type={"date"}
                value={startDateFilter} onChange={(e) => setStartDateFilter(e.target.value)} style={{
                  width: "200px",
                  overflowX: 'auto'
                }} /> */}
                            <DatePicker
                                format="yyyy/MM/dd"
                                style={{ border: "1px solid black", borderRadius: "10px" }}
                            // value={startDate}
                            />
                        </div>
                        {/* <label>
              Display invoices which RPA files has been downloaded
            </label> */}
                        <div style={{ display: "flex", justifyContent: "center", alignItems: 'center' }}>
                            <label style={{ marginRight: "10px" }}>
                                End Date:
                            </label>
                            {/* <input id="endDate" className="form-check-input p-4" type={"date"} value={endDateFilter} onChange={(e) => setEndDateFilter(e.target.value)} style={{
                width: "200px"
              }} /> */}
                            <DatePicker
                                format="yyyy/MM/dd"
                                style={{ border: "1px solid black", borderRadius: "10px" }}
                            // value={startDate}
                            />
                        </div>
                        <Button
                            className={styles.styleFileUpload}
                            variant="outlined"
                            component="span"
                        >
                            <Typography variant="h6">Search Date</Typography>
                        </Button>
                        {/* user name filter */}
                        {isSuperAdmin === true ?
                            <>
                                <div className="col-md-2" style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", alignItems: "center", flexDirection: "row" }}>
                                    <FormControl className={styles.formControl}>
                                        <InputLabel id="mutiple-select-label">PIC Filter</InputLabel>
                                        <Select
                                            labelId="mutiple-select-label"
                                            multiple
                                            value={selected}
                                            onChange={handleChange}
                                            renderValue={(selected) => selected.join(", ")}
                                            MenuProps={MenuProps}
                                        >
                                            <MenuItem
                                                value="all"
                                                classes={{
                                                    root: isAllSelected ? styles.selectedAll : ""
                                                }}
                                            >
                                                <ListItemIcon>
                                                    <Checkbox
                                                        classes={{ indeterminate: styles.indeterminateColor }}
                                                        checked={isAllSelected}
                                                        indeterminate={
                                                            selected.length > 0 && selected.length < options.length
                                                        }
                                                    />
                                                </ListItemIcon>
                                                <ListItemText
                                                    classes={{ primary: styles.selectAllText }}
                                                    primary="Select All"
                                                />
                                            </MenuItem>
                                            {options.map((option) => (
                                                <MenuItem key={option} value={option}>
                                                    <ListItemIcon>
                                                        <Checkbox checked={selected.indexOf(option) > -1} />
                                                    </ListItemIcon>
                                                    <ListItemText primary={option} />
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                    {/* <Button
                className={styles.styleFilter}
                variant="outlined"
                component="span"
              >
                <Typography variant="h6">Submit PIC</Typography>
              </Button> */}

                                </div>

                            </>
                            : ""
                        }

                    </div>
                    <div className="rpa-checked p-2" style={{ display: "flex", flexWrap: "wrap", justifyContent: "space-between" }}>
                        <div>
                            <input className="form-check-input" type="checkbox" />
                            <label style={{ marginLeft: "10px" }}>
                                Display invoices which RPA files has been downloaded
                            </label>
                        </div>


                    </div>
                </div>



                <div className="col-md-4" >

                </div>

            </div>
        </>
    )
}

export default Filter