import React, { useState, useEffect } from 'react'

// Additional Package
import { DatePicker } from "rsuite";
import { toast } from 'react-toastify';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';

import Checkbox from "@material-ui/core/Checkbox";
import InputLabel from "@material-ui/core/InputLabel";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";

// Redux
import { useSelector, useDispatch } from "react-redux";
import { setPagedata, totalFile, setSelectedId, setStartDate, setEndDate, rpaChekedValue,setSelected,setSelectBool,resetCredentials } from '../../action/index.js'

// Mui
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import { makeStyles, withStyles } from "@material-ui/core";
import Loader from '../Loader/Loader.js';

// Style Sheet
const useStyles = makeStyles((theme) => ({
    styleFileUpload: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,
        overflowY: "hidden",
        marginBottom: 5,
        width: '30%'
    },
    styleFilter: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,
        overflowY: "hidden",
        marginTop: 20,
        width: '25%',
        marginLeft: "40px"
        // height:"50%"
    },
    formControl: {
        margin: theme.spacing(1),
        width: 300
    },
    indeterminateColor: {
        color: "#f50057"
    },
    selectAllText: {
        fontWeight: 500
    },
    selectedAll: {
        backgroundColor: "rgba(0, 0, 0, 0.08)",
        "&:hover": {
            backgroundColor: "rgba(0, 0, 0, 0.08)"
        }
    },
    styleSearchDate: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,
        overflowY: "hidden",
        // width: '15%',
        minWidth: "12%"
    }
}));


const NewFilter = ({ isSuperAdmin, sessionId, jwt,setcurrPage }) => {
    const styles = useStyles()
    const dispatch = useDispatch()
    const navigate = useNavigate()
    // for multiple language
const [t] = useTranslation();

    // Redux State Value from filter Reducer
    const startDate = useSelector((state) => state.filterReducer.startDate);
    const endDate = useSelector((state) => state.filterReducer.endDate);
    const selectedId = useSelector((state) => state.filterReducer.selectedId);
    const selected = useSelector((state) => state.filterReducer.selected);
    const rpaCheck = useSelector((state) => state.filterReducer.rpaCheck);
    const selectBool = useSelector((state) => state.filterReducer.selectBool);
    const currPageNumber = useSelector((state) => state.reducer.currPageNumber);
    const id= useSelector((state) => state.reducer._id);

    // // initially date is today's date
    // const [startDate, setStartDateFilter] = useState(new Date())
    // const [endDate, setEndDateFilter] = useState(new Date())

    const [allUser, setAllUser] = useState([])

    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;
    const MenuProps = {
        PaperProps: {
            style: {
                maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
                width: 200
            }
        },
        getContentAnchorEl: null,
        anchorOrigin: {
            vertical: "bottom",
            horizontal: "center"
        },
        transformOrigin: {
            vertical: "top",
            horizontal: "center"
        },
        variant: "menu"
    };


    // const [selected, setSelected] = useState([]);
    // const [selectedId, setSelectedId] = useState([])
    const [allUserName, setAllUserName] = useState([])
    const [allUserId, setAllUserId] = useState([])
    // const [selectBool, setSelectBool] = useState(false)
    const [attrid, setAttrid] = useState()
    // Loading state
    const [loading, setLoading] = useState(false)
    // RPA File Download filter
    const [rpaChecked,setRpaChecked] = useState(true)

    const isAllSelected =
        allUserName.length > 0 && selected.length === allUserName.length;
    // console.log("Selected",selected);

    const handleChange = (event) => {
        setAttrid(event.currentTarget.getAttribute('data-name'))
        if (selectedId.includes(event.currentTarget.getAttribute('data-name'))) {
            const filteredArr = selectedId.filter((val) => { return val !== event.currentTarget.getAttribute('data-name') })
            dispatch(setSelectedId(filteredArr))
        } else {
            dispatch(setSelectedId([...selectedId, event.currentTarget.getAttribute('data-name')]))
        }

        var value = event.target.value;

        if (value[value.length - 1] === "all") {

           dispatch(setSelectBool(!selectBool))

            // console.log("select all hitted if", selectBool);
            dispatch(setSelected(selected.length === allUserName.length ? [] : allUserName));
            // console.log("alluser Name , selected",allUserName,selected);
            dispatch(setSelectedId(allUserId))
            return;
        }

        if (value[value.length - 1] === "none") {

            dispatch(setSelectBool(!selectBool))
            // console.log("select all hitted if", selectBool);
            dispatch(setSelected([]));
            dispatch(setSelectedId([]))
            return;
        }

        dispatch(setSelected(value))

    };

    // Get All User to show in table
    const getAllUser = async () => {
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/users/getall`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                "Authorization": "Bearer " + jwt,
                "sid": sessionId
            }
        })
        const temp = await res.json()
        // console.log(temp);
        if (res.status === 200 && temp.data) {
            setAllUser(temp.data)
        }
    }

    // Search Filtrer
    const filter = async () => {
        setcurrPage(1)
        setLoading(true)
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/file/filter?page=1`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                "Authorization": "Bearer " + jwt,
                "sid": sessionId
            },
            body: JSON.stringify({
                filter: {
                    uploadedBy: selectedId.length > 0 ? selectedId : [id],
                    startDate,
                    endDate,
                    rpaCheck: rpaCheck
                }
            })

        })
        const data = await res.json()
        // console.log("Data",data);
        if (res.status === 200) {
            // setTimeout(() => {
            //     setLoading(false)
            // }, 2000);
            setLoading(false)
            dispatch(setPagedata(data.data))
            dispatch(totalFile(data.total))
        } 
        else if(res.status===401){
            toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
            dispatch(resetCredentials())
            navigate('/login', { state: { isLoading: false } })
          }
        else if(res.status===400){
            if(data.message==='invalid date range'){
                toast.warning(t('stringInvalidDate'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
            }else if(data.message==='data not found'){
                toast.warning(t('stringNoData'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
            }else{
                toast.error(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
            }
            
            setLoading(false)
            dispatch(setPagedata([]))
            dispatch(totalFile(0))
        }
        else {
            // toast.warning(data.message, { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
            setLoading(false)
            dispatch(setPagedata([]))
            dispatch(totalFile(0))
        }


        // console.log("Pagination Data",pageData);
    }

    useEffect(() => {
        if (isSuperAdmin) {
            getAllUser()
        }
    }, [])

    useEffect(() => {

        setAllUser(allUser)
        setAllUserName([...allUser.map(val => val.userName)])
        setAllUserId([...allUser.map(val => val._id)])

    }, [allUser])


    return (
        <>
            {loading ? <Loader loading={loading} /> :
                <>
                    <div className='row'>
                        {/* RPA File Download filter */}
                        {/* rgba(107, 107, 186, 0.04) */}
                        <div className="rpa-file-filter p-4 col-md-6" style={{ backgroundColor: "#95A5A6", width: "60%", marginLeft: "2.5%" }}>
                            <div className="date-filter p-2 d-flex align-items-center justify-content-between" style={{ flexWrap: 'wrap' }}>
                                <span style={{ fontWeight: "bold" }}>{t('stringUploadDateFilter')}: </span>
                                <div style={{ display: "flex", justifyContent: "center", alignItems: 'center' }}>
                                    {/* <label style={{ marginRight: "10px" }}>
                                    {t('stringStartDate')}:
                                    </label> */}

                                    <DatePicker
                                        format="yyyy/MM/dd"
                                        style={{ border: "1px solid black", borderRadius: "10px" }}
                                        value={startDate}
                                        onChange={(date) => {
                                            dispatch(setStartDate(date))
                                        }
                                        }
                                    />
                                </div>
                                <div>
                                    ~
                                </div>

                                <div style={{ display: "flex", justifyContent: "center", alignItems: 'center' }}>
                                    {/* <label style={{ marginRight: "10px" }}>
                                    {t('stringEndDate')}:
                                    </label> */}

                                    <DatePicker
                                        format="yyyy/MM/dd"
                                        style={{ border: "1px solid black", borderRadius: "10px" }}
                                        value={endDate}
                                        onChange={(date) => dispatch(setEndDate(date))}
                                    />
                                </div>
                                {!isSuperAdmin ?
                                    <Button
                                        className={styles.styleSearchDate}
                                        variant="outlined"
                                        component="span"
                                        onClick={filter}
                                    >
                                        <Typography variant="h6">{t('stringSearch')}</Typography>
                                    </Button> : ""
                                }

                                {/* user name filter */}
                                {isSuperAdmin === true ?
                                    <>
                                        <div className="col-md-2" style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", alignItems: "center", flexDirection: "row", marginLeft: "150px" }}>
                                            <FormControl className={styles.formControl}>
                                                <InputLabel id="mutiple-select-label">{t('stringPicFilter')}</InputLabel>
                                                <Select
                                                    labelId="mutiple-select-label"
                                                    multiple
                                                    value={selected}
                                                    onChange={handleChange}
                                                    // selected.map(val=>{return val.name.join(", ")})
                                                    renderValue={(selected) => selected.join(", ")}
                                                    MenuProps={MenuProps}
                                                >
                                                    <MenuItem
                                                        value={!selectBool ? "all" : "none"}
                                                        classes={{
                                                            // isAllSelected
                                                            root: selectBool ? styles.selectedAll : ""
                                                        }}
                                                    >
                                                        <ListItemIcon>
                                                            <Checkbox
                                                                classes={{ indeterminate: styles.indeterminateColor }}
                                                                checked={selectBool}
                                                                indeterminate={
                                                                    selected.length > 0 && selected.length < allUserName.length
                                                                }
                                                            />
                                                        </ListItemIcon>
                                                        <ListItemText
                                                            classes={{ primary: styles.selectAllText }}
                                                            primary={!selectBool  ? `${t('stringSelectAll')}` : `${t('stringSelectNone')}` }
                                                        />
                                                    </MenuItem>
                                                    {allUser.map((option) => {
                                                        return (
                                                            // value={{id:option._id,name:option.userName}}

                                                            <MenuItem key={option._id} value={option.userName} data-name={option._id} >
                                                                <ListItemIcon>
                                                                    <Checkbox checked={(selectBool === true && allUser.length === selected) || selected.indexOf(option.userName) > -1} />
                                                                </ListItemIcon>
                                                                <ListItemText primary={option.userName} />
                                                            </MenuItem>
                                                        )
                                                    })}
                                                </Select>
                                            </FormControl>


                                        </div>

                                    </>
                                    : ""
                                }

                            </div>
                            <div className="rpa-checked p-2" style={{ display: "flex", flexWrap: "wrap", justifyContent: "space-between" }}>
                                <div>
                                    <input className="form-check-input" type="checkbox" checked={rpaCheck} onChange={()=>{
                                        setRpaChecked(!rpaChecked)
                                        dispatch(rpaChekedValue(rpaChecked))
                                    }}/>
                                    <label style={{ marginLeft: "10px" }}>
                                    {t('stringStaticRpaMessage')}
                                    </label>
                                </div>

                                {isSuperAdmin ?
                                    <Button
                                        className={styles.styleSearchDate}
                                        variant="outlined"
                                        component="span"
                                        onClick={filter}
                                    >
                                        <Typography variant="h6">{t('stringSearch')}</Typography>
                                    </Button> : ""
                                }


                            </div>
                        </div>



                        <div className="col-md-4" >

                        </div>

                    </div>
                </>
            }
        </>
    )
}

export default NewFilter