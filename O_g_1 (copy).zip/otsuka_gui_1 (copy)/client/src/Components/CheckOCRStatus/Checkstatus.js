import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

// Additional Packages
import _ from 'lodash'
import { toast } from 'react-toastify';
import {
  Modal, ModalFooter,
  ModalHeader, ModalBody
} from "reactstrap"
import { useTranslation } from 'react-i18next';
import AWS from 'aws-sdk'

// Mui
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import { makeStyles, withStyles } from "@material-ui/core";


// Redux
import { updateUploadedFiles, setPagedata, totalFile, resetCredentials, trackChangeInResultPage } from "../../action/index";
import { useSelector, useDispatch } from "react-redux";
import Filter from "./Filter";
import NewFilter from "./NewFilter";
import SecondNav from "../SecondNav/SecondNav";
import Loader from "../Loader/Loader";
import MenuBar from "../Shared/MenuBar/MenuBar";

// Style Sheet
const useStyles = makeStyles((theme) => ({
  styleFileUpload: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
    overflowY: "hidden",
    marginBottom: 5,
    width: '12%'
  },
  styleOperation: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
    overflowY: "hidden",
    marginBottom: 5,
  },
  styleFilter: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
    overflowY: "hidden",
    marginTop: 20,
    width: '25%',
    marginLeft: "40px"
    // height:"50%"
  },
  formControl: {
    margin: theme.spacing(1),
    width: 300
  },
  indeterminateColor: {
    color: "#f50057"
  },
  selectAllText: {
    fontWeight: 500
  },
  selectedAll: {
    backgroundColor: "rgba(0, 0, 0, 0.08)",
    "&:hover": {
      backgroundColor: "rgba(0, 0, 0, 0.08)"
    }
  }
}));

const Checkstatus = () => {

  const navigate = useNavigate();
  const styles = useStyles();
  const dispatch = useDispatch();
  // for multiple language
  const [t] = useTranslation();

  // All States
  // Checked Box state
  const [selectedCheckedFile, setSelectedCheckedFile] = useState([]);
  const uploadedFiles = useSelector((state) => state.reducer.uploadedFiles);
  const isSuperAdmin = useSelector((state) => state.reducer.isSuperAdmin)
  const jwt = useSelector((state) => state.reducer.jwt)
  const sessionId = useSelector((state) => state.reducer.sessionId)
  const pageData = useSelector((state) => state.reducer.pageData);
  const page = useSelector((state) => state.reducer.page);
  const currPageNumber = useSelector((state) => state.reducer.currPageNumber);
  const id = useSelector((state) => state.reducer._id);
  //  console.log("Reducer page",page);

  // Redux State Value from filter Reducer
  const startDate = useSelector((state) => state.filterReducer.startDate);
  const endDate = useSelector((state) => state.filterReducer.endDate);
  const selectedId = useSelector((state) => state.filterReducer.selectedId);
  const rpaCheck = useSelector((state) => state.filterReducer.rpaCheck);


  // Loading State
  const [loading, setLoading] = useState(false)

  // For pagination
  const [prevBtn, setPrevBtn] = useState(true)
  const [nextBtn, setNextBtn] = useState(true)
  // const [page, setPage] = useState(0)
  const [pagePost, setpagePost] = useState([])
  const [currPage, setcurrPage] = useState(1)
  const [pageNumberLimit, setpageNumberLimit] = useState(5);
  const [maxPageNumberLimit, setmaxPageNumberLimit] = useState(5);
  const [minPageNumberLimit, setminPageNumberLimit] = useState(0);

  // Modal open state
  const [modal, setModal] = useState(false);
  // for RPA File Download
  const [modalTwo, setModalTwo] = useState(false)

  // Toggle for Modal
  const toggle = () => setModal(!modal);
  // For Rpa File Download
  const toggleTwo = () => setModalTwo(!modalTwo);

  var pageSize = 10

  // console.log("Curtrent Page Number", currPage);
  // Pagination Function
  var pageIndexArr = []
  // var i = 0

  for (let index = 0; index < page; index++) {
    pageIndexArr.push(index + 1)
  }


  let pageIncrementBtn = null
  if (pageIndexArr.length > maxPageNumberLimit) {
    pageIncrementBtn = <li style={{ color: "black" }} onClick={() => setNextBtn(!nextBtn)}>&hellip;</li>
  }

  let pageDecrementBtn = null
  if (pageIndexArr.length > maxPageNumberLimit) {
    pageDecrementBtn = <li style={{ color: "black" }} onClick={() => setPrevBtn(!prevBtn)}>&hellip;</li>
  }

  const getPagination = (pageValue) => {
    setcurrPage(pageValue);
    filter(pageValue)
  }


  // converting date formate into dd/mm/yyy hour/min/sec format
  function formatDate(date) {
    const dateString = new Date(date).toLocaleString("en-US", { hourCycle: "h23" });
    const splitDate = dateString.split(",");
    let first = splitDate[0];
    first = first.split('/')
    let dateFormat = `${first[2]}/${first[0]}/${first[1]}`
    const second = splitDate[1].split(" ")[1];
    return `${dateFormat} ${second}`
  }

  //Checkbox clicked Data stored and unstored
  const SelectedCheckedData = (val, e) => {
    // console.log(e.target.checked);
    if (e.target.checked) {
      setSelectedCheckedFile([...selectedCheckedFile, val]);
    } else {
      setSelectedCheckedFile(
        selectedCheckedFile.filter((file) => file !== val)
      );

    }
  };

  // console.log(selectedCheckedFile);
  // Search Filtrer
  const filter = async (getCurrPageNo) => {
    setLoading(true)
    // console.log("Api Call Page Number", getCurrPageNo);
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/file/filter?page=${getCurrPageNo}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      },
      body: JSON.stringify({
        filter: {
          uploadedBy: selectedId.length > 0 ? selectedId : [id],
          startDate,
          endDate,
          rpaCheck: rpaCheck
        }
      })

    })

    const data = await res.json()
    // console.log("Filter data", data);
    if (res.status === 200) {
      setLoading(false)
      dispatch(setPagedata(data.data))
      dispatch(totalFile(data.total))
    }
    else if (res.status === 401) {
      toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
      dispatch(resetCredentials())
      navigate('/login', { state: { isLoading: false } })
    }
    else {
      toast.warning(t('stringNoData'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
      dispatch(setPagedata([]))
      setLoading(false)
    }
  }

  // Converting base64 value of xcel sheet into buffer data
  // call it into blob function
  function base64ToUint8Array(string) {
    var raw = atob(string);
    var rawLength = raw.length;
    var array = new Uint8Array(new ArrayBuffer(rawLength));
    for (var i = 0; i < rawLength; i += 1) {
      array[i] = raw.charCodeAt(i);
    }
    return array;
  }

  // Download RPA File for S3

  function downloadBlob(blob, name = `支払申請RPAデータ_20221007120348.xlsx`) {
    // Convert your blob into a Blob URL (a special url that points to an object in the browser's memory)
    const blobUrl = URL.createObjectURL(blob, {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    // Create a link element
    const link = document.createElement('a');
    // Set link's href to point to the Blob URL
    link.href = blobUrl;
    link.download = name;
    // Append link to the body
    document.body.appendChild(link);
    link.click();
    link.remove();

  }

  const rpaDownload = async () => {
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/deepicr/rpa`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      },
      body: JSON.stringify({
        fids: selectedCheckedFile
      })

    })
    const data = await res.json()
    console.log("download Response", data);

    var fileName = data.response && data.response.key.split('/')[2]
    if (res.status === 200) {

      fetch(data.link)
        .then(res => res.blob())
        .then(blob => {
          const url = window.URL.createObjectURL(new Blob([blob]), {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          });
          const link = document.createElement('a');
          link.href = url;
          link.setAttribute('download', fileName);
          document.body.appendChild(link);
          link.click();
          link.parentNode.removeChild(link);
          setSelectedCheckedFile([])
          filter(currPage)

        });

    }
    else if (res.status === 401) {
      toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
      dispatch(resetCredentials())
      navigate('/login', { state: { isLoading: false } })
    }
    else {
      if (data.message === 'Please select without invoice error files') {
        toast.error(t('stringSelectNoError'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
      }
      if (data.message === 'Please select only OCR completed files') {
        toast.error(t('stringSelectCompletedFile'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
      }
      if (data.message === 'Something went wrong') {
        toast.error(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
      }
      if (data.message === 'no file selected') {
        toast.error(t('stringNoFileSelected'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
      }
    }
  }


  // Download RPA File from base64 value
  // const rpaDownload = async () => {
  //   // console.log(selectedCheckedFile);
  //   const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/deepicr/rpa`, {
  //     method: "POST",
  //     headers: {
  //       "Content-Type": "application/json",
  //       Accept: "application/json",
  //       "Authorization": "Bearer " + jwt,
  //       "sid": sessionId
  //     },
  //     body: JSON.stringify({
  //       fids: selectedCheckedFile
  //     })

  //   })
  //   const data = await res.json()
  //   console.log("Rpa downlopad data", data);
  //   if (res.status === 200 && data.data) {
  //     const url = window.URL.createObjectURL(
  //       new Blob([base64ToUint8Array(data.data)], {
  //         type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  //       })
  //     );
  //     const link = document.createElement("a");
  //     link.href = url;
  //     link.setAttribute("download", data.fileName);
  //     document.body.appendChild(link);
  //     link.click();
  //     link.remove();
  //     setSelectedCheckedFile([])
  //     filter(currPage)
  //   } else {
  //     toast.warning(data.message, { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
  //   }
  // }

  // console.log("Previous curr page", currPage);
  const previousBtn = () => {
    if (currPage > 1) {
      setcurrPage((oldValue) => { return oldValue - 1 });

      // dispatch(currPageNumbers(currPage - 2))
      // console.log("Previous curr page", currPage);
      if ((currPage - 1) % pageNumberLimit === 0) {
        setmaxPageNumberLimit(maxPageNumberLimit - pageNumberLimit)
        setminPageNumberLimit(minPageNumberLimit - pageNumberLimit)
      }
      // console.log("CurrentPAGENumber",currPageNumber);
      // filter(currPage - 1)
    }
  }

  const nextsBtn = () => {
    setcurrPage((oldValue) => { return oldValue + 1 });
    if (currPage < pageIndexArr.length) {
      if (currPage + 1 > maxPageNumberLimit) {
        // setcurrPage((oldValue) => { return oldValue - 1 });  
        setmaxPageNumberLimit(maxPageNumberLimit + pageNumberLimit)
        setminPageNumberLimit(minPageNumberLimit + pageNumberLimit)
      }
    } else {
      setcurrPage((oldValue) => { return oldValue - 1 });
    }

  }

  const deleteInvoice = async () => {
    if (selectedCheckedFile.length > 0) {
      const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/file/delete`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          "Authorization": "Bearer " + jwt,
          "sid": sessionId
        },
        body: JSON.stringify({
          fid: selectedCheckedFile
        })
      })
      const data = await res.json()

      if (res.status === 200) {
        toast.success(t('stringFileDelete'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
        filter(currPage)
        setSelectedCheckedFile([])
      }
      else if (res.status === 401) {
        toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
        dispatch(resetCredentials())
        navigate('/login', { state: { isLoading: false } })
      }
      else {
        // console.log(data.message);
        toast.error(t('stringSomethingWentWrong'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
      }
    } else {
      toast.error(t('stringNoFileSelected'), { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
    }

  }

  // Bizz Logic Apis function
  const getBizLogicApi = async (param, page) => {
    console.log("Entered");
    setLoading(true)
    const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/biz-logic/${param}?page_no=${page}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "Authorization": "Bearer " + jwt,
        "sid": sessionId
      }

    })
    const data = await res.json()
    // console.log("bizzlogic data", data);
    if (param === 'get-category-names') {
      sessionStorage.setItem(param, JSON.stringify(data.category_names))
    }
    if (param === 'get-protocol-numbers') {
      sessionStorage.setItem(param, JSON.stringify(data.protocol_numbers))
    }
    if (param === 'get-seller-names') {
      if (sessionStorage.getItem('get-seller-names')) {
        var newArr = JSON.parse(sessionStorage.getItem('get-seller-names')).concat(data.seller_names)
        sessionStorage.setItem(param, JSON.stringify(newArr))
      } else {
        sessionStorage.setItem(param, JSON.stringify(data.seller_names))
      }
    }
    if (param === 'get-hospital-names') {
      if (sessionStorage.getItem('get-hospital-names')) {
        var newArr = JSON.parse(sessionStorage.getItem('get-hospital-names')).concat(data.hospital_names)
        sessionStorage.setItem(param, JSON.stringify(newArr))
      } else {
        sessionStorage.setItem(param, JSON.stringify(data.hospital_names))
      }

    }
    if (param === 'get-cost-center') {
      if (sessionStorage.getItem('get-cost-center')) {
        var formattedCostCenter = data.cost_center_codes.map((val) => {
          return (
            val[1] + ' - ' + val[0]
          )
        })
        var newArr = JSON.parse(sessionStorage.getItem('get-cost-center')).concat(formattedCostCenter)
        sessionStorage.setItem(param, JSON.stringify(newArr))
      } else {
        var formattedCostCenter = data.cost_center_codes.map((val) => {
          return (
            val[1] + ' - ' + val[0]
          )
        })
        sessionStorage.setItem(param, JSON.stringify(formattedCostCenter))
        // data.cost_center_codes
      }
    }
    if (data.next_page_exists) {
      page++
      getBizLogicApi(param, page)
    } else {
      setLoading(false)
    }
  }

  // Checking if the key already exists in local Storage
  // if already exists this api will not be called
  const hasLocalStorage = (key) => {
    if (sessionStorage.getItem(key)) return true
    else return false
  }

  // Making Error Message translation
  const errorMessageTranslation = (errorList) => {
    const spreadError = [...errorList]
    if (spreadError.length === 1) {
      if (spreadError[0] === 'Multiple') {
        return `${t('')}`
      }
      else if (spreadError[0] === 'Mandatory field missing') {
        return `${t('stringMandatoryFieldMiss')}`
      } else {
        return `${t('stringTotalMatch')}`
      }
    } else if (spreadError.length === 2 && !spreadError.includes('Multiple')) {
      return `${t('stringMandatoryTotalAmountError')}`
    } else if (spreadError.length === 2 && spreadError.includes('Multiple')) {
      if (spreadError.includes('Mandatory field missing')) {
        return `${t('stringMandatoryFieldMiss')}`
      } else {
        return `${t('stringTotalMatch')}`
      }
    } else if (spreadError.length === 3) {
      return `${t('stringMandatoryTotalAmountError')}`
    }
    else {
      return null
    }
  }


  useEffect(() => {
    if (!hasLocalStorage('get-category-names')) {
      getBizLogicApi('get-category-names', 0)
    }
    if (!hasLocalStorage('get-protocol-numbers')) {
      getBizLogicApi('get-protocol-numbers', 0)
    }
    if (!hasLocalStorage('get-cost-center')) {
      getBizLogicApi('get-cost-center', 0)
    }
  }, [])


  useEffect(() => {
    setSelectedCheckedFile(selectedCheckedFile);
    // console.log(selectedCheckedFile);
  }, [selectedCheckedFile]);


  useEffect(() => {
    dispatch(trackChangeInResultPage(false))
    setcurrPage(currPage)
    // console.log("CurrPage useEffect",currPage);
    filter(currPage)

  }, [currPage])

  // console.log("sessionStorage Saved Value", JSON.parse(sessionStorage.getItem('get-protocol-numbers')).length)
  return (
    <>
      <MenuBar />
      {loading ? <Loader loading={loading} /> :
        <>
          <SecondNav />
          <div className="p-1">
            {/* Upper filter div */}
            <NewFilter isSuperAdmin={isSuperAdmin} jwt={jwt} sessionId={sessionId} setcurrPage={setcurrPage} />

            {/* Status Table */}

            <ul className="responsive-table mt-5">
              <li className="table-header">
                <div className="col col-8">{t('stringInvoiceSelection')}</div>
                {isSuperAdmin === true ? <div className="col col-9">{t('stringPicName')}</div> : ''}
                <div className="col col-3">{t('stringFileName')}</div>
                <div className="col col-4">{t('stringOcrStatus')}</div>
                <div className="col col-5">{t('stringMemoInput')}</div>
                <div className="col col-6">{t('stringInvoiceErrors')}</div>
                <div className="col col-7">{t('stringContentCheck')}</div>
                <div className="col col-1">{t('stringUploadDate')}</div>
                <div className="col col-2">{t('stringSlNo')}</div>
              </li>
              {pageData &&
                pageData.map((val, ind) => {
                  return (
                    <>
                      <li className="table-row" key={ind} style={{ backgroundColor: selectedCheckedFile.includes(val._id) ? "#F5F4F2" : "#ffffff" }}>
                        <div className="col col-8" data-label="Delete Check">
                          {" "}
                          <input
                            className="form-check-input"
                            type="checkbox"
                            name={val.fileName}
                            value={val.fileNameame}
                            checked={selectedCheckedFile.includes(val._id) ? true : false}
                            disabled={val.ocrStatus === 'In Process' ? true : false}
                            onChange={(e) => SelectedCheckedData(val._id, e)}
                          />
                        </div>
                        {isSuperAdmin === true ? <div className="col col-9">{val.uploadedBy.userName}</div> : ''}

                        <div className="col col-3" data-label="File Name" title={val.fileName}>
                          {val.fileName.length > 50
                            ? val.fileName.slice(0, 42) + "....." + val.fileName.slice(-5)
                            : val.fileName}
                        </div>
                        <div
                          className="col col-4"
                          data-label="OCR Status"
                          style={{ cursor: "pointer" }}
                        >
                          {val.ocrStatus === "Not Started" ?
                            <span style={{ textDecoration: "underline", cursor: "pointer" }} onClick={() => navigate("/pdfprocess", { state: { fid: val._id, fName: val.fileName } })}>{t('stringNotStarted')}</span> :
                            <span style={{ cursor: "default" }} >{val.ocrStatus === 'In Process' ? `${t('stringInProgress')}` : val.ocrStatus === 'OCR Error' ? `${t('stringOCRError')}` : `${t('stringCompleted')}`}</span>
                          }
                        </div>
                        <div className="col col-5" data-label="Memo Input">
                          {val.ocrStatus === 'Not Started' ? `${t('stringStatusNo')}` : `${t('stringStatusYes')}`}
                        </div>
                        <div className="col col-6" data-label="Invoice Error" style={(val.ocrStatus === 'Completed' && val.invoiceError.length <= 0) ? { color: "black" } : { color: "red" }} title={errorMessageTranslation(val.invoiceError)}>
                          {/* val.ocrStatus==='Completed' &&  */}
                          {(val.ocrStatus === 'Completed' && val.invoiceError.length > 0) ? `${t('stringError')}` : (val.ocrStatus === 'Completed' && val.invoiceError.length <= 0) ? `${t('stringNoError')}` : ""}
                        </div>
                        <div className="col col-7" data-label="Check result">
                          <span style={{ textDecoration: "underline", cursor: "pointer" }} onClick={() => navigate("/resultpage", { state: { fid: val._id, fname: val.fileName } })}>
                            {

                              (val.resultCheck === 'raw' && val.ocrStatus === 'Completed') ? `${t('stringUnchecked')}` : val.resultCheck === 'temp' ? `${t('stringUnchecked')}` : val.resultCheck === 'checked' ? `${t('stringChecked')}` : val.resultCheck === 'done' ? `${t('stringRPAOutputDone')}` : ""

                            }

                          </span>
                        </div>
                        <div className="col col-1" data-label="Upload Date">
                          {formatDate(val.createdAt)}
                        </div>
                        <div className="col col-2" data-label="SL No">
                          {val.uploadSerial}
                        </div>
                      </li>
                    </>
                  );
                })}
            </ul>

            <div className='footer'>
              <ul className="pagination pagination-sm " style={{ display: "flex", justifyContent: "center" }}>
                <button className='btn pagination-btn' onClick={() => previousBtn()}>&laquo;</button>
                {pageIndexArr.length > 0 && pageDecrementBtn}
                {pageIndexArr.length > 0 && pageIndexArr.map((val, ind) => {

                  if (val < maxPageNumberLimit + 1 && val > minPageNumberLimit) {

                    return (
                      <li key={ind}><button className={currPage === val ? "btn  pagination-btn active" : 'btn pagination-btn'} onClick={() => getPagination(val)}>{val}</button></li>
                    )
                  } else {
                    return null
                  }

                })}
                {pageIndexArr.length > 0 && pageIncrementBtn}
                <button className='btn pagination-btn ' onClick={() => nextsBtn()}>&raquo;</button>
              </ul>
            </div>

            <div className="file-upload-bottom-btn-status row">

              <div className="" style={{
                display: "flex",
                flexDirection: "column",
                width: "100vw",
                // border:"2px solid red",
                marginLeft: "10px",
                justifyContent: "center",
                alignItems: "center",
                textAlign: "center"
              }}>

                <Button
                  className={styles.styleFileUpload}
                  variant="outlined"
                  component="span"
                  onClick={() => {
                    // setSelectedCheckedFile([]);
                    // dispatch(updateUploadedFiles(selectedCheckedFile));
                    // deleteInvoice()
                    toggle()
                  }}
                // onClick={()=>navigate('/checkstatus')}
                >
                  <Typography variant="h6">{t('stringDeleteInvoice')}</Typography>
                </Button>
                <Button
                  className={styles.styleFileUpload}
                  variant="outlined"
                  component="span"
                  onClick={toggleTwo}
                >
                  <Typography variant="h6">{t('stringFileDownload')}</Typography>
                </Button>
                <span style={{ fontSize: "14px" }}>
                  {t('stringStaticInvoiceMessage')}
                </span>
              </div>
            </div>
          </div>
          <Modal isOpen={modal} toggle={toggle}>
            {
              selectedCheckedFile.length > 0 ?
                <>
                  <ModalBody>
                    {t('stringPdfDelete')}
                  </ModalBody>
                  <ModalFooter>
                    <Button
                      className={`${styles.styleOperation} col-12 col-md-6 `}
                      variant="outlined"
                      component="span"
                      onClick={() => {
                        deleteInvoice()
                        dispatch(updateUploadedFiles(selectedCheckedFile));
                        toggle()
                      }

                      }
                    >{t('stringYes')}
                    </Button>
                    <Button
                      className={`${styles.styleOperation} col-12 col-md-6 `}
                      variant="outlined"
                      component="span"
                      onClick={toggle}
                    >{t('stringNo')}
                    </Button>
                  </ModalFooter>
                </> :
                <>
                  <ModalBody>
                    {t('stringNoFileCheckedStatus')}
                  </ModalBody>
                  <ModalFooter>
                    <Button
                      className={`${styles.styleFileUpload} col-12 col-md-4 `}
                      variant="outlined"
                      component="span"
                      onClick={() => {
                        toggle()
                      }
                      }
                    >{t('stringYes')}
                    </Button>
                  </ModalFooter>
                </>
            }


          </Modal>

          <Modal isOpen={modalTwo} toggle={toggleTwo}>

            <ModalBody>
              {t('stringRpaDownload')}
            </ModalBody>
            <ModalFooter>
              <Button
                className={`${styles.styleOperation} col-12 col-md-6 `}
                variant="outlined"
                component="span"
                onClick={() => {
                  rpaDownload()
                  toggleTwo()
                }
                }
              >{t('stringYes')}
              </Button>
              <Button
                className={`${styles.styleOperation} col-12 col-md-6 `}
                variant="outlined"
                component="span"
                onClick={toggleTwo}
              >{t('stringNo')}
              </Button>
            </ModalFooter>
          </Modal>
        </>
      }
    </>
  );
};

export default Checkstatus;
  // ((val.resultCheck ===('raw'||'temp'))&&(val.ocrStatus ==="Completed"))?`${t('stringUnchecked')}`:val.resultCheck==="checked"?`${t('stringChecked')}`:val.resultCheck==="done"?`${t('stringDone')}`:""