import React, { useState, useEffect, useCallback } from 'react'
import { useSelector,useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { resetCredentials } from '../../action';
import { toast } from 'react-toastify';
import SecondNav from '../SecondNav/SecondNav';
import { useTranslation } from 'react-i18next';
// importing components
import Dataeditable from './Dataeditable';
import Readonlydata from './Readonlydata';
import MenuBar from '../Shared/MenuBar/MenuBar';

const UserInfoTable = () => {
    // for multiple language
    const [t] = useTranslation();
    const dispatch = useDispatch()
    const navigate = useNavigate()
    //Logged in User Object Id from redux
    const jwt = useSelector((state) => state.reducer.jwt);
    // Logged inUser Session Id from redux
    const sessionId = useSelector((state) => state.reducer.sessionId);
    // Logged in User name from redux
    const loggedUserName = useSelector((state) => state.reducer.userName);

    // Edit button bool handle
    const [editted, setEditted] = useState(false)
    // save all user to the array
    const [allUser, setAllUser] = useState([])
    // updated row's user object Id
    const [updateState, setUpdateState] = useState("");
    // Set updated user data
    const [userData, setUserData] = useState({
        userName: "",
        role: "",
        employeeCode: ""
    })


    // managing the input field state
    let inputName, value
    const handleEvent = (event) => {
        inputName = event.target.name
        value = event.target.value
        setUserData({ ...userData, [inputName]: value })
    }

    //cancel button executes this function
    const cancelUpdate = () => {
        setUpdateState("")
    }
    //After update, saving the data
    const saveUpdate = async (id) => {
        const { role, userName, employeeCode } = userData
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/users?u=${id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                "Authorization": "Bearer " + jwt,
                "sid": sessionId
            },
            body: JSON.stringify({
                role, userName, employeeCode
            })
        })
        const updatedData = await res.json()
        if (res.status === 200) {
            toast.success(`${t('stringConfigUpdatedPopUp')}`, { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
            setUpdateState("")
            getAllUser()
        }
        else if (res.status === 401) {
            toast.warning(t('stringLoggedOut'), { position: toast.POSITION.TOP_CENTER, autoClose: 1500, pauseOnHover: false })
            dispatch(resetCredentials())
            navigate('/login', { state: { isLoading: false } })
        }
        if (res.status === 400) {
            toast.warning(`${t('stringSomethingWentWrong')}`, { position: toast.POSITION.TOP_CENTER, autoClose: 2000, pauseOnHover: false })
        }

    }


    // Update Button triggered this function
    const updateData = useCallback((val) => {
        setUpdateState(val._id)
        setUserData({ userName: val.userName, role: val.role, employeeCode: val.employeeCode })
    }, []);


    // Get All User to show in table
    const getAllUser = async () => {
        const res = await fetch(`${process.env.REACT_APP_URL}/api/v1/users/getall`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                "Authorization": "Bearer " + jwt,
                "sid": sessionId
            }
        })
        const temp = await res.json()
        // console.log(temp);
        if (res.status === 200 && temp.data) {
            setAllUser(temp.data)
        }
    }

    useEffect(() => {
        getAllUser()
    }, [])

    return (
        <>
            <MenuBar />
            <SecondNav />
            <div className='users-info'>
                <div className='users-info-wrapper' >
                    <div className='row p-2'>
                        <div className='col col-md-6'>
                            <div className='user-info p-2'>
                                {/* card info */}
                                <div className='card' >
                                    <div className='card-body' >
                                        <h3 style={{
                                            overflowY: "hidden"
                                        }} >{t('stringConfigName')}: {loggedUserName}
                                        </h3>
                                        <p> {t('stringConfigRole')}: Super Admin</p>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='col col-md-6'>
                            {/* <button className='btn btn-primary'>Add User</button> */}
                        </div>
                    </div>

                    <div className='row user-table p-4'>
                        <div className="card mb-4">
                            <div className="card-body" style={{ overflowX: "auto" }}>
                                <table className="table table-hover">
                                    <thead className="mdb-color darken-3">
                                        <tr className="text-white ">
                                            {/* <th>#</th> */}
                                            <th>{t('stringConfigUserName')}</th>
                                            <th>{t('stringConfigEmail')}</th>
                                            <th>{t('stringConfigRole')}</th>
                                            <th>{t('stringConfigEmployeeCode')}</th>
                                            <th>{t('stringConfigLastLogin')}</th>
                                            <th>{t('stringConfigEdit')}</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        {
                                            allUser.map((val, ind) => {
                                                return (
                                                    <>
                                                        {updateState === val._id ? (
                                                            <Dataeditable key={ind} val={val} cancelUpdate={cancelUpdate} handleEvent={handleEvent} saveUpdate={saveUpdate} userData={userData} />
                                                        ) : (
                                                            <Readonlydata key={ind} val={val} updateData={updateData} />
                                                        )}
                                                    </>
                                                )
                                            })
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>

    )
}

export default UserInfoTable