import React, { memo } from "react";

const Dataeditable = ({ val, cancelUpdate, handleEvent, saveUpdate, userData }) => {
    return (
        <tr>
            {/* <th scope="row">3</th> */}
            {/* <td><input type={'text'} name="userName" value={userData.userName} onChange={handleEvent} /></td> */}
            <td>{userData.userName}</td>
            <td>{val.email}</td>
            <td>
                <select style={{ border: "none", width: "100%" }} name="role" onChange={handleEvent}>
                    {
                        val.role === 'user' ?
                            <>
                                <option value='user' selected>user</option>
                                <option value='superadmin'>superadmin</option>
                            </>
                            :
                            <>
                            <option value='user' >user</option>
                            <option value='superadmin' selected>superadmin</option>
                            </>
                    }

                </select>
            </td>
            {/* <td><input type={'text'} name="employeeCode" value={userData.employeeCode} onChange={handleEvent} /></td> */}
            <td>{userData.employeeCode}</td>
            <td>{new Date().toISOString().slice(0, 10)}</td>

            <td className='text-center'>
                <div style={{ display: 'flex', justifyContent: 'space-around', height: "100%" }}>
                    <i className="fa-solid fa-square-check fa-2x" onClick={()=>saveUpdate(val._id)}></i>
                    <i class="fa-sharp fa-solid fa-xmark fa-2x" onClick={cancelUpdate}></i>
                </div>
            </td>
        </tr>
    );
};

export default memo(Dataeditable);