import React, { memo } from "react";
const Readonlydata = ({ val, updateData }) => {
    // converting date formate into dd/mm/yyy hour/min/sec format
    function formatDate(date){
        const dateString = new Date(date).toLocaleString("en-US",{hour12: false});
        const splitDate = dateString.split(",");
        let first = splitDate[0];
        first = first.split('/')
        let dateFormat = `${first[2]}/${first[0]}/${first[1]}`
        const second = splitDate[1].split(" ")[1];
        return `${dateFormat} ${second}`
    }
    return (
        <tr>
            {/* <th scope="row">3</th> */}
            <td>{val.userName}</td>
            <td>{val.email}</td>
            <td>
                {val.role}
            </td>
            <td>{val.employeeCode}</td>
            <td>{formatDate(val.lastLogin)}</td>

            <td className='text-center'>
                {/* <div style={{ display: 'flex', justifyContent: 'space-around', height: "100%" }}> */}
                    <i className="fa-sharp fa-solid fa-pen-to-square" onClick={() => updateData(val)}></i>
                    {/* <i className="fa-solid fa-square-check"></i> */}
                {/* </div> */}

            </td>
        </tr>
    );
};

export default memo(Readonlydata);