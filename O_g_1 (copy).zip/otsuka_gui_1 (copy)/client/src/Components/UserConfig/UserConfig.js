import React, { useState } from 'react'

const UserConfig = () => {
    const emolyeeData = useState({
        emolyeeName: "",
        emolyeeCode: ""
    })
    return (
        <div className='user-input'>
            <div className='user-input-wrapper'>
                <div style={{
                    minHeight: "80vh"
                }} className='container d-flex flex-column justify-content-center align-items-center'>
                    <div className='userinfo-title text-align-center'>
                        <p className='text-center'>Welcome to the DeepICR Payment Application System.</p>
                        <p className='text-center'>Please input the following information.</p>
                    </div>
                    <div class="card w-80">
                        <div class="card-body">
                            <form>
                                <div class="form-group">
                                    <div className='row'>
                                        <div className='col'>
                                            <label for="name">Employee Name</label>
                                        </div>
                                        <div className='col'>
                                            <input type="text" class="form-control border" id="name" aria-describedby="name" placeholder="Enter email" />
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mt-2">
                                    <div className='row'>
                                        <div className='col'>
                                            <label for="employeeCode">Employee Code</label>
                                        </div>
                                        <div className='col'>
                                            <input type="text" class="form-control border" id="employeeCode" placeholder="Employee Code" />

                                        </div>
                                    </div>
                                </div>
                                <div className='row mt-2' >
                                    <div className='col-9'></div>
                                    <div className='col'>

                                        <button type="submit" class="btn btn-primary text-right">Submit</button>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default UserConfig