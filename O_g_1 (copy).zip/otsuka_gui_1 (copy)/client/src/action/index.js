import { useContext, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux'
import DeepICRContext from '../resources/DeepICRContext'




// Saving Uploaded files to context
export const setUploadedFiles = (data) => {
    return {
        type: "SET_UPLOADED_FILE",
        payload: {
            data: data
        }
    }
}

// Delete Selected files from status table
export const updateUploadedFiles = (data) => {
    return {
        type: "UPDATE_UPLOADED_FILE",
        payload: {
            data: data
        }
    }
}

// Getting JWT token from Cookies and decode
export const getCookie = () => {
    return {
        type: "GET_COOKIE"
    }
}

// After Logout reset the initial state
export const resetCredentials = () => {
    return (dispatch, getState) => {
        dispatch({
            type: "RESET_COOKIE"
        })
        dispatch({
            type: "RESET_DATE"
        })
    }

}


// Save Pagination data for check status page
export const setPagedata = (data) => {
    return {
        type: "SAVE_PAGE_DATA",
        payload: {
            data: data
        }
    }
}

// For pagination calculation totalFile track
export const totalFile = (data) => {
    return {
        type: "TOTAL_FILE",
        payload: {
            data: data
        }
    }
}
// Tracking current page number globally to send it to API
export const currPageNumbers = (data) => {
    return {
        type: "CURRENT_NUMBER",
        payload: {
            data: data
        }
    }
}

// For saving filtered data
export const setStartDate = (data) => {
    return {
        type: "SAVE_START_DATE",
        payload: {
            data: data
        }
    }
}

export const setEndDate = (data) => {
    return {
        type: "SAVE_END_DATE",
        payload: {
            data: data
        }
    }
}

export const setSelectedId = (data) => {
    return {
        type: "SAVE_SELECTED_ID",
        payload: {
            data: data
        }
    }
}
export const rpaChekedValue = (data) => {
    return {
        type: "RPA_CHECKED",
        payload: {
            data: data
        }
    }
}

export const saveResponseFunc = (data) => {
    return {
        type: "SAVE_RESPONSE",
        payload: {
            data: data
        }
    }
}

// // Result Page PAgination
export const resultTotalFile = (data) => {
    return {
        type: "RESULT_TOTAL_FILE",
        payload: {
            data: data
        }
    }
}

// While uploading file Home Button and deepICR Button will be non clickable
// Track the value with a boolean isFileUpload
export const fileUploadActive = (data) => {
    return {
        type: "FILE_UPLOAD_ACTIVE",
        payload: {
            data: data
        }
    }
}
export const fileUploadActivePage = (data) => {
    return {
        type: "FILE_UPLOAD_ACTIVE_PAGE",
        payload: {
            data: data
        }
    }
}

// For PIC Filter
// Selected Value save for further show

export const setSelected = (data) => {
    return {
        type: "SET_SELECTED",
        payload: {
            data: data
        }
    }
}

// For PIC Filter
// Set select Bool value 
export const setSelectBool = (data) => {
    return {
        type: "SET_SELECT_BOOL",
        payload: {
            data: data
        }
    }
}

// For Result Page
export const setLoadingImage = (data) => {
    return {
        type: "SET_LOADING_IMAGE",
        payload: {
            data: data
        }
    }
}

export const setInvoiceChange = (data) => {
    return {
        type: "RESULT_INVOICE_CHANGE",
        payload: {
            data: data
        }
    }
}

export const setTextChange = (data) => {
    return {
        type: "RESULT_TEXT_CHANGE",
        payload: {
            data: data
        }
    }
}


export const setMemoChange = (data) => {
    return {
        type: "RESULT_MEMO_CHANGE",
        payload: {
            data: data
        }
    }
}

export const setPopChange = (data) => {
    return {
        type: "RESULT_POP_CHANGE",
        payload: {
            data: data
        }
    }
}

export const setTrackSingleValue = (data,field) => {
    return {
        type: "RESULT_MULTIPLE_FIELD",
        payload: {
            data: data,
            field:field
        }
    }
}


// For Tracking Wheather Result Page has any change or not
// It will set Boolean value ,if true changes have made 
// If no change it will go to home page without any pop up
export const trackChangeInResultPage = (data)=>{
    return{
        type:"SET_BOOLEAN_CHANGES",
        payload:{
            data:data
        }
    }
}