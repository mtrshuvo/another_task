const { charAlterList } = require("./server/src/api/helpers/utils/resource");

 resObj = {
    // _id: new ObjectId("642bce4cb8e5cf3f18fc3be1"),
    // fileId: new ObjectId("642bc5c6f76fa7024aeffea2"),
    multipleSellerInfo: {
      'PAREXELΨ International, ϘIncΨ': { 'NΨ4158501Ψ': {"foramt": "1223"}, "N415Ϙ8502": {"foramt": "1223"} }
    //   'PAREXELΨ International, ϘIncΨ': {  'NΨ4158501Ψ': {"foramt": "1223"} }
      

    },
    currencyCode: 'JPY',
    invoiceNumber: '11101084781',
    issueDate: '2023-02-02',
    paymentDeadline: '2023-04-03',
    sellerName: [ 'PAREXEL. International, $Inc.' ],
    sellerCode: [ [ 'N.4158501.', 'N4158502' ] ],
    sellerSelectedIndex: [ 0, 0 ],
    sellerCorrectedValues: [],
    hospitalName: [],
    hospitalCode: [ [ '' ] ],
    hospitalSelectedIndex: [ 0, 0 ],
    hospitalCorrectedValues: [],
    protocolName: [ [ '33110200058 Brex Tab MDD Pivotal' ] ],
    protocolNo: [ '11033110200058' ],
    protocolSelectedIndex: [ 0, 0 ],
    protocolCorrectedValues: [],
    totalAmount: 19243277,
    purposeOfPayment: '◆2月',
    isSellerUserInput: false,
    isHospitalUserInput: false,
    isProtocolUserInput: false,
    isSellerDropdownchanged: false,
    isHospitalDropdownchanged: true,
    isProtocolDropdownchanged: true,
  }

  function alterSpecialChar (responseNerData){

       if(responseNerData?.multipleSellerInfo){
      for(let name in responseNerData.multipleSellerInfo){
        if(name.search(".") !== -1){
          let val = responseNerData.multipleSellerInfo[name]         
          let n = name.replace(/Ψ/g, ".").replace(/Ϙ/g, "$");
          
          delete responseNerData.multipleSellerInfo[name]
          responseNerData.multipleSellerInfo[n] = val

          if( Object.entries(responseNerData.multipleSellerInfo[n]).length){
            for(let sCode in responseNerData.multipleSellerInfo[n]){
                let sCodeVal = responseNerData.multipleSellerInfo[n][sCode];
                let alterSelleCOde = sCode.replace(/Ψ/g, ".").replace(/Ϙ/g, "$");
                delete responseNerData.multipleSellerInfo[n][sCode]
                responseNerData.multipleSellerInfo[n][alterSelleCOde] = sCodeVal;

            }
          }

        }
      }
    }
    return responseNerData;

  }

alterSpecialChar(resObj)

 