/**
 * Definition for singly-linked list.
 * function ListNode(val, next) {
 *     this.val = (val===undefined ? 0 : val)
 *     this.next = (next===undefined ? null : next)
 * }
 */
/**
 * @param {ListNode} head
 * @param {number} k
 * @return {ListNode}
 */
class ListNode{
    constructor(val){
        this.val = val;
        this.next = null;
    }

}

const one = new ListNode(1)
const two = new ListNode(2)
const three = new ListNode(3)
const four = new ListNode(4)
const five = new ListNode(5)
one.next = two
two.next = three
three.next = four
four.next = five;



var rotateRight = function(head, k) {
    let tail = head;
    let len = 0;

    while(tail.next){
        len += 1;
        tail = tail.next;
    }

    tail.next = head;
    k = k % len;

    let current = head;
    for(let i = 0; i < len - k; i++){
        current = current.next
    }
    current.next = null;
    tail.next = head
    console.log(head);
    console.log(tail);

};

rotateRight(one, 2)