export const skillData = [
    {
        _id: "1",
        title: "React JS",
        tools: "Frontend Engineering"
    },
    {
        _id: "2",
        title: "Node JS",
        tools: "Backend Engineering"
    },

]

