import { Box, Typography } from '@mui/material'
import React from 'react'

const Leavesetting = () => {
  return (
    <Box>
      <Box sx={{ display: "flex", justifyContent: "space-between" }}>
        <Typography sx={{ fontSize: '24px', fontWeight: 'bold' }}>Leave Setting</Typography>
      </Box>
    </Box>

  )
}

export default Leavesetting