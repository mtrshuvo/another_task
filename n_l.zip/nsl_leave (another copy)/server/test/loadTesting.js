const autocannon = require('autocannon');

// Replace 'YOUR_AUTH_TOKEN' with your actual token
const authToken = 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDJkNGEzZDM2MmUzNTQzYjFiZGRjOTMiLCJyb2xlIjp7Il9pZCI6IjY0MjI3Yjg5ODUyYzZlZDhkYTQ5YmJmMCIsIm5hbWUiOiJlbXBsb3llZSIsImFsaWFzIjoiRW1wbG95ZWUifSwiaWF0IjoxNjkxMzg0MjAzLCJleHAiOjE2OTE0Mjc0MDMsImF1ZCI6Imh0dHBzOi8vbmV4dHNvbHV0aW9ubGFiLmNvbSIsImlzcyI6Ik5TTCIsInN1YiI6InF1ZXJ5QG5leHRzb2x1dGlvbmxhYi5jb20ifQ.6h5VMPRyMppNaGIqNmgE-TnoYgfuLVlOsEL9117Il029CCIm3WPRo1mpFD0gJZusqHA4G2ko013wehZvR4CnzxvpmlmtSw0Fviyh5ay0MwreITzHr7ehNzNLZuwjrJVsD6zhtEgPCINPbsAhOLafTAHQ_6DPbg8rvLZwENPfQYKCNZJo5xRCcD3YasFuAJaP_8VNuCviYJzZTQphoXiueCU5-FvDTwFudWcrVaALjRG_Xf9tiGwq1L8hg96Nz4HdpmyyOL9rMsYYoUOWPdvOGb4Pn2ePGyNGc6SD8eduC86mQwYJ0IvrPLNU7EGrInGeh6Y4yjsrjOmrmq5J58EgXg';

const config = {
  url: 'http://localhost:3001/api/v1/task/filter', // Replace with your API URL
  method: 'POST', // Replace with the appropriate HTTP method
  headers: {
    'Authorization': authToken,
    'Content-Type': 'application/json', // Replace with the appropriate content type
  },
  body: JSON.stringify(
    // {"email":"shuvo@nextsolutionlab.com","password":"12345"}
    {"pcd":"WP-001","query":{"userId":[],"startTime":"","endTime":"","priority":[],"taskType":[],"sortBy":"","status":"","limit":3,"page":1}}
  ), // Replace with the request body (if required)
  connections: 100, // Number of concurrent connections
  duration: 10, // Duration of the test in seconds
};

const instance = autocannon(config, (err, result) => {
  if (err) {
    console.error(err);
  } else {
    console.log(result);
  }
});

autocannon.track(instance, {renderProgressBar: true});
