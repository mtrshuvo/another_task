module.exports.AttendeceTypes = ["WFH", "WAO", "HD", "WOH"]
module.exports.TASKSTATUSTYPES = ["todo", "in progress", "done", "pause"]
module.exports.TASKCATEGORY = ["feature", "bug", "test", "research", "meeting", "design", "others"]
module.exports.TASKPRIORITIES = ["high", "medium", "low"]