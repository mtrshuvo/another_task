// const reg = new RegExp("^[^/]+/[^/]+\.zip$");
let parentFolderName = "folder";
const subfolderRegex = new RegExp(`^${parentFolderName}/[^/]+\.zip$`)


console.log(subfolderRegex.test("folders/filname.zip"))


// authentication check

 //// setIsDisableConvert(true)
    // if (typeof deepICRCTX.file.name === "undefined" || deepICRCTX.file.name === "") {
    //   props.enqueueSnackbar(t("errorBeforeSetFile"), {
    //     variant: "error",
    //     anchorOrigin: { vertical: "top", horizontal: "right" },
    //   });
    //   deepICRLogging({
    //     LogType: "ERROR",
    //     ErrType: "BeforeSetFileError",
    //     Message: t("errorBeforeSetFile"),
    //     Src: "Toolbar.js",
    //     Line: 0,
    //     Column: 0,
    //     Stack: "",
    //   });
    //   // setIsDisableConvert(false)
    //   return;
    // }

    // if (deepICRCTX.file.name === deepICRCTX.requestedFile) {
    //   props.enqueueSnackbar(t("errorRequestSameFile"), {
    //     variant: "error",
    //     anchorOrigin: { vertical: "top", horizontal: "right" },
    //   });
    //   deepICRLogging({
    //     LogType: "ERROR",
    //     ErrType: "RequestSameFileError",
    //     Message: t("errorRequestSameFile"),
    //     Src: "Toolbar.js",
    //     Line: 0,
    //     Column: 0,
    //     Stack: "",
    //   });
    //   // setIsDisableConvert(false)
    //   return;
    // }

    // // Upload image data and input json to S3
    // const snackbarDoConvert = props.enqueueSnackbar(t("infoDoConvert") + deepICRCTX.file.name, {
    //   variant: "info",
    //   persist: true,
    //   anchorOrigin: { vertical: "bottom", horizontal: "right" },
    // });
    // const [yyyymmddhhmmss, unixtime, microsec] = deepICRNow();
    // // Get hash of Username
    // const md5 = crypto.createHash("md5");
    // const md5hash = md5.update(deepICRCTX.cognitoUser.Username, "binary").digest("hex");

    // // Refresh token
    // let isError = false;
    // let newAccessToken = "";
    // let requestJson = {
    //   type: "request",
    //   head: {
    //     command: "refreshToken",
    //     format_version: deepICRCTX.apiFormatVersion,
    //     service_id: deepICRCTX.apiServiceId,
    //     transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
    //     unix_time: unixtime,
    //     micro_seconds: microsec,
    //     time_zone: deepICRCTX.apiTimeZone,
    //   },
    //   //      "body": {refreshToken: deepICRCTX.refreshToken, username: deepICRCTX.cognitoUser.Username}
    //   body: { refreshToken: global.refreshToken, username: deepICRCTX.cognitoUser.Username },
    // };
    // await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTokenRefresh, {
    //   method: "POST",
    //   mode: "cors",
    //   //        headers: {Authorization: deepICRCTX.accessToken, "Content-Type": "application/json"},
    //   headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
    //   body: JSON.stringify(requestJson),
    // })
    //   .then((res) => {
    //     return res.json();
    //   })
    //   .then((json) => {
    //     // Timeout access token
    //     if (json.message === "Unauthorized") {
    //       props.closeSnackbar(snackbarDoConvert);
    //       props.enqueueSnackbar(t("errorLoginTimeout"), {
    //         variant: "error",
    //         anchorOrigin: { vertical: "top", horizontal: "right" },
    //       });
    //       deepICRLogging({
    //         LogType: "ERROR",
    //         ErrType: "LoginTimeoutError",
    //         Message: t("errorLoginTimeout"),
    //         Src: "Toolbar.js",
    //         Line: 0,
    //         Column: 0,
    //         Stack: "",
    //       });
    //       logout();
    //       isError = true;
    //       return;
    //     }
    //     if (json.body.status !== "OK") {
    //       if (json.body.error.message === "Token do not match") {
    //         props.closeSnackbar(snackbarDoConvert);
    //         props.enqueueSnackbar(t("errorLoginDuplicate"), {
    //           variant: "error",
    //           anchorOrigin: { vertical: "top", horizontal: "right" },
    //         });
    //         deepICRLogging({
    //           LogType: "ERROR",
    //           ErrType: "DuplicateLoginError",
    //           Message: t("errorLoginDuplicate"),
    //           Src: "Toolbar.js",
    //           Line: 0,
    //           Column: 0,
    //           Stack: "",
    //         });
    //         logout();
    //         isError = true;
    //         return;
    //       } else {
    //         if (deepICRCTX.debug === true) {
    //           console.log("[ToolBar - updateJson] token-refresh error for output json file");
    //         }
    //         if (deepICRCTX.debug === true) {
    //           console.log(JSON.stringify(json, null, 1));
    //         }
    //         props.closeSnackbar(snackbarDoConvert);
    //         props.enqueueSnackbar(t("errorSystemError"), {
    //           variant: "error",
    //           anchorOrigin: { vertical: "top", horizontal: "right" },
    //         });
    //         deepICRLogging({
    //           LogType: "ERROR",
    //           ErrType: "TokenRefreshFetchError",
    //           Message: "token-refresh error for output json file",
    //           Src: "Toolbar.js",
    //           Line: 0,
    //           Column: 0,
    //           Stack: "",
    //         });
    //         isError = true;
    //         return;
    //       }
    //     }
    //     newAccessToken = json.body.result.accessToken;
    //     global.accessToken = newAccessToken;
    //   })
    //   .catch((err) => {
    //     if (deepICRCTX.debug === true) {
    //       console.log("[ToolBar - updateJson] token-refresh catch error for output json file");
    //     }
    //     if (deepICRCTX.debug === true) {
    //       console.log(err);
    //     }
    //     props.closeSnackbar(snackbarDoConvert);
    //     props.enqueueSnackbar(t("errorSystemError"), {
    //       variant: "error",
    //       anchorOrigin: { vertical: "top", horizontal: "right" },
    //     });
    //     deepICRLogging({
    //       LogType: "ERROR",
    //       ErrType: "TokenRefreshCatchError",
    //       Message: "token-refresh catch error for output json file",
    //       Src: "Toolbar.js",
    //       Line: 0,
    //       Column: 0,
    //       Stack: "",
    //     });
    //     isError = true;
    //     return;
    //   });
    // if (isError) {
    //   // setIsDisableConvert(false)
    //   return;
    // }


