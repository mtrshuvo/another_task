const path = require("path");

const contextMode = process.env.REACT_APP_CONTEXT_MODE || process.env.NODE_ENV;
console.log("contextMode:", contextMode);

const originalContext = path.resolve(__dirname, "src/resources/deepICRContext.json");

const contextPath = {
  development: originalContext,
  staging: path.resolve(__dirname, `src/resources/deepICRContext.stage.json`),
  production: path.resolve(__dirname, `src/resources/deepICRContext.prod.json`),
};

module.exports = {
  webpack: function (config) {
    config.resolve.alias = {
      [originalContext]: contextPath[contextMode],
    };
    return config;
  },
};
