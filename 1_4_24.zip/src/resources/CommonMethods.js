import { useRef, useEffect, useContext } from "react";
import deepICRLogging from "../Logging/deepICRLogging";
import DeepICRContext from "./deepICRContext.json";

export function useEventListener(eventName, handler, element = window) {

  const savedHandler = useRef();
  useEffect(() => {
    savedHandler.current = handler;
  }, [handler]);

  useEffect(() => {
    const isSupported = element && element.addEventListener;
    if (!isSupported) return;
    const eventListener = (event) => savedHandler.current(event);
    element.addEventListener(eventName, eventListener);
    return () => {
      element.removeEventListener(eventName, eventListener);
    };
  }, [eventName, element]);
}

// export function useDidUpdate(callback, deps) {
//     const hasMount = useRef(false)

//     useEffect(() => {
//         if (hasMount.current) {
//             callback()
//         } else {
//             hasMount.current = true
//         }
//     }, deps)
// }

export function generateMessageFromError(error) {
  var caller_line = error.stack.split("\n")[1];
  var src_ln_col = caller_line.match(/\(([^)]+)\)/)[1];
  var src_ln_col_arr = src_ln_col.split(":");

  let colno = src_ln_col_arr.pop();
  let lineno = src_ln_col_arr.pop();
  let src = src_ln_col_arr.join(":");
  let type = error.stack.split("\n")[0].split(":")[0];
  let msg = error.message;

  let message = {
    LogType: "ERROR",
    ErrType: type,
    Message: msg,
    Src: src,
    Line: lineno,
    Column: colno,
    Stack: error.stack,
  };

  return message;
}

export function orderShapeSelectionLayer(shapeList, image_id, shape_id) {
  for (let i in shapeList) {
    if (parseInt(i) === image_id) {
      let temp = {};
      let filter = {};
      for (let s in shapeList[i]) {
        if (s === shape_id) {
          temp[s] = shapeList[i][s];
        } else {
          filter[s] = shapeList[i][s];
        }
      }
      shapeList[i] = Object.assign(temp, filter);
    }
  }
  return shapeList;
}

export function GetPointsFromShape(deepICRCTX, shape) {
  if (shape === undefined || shape === null || !("type" in shape)) {
    deepICRLogging({
      LogType: "ERROR",
      ErrType: "NetworkError",
      Message: "Can't convert shape information to points",
      Src: "Toolbar.js",
      Line: 0,
      Column: 0,
      Stack: "",
    });
    return [];
  }
  let points = [];
  if (shape.type === "rect") {
    let x = shape["x"];
    let y = shape["y"];
    let w = x + shape["width"];
    let h = y + shape["height"];
    points = [
      [x, y],
      [w, y],
      [w, h],
      [x, h],
    ];
  } else if (shape.type === "ellipse") {
    let cx = shape["cx"];
    let cy = shape["cy"];
    let rx = shape["rx"];
    let ry = shape["ry"];
    points = [
      [cx - rx, cy],
      [cx, cy - ry],
      [cx + rx, cy],
      [cx, cy + ry],
    ];
  } else if (shape.type === "polygon") {
    let s_points = shape["points"].split(" ");
    for (let i = 0; i < s_points.length; i++) {
      points.push(s_points[i].split(","));
    }
  }
  return points;
}

// Deep copy of javascript object
export function deepCopy(obj) {
  return JSON.parse(JSON.stringify(obj));
}

// Get size of any javascript object
export function objectSize(obj) {
  var size = 0,
    key;
  for (key in obj) {
    if (obj.hasOwnProperty(key)) size++;
  }
  return size;
}

export function sortObjectByKeys(obj) {
  return Object.keys(obj)
    .sort()
    .reduce((acc, key) => {
      acc[parseInt(key)] = obj[parseInt(key)];
      return acc;
    }, {});
}

export function getImage(path) {
  return new Promise(function (resolve, reject) {
    let image = new Image();
    image.crossOrigin = "Anonymous";
    image.onload = resolve(image);
    image.onerror = reject;
    image.src = path;
  });
}

export function cropImage(path, shape) {
  return new Promise(function (resolve, reject) {
    let image = new Image();
    image.crossOrigin = "Anonymous";
    image.onload = function () {
      var canvas = document.createElement("canvas");
      canvas.width = this.width;
      canvas.height = this.height;

      const ctx = canvas.getContext("2d");
      ctx.strokeStyle = "#BADA55";
      ctx.fillStyle = "#ffffff"; //HERE, use HEX format in 6 digits

      ctx.fillRect(0, 0, canvas.width, canvas.height); //HERE

      let x = Infinity,
        y = Infinity,
        w = -Infinity,
        h = -Infinity;

      ctx.beginPath();

      if (shape.type === "rect") {
        let points = [
          { x: shape.x, y: shape.y },
          { x: shape.x + shape.w, y: shape.y },
          { x: shape.x + shape.w, y: shape.y + shape.h },
          { x: shape.x, y: shape.y + shape.h },
        ];

        ctx.moveTo(points[0].x, points[0].y);
        for (var i = 1; i < points.length; i++) {
          if (x > points[i].x) x = points[i].x;
          if (w < points[i].x) w = points[i].x;
          if (y > points[i].y) y = points[i].y;
          if (h < points[i].y) h = points[i].y;

          ctx.lineTo(points[i].x, points[i].y);
        }
      } else if (shape.type === "polygon") {
        let points = shape.points;

        ctx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) {
          if (x > points[i].x) x = points[i].x;
          if (w < points[i].x) w = points[i].x;
          if (y > points[i].y) y = points[i].y;
          if (h < points[i].y) h = points[i].y;

          ctx.lineTo(points[i].x, points[i].y);
        }
      } else if (shape.type === "ellipse") {
        x = shape.x;
        y = shape.y;
        w = x + shape.w;
        h = y + shape.h;

        let cx = shape.x + shape.w / 2;
        let cy = shape.y + shape.h / 2;
        let rx = (shape.w * 2) / 3;
        let ry = shape.h / 2;

        ctx.moveTo(cx, cy - ry);
        ctx.bezierCurveTo(cx + rx, cy - ry, cx + rx, cy + ry, cx, cy + ry);
        ctx.bezierCurveTo(cx - rx, cy + ry, cx - rx, cy - ry, cx, cy - ry);
      }

      ctx.closePath();
      ctx.clip();
      ctx.drawImage(this, 0, 0);

      // create a new canvas
      var c = document.createElement("canvas");
      var cx = c.getContext("2d");
      cx.fillStyle = "white";
      cx.fillRect(0, 0, c.width, c.height);
      // resize the new canvas to the size of the clipping area
      c.width = w - x;
      c.height = h - y;

      // draw the clipped image from the main canvas to the new canvas
      cx.drawImage(canvas, x, y, w - x, h - y, 0, 0, w - x, h - y);
      let dataURL = c.toDataURL("image/png");
      resolve(dataURL);
    };
    image.onerror = reject;
    image.src = path;
  });
}

export function cropImageFromCanvas(src, shape, callBack) {
  if (objectSize(shape) > 0) {
    getImage(src).then((img) => {
      if (img.width === 0 || img.height === 0) return;
      var canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      ctx.strokeStyle = "#BADA55";
      ctx.fillStyle = "#ffffff"; //HERE, use HEX format in 6 digits
      ctx.fillRect(0, 0, canvas.width, canvas.height); //HERE

      canvas.width = img.width;
      canvas.height = img.height;

      let x = Infinity,
        y = Infinity,
        w = -Infinity,
        h = -Infinity;

      ctx.beginPath();

      if (shape.type === "rect") {
        let points = [
          { x: shape.x, y: shape.y },
          { x: shape.x + shape.w, y: shape.y },
          { x: shape.x + shape.w, y: shape.y + shape.h },
          { x: shape.x, y: shape.y + shape.h },
        ];

        ctx.moveTo(points[0].x, points[0].y);
        for (var i = 1; i < points.length; i++) {
          if (x > points[i].x) x = points[i].x;
          if (w < points[i].x) w = points[i].x;
          if (y > points[i].y) y = points[i].y;
          if (h < points[i].y) h = points[i].y;

          ctx.lineTo(points[i].x, points[i].y);
        }
      } else if (shape.type === "polygon") {
        let points = shape.points;

        ctx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) {
          if (x > points[i].x) x = points[i].x;
          if (w < points[i].x) w = points[i].x;
          if (y > points[i].y) y = points[i].y;
          if (h < points[i].y) h = points[i].y;

          ctx.lineTo(points[i].x, points[i].y);
        }
      } else if (shape.type === "ellipse") {
        x = shape.x;
        y = shape.y;
        w = x + shape.w;
        h = y + shape.h;

        let cx = shape.x + shape.w / 2;
        let cy = shape.y + shape.h / 2;
        let rx = (shape.w * 2) / 3;
        let ry = shape.h / 2;

        ctx.moveTo(cx, cy - ry);
        ctx.bezierCurveTo(cx + rx, cy - ry, cx + rx, cy + ry, cx, cy + ry);
        ctx.bezierCurveTo(cx - rx, cy + ry, cx - rx, cy - ry, cx, cy - ry);
      }

      ctx.closePath();
      ctx.clip();
      ctx.drawImage(img, 0, 0);

      // create a new canvas
      var c = document.createElement("canvas");
      var cx = c.getContext("2d");
      cx.fillStyle = "white";
      cx.fillRect(0, 0, c.width, c.height);
      // resize the new canvas to the size of the clipping area
      c.width = w - x;
      c.height = h - y;

      // draw the clipped image from the main canvas to the new canvas
      cx.drawImage(canvas, x, y, w - x, h - y, 0, 0, w - x, h - y);
      let dataURL = c.toDataURL("image/png");
      callBack(dataURL);
      // resolve(dataURL)
    });
  }
}


export function commaRemovingFromNumberValue(val) {
  // return val.replace(/(\d+)\s*,\s*(\d+)/g, (_, numberPart1, numberPart2) => {
  //   return numberPart1 + numberPart2;
  // })
  // return val.replace(/(\d)(,)(\d)/g, '$1$3');
  // return val.replace(/(\d)(,\s*)(\d)/g, '$1$3')
  return val.replace(/(\d)\s*,\s*(\d)/g, '$1$2');



}

/**
 * 
 * @param {*} obj 
 * @returns Boolean
 */
export const isthereAnyShape = (obj) => {
  // const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  // console.log(deepICRCTX,"Common method");
  let yesOrNo = false;
  let keys = Object.keys(obj);
  if(keys.length)
  for (let key of keys) {
      for (let region in obj[key]){
          let innerKeys = Object.keys(obj[key][region]);
          if(innerKeys.length)
          for(let innerkey of innerKeys){
              if(Object.values(obj[key][region][innerkey]).length){
                  yesOrNo = true
                  break;
              }
          }
      }
  }
  // console.log({yesOrNo});

  return yesOrNo;
}

/**
 * 
 * @param {Array} pages 
 * @returns {Object}
 */
export function formatDataForPreview(pages) {
  // const finalOutput = [];
  // for(let i =0; i < pages.length; i++){
  //     for(let j = 0; j < pages[i]?.regions?.length; j++){
  //         let objData = pages[i].regions[j];
  //         for (let item in objData) {
  //             let newData = {page: i +1, shapekeyId: item,...objData[item]}
  //             finalOutput.push(newData)
  //           }
  //     }
  // }
  // return finalOutput;
  let finalObj = {}
  for (let i = 0; i < pages.length; i++) {
    let page = i + 1;
    // console.log(pages);
    finalObj = { ...finalObj, [page]: [] }
    for (let j = 0; j < pages[i].regions?.length; j++) {
      let objData = pages[i].regions[j];
      for (let item in objData) {
        let newData = { page: i + 1, shapekeyId: item, ...objData[item] }
        finalObj[page].push(newData)
        finalObj[page].sort((a, b) => parseInt(a.shapekeyId.split("_")[3]) - parseInt(b.shapekeyId.split("_")[3]))
      }
    }

  }
  return finalObj;
}

/**
 * csv file naming conevntion
 * @param {Date} date 
 * @returns {string} 
 */
export function formatYYYYMMDDHHMMSS(date) {
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Adding 1 because months are zero-indexed
  const day = date.getDate().toString().padStart(2, '0');
  const hour = date.getHours().toString().padStart(2, '0');
  const minute = date.getMinutes().toString().padStart(2, '0');
  const second = date.getSeconds().toString().padStart(2, '0');

  return `${year}${month}${day}${hour}${minute}${second}`;
}

/**
 * 
 * @param {Array} arrayData 
 * @returns {Boolean} isSelected
 */
//checking for line object is selected or not
export function isSelectedLineData(arrayData) {
  let isSelected = true;
  for (let lineData of arrayData) {
    if (Object.keys(lineData).includes("objectInfo")) {
      isSelected = lineData.objectInfo.isSelected;
    }
  }

  return isSelected

}

/**
 * 
 * @param {Object} bbox_1 
 * @param {Object} bbox_2 
 * @param {Number} thresh 
 * @returns 
 */

function isSameLine(bbox_1, bbox_2, thresh = 2.5) {
  // Set the top box as the first box and the other box as the second box
  const [box_1, box_2] = bbox_1['y'] <= bbox_2['y'] ? [bbox_1, bbox_2] : [bbox_2, bbox_1];
  // Get the coordinates
  const { x: x_1, y: y_1, width: w_1, height: h_1 } = box_1;
  const { x: x_2, y: y_2, width: w_2, height: h_2 } = box_2;
  // If the top (y1) value of the second box is inside the range of the top part (y1) and threshold
  // then return true, else return false
  if (y_2 <= y_1 + h_1 / thresh && y_1 <= y_2) {
    return true;
  }
  return false;
}

/**
 * 
 * @param {Array} sequences 
 * @param {Boolean} getLine 
 * @returns 
 */
export function findLinesAndSort(sequences, getLine = true) {
  // Sort the words from top to bottom and initialize lines
  sequences = JSON.parse(JSON.stringify(sequences))
  sequences.sort((a, b) => a['y'] - b['y']);
  const lines = [];
  // Iterate words one by one and append to the same line, then generate/format the line using the same line words.
  // Finally, append the formatted line to lines
  while (sequences.length > 0) {
    const line = [sequences[0]];
    sequences.shift();
    while (sequences.length > 0) {
      if (isSameLine(line[line.length - 1], sequences[0])) {
        line.push(sequences[0]);
        sequences.shift();
      } else {
        break;
      }
    }
    line.sort((a, b) => a['x'] - b['x']);
    if (getLine) {
      lines.push(line);
    } else {
      lines.push(...line);
    }
  }
  // console.log({lines});
  // Return all formatted lines
  return lines;
}


// paramter will be  regions array
// if deepICR detect mutiple word in one cell then it will merge into one text


export function allTextData(regions) {
  regions = deepCopy(regions)
  const allText = [];
  if (regions.length) {
    for (let item of regions) {
      if (item.type.search(/Table/i) > 0) {
        // console.log(item);
        if (item.cells.length) {
          for (let cell of item?.cells) {
            if (cell.cell.length) {
              const cellTextData = mergeIntoOneCellText(cell.cell)
              // console.log("cellText", cellTextData);
              allText.push(...cellTextData)
            }

          }
        }
      } else {
        // console.log("item", item);
        if (item?.words?.length) {
          allText.push(...item.words)
        }

      }
    }
  }
  return allText;

}


export function mergeIntoOneCellText(cell) {
  let mergedText = "";
  let mergedX = null;
  let mergedY = null;
  let mergedWidth = null;
  let mergedHeight = null;
  // let confidences = [];

  cell.forEach(element => {
    // console.log("element", element);
    const words = element.words;
    if (words && words.length > 0) {
      // Concatenate the text
      mergedText += words[0].text;

      // Store the information from the first element
      if (mergedX === null) {
        mergedX = element.x;
        mergedY = element.y;
        mergedWidth = element.width;
        mergedHeight = element.height;
      }

    }
  });
  // Create the merged data object
  const mergedData = {
    text: mergedText,
    x: mergedX,
    y: mergedY,
    width: mergedWidth,
    height: mergedHeight,
    // averageConfidence: averageConfidence
  };


  // return findLinesAndSort(finalCell, false)
  return [mergedData];
}

// Function to find the index of the object containing the keyName
export function findIndexForKeyName(array, keyName) {
  const index = array.findIndex(obj => obj.hasOwnProperty(keyName));
  return index;
}

// Draw box modified in the existed shape id
export function findIndexForModifiedKeyName(array, keyName) {
  // console.log("sent array", array);
  const index = array.findIndex(obj => Object.keys(obj).some(key => key.includes(keyName)));
  // const index = array.findIndex(obj => obj.includes(keyName));
  return index;
}

export function insertValueWithBlanks(array, index, value) {
  // console.log("page no", index);
  // Fill all previous indexes with blank objects
  for (let i = 0; i < index; i++) {
      if (typeof array[i] === 'undefined') {
          array[i] = {};
      }
  }

  // Insert the value at the specified index
  array[index] = value;
  // setDeepICRCTX({
  //     ...deepICRCTX,
  //     selectedRegion:{
  //         pages:array
  //     }
  // })
  return array
}
export function hasMultipleObjects(obj) {
  const nestedObjectsCount = Object.values(obj).filter(value => typeof value === 'object').length;
  return nestedObjectsCount > 1;
}

export function ODataForCSV (outputJson){
  const oResultArray = outputJson.original_output.pages;
  // const oDataHeight = outputJson.original_output.pages[0].height;
  // const oDataWidth = outputJson.original_output.pages[0].width;
  const documentName = outputJson.original_output.document_name;
  const prefixArray = documentName.split(".");
  prefixArray.pop();
  const prefix = prefixArray.join(".");
  let id = 1;
  // let uniqueKeyForData = 0;
  // let shapes = {};
  let isSel = false;

  const oData = { documentName: documentName };
  const oTable = { documentName: documentName };
  for (let i = 0; i < oResultArray.length; i++) {
    let uniqueKeyForData = 0;
    if (oResultArray[i].id !== prefix) {
      id = oResultArray[i].id.replace(prefix + "_page_", "");

    }
    oData[id] = {
      id: oResultArray[i].id,
      height: oResultArray[i].height,
      width: oResultArray[i].width,
      data: [],
    };
    oTable[id] = {
      id: oResultArray[i].id,
      data: [],
    };
    for (let j = 0; j < oResultArray[i].regions.length; j++) {
      if (oResultArray[i].regions[j].selection_id !== undefined) isSel = true;
      if (
        oResultArray[i].regions[j].type === "Single Line" ||
        oResultArray[i].regions[j].type === "Line"
      ) {
        for (let k = 0; k < oResultArray[i].regions[j].words.length; k++) {
          if(oResultArray[i].regions[j].words[k].text !== ""){
            oData[id].data.push({
              shape_id: oResultArray[i].regions[j].selection_id,
              shape_type: oResultArray[i].regions[j].selection_type,
              meta: oResultArray[i].regions[j].meta,
              x: oResultArray[i].regions[j].words[k].x,
              y: oResultArray[i].regions[j].words[k].y,
              width: oResultArray[i].regions[j].words[k].width,
              height: oResultArray[i].regions[j].words[k].height,
              text: oResultArray[i].regions[j].words[k].text,
              confidence: oResultArray[i].regions[j].words[k].confidence,
              key: i + "-" + j + "-" + k,
              color: oResultArray[i].regions[j].words[k].confidence < 0.9 ? "red" : "black",
              originalText: "",
              type: "dataFromLine",
              uniqueKey: uniqueKeyForData,
            });
           
            uniqueKeyForData++;

          }
        }
      }
      else if (oResultArray[i].regions[j].type === "Blank") {
        
        oData[id].data.push({
          shape_id: oResultArray[i].regions[j].selection_id,
          shape_type: oResultArray[i].regions[j].selection_type,
          meta: oResultArray[i].regions[j].meta,
          x: oResultArray[i].regions[j].x,
          y: oResultArray[i].regions[j].y,
          width: oResultArray[i].regions[j].width,
          height: oResultArray[i].regions[j].height,
          key: i + "-" + j,
          points: oResultArray[i].regions[j].points,
          type: "Blank",
          uniqueKey: uniqueKeyForData,
        });
        uniqueKeyForData++;
      } else if (oResultArray[i].regions[j].type === "Multi Line") {
        for (let k = 0; k < oResultArray[i].regions[j].lines.length; k++) {
          for (let l = 0; l < oResultArray[i].regions[j].lines[k].words.length; l++) {
            oData[id].data.push({
              shape_id: oResultArray[i].regions[j].selection_id,
              shape_type: oResultArray[i].regions[j].selection_type,
              meta: oResultArray[i].regions[j].meta,
              x: oResultArray[i].regions[j].lines[k].words[l].x,
              y: oResultArray[i].regions[j].lines[k].words[l].y,
              width: oResultArray[i].regions[j].lines[k].words[l].width,
              height: oResultArray[i].regions[j].lines[k].words[l].height,
              text: oResultArray[i].regions[j].lines[k].words[l].text,
              confidence: oResultArray[i].regions[j].lines[k].words[l].confidence,
              key: i + "-" + j + "-" + k + "-" + l,
              color:
                oResultArray[i].regions[j].lines[k].words[l].confidence < 0.9 ? "red" : "black",
              originalText: "",
              type: "dataFromLine",
              uniqueKey: uniqueKeyForData,
            });
            uniqueKeyForData++;
          }
        }
      } else if (oResultArray[i].regions[j].type === "Handwritten") {
        if ("lines" in oResultArray[i].regions[j]) {
          for (let k = 0; k < oResultArray[i].regions[j].lines.length; k++) {
            for (let l = 0; l < oResultArray[i].regions[j].lines[k].words.length; l++) {
              if(oResultArray[i].regions[j].lines[k].words[l].text !== ""){

                oData[id].data.push({
                  shape_id: oResultArray[i].regions[j].selection_id,
                  shape_type: oResultArray[i].regions[j].selection_type,
                  meta: oResultArray[i].regions[j].meta,
                  x: oResultArray[i].regions[j].lines[k].words[l].x,
                  y: oResultArray[i].regions[j].lines[k].words[l].y,
                  width: oResultArray[i].regions[j].lines[k].words[l].width,
                  height: oResultArray[i].regions[j].lines[k].words[l].height,
                  text: oResultArray[i].regions[j].lines[k].words[l].text,
                  confidence: oResultArray[i].regions[j].lines[k].words[l].confidence,
                  key: i + "-" + j + "-" + k + "-" + l,
                  color:
                    oResultArray[i].regions[j].lines[k].words[l].confidence < 0.9
                      ? "red"
                      : "black",
                  originalText: "",
                  type: "dataFromLine",
                  uniqueKey: uniqueKeyForData,
                });
                uniqueKeyForData++;
              }
            }
          }
        }
      }
      //} else if(oResultArray[i].regions[j].type.match(/_Table/)) {
      else if (
        ((oResultArray[i].regions[j].type === "Table" ||
            oResultArray[i].regions[j].type.match(/_Table/)) && oResultArray[i].regions[j].type!=='Borderless_Table')
      ) {
        for (let k = 0; k < oResultArray[i].regions[j].cells.length; k++) {
          let flag = false;

          oTable[id].data.push({
            shape_id: oResultArray[i].regions[j].selection_id,
            shape_type: oResultArray[i].regions[j].selection_type,
            meta: oResultArray[i].regions[j].meta,
            x: oResultArray[i].regions[j].cells[k].x,
            y: oResultArray[i].regions[j].cells[k].y,
            width: oResultArray[i].regions[j].cells[k].width,
            height: oResultArray[i].regions[j].cells[k].height,
            row_no: oResultArray[i].regions[j].cells[k].row_no,
            col_no: oResultArray[i].regions[j].cells[k].col_no,
            row_span: oResultArray[i].regions[j].cells[k].row_span,
            col_span: oResultArray[i].regions[j].cells[k].col_span,
            key: i + "-" + j + "-" + k,
            type: "borderFromTable",
          });
          // console.log("table text data",oResultArray[i].regions[j].cells[k] );
          for (let l = 0; l < oResultArray[i].regions[j].cells[k].cell.length; l++) {
              if(flag) break;
            for (let m = 0; m < oResultArray[i].regions[j].cells[k].cell[l].words.length; m++) {
              if (oResultArray[i].regions[j].cells[k].cell[l].words[m].text !== "") {
                oData[id].data.push({
                  shape_id: oResultArray[i].regions[j].selection_id,
                  shape_type: oResultArray[i].regions[j].selection_type,
                  meta: oResultArray[i].regions[j].meta,
                  x: oResultArray[i].regions[j].cells[k].cell[l].words[m].x,
                  y: oResultArray[i].regions[j].cells[k].cell[l].words[m].y,
                  width: oResultArray[i].regions[j].cells[k].cell[l].words[m].width,
                  height: oResultArray[i].regions[j].cells[k].cell[l].words[m].height,
                  text: oResultArray[i].regions[j].cells[k].cell_text,
                  confidence: oResultArray[i].regions[j].cells[k].cell[l].words[m].confidence,
                  key: i + "-" + j + "-" + k + "-" + l + "-" + m,
                  color:
                    oResultArray[i].regions[j].cells[k].cell[l].words[m].confidence < 0.9
                      ? "red"
                      : "black",
                  originalText: "",
                  type: "dataFromTable",
                  uniqueKey: uniqueKeyForData,
                });
                uniqueKeyForData++;
              }
              flag = true;
              if (flag) break;
            }
          }
        }
      }
    }
  }
  return oData
}