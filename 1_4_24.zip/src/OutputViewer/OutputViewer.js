import React, { useContext, useState, useEffect, useRef } from "react";
// import "./src/index.css"
import "./../../src/index.css";
import { useTranslation } from "react-i18next";
import { Button, Dialog, Fade, TextField, makeStyles, withStyles } from "@material-ui/core";
import { withSnackbar } from "notistack";
import { Tabs, Tab } from "@material-ui/core";
import Toolbar from "@material-ui/core/Toolbar";
import Divider from "@material-ui/core/Divider";
import Typography from "@material-ui/core/Typography";
import InputBase from "@material-ui/core/InputBase";
import IconButton from "@material-ui/core/IconButton";
import Search from "@material-ui/icons/Search";

// import react components
import deepICRTheme from "../resources/deepICRTheme";
import ButtonEnlargeFont from "./ButtonEnlargeFont";
import ButtonShrinkFont from "./ButtonShrinkFont";
import ButtonResetFont from "./ButtonResetFont";
import ExtractedOutput from "./ExtractedOutput";
import OriginalOutput from "./OriginalOutput";

// import resource files
import DeepICRContext from "../resources/DeepICRContext";
import CroppingOutput from "./CroppingOutput";
import { LiaFileUploadSolid, LiaFileDownloadSolid } from "react-icons/lia"
import { isthereAnyShape } from "../resources/CommonMethods";
import { deepICRDownload, deepICRtoBlobWithBom } from "../deepICRCommon";
import deepICRLogging from "../Logging/deepICRLogging";
import Menu from '@material-ui/core/Menu';
import MenuItem from "@material-ui/core/MenuItem"
import { deepICRNow } from "../deepICRCommon";
import PopupModal from "../PopUpModal/PopupModal";
import useCustomModal from "../PopUpModal/useModal";
import useSetInfo from "../useHook/setInfo";


// Style Sheet
const useStyles = makeStyles((theme) => ({
  styleOutputViewer: {

    // border: "2px solid " + theme.palette.deepICR.borderColor,
    backgroundColor: theme.palette.deepICR.color,
    color: theme.palette.deepICR.backgroundColor,
    // margin: theme.spacing(1, 1, 0, 0),
    // padding: theme.spacing(0, 0, 0, 0),
    boxSizing: "border-box",
    height: "99.5%",
    display: "flex",
    flexDirection: "column",
    flex: 1,
  },
  styleOutputs: {
    margin: theme.spacing(0, 0, 0, 0),
    boxSizing: "border-box",
    height: "100%",
  },
  styleOutput: {
    display: "flex",
    flexDirection: "column",
    flexGrow: 1,
    backgroundColor: theme.palette.deepICR.outputBackground,
    boxSizing: "border-box",
    height: "100%",
  },
  styleToolbar: {
    paddingLeft: 0,
    paddingRight: 0,
    borderBottom: "1px solid #EAEAF0",


  },
  styleToolbar2: {
    paddingLeft: 0,
    paddingRight: 0,
    borderBottom: "1px solid #EAEAF0",
    "& .MuiButtonBase-root:hover": {
      backgroundColor: `${theme.palette.deepICR.blue4} !important`,
      color: "#ffffff !important"
    },
    "& .Mui-selected:hover": {
      backgroundColor: `${theme.palette.deepICR.deloitteGreen} !important`
    },
  },

  styleDivider: {
    height: theme.palette.deepICR.dividerHeight,
    margin: theme.palette.deepICR.deviderMargin,
  },
  styleSearchInputRoot: {
    // border: '2px solid ' + theme.palette.deepICR.borderColor,
    color: "inherit",
    backgroundColor: "#fff",
  },
  styleSearchInput: {
    padding: theme.spacing(1, 1, 1, 2),
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      // width: theme.palette.deepICR.searchInputSize,
      "&:focus": {
        // width: theme.palette.deepICR.searchInputSizeFocus,
        // backgroundColor: theme.palette.deepICR.input,
      },
    },
  },
  styleTemplateJson: { fontSize: ".9rem", color: "#26890D" },
  styleTemplateJsonLabel: { fontSize: ".9rem", },

  styleSearchIcon: { padding: theme.spacing(1), color: deepICRTheme.palette.deepICR.blue4 },
  styleSpacer: { flexGrow: 1 },
  arrowIndicator: {
    position: "relative",
    "&::before": {
      content: "''",
      position: "absolute",
      width: "0",
      borderBottom: `2px solid ${theme.palette.primary.main}`,
      bottom: 0,
      transition: "width 0.2s",
    }
  },
  modal: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  paper: {
    backgroundColor: theme.palette.background.paper,
    border: `1px solid ${theme.palette.deepICR.blue4}`,
    boxShadow: theme.shadows[5],
    padding: theme.spacing(2, 4, 3),
    color: "black"
  },
  styleOkButton: {
    color: theme.palette.deepICR.modalCancelColor,
    backgroundColor: theme.palette.deepICR.color,
    borderRadius: 2,
    "&:hover": {
      color: theme.palette.deepICR.blue4
    }
  },
  styleCancelButton: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
    // borderColor: theme.palette.deepICR.blue4,
    "&:hover": {
      color: theme.palette.deepICR.blue4
    }
  },
  modalContainer: {
    position: "absolute",
    top: "calc(100% + 5px)",
    display: "flex",
    flexDirection: "column",
    zIndex: 9999,
    width: "250px",

  },
  modalButton: {
    width: "100%",
    textAlign: "left",
    padding: "8px 16px",
    backgroundColor: "#fff",
    border: "1px solid #ccc",
    cursor: "pointer",
  },
  modalButtonHover: {
    backgroundColor: "#f0f0f0",
  },
  styleTemplateNameField: {
    width: "100%",
    padding: "0 0 10px 0",
    "& input": {
      fontSize: ".9rem"
    }
  }


}));
const CustomTabs = withStyles({

  indicator: {
    display: "none",
    backgroundColor: deepICRTheme.palette.deepICR.blue4,

  },



})(Tabs);


// Output Tab Panel
const TabPanel = (props) => {
  const styles = useStyles();

  const { children, value, index, ...other } = props;

  return (
    <div
      className={styles.styleOutputs}
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      {...other}
    >
      <div className={styles.styleOutput} >{children}</div>
    </div>
  );
};

// Set Tab Property
const retProps = (value, index) => {

  if (value === index) {
    return {
      id: `tabpanel-${index}`,
      style: {
        minHeight: "auto",
        // backgroundColor: "inherit",
        color: deepICRTheme.palette.deepICR.color,
        fontSize: "0.9rem",
        maxWidth: "none",
        backgroundColor: deepICRTheme.palette.deepICR.deloitteGreen,
        flex: 1,
        fontWeight: 600,
      },
    };
  } else {
    return {
      id: `tabpanel-${index}`,
      className: "tab_buttons",
      style: {
        color: deepICRTheme.palette.deepICR.blue4,
        minHeight: "auto",
        fontSize: "0.9rem",
        backgroundColor: deepICRTheme.palette.deepICR.color,
        fontWeight: 600,
        flex: 1,
        maxWidth: "none",
        border: "0 1px 0 0 solid #E2E2E2"

      },
    };
  }
};

// [React function component]
// Output viewer component
const OutputViewer = (props) => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [value, setValue] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [isSwitch, setIsSwitch] = useState(false);
  // const [isChanged, setIsChanged] = useState(false)
  const [isOpen, setIsOpen] = useState(false)
  const [responseImportLibrary, setResponseImportLibrary] = useState({})
  // const [isJsonImported, setIsJsonImported] = useState(false)
  // const [pageVisited, setPageVisited] = useState({})
  const cancelRefButton = useRef(null)
  const [inputModal, setInputModal] = useState(false);
  const [templateName, setTemplateName] = useState("");
  const [validTemplateName, setValidTemplateName] = useState(false);
  const [yyyymmddhhmmss, unixtime, microsec] = deepICRNow();
  const { getData } = useSetInfo()

  // additional states 
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [anchorElexport, setAnchorElexport] = React.useState(null);

  //focusing on cancel button
  const onEntered = () => cancelRefButton?.current?.focusVisible();
  const openModal = () => {
    setIsOpen(true)
    // anotherRef.current.focus()
  }
  const closeModal = () => {
    setIsOpen(false)
  }

  const inputModalOp = () => setInputModal(!inputModal);

  if (deepICRCTX.debug === true) {
    console.log("OutputViewer");
  }

  // convert modal
  const {
    openModal: openModalC,
    closeModal: closeModalC,
    isOpen: isOpenC
  } = useCustomModal()

  // save to template library
  const {
    openModal: openModalT,
    closeModal: closeModalT,
    isOpen: isOpenT
  } = useCustomModal()


  /////// functions for export import modal starts from here ///////
  const handleOpenModal = (event) => {
    setAnchorEl(event.currentTarget);
  };


  const handleClose = () => {
    setAnchorEl(null);
  };


  const handleOpenExportModal = (event) => {
    setAnchorElexport(event.currentTarget);

  };

  const handleCloseExportModal = () => {
    setAnchorElexport(null);
  };
  const changeTemplateName = (e) => {
    let val = e.target.value;
    const regex = /^[^<>:"/\\|?*\x00-\x1F]+$/;
    setValidTemplateName((regex.test(val)))


    setTemplateName(val.trim());
  }

  // ************** save to library functions start ****************

  // deepicr orignal_output page wise template json data selection
  const templateJsonParsing = () => {
    let templateInfo = {};
    let pagesArray = [];
    if (!deepICRCTX.pdfBase64) pagesArray = [1];
    else {
      for (let page of deepICRCTX.outputJson.original_output.pages) {
        const pageSplitter = page.id.split("_");
        let pageInfo = pageSplitter[pageSplitter.length - 1];
        pagesArray.push(parseInt(pageInfo))
      }

    }
    for (let page in deepICRCTX.shapeListRight) {
      let key = parseInt(page.split("_")[3]);
      if (pagesArray.includes(key)) {
        templateInfo[page] = deepICRCTX.shapeListRight[page];
      }
    }
    console.log("template info", templateInfo);
    return templateInfo
  }

  const saveToLibrary = async () => {

    // Authorization Function
    // Refresh token
    // let isError = false;
    // let newAccessToken = "";
    // let requestJson = {
    //   type: "request",
    //   head: {
    //     command: "refreshToken",
    //     format_version: deepICRCTX.apiFormatVersion,
    //     service_id: deepICRCTX.apiServiceId,
    //     transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
    //     unix_time: unixtime,
    //     micro_seconds: microsec,
    //     time_zone: deepICRCTX.apiTimeZone,
    //   },
    //   //      "body": {refreshToken: deepICRCTX.refreshToken, username: deepICRCTX.cognitoUser.Username}
    //   body: { refreshToken: global.refreshToken, username: deepICRCTX.cognitoUser.Username },
    // };
    // await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTokenRefresh, {
    //   method: "POST",
    //   mode: "cors",
    //   //        headers: {Authorization: deepICRCTX.accessToken, "Content-Type": "application/json"},
    //   headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
    //   body: JSON.stringify(requestJson),
    // })
    //   .then((res) => {
    //     return res.json();
    //   })
    //   .then((json) => {
    //     // Timeout access token
    //     if (json.message === "Unauthorized") {
    //       props.enqueueSnackbar(t("errorLoginTimeout"), {
    //         variant: "error",
    //         anchorOrigin: { vertical: "top", horizontal: "right" },
    //       });
    //       deepICRLogging({
    //         LogType: "ERROR",
    //         ErrType: "LoginTimeoutError",
    //         Message: t("errorLoginTimeout"),
    //         Src: "Toolbar.js",
    //         Line: 0,
    //         Column: 0,
    //         Stack: "",
    //       });
    //       logout();
    //       isError = true;
    //       return;
    //     }
    //     if (json.body.status !== "OK") {
    //       if (json.body.error.message === "Token do not match") {
    //         props.enqueueSnackbar(t("errorLoginDuplicate"), {
    //           variant: "error",
    //           anchorOrigin: { vertical: "top", horizontal: "right" },
    //         });
    //         deepICRLogging({
    //           LogType: "ERROR",
    //           ErrType: "DuplicateLoginError",
    //           Message: t("errorLoginDuplicate"),
    //           Src: "Toolbar.js",
    //           Line: 0,
    //           Column: 0,
    //           Stack: "",
    //         });
    //         logout();
    //         isError = true;
    //         return;
    //       } else {
    //         if (deepICRCTX.debug === true) {
    //           console.log("[ToolBar - updateJson] token-refresh error for output json file");
    //         }
    //         if (deepICRCTX.debug === true) {
    //           console.log(JSON.stringify(json, null, 1));
    //         }
    //         props.enqueueSnackbar(t("errorSystemError"), {
    //           variant: "error",
    //           anchorOrigin: { vertical: "top", horizontal: "right" },
    //         });
    //         deepICRLogging({
    //           LogType: "ERROR",
    //           ErrType: "TokenRefreshFetchError",
    //           Message: "token-refresh error for output json file",
    //           Src: "Toolbar.js",
    //           Line: 0,
    //           Column: 0,
    //           Stack: "",
    //         });
    //         isError = true;
    //         return;
    //       }
    //     }
    //     newAccessToken = json.body.result.accessToken;
    //     global.accessToken = newAccessToken;
    //   })
    //   .catch((err) => {
    //     if (deepICRCTX.debug === true) {
    //       console.log("[ToolBar - updateJson] token-refresh catch error for output json file");
    //     }
    //     if (deepICRCTX.debug === true) {
    //       console.log(err);
    //     }
    //     props.enqueueSnackbar(t("errorSystemError"), {
    //       variant: "error",
    //       anchorOrigin: { vertical: "top", horizontal: "right" },
    //     });
    //     deepICRLogging({
    //       LogType: "ERROR",
    //       ErrType: "TokenRefreshCatchError",
    //       Message: "token-refresh catch error for output json file",
    //       Src: "Toolbar.js",
    //       Line: 0,
    //       Column: 0,
    //       Stack: "",
    //     });
    //     isError = true;
    //     return;
    //   });
    // if (isError) {
    //   // setIsDisableConvert(false)
    //   return;
    // }
    // Authorization function end

    // For production
    let data = getData()

    const dummyRequest = {
      "contract_id": data.contract_id,
      "user_id": data.user_id,
      "template_name": templateName,
      "need_replace": false,
      "statusCode": 200,
      "template": {
        "template_name": templateName,
        "template_info": templateJsonParsing()
      },
      "input_file_info": {
        "bucket_name": deepICRCTX.s3Bucket,
        "file_path": data.file_path,
        "file_name": data.file_name
      }
    }

    // For local
    // const request = {
    //   "contract_id": "string",
    //   "user_id": "string",
    //   "company_name": "string",
    //   "template_name": templateName,
    //   "need_replace": true,
    //   "statusCode": 200,
    //   "template": {
    //     "template_name": "string",
    //     "template_info": templateJsonParsing()
    //   },
    //   "input_file_info": {
    //     "bucket_name": "string",
    //     "file_path": "string",
    //     "file_name": "string"
    //   }
    // }

    fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiSaveTemplate, {
      method: "POST",
      mode: "cors",
      headers: {
        "Authorization": global.accessToken,
        "Content-Type": "application/json",
        "x-api-key": "bt0PdkDK7z7Adzg0qpIlo87gzVcdUunO4J0NH4C4"
      },
      body: JSON.stringify(dummyRequest)
    }).then(async (res) => {
      if (res.status === 200) {
        setTemplateName("")
        props.enqueueSnackbar(
          t("Successfully save to library"),
          { variant: 'success', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
        );
        return;
      }
      if (res.status === 409) {
        //pop up a modal 
        openModalT();
        return

      }
      else {
        setTemplateName("")

        throw new Error("Something went wrong")
      }
    }).catch(err => {
      setTemplateName("")

      props.enqueueSnackbar(
        t("Error Occured"),
        { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
      );
    })


  }

  // modify data if matched found
  const modifyRequest = async () => {

    // Refresh token
    let isError = false;
    let newAccessToken = "";
    let requestJson = {
      type: "request",
      head: {
        command: "refreshToken",
        format_version: deepICRCTX.apiFormatVersion,
        service_id: deepICRCTX.apiServiceId,
        transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
        unix_time: unixtime,
        micro_seconds: microsec,
        time_zone: deepICRCTX.apiTimeZone,
      },
      //      "body": {refreshToken: deepICRCTX.refreshToken, username: deepICRCTX.cognitoUser.Username}
      body: { refreshToken: global.refreshToken, username: deepICRCTX.cognitoUser.Username },
    };
    await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTokenRefresh, {
      method: "POST",
      mode: "cors",
      //        headers: {Authorization: deepICRCTX.accessToken, "Content-Type": "application/json"},
      headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
      body: JSON.stringify(requestJson),
    })
      .then((res) => {
        return res.json();
      })
      .then((json) => {
        // Timeout access token
        if (json.message === "Unauthorized") {
          props.enqueueSnackbar(t("errorLoginTimeout"), {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          deepICRLogging({
            LogType: "ERROR",
            ErrType: "LoginTimeoutError",
            Message: t("errorLoginTimeout"),
            Src: "Toolbar.js",
            Line: 0,
            Column: 0,
            Stack: "",
          });
          logout();
          isError = true;
          return;
        }
        if (json.body.status !== "OK") {
          if (json.body.error.message === "Token do not match") {
            props.enqueueSnackbar(t("errorLoginDuplicate"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "DuplicateLoginError",
              Message: t("errorLoginDuplicate"),
              Src: "Toolbar.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
            logout();
            isError = true;
            return;
          } else {
            if (deepICRCTX.debug === true) {
              console.log("[ToolBar - updateJson] token-refresh error for output json file");
            }
            if (deepICRCTX.debug === true) {
              console.log(JSON.stringify(json, null, 1));
            }
            props.enqueueSnackbar(t("errorSystemError"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "TokenRefreshFetchError",
              Message: "token-refresh error for output json file",
              Src: "Toolbar.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
            isError = true;
            return;
          }
        }
        newAccessToken = json.body.result.accessToken;
        global.accessToken = newAccessToken;
      })
      .catch((err) => {
        if (deepICRCTX.debug === true) {
          console.log("[ToolBar - updateJson] token-refresh catch error for output json file");
        }
        if (deepICRCTX.debug === true) {
          console.log(err);
        }
        props.enqueueSnackbar(t("errorSystemError"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        deepICRLogging({
          LogType: "ERROR",
          ErrType: "TokenRefreshCatchError",
          Message: "token-refresh catch error for output json file",
          Src: "Toolbar.js",
          Line: 0,
          Column: 0,
          Stack: "",
        });
        isError = true;
        return;
      });
    if (isError) {
      // setIsDisableConvert(false)
      return;
    }

    // For production
    let data = getData()

    const request = {
      "contract_id": data.contract_id,
      "user_id": data.user_id,
      "template_name": templateName,
      "need_replace": false,
      "statusCode": 200,
      "template": {
        "template_name": templateName,
        "template_info": templateJsonParsing()
      },
      "input_file_info": {
        "bucket_name": deepICRCTX.s3Bucket,
        "file_path": data.file_path,
        "file_name": data.file_name
      }
    }

    // For Local test
    // const request = {
    //   "contract_id": "string",
    //   "user_id": "string",
    //   "company_name": "string",
    //   "template_name": templateName,
    //   "need_replace": true,
    //   "statusCode": 200,
    //   "template": {
    //     "template_name": "string",
    //     "template_info": templateJsonParsing()
    //   },
    //   "input_file_info": {
    //     "bucket_name": "string",
    //     "file_path": "string",
    //     "file_name": "string"
    //   }
    // }

    let res = await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiSaveTemplate, {
      method: "POST",
      mode: "cors",
      headers: {
        "Authorization": global.accessToken,
        "Content-Type": "application/json",
        "x-api-key": "bt0PdkDK7z7Adzg0qpIlo87gzVcdUunO4J0NH4C4"
      },
      body: JSON.stringify(request)
    })
    if (res.status === 200) {
      setTemplateName("")
      props.enqueueSnackbar(
        t("Successfully save to library"),
        { variant: 'success', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
      );
      return;
    } else {
      setTemplateName("")

      props.enqueueSnackbar(
        t("Error Occured"),
        { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
      );
      return
    }
  }

  // ************** save to library functions end ****************



  /////// functions for export import modal ends here ////////

  /******************************* check box funtionality *************************/

  const handleChange = (event, newValue) => {

    if (newValue === 1) {
      setIsSwitch(true)
    } else {
      setIsSwitch(false)
    }
    setValue(newValue);
    setDeepICRCTX({ ...deepICRCTX, outputTab: newValue, isSwitch: isSwitch });
  }

  if (deepICRCTX.outputTab === 0 && value === 1) {
    // console.log("Changing tab");
    setValue(0);
    setIsSwitch(false)
    // setDeepICRCTX({...deepICRCTX,isSwitch:false});
  }


  useEffect(() => {
    setDeepICRCTX({ ...deepICRCTX, isSwitch: isSwitch })
  }, [isSwitch])

  useEffect(() => {
    setValue(deepICRCTX.outputTab)
  }, [deepICRCTX.outputTab])

  useEffect(() => {
    setTemplateName("");
  }, [deepICRCTX.file])


  let width = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
  let height = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

  const [t] = useTranslation(); // for multiple language
  const styles = useStyles(); // for material ui style



  const handleExportTemplate = () => {
    // let page_index = "p_" + width + "_" + height + "_" + (deepICRCTX.pdfPage);
    if (isthereAnyShape(deepICRCTX.selectedRegion) === false) {
      props.enqueueSnackbar(
        t("noSelectionError"),
        { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
      );
    }
    else {
      let tempJson = {};
      tempJson = deepICRCTX.shapeListRight;
      // tempJson['pages'] = deepICRCTX.selectedRegion.pages;
      let fileName = deepICRCTX.file.name.split(".");
      fileName.pop();
      fileName = fileName.join(".");
      deepICRDownload(deepICRtoBlobWithBom(JSON.stringify(tempJson, null, 1), "application/json"), fileName + ".json");
    }
  };




  /******* validate json ******/
  function isNumeric(value) {
    return /^-?\d+$/.test(value);
  }
  /**
   * 
   * @param {Object} jsonData 
   * @returns {Boolean} 
   *    */

  const uploadedJsonValidation = (jsonData) => {
    let isError = false;
    try {
      for (let page in jsonData) {
        const pagesSplitter = page.split("_");
        // console.log("splitter",pagesSplitter[0]);

        if (pagesSplitter[0] === "p"
          &&
          isNumeric(pagesSplitter[1]) &&
          isNumeric(pagesSplitter[2]) &&
          isNumeric(pagesSplitter[3])
        ) {
          for (let shape in jsonData[page]) {
            if (("type" in jsonData[page][shape])
              &&
              ("x" in jsonData[page][shape]) &&
              ("y" in jsonData[page][shape]) &&
              ("width" in jsonData[page][shape]) &&
              ("height" in jsonData[page][shape]) &&
              ("label" in jsonData[page][shape]) &&
              ("meta" in jsonData[page][shape]) &&
              ("image_id" in jsonData[page][shape]) &&
              ("shape_id" in jsonData[page][shape])

            ) {
              if (
                jsonData[page][shape]['type'] === "rect"
                &&
                typeof jsonData[page][shape]['x'] === "number" &&
                typeof jsonData[page][shape]['y'] === "number" &&
                typeof jsonData[page][shape]['height'] === "number" &&
                typeof jsonData[page][shape]['width'] === "number" &&
                typeof jsonData[page][shape]['label'] === "string" &&
                jsonData[page][shape]['image_id'] === page &&
                typeof jsonData[page][shape]['shape_id'] === "string"

              ) {
                continue
              }
              else {
                throw new Error("Invalid")
              }
            } else {
              throw new Error("Invalid")
            }

          }
        }
      }

    } catch (err) {
      isError = true;
    }
    finally {
      return isError
    }

  }

  const getTemplateJsonMultiPage = (e) => {
    if (e.target.files[0].type !== "application/json") {
      props.enqueueSnackbar(
        t("errorInvalidJsonType"),
        { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
      );
      return;
    }


    let file = e.target.files[0];
    let reader = new FileReader();
    let isError = false;
    // console.log("files", file);

    reader.onload = function (e) {
      if (e.target.result === "" || Object.keys(JSON.parse(e.target.result)).length < 1) {
        isError = true;
        props.enqueueSnackbar(
          t("errorEmptyJsonFile"),
          { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
        );
        return;

      }
      let tempJson = JSON.parse(e.target?.result);
      let shapeList = {};
      // json validation function
      isError = uploadedJsonValidation(tempJson);
      // console.log("is Error", isError);
      if (isError) {
        props.enqueueSnackbar(
          t("templateFormatError"),
          { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
        );
        return;
      }
      for (let p in tempJson) {
        let keyArr = p.split("_");
        // console.log(keyArr[3]);
        const newPageIndex = parseInt(keyArr[3]) <= deepICRCTX.fileSize.length ?
          `p_${deepICRCTX.fileSize[parseInt(keyArr[3]) - 1].width}_${deepICRCTX.fileSize[parseInt(keyArr[3]) - 1].height}_${parseInt(keyArr[3])}` : p;

        if (keyArr && keyArr.length === 4 && keyArr[0] === "p") {
          let w = parseInt(keyArr[1]);
          let h = parseInt(keyArr[2]);

          if (typeof w !== 'number' || typeof h !== 'number') {
            deepICRLogging({
              "LogType": "ERROR",
              "ErrType": "TypeError",
              "Message": "Value of w and h must be integer",
              "Src": "InputViewer.js",
              "Line": 0,
              "Column": 0,
              "Stack": ""
            });
            isError = true;
            break;
          }

          //for every individual page height width
          let width = parseInt(keyArr[1]);
          let height = parseInt(keyArr[2]);
          // console.log("Checking width,w", { width }, { w });
          let ratio = width / w;
          if (height < h * ratio) {
            ratio = height / h;
          }
          // console.log("ratio", ratio);

          for (let s in tempJson[p]) {
            let sArr = s.split("_");
            if (sArr.length !== 2 || sArr[0] !== "sr" || typeof parseInt(sArr[1]) !== 'number') {
              deepICRLogging({
                "LogType": "ERROR",
                "ErrType": "TypeError",
                "Message": "Length of sArr must but 2, first index value of sArr must be s and second index value of sArr must be integer",
                "Src": "OutputViwer.js",
                "Line": 0,
                "Column": 0,
                "Stack": ""
              });
              isError = true;
            }
            if (tempJson[p][s].type === "rect") {
              tempJson[p][s].x = (parseInt(tempJson[p][s].x)) * ratio;
              tempJson[p][s].y = parseInt(tempJson[p][s].y) * ratio;
              tempJson[p][s].width = parseInt(tempJson[p][s].width) * ratio;
              tempJson[p][s].height = parseInt(tempJson[p][s].height) * ratio;
              tempJson[p][s].isSelected = tempJson[p][s].isSelected;
              tempJson[p][s].image_id = newPageIndex;
            }
            else if (tempJson[p][s].type === "ellipse") {
              tempJson[p][s].cx = parseInt(tempJson[p][s].cx) * ratio;
              tempJson[p][s].cy = parseInt(tempJson[p][s].cy) * ratio;
              tempJson[p][s].rx = parseInt(tempJson[p][s].rx) * ratio;
              tempJson[p][s].ry = parseInt(tempJson[p][s].ry) * ratio;
            }
            else if (tempJson[p][s].type === "polygon") {
              let str_points = "";
              let points = tempJson[p][s].points.split(" ");
              for (let i = 0; i < points.length; i++) {
                let point = points[i].split(",");
                if (i === 0) str_points += (parseInt(point[0]) * ratio) + "," + (parseInt(point[1]) * ratio);
                else str_points += " " + (parseInt(point[0]) * ratio) + "," + (parseInt(point[1]) * ratio);
              }
              tempJson[p][s].points = str_points;
            }
          }

          // console.log("new page index", keyArr);
          shapeList[newPageIndex] = tempJson[p];
          // console.log("final shape list", tempJson[p]);
        }
        else {
          deepICRLogging({
            "LogType": "ERROR",
            "ErrType": "TypeError",
            "Message": "keyArr must not be undefined or null, length of keyArr must but 4 and first index value of keyArr must be p",
            "Src": "InputViewer.js",
            "Line": 0,
            "Column": 0,
            "Stack": ""
          });
          isError = true;
          break;
        }
      }
      if (isError) {
        props.enqueueSnackbar(
          t("templateFormatError"),
          { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
        );
      }
      else {
        // console.log("Entered Else");
        // setIsJsonImported(true)
        // console.log("ekbare final", shapeList);
        setDeepICRCTX({
          ...deepICRCTX,
          templateJsonName: file.name,
          selectedShapeRight: [],
          shapeListRight: shapeList,
          selectedRegion: {
            pages: []
          },
          jsonImported: true,
          pageVisited: {},
          trackImport: !deepICRCTX.trackImport
        })
      }
    };

    reader.onerror = function (e) {
      // Error : Can not read template json file
      if (deepICRCTX.debug === true) console.log(e);
    };
    reader.readAsText(file);
    e.target.value = null;
  }

  // After getting matching template if user click on yes button
  const getTemplateJsonServer = () => {
    let isError
    if (Object.keys(responseImportLibrary.template_info).length < 1) {
      isError = true;
      props.enqueueSnackbar(
        t("errorEmptyJsonFile"),
        { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
      );
      return;

    }
    let tempJson = responseImportLibrary.template_info;
    let shapeList = {};
    // json validation function
    isError = uploadedJsonValidation(tempJson);
    // console.log("is Error", isError);
    if (isError) {
      props.enqueueSnackbar(
        t("templateFormatError"),
        { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
      );
      return;
    }
    for (let p in tempJson) {
      let keyArr = p.split("_");
      // console.log(keyArr[3]);
      const newPageIndex = parseInt(keyArr[3]) <= deepICRCTX.fileSize.length ?
        `p_${deepICRCTX.fileSize[parseInt(keyArr[3]) - 1].width}_${deepICRCTX.fileSize[parseInt(keyArr[3]) - 1].height}_${parseInt(keyArr[3])}` : p;

      if (keyArr && keyArr.length === 4 && keyArr[0] === "p") {
        let w = parseInt(keyArr[1]);
        let h = parseInt(keyArr[2]);

        if (typeof w !== 'number' || typeof h !== 'number') {
          deepICRLogging({
            "LogType": "ERROR",
            "ErrType": "TypeError",
            "Message": "Value of w and h must be integer",
            "Src": "InputViewer.js",
            "Line": 0,
            "Column": 0,
            "Stack": ""
          });
          isError = true;
          break;
        }

        //for every individual page height width
        let width = parseInt(keyArr[1]);
        let height = parseInt(keyArr[2]);
        // console.log("Checking width,w", { width }, { w });
        let ratio = width / w;
        if (height < h * ratio) {
          ratio = height / h;
        }
        // console.log("ratio", ratio);

        for (let s in tempJson[p]) {
          let sArr = s.split("_");
          if (sArr.length !== 2 || sArr[0] !== "sr" || typeof parseInt(sArr[1]) !== 'number') {
            deepICRLogging({
              "LogType": "ERROR",
              "ErrType": "TypeError",
              "Message": "Length of sArr must but 2, first index value of sArr must be s and second index value of sArr must be integer",
              "Src": "OutputViwer.js",
              "Line": 0,
              "Column": 0,
              "Stack": ""
            });
            isError = true;
          }
          if (tempJson[p][s].type === "rect") {
            tempJson[p][s].x = (parseInt(tempJson[p][s].x)) * ratio;
            tempJson[p][s].y = parseInt(tempJson[p][s].y) * ratio;
            tempJson[p][s].width = parseInt(tempJson[p][s].width) * ratio;
            tempJson[p][s].height = parseInt(tempJson[p][s].height) * ratio;
            tempJson[p][s].isSelected = tempJson[p][s].isSelected;
            tempJson[p][s].image_id = newPageIndex;
          }
          else if (tempJson[p][s].type === "ellipse") {
            tempJson[p][s].cx = parseInt(tempJson[p][s].cx) * ratio;
            tempJson[p][s].cy = parseInt(tempJson[p][s].cy) * ratio;
            tempJson[p][s].rx = parseInt(tempJson[p][s].rx) * ratio;
            tempJson[p][s].ry = parseInt(tempJson[p][s].ry) * ratio;
          }
          else if (tempJson[p][s].type === "polygon") {
            let str_points = "";
            let points = tempJson[p][s].points.split(" ");
            for (let i = 0; i < points.length; i++) {
              let point = points[i].split(",");
              if (i === 0) str_points += (parseInt(point[0]) * ratio) + "," + (parseInt(point[1]) * ratio);
              else str_points += " " + (parseInt(point[0]) * ratio) + "," + (parseInt(point[1]) * ratio);
            }
            tempJson[p][s].points = str_points;
          }
        }

        // console.log("new page index", keyArr);
        shapeList[newPageIndex] = tempJson[p];
        // console.log("final shape list", tempJson[p]);
      }
      else {
        deepICRLogging({
          "LogType": "ERROR",
          "ErrType": "TypeError",
          "Message": "keyArr must not be undefined or null, length of keyArr must but 4 and first index value of keyArr must be p",
          "Src": "InputViewer.js",
          "Line": 0,
          "Column": 0,
          "Stack": ""
        });
        isError = true;
        break;
      }
    }
    if (isError) {
      props.enqueueSnackbar(
        t("templateFormatError"),
        { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
      );
    }
    else {
      // console.log("Entered Else");
      // setIsJsonImported(true)
      // console.log("ekbare final", shapeList);
      setDeepICRCTX({
        ...deepICRCTX,
        templateJsonName: responseImportLibrary.template_name,
        selectedShapeRight: [],
        shapeListRight: shapeList,
        selectedRegion: {
          pages: []
        },
        jsonImported: true,
        pageVisited: {},
        trackImport: !deepICRCTX.trackImport
      })
    }
  }

  // Logout
  const logout = async () => {
    const [, unixtime, microsec] = deepICRNow();
    let requestJson = {
      type: "request",
      head: {
        command: "signout",
        format_version: deepICRCTX.apiFormatVersion,
        service_id: deepICRCTX.apiServiceId,
        transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
        unix_time: unixtime,
        micro_seconds: microsec,
        time_zone: deepICRCTX.apiTimeZone,
      },
    };
    await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiSignout, {
      method: "POST",
      mode: "cors",
      headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
      body: JSON.stringify(requestJson),
    })
      .then((res) => {
        return res.json();
      })
      .then((json) => {
        if (deepICRCTX.debug === true) {
          console.log(json);
        }
      })
      .catch((err) => {
        if (deepICRCTX.debug === true) {
          console.log("[ToolBar - logout] signout catch error");
        }
        if (deepICRCTX.debug === true) {
          console.log(err);
        }

        deepICRLogging({
          LogType: "ERROR",
          ErrType: "SignoutCatchError",
          Message: "Signout catch error",
          Src: "Toolbar.js",
          Line: 0,
          Column: 0,
          Stack: "",
        });
      });

    global.accessToken = "";
    global.refreshToken = "";
    global.rotation = [];
    setDeepICRCTX({
      ...deepICRCTX,
      isLogin: false,
      isTerms: false,
      isContract: false,
      changePassword: false,
      documentId: "",
      cognitoUser: {},
      // accessToken: "",
      // refreshToken: "",
      inputViewerBounds: {
        bounds: { height: 100, width: 100, top: 0, bottom: 100, left: 0, right: 100 },
      },
      imageScale: 1,
      outputTab: 0,
      file: {},
      requestedFile: "",
      fileBase64: [],
      fileSize: [{ height: 0, width: 0 }],
      pdfBase64: "",
      pdfPage: 1,
      pdfPages: 1,
      targetPages: "",
      size: 12,
      originalOutputFontScale: 1,
      outputSw: false,
      outputLinkSw: false,
      originalOutputSize: { height: 0, width: 0 },
      originalOutputData: { data: [] },
      originalOutputTable: { data: [] },
      extractedOutputData: { data: [] },
      extractedOutputTable: { data: [] },
      searchText: "",
    });
  };

  const importTemplateMatch = async () => {
// Authorization Function

    // let isError = false;
    // let newAccessToken = "";
    // let requestJson = {
    //   type: "request",
    //   head: {
    //     command: "refreshToken",
    //     format_version: deepICRCTX.apiFormatVersion,
    //     service_id: deepICRCTX.apiServiceId,
    //     transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
    //     unix_time: unixtime,
    //     micro_seconds: microsec,
    //     time_zone: deepICRCTX.apiTimeZone,
    //   },
    //   //      "body": {refreshToken: deepICRCTX.refreshToken, username: deepICRCTX.cognitoUser.Username}
    //   body: { refreshToken: global.refreshToken, username: deepICRCTX.cognitoUser.Username },
    // };
    // await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTokenRefresh, {
    //   method: "POST",
    //   mode: "cors",
    //   //        headers: {Authorization: deepICRCTX.accessToken, "Content-Type": "application/json"},
    //   headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
    //   body: JSON.stringify(requestJson),
    // })
    //   .then((res) => {
    //     return res.json();
    //   })
    //   .then((json) => {
    //     // Timeout access token
    //     if (json.message === "Unauthorized") {
    //       props.enqueueSnackbar(t("errorLoginTimeout"), {
    //         variant: "error",
    //         anchorOrigin: { vertical: "top", horizontal: "right" },
    //       });
    //       deepICRLogging({
    //         LogType: "ERROR",
    //         ErrType: "LoginTimeoutError",
    //         Message: t("errorLoginTimeout"),
    //         Src: "Toolbar.js",
    //         Line: 0,
    //         Column: 0,
    //         Stack: "",
    //       });
    //       logout();
    //       isError = true;
    //       return;
    //     }
    //     if (json.body.status !== "OK") {
    //       if (json.body.error.message === "Token do not match") {
    //         props.enqueueSnackbar(t("errorLoginDuplicate"), {
    //           variant: "error",
    //           anchorOrigin: { vertical: "top", horizontal: "right" },
    //         });
    //         deepICRLogging({
    //           LogType: "ERROR",
    //           ErrType: "DuplicateLoginError",
    //           Message: t("errorLoginDuplicate"),
    //           Src: "Toolbar.js",
    //           Line: 0,
    //           Column: 0,
    //           Stack: "",
    //         });
    //         logout();
    //         isError = true;
    //         return;
    //       } else {
    //         if (deepICRCTX.debug === true) {
    //           console.log("[ToolBar - updateJson] token-refresh error for output json file");
    //         }
    //         if (deepICRCTX.debug === true) {
    //           console.log(JSON.stringify(json, null, 1));
    //         }
    //         props.enqueueSnackbar(t("errorSystemError"), {
    //           variant: "error",
    //           anchorOrigin: { vertical: "top", horizontal: "right" },
    //         });
    //         deepICRLogging({
    //           LogType: "ERROR",
    //           ErrType: "TokenRefreshFetchError",
    //           Message: "token-refresh error for output json file",
    //           Src: "Toolbar.js",
    //           Line: 0,
    //           Column: 0,
    //           Stack: "",
    //         });
    //         isError = true;
    //         return;
    //       }
    //     }
    //     newAccessToken = json.body.result.accessToken;
    //     global.accessToken = newAccessToken;
    //   })
    //   .catch((err) => {
    //     if (deepICRCTX.debug === true) {
    //       console.log("[ToolBar - updateJson] token-refresh catch error for output json file");
    //     }
    //     if (deepICRCTX.debug === true) {
    //       console.log(err);
    //     }
    //     props.enqueueSnackbar(t("errorSystemError"), {
    //       variant: "error",
    //       anchorOrigin: { vertical: "top", horizontal: "right" },
    //     });
    //     deepICRLogging({
    //       LogType: "ERROR",
    //       ErrType: "TokenRefreshCatchError",
    //       Message: "token-refresh catch error for output json file",
    //       Src: "Toolbar.js",
    //       Line: 0,
    //       Column: 0,
    //       Stack: "",
    //     });
    //     isError = true;
    //     return;
    //   });
    // if (isError) {
    //   // setIsDisableConvert(false)
    //   return;
    // }

// Authorization Function ends

    const data = getData();

    //geting custom page value
    let pagesArray = [];
    if (!deepICRCTX.pdfBase64) pagesArray = [1];
    else {
      for (let page of deepICRCTX.outputJson.original_output.pages) {
        const pageSplitter = page.id.split("_");
        let pageInfo = pageSplitter[pageSplitter.length - 1];
        pagesArray.push(parseInt(pageInfo))
      }

    }
    console.log({pagesArray});

    // For local test
    let info = {
      contract_id: "23453678",
      user_id: "dddd",
      input_file_info: {
        bucket_name: "bucket 1",
        file_path: "auto/template/files",
        file_name: "test1.pdf",
        custom_pages: pagesArray.length === deepICRCTX.fileSize.length ? [] : pagesArray
      },
      statusCode: 200
    }

    console.log({info});

    // For production
    // let info = {
    //   contract_id: data.contract_id,
    //   user_id: data.user_id,
    //   input_file_info: {
    //     bucket_name: deepICRCTX.s3Bucket,
    //     file_path: data.file_path,
    //     file_name: data.file_name,
    //     custom_pages: [2, 3, 4, 5]
    //   },
    //   statusCode: 200
    // }
    // console.log("global ac", global.accessToken);

    const res = await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTemplateMatch, {
      method: "POST",
      mode: "cors",

      // For Local with x-api-key
      headers: {
        'x-api-key': 'bt0PdkDK7z7Adzg0qpIlo87gzVcdUunO4J0NH4C4',
      },

      // For Production
      // headers: {
      //   "Authorization": global.accessToken,
      //   "Content-Type": "application/json"
      // },
      body: JSON.stringify(info),
    })

    let responseJson = await res.json()
    console.log({ responseJson });
    if (res.status === 200) {
      openModalC()
      setResponseImportLibrary(responseJson)
    } else if (res.status === 204) {
      openModalC()
      // If backend send blank object then save the blank object
      // For now save it as 'no Content' in an object
      setResponseImportLibrary({ warning: "No Content" })
    } else {

    }

  }


  return (
    <div className={styles.styleOutputViewer}>
      {/* template json export import bar */}
      <Toolbar className={styles.styleToolbar}>
        <Typography style={{ flexGrow: 4, flexShrink: 1, letterSpacing: deepICRCTX.language === "en" ? "10px" : "0" }}></Typography>

        <Typography className={styles.styleTemplateJsonLabel} style={{
          flexFlow: 1,
          fontSize: deepICRCTX.language === "en" ? "1rem" : "initial",
          letterSpacing: deepICRCTX.language === "en" ? "1px" : "initial",
        }}
        >{t("stringTemplateJsonLabel")}</Typography>
        <Typography className={styles.styleSpacer} style={{ flex: 2 }}></Typography>

        {/*New design of import  starts */}

        <Button
          className={styles.styleTemplateJson}
          onClick={handleOpenModal}
          startIcon={<LiaFileUploadSolid />}
          disabled={(deepICRCTX.outputTab === 1 ? false : true) || (typeof deepICRCTX.originalOutputData.data[deepICRCTX.pdfPage] !== 'undefined' ? false : true)}
        >
          {t("stringTemplateJsonImport")}
        </Button>
        <Menu
          sx={{ mt: '45px', top: '160px' }}
          id="menu-appbar"
          anchorEl={anchorEl}
          anchorOrigin={{
            vertical: 'bottom',
            horizontal: 'right',
          }}
          keepMounted
          transformOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
          open={Boolean(anchorEl)}
          onClose={handleClose}
          PaperProps={{
            style: {
              marginTop: "45px",
              marginLeft: "45px"
            }
          }}
        >
          <MenuItem
            onClick={() => {
              importTemplateMatch()
              handleClose()
            }
            }
          >
            Import from Library

          </MenuItem>
          <MenuItem
            component="label"
            onClick={(e) => {
              if (isthereAnyShape(deepICRCTX.selectedRegion)) {
                e.preventDefault()
                openModal();
              }
              handleClose()
            }}
          >
            {t("Import from Local")}
            <input
              type="file"
              accept=".json"
              id="templateUpload"
              hidden
              onChange={getTemplateJsonMultiPage}
            />
          </MenuItem>
        </Menu>

        {/*New design of import ends */}

        <pre  > | </pre>

        <Button
          className={styles.styleTemplateJson}
          onClick={handleOpenExportModal}
          startIcon={<LiaFileDownloadSolid />}
          disabled={deepICRCTX.outputTab === 2 ? false : true}
        >
          {t("stringTemplateJsonExport")}
        </Button>
        <Menu
          sx={{ mt: '45px' }}
          anchorEl={anchorElexport}
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
          keepMounted
          transformOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
          open={Boolean(anchorElexport)}
          onClose={handleCloseExportModal}
          PaperProps={{
            style: {
              marginTop: "45px",
              marginLeft: "35px"
            }
          }}
        >
          <MenuItem
            onClick={() => { inputModalOp(); handleCloseExportModal() }}
          >
            {t("Save to Library")}
          </MenuItem>
          <MenuItem
            onClick={handleExportTemplate}
          >
            {t("Export to Local")}
          </MenuItem>
        </Menu>


        {/*New design of export ends  */}

        {/* <Typography className={styles.styleSpacer}></Typography> */}


        <Typography className={styles.styleSpacer}></Typography>
        <InputBase
          placeholder={t("stringMenuBarSearch")}
          classes={{
            root: styles.styleSearchInputRoot,
            input: styles.styleSearchInput,
          }}
          className={typeof deepICRCTX.originalOutputData.data[deepICRCTX.pdfPage] === 'undefined' ? "" : "styleAcitveBottomBar"}
          disabled={((deepICRCTX.outputSw === true) ? false : true) || typeof deepICRCTX.originalOutputData.data[deepICRCTX.pdfPage] === 'undefined' ? true : false}
          value={deepICRCTX.searchTextValue}
          inputProps={{ "aria-label": "Search" }}
          onChange={(e) => {
            setSearchText(e.target.value);
            setDeepICRCTX({ ...deepICRCTX, searchTextValue: e.target.value })
            if (e.target.value === "") {
              setDeepICRCTX({ ...deepICRCTX, searchText: e.target.value, searchTextValue: e.target.value });
            }

          }}
        />
        <IconButton
          className={styles.styleSearchIcon}
          disabled={((deepICRCTX.outputSw === true || deepICRCTX.documentId === false) ? false : true) || typeof deepICRCTX.originalOutputData.data[deepICRCTX.pdfPage] === 'undefined' ? true : false}
          onClick={(e) => {
            if (searchText !== "") {
              if (Object.keys(deepICRCTX.originalOutputData.data).length !== 0) {
                setDeepICRCTX({ ...deepICRCTX, searchText: searchText });
              }
            }
          }}
        >
          <Search />
        </IconButton>
        <div style={{ display: "none" }}>
          <Divider orientation="vertical" className={styles.styleDivider} />
          <ButtonEnlargeFont value={value} />
          <ButtonShrinkFont value={value} />
          <ButtonResetFont value={value} />
        </div>

      </Toolbar>

      {/* tab button bar*/}
      <Toolbar className={styles.styleToolbar2}   >
        <CustomTabs
          value={value}
          onChange={handleChange}
          aria-label="output tabs"
          style={{ minHeight: "auto", width: "100%", backgroundColor: "#EAEAF0 !important", gap: "0.2rem !important" }}
          classes={{

          }}
        >
          <Tab label={t("stringOutputViewerTabOriginal")} {...retProps(value, 0)} disabled={deepICRCTX.outputSw === false && deepICRCTX.documentId === ""} />
          <Tab label={t('stringCroppingOutput')} classes={{ root: "outputTabHeight" }} {...retProps(value, 1)} disabled={deepICRCTX.outputSw === false && deepICRCTX.documentId === ""} />
          <Tab label={t("stringOutputViewerTabExtracted")} {...retProps(value, 2)} classes={{
            root: (!isthereAnyShape(deepICRCTX.selectedRegion)) ? "preview-tab active-preview" : ""
          }}
            disabled={deepICRCTX.outputSw === false && deepICRCTX.documentId === "" || !isthereAnyShape(deepICRCTX.selectedRegion)}
          />

        </CustomTabs>
        <Typography className={styles.styleSpacer}></Typography>

        <div style={{ display: "none" }}>
          <Divider orientation="vertical" className={styles.styleDivider} />
          <ButtonEnlargeFont value={value} />
          <ButtonShrinkFont value={value} />
          <ButtonResetFont value={value} />
        </div>
      </Toolbar>


      <TabPanel value={value} index={0}>
        <OriginalOutput height={global.inputViewerHeight} width={global.inputViewerWidth} />
      </TabPanel>
      <TabPanel value={value} index={1}>
        {/* isJsonImported={isJsonImported} setIsJsonImported = {setIsJsonImported} */}
        <CroppingOutput height={height} width={width} imageIndex={deepICRCTX.pdfPage - 1} isSwitch={deepICRCTX.isSwitch} />
      </TabPanel>
      <TabPanel value={value} index={2}  >
        <ExtractedOutput />
      </TabPanel>
      <footer style={{ display: "none" }}>
        <Toolbar />
      </footer>


      {/* tmplate name input modal start  */}
      <div>
        <Dialog
          className={styles.modal}
          open={inputModal}
          onClose={inputModalOp}
          TransitionProps={{ onEntered }}
        >
          <Fade in={inputModal}>
            <div className={styles.paper}>
              {/* <h2 id="transition-modal-title"></h2> */}
              <p id="transition-modal-description">{t("stringTemplateNameLabel")}</p>

              {/* <input id="templateName" onChange={changeTemplateName} value={templateName} /> */}
              <TextField id="outlined-basic" className={styles.styleTemplateNameField} onChange={changeTemplateName} value={templateName} variant="outlined" />
              {/* {(templateName.length > 0 && !validTemplateName) ? <span style={{ color: "red" }}>Invalid character contains in filename</span> : ""} */}
              <Button
                style={{
                  minWidth: deepICRCTX.language === "en" ? "49%" : "",
                }}
                onClick={(e) => {
                  saveToLibrary();
                  inputModalOp();
                }}
                className={styles.styleOkButton}
                disabled={(templateName.length > 0 ) ? false : true}
                action={(actions) => cancelRefButton.current = actions}

                variant="outlined" component="span">
                <Typography
                  style={{
                    letterSpacing: deepICRCTX.language === "en" ? "1px" : "",
                    fontWeight: deepICRCTX.language === "en" ? "600" : "initial"
                  }}
                  variant="h6">{t("stringPopUpMessageOk")}</Typography>
              </Button>
              <Button
                style={{
                  minWidth: deepICRCTX.language === "en" ? "49%" : "",
                }}
                className={styles.styleCancelButton}
                // action={(actions) => cancelRefButton.current = actions}
                onClick={inputModalOp}
                variant="outlined" component="span">
                <Typography
                  style={{
                    letterSpacing: deepICRCTX.language === "en" ? "1px" : "",
                    fontWeight: deepICRCTX.language === "en" ? "600" : "initial"
                  }}
                  variant="h6">{t("stringPopUpMessageCancel")}</Typography>
              </Button>
            </div>
          </Fade>
        </Dialog>
      </div>
      {/* tmplate name input modal end  */}
      {/* modal  start*/}
      <div>
        <input
          type="file"
          accept=".json"
          id="templateUpload-another"
          hidden
          onChange={(e) => {
            getTemplateJsonMultiPage(e);
            closeModal();
          }}
        />

        <Dialog
          className={styles.modal}
          open={isOpen}
          onClose={closeModal}
          TransitionProps={{ onEntered }}
        >
          <Fade in={isOpen}>
            <div className={styles.paper}>
              {/* <h2 id="transition-modal-title"></h2> */}
              <p id="transition-modal-description">{t("stringPopUpMessage")}</p>


              <label htmlFor="templateUpload-another">
                <Button
                  style={{
                    minWidth: deepICRCTX.language === "en" ? "49%" : "",
                  }}
                  onClick={closeModal}
                  className={styles.styleOkButton}
                  variant="outlined" component="span">
                  <Typography
                    style={{
                      letterSpacing: deepICRCTX.language === "en" ? "1px" : "",
                      fontWeight: deepICRCTX.language === "en" ? "600" : "initial"
                    }}
                    variant="h6">{t("stringPopUpMessageOk")}</Typography>
                </Button>
              </label>
              <Button
                style={{
                  minWidth: deepICRCTX.language === "en" ? "49%" : "",
                }}
                className={styles.styleCancelButton}
                action={(actions) => cancelRefButton.current = actions}
                onClick={closeModal}
                variant="outlined" component="span">
                <Typography
                  style={{
                    letterSpacing: deepICRCTX.language === "en" ? "1px" : "",
                    fontWeight: deepICRCTX.language === "en" ? "600" : "initial"
                  }}
                  variant="h6">{t("stringPopUpMessageCancel")}</Typography>
              </Button>
            </div>
          </Fade>
        </Dialog>
      </div>
      {/* modal end */}
      {/* getTemplateJsonServer */}
      <PopupModal isOpen={isOpenC} closeModal={closeModalC} cb={responseImportLibrary === undefined ? getTemplateJsonMultiPage : getTemplateJsonServer} textBtnInfo={{ alertTitle: responseImportLibrary === undefined ? "stringTemplateServerNoDataFound" : "stringTemplateServerSuccess", positiveBtn: "stringPopUpMessageOk", negativeBtn: "stringPopUpMessageCancel" }} templateName={responseImportLibrary === undefined ? "" : responseImportLibrary.template_name} isTemplateLibrary={true} />
      <PopupModal isOpen={isOpenT} closeModal={closeModalT} cb={modifyRequest} textBtnInfo={{
        alertTitle: "stringSaveToTemplateLibraryMatchedAlert",
        positiveBtn: "stringPopUpMessageOk", negativeBtn: "stringPopUpMessageCancel"
      }} templateName={responseImportLibrary === undefined ? "" : templateName + ".json"} isTemplateLibrary={false} />
    </div>
  );
};

export default withSnackbar(OutputViewer);


