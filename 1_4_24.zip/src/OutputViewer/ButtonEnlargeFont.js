import React, { useContext } from "react";
import { useTranslation } from "react-i18next";
import { makeStyles } from "@material-ui/core";
import { withSnackbar } from "notistack";
import IconButton from "@material-ui/core/IconButton";
import createSvgIcon from "@material-ui/icons/utils/createSvgIcon";

// import resource files
import DeepICRContext from "../resources/DeepICRContext";

// Style Sheet
const useStyles = makeStyles((theme) => ({
  styleButton: {},
}));

// +A(SVG)
const IconPlusA = createSvgIcon(
  <>
    <text transform="translate(0 18) scale(0.7 0.7)">＋</text>
    <text transform="translate(10 20) scale(1 1)">A</text>
  </>,
  "Copy"
);

// [React function component]
// Enlarge Output View Font size
const ButtonEnlargeFont = (props) => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const { value } = props;

  const [t] = useTranslation(); // for Multiple language
  const styles = useStyles(); // for material ui style

  // Enlarge Font size
  const enlargeFont = (e) => {
    if (deepICRCTX.outputSw === false && deepICRCTX.documentId === "") {
      return;
    }

    if (value === 0) {
      let newFontSize = deepICRCTX.size + deepICRCTX.unit;
      if (newFontSize > deepICRCTX.maxSize) {
        props.enqueueSnackbar(t("errorMaxFontSize"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
      } else {
        setDeepICRCTX({
          ...deepICRCTX,
          size: newFontSize,
        });
      }
    } else if (value === 1) {
      setDeepICRCTX({
        ...deepICRCTX,
        originalOutputFontScale: deepICRCTX.originalOutputFontScale + 0.1,
      });
    }
  };

  return (
    <div className={styles.styleButton}>
      <IconButton onClick={enlargeFont}>
        <IconPlusA />
      </IconButton>
    </div>
  );
};

export default withSnackbar(ButtonEnlargeFont);
