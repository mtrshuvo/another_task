import React, { useState, useContext, useRef, useEffect } from "react";

import { useTranslation } from "react-i18next";
import { Button, makeStyles } from "@material-ui/core";
import DeepICRContext from "../resources/DeepICRContext";

const useStyles = makeStyles((theme) => ({
  dialogContainer: {
    width: 300,
    height: "auto",
    background: "#fff",
    position: "absolute",
    borderRadius: 2,
    padding: 12,
    top: 100,
    left: 100,
    zIndex: 999,
    textAlign: "left",
    boxSizing: "border-box",
    fontSize: 14,
    boxShadow: "0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23)",
  },
  labelTitle: {
    width: 120,
  },
  dialogBody: {
    width: "100%",
    height: 200,
  },
  userSelect: {
    outline: "none",
    border: "none",
    borderBottom: "1px solid #d1d1d1",
  },
  textArea: {
    width: "100%",
    height: 100,
    fontSize: 12,
    resize: "none",
    backgroundColor: "#EAEAF0",
    padding: 5,
    boxSizing: "border-box",
    "&::placeholder":{
      fontSize:"12px"
    }
  },
  modalAction: {
    textAlign: "right",
  },
  btnCancel: {
    // backgroundColor: "tomato",
    color: theme.palette.deepICR.modalCancelColor,
    // backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
    "&:hover": {
      color: theme.palette.deepICR.blue4
    },
    fontWeight:600,
    marginRight: 8,
  },
  btnSave: {
    // backgroundColor: theme.palette.deepICR.blue4,
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
    fontWeight:600,
    borderColor: theme.palette.deepICR.blue4,
    "&:hover": {
      color: theme.palette.deepICR.blue4
    }
  },
}));

export default function PopupDialogOutput({ label, setLabel, meta, setMeta, setShouldJsonTriggered }) {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [charCount, setCharCount] = useState(255);

  // const [label, setLabel] = useState("Blank");
  // const [meta, setMeta] = useState("");

  const [t] = useTranslation();
  const styles = useStyles();

  const metaRef = useRef(null);

  useEffect(() => {
    // setLabel(deepICRCTX.popUpDialog.label);
    setMeta(deepICRCTX.popUpDialog.meta);
  }, [deepICRCTX.popUpDialog]);



  function updateMetaData(e) {
    let str = metaRef.current.value;
    if (str.length > 255) {
      str = str.substring(0, 255);
      metaRef.current.value = str;
      setCharCount(255 - str.length);
      setMeta(str);
    } else {
      setCharCount(255 - str.length);
      setMeta(str);
    }
  }

  function handleCancel() {
    let shapeList = deepICRCTX.shapeListRight;
    if (!deepICRCTX.popUpDialog.metaModification){
      // let shape = deepICRCTX.selectedShapeRight;
      const imageId = deepICRCTX.popUpDialog.image_id;
      const shapeId = deepICRCTX.popUpDialog.shape_id;
      delete shapeList[imageId][shapeId]
    }
    
    
    // shapeList[imageId][shapeId]["image_id"] = imageId;
    // shapeList[imageId][shapeId]["shape_id"] = shapeId;

    setDeepICRCTX({
      ...deepICRCTX,
      shapeListRight: shapeList,
      // selectedShapeRight: [shapeList[imageId][shapeId]],
      selectedShapeRight:[],
      popUpDialog: {
        image_id: "",
        shape_id: "",
        label: "Cancel",
        meta: "",
        left: 0,
        top: 0,
        show: false,
        testShow: false,
        metaModification:false
      },
    });
    setCharCount(255);
  }

  function handleSave() {
    let shape_id = deepICRCTX.selectedShapeRight[0].shape_id;
    let tempPageNo = deepICRCTX.selectedShapeRight[0].image_id.split('_')
    const updatedJson = deepICRCTX.outputJson

    // let selectedpageNo =  updatedJson.original_output.pages.map((val,i)=>{
            //   // console.log({val});
            //   let pageArr =  val.id.split('_')
            //   let pagesPageNo = pageArr[pageArr.length - 1]
            //   // console.log({pagesPageNo});
            //   if(pagesPageNo === tempPageNo[tempPageNo.length - 1]){
            //     return i
            //   }
            // })
            let selectedpageNo = tempPageNo[tempPageNo.length - 1] -1
            // console.log({selectedpageNo});
            // let pageNo = deepICRCTX.file.type === 'application/pdf'?selectedpageNo.filter((val)=>{return val!== undefined})[0]:0
            let pageNo = deepICRCTX.file.type === 'application/pdf'?selectedpageNo:0
    // console.log({ pageNo });

    // end
    // let shape_id = deepICRCTX.selectedShapeRight[0].shape_id

    let region = deepICRCTX.selectedRegion.pages[pageNo]?.regions || []

    function updateMetaValue(dataArray, keyToUpdate, newMetaValue) {
      // console.log({keyToUpdate},{newMetaValue},{dataArray});
      for (let i = 0; i < dataArray.length; i++) {
        let obj = dataArray[i];
        let keyName = Object.keys(obj)[0]

        if (keyName.includes(keyToUpdate)) {
          // If it is line type 
          if(keyName.includes('line')){
              for(let i = 0;i<obj[keyName].length-1;i++){
                // console.log("data key",obj[keyName][1],Object.getOwnPropertyNames(obj[keyName][1])[0] === 'objectInfo');
                if(Object.getOwnPropertyNames(obj[keyName][i])[0] === 'objectInfo' ){
                  // console.log("Entered",obj[keyName][i]);
                  obj[keyName][i]['objectInfo'].meta = newMetaValue
                }else if(Object.getOwnPropertyNames(obj[keyName][1])[0] === 'objectInfo'){
                  // console.log("Entered else",obj[keyName][i]['objectInfo']);
                  obj[keyName][1]['objectInfo'].meta = newMetaValue
                }
              }
          }else{
            obj[keyName].meta = newMetaValue;
          }
          // console.log(obj[keyToUpdate]);
        }
      }
    }

    updateMetaValue(region, shape_id, meta)
    // setShouldJsonTriggered(true)
    if (!deepICRCTX.popUpDialog.metaModification) {
      setShouldJsonTriggered(true)
    }
    else {
      let shapes = deepICRCTX.shapeListRight;
      const imageId = deepICRCTX.popUpDialog.image_id
      const shapeId = deepICRCTX.popUpDialog.shape_id;
      shapes[imageId][shapeId]["meta"] = meta;

      setDeepICRCTX({
        ...deepICRCTX,
        popUpDialog: {
          ...deepICRCTX.popUpDialog,
          testShow: false,
          metaModification: false
        },
      });
    }
    setCharCount(255);
  }

  return (
    <>
      {deepICRCTX.popUpDialog.testShow && (
        <div
          style={{
            position: "absolute",
            zIndex: 99999,
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            background: "none",
          }}
        >
          <div
            className={styles.dialogContainer}
            style={{ left: deepICRCTX.popUpDialog.left, top: deepICRCTX.popUpDialog.top }}
          >
            <form onSubmit={() => handleSave()}>
              <table className={styles.dialogBody}>
                <tbody>
                  <tr>
                    <td className={styles.labelTitle}>{t("stringLabelId")}</td>
                    <td>:</td>
                    <td>{deepICRCTX.popUpDialog.shape_id.split("_")[1]}</td>
                  </tr>
                  {/* <tr>
                    <td className={styles.labelTitle}>{t("stringLabelType")}</td>
                    <td>:</td>
                    <td>
                      <select
                        className={styles.userSelect}
                        ref={labelRef}
                        value={label}
                        onChange={(e) => updateLabelData(e)}
                      >
                       
                        <option key={4} value="Line">
                          {t("Line")}
                        </option>
                        <option key={2} value="Table">
                          {t("stringTable")}
                        </option>
   
                      </select>
                    </td>
                  </tr> */}
                  <tr>
                    <td className={styles.labelTitle}>{t("stringMetaInfo") }</td>
                    <td>:</td>
                    <td>
                      <small >{"(" + t('stringRemainCharPrev')+ charCount + t("stringRemainChar") + ")"}</small>
                    </td>
                  </tr>
                  <tr>
                    <td colSpan={3}>
                      <textarea
                        placeholder={t('stringPopupPlaceholderText')}
                        className={styles.textArea}
                        ref={metaRef}
                        value={meta}
                        onChange={(e) => updateMetaData(e)}
                      />
                    </td>
                  </tr>
                  <tr>
                    <td colSpan={3} className={styles.modalAction}>
                      <Button onClick={(e) => handleCancel(e)} className={styles.btnCancel} variant="outlined" >
                        {t("stringCancel")}
                      </Button>
                      <Button onClick={(e) => handleSave(e)} className={styles.btnSave} variant="outlined">
                        {t("stringSave")}
                      </Button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
