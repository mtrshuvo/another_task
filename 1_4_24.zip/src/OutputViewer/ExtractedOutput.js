import React, { useContext, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  hasMultipleObjects,
  isthereAnyShape,
} from "../resources/CommonMethods";

// import react components
import DeepICRContext from "../resources/DeepICRContext";
import { makeStyles, Toolbar, FormGroup, FormControlLabel, Checkbox } from "@material-ui/core";


/************* helper function for preview data */
function getLineObjectInfo(lineData) {
  // console.log({lineData});
  let page
  for (let item of lineData) {
    if (Object.keys(item)[0] === "objectInfo") {
      const splitingPageInfo = item['objectInfo'].pageInfo.split("_");
      page = splitingPageInfo[splitingPageInfo.length - 1];

    }
  }
  return page
}

function tableHeight(data){
  let height = 0;
  let YminValFromFirstRow = Infinity;
  let YmaxValFromLastRow = -Infinity;

  // let {minCol, minRow} = findMinRowAndCol(data.cells);
  // console.log("min row", minRow);

  // let {maxRow, maxCol} = findMaxRowAndCol(data.cells);
  // console.log("max row", maxRow);

  for(let item of data.cells){
      // if(item.row_no === minRow){
      //     YminValFromFirstRow = Math.min(YminValFromFirstRow, item.y);
      // }
      // if(item.row_no === maxRow){
      //     YmaxValFromLastRow = Math.max(YmaxValFromLastRow, item.y + item.height);

      // }
          YminValFromFirstRow = Math.min(YminValFromFirstRow, item.y);
          YmaxValFromLastRow = Math.max(YmaxValFromLastRow, item.y + item.height);



  }


  height = YmaxValFromLastRow - YminValFromFirstRow;
  return height


}

// function findMinRowAndCol(data) {
//   let minRow = Infinity;
//   let minCol = Infinity;

//   data.forEach((row) => {
//     minRow = Math.min(minRow, row.row_no);
//     minCol = Math.min(minCol, row.col_no);
//   });

//   return { minRow, minCol };
// }
// function findMaxRowAndCol(data) {
//   let maxRow = -Infinity;
//   let maxCol = -Infinity;

//   data.forEach((row) => {
//       maxRow = Math.max(maxRow, row.row_no);
//       maxCol = Math.max(maxCol, row.col_no);
//   });

//   return { maxRow, maxCol };
// }
const useStyles = makeStyles((theme) => ({
  styleShape: {
    border: "1px solid #dadada",
    margin: "20px 0",
    backgroundColor: "#ffffff",
    overflowX: "auto",
  },
  styleShapeWrapper: {
    fontWeight: "bold",
    padding: "4px 10px",
    color: "#26890d",
    fontSize: "1rem",
    position: "relative",
    display: "block",
    width: "90%",
    height: "auto",
  },
  stylePage: { margin: "0 0 0 20px", width: "90%" },
  styleCheckBoxColor: {
    color: theme.palette.deepICR.blue4,
  },
  stylePageInfo: {
    margin: "0 0 0 20px",
    width: "90%",
  },
  styleToolbar: {
    paddingLeft: 0,
    paddingRight: 0,
    borderBottom: "1px solid #EAEAF0",


  },
  styleCheckUncheck: {
    margin: "0 0 0 10px",
    gap: "1rem",
    "& .MuiFormControlLabel-label": {
      fontSize: ".9rem"
    }
  }
}));

//extracte output -> preview output
const ExtractedOutput = () => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [checkChange, setCheckChange] = useState(false);
  const [shapeWithData, setShapeWithData] = useState({});
  const [check, setCheck] = useState(true);
  const [uncheck, setUncheck] = useState(false);


  // for multiple language
  const [t] = useTranslation();
  const styles = useStyles(); // for material ui style


  //check uncheck for selected object
  function shapeSelectionForExport(e, pageNumber, shapeIndex, keyName) {
    // console.log(e.currentTarget.checked, pageNumber, shapeIndex, keyName);
    const shapeListRight = deepICRCTX.shapeListRight;
    // console.log(shapeListRight);
    for (let page in shapeListRight) {
      if (shapeListRight?.page) {
        const pageArr = page.split("_")
        if (pageArr[pageArr.length - 1] === pageNumber) {
          // shapeListRight[page][]
          const shapekeyIdArr = keyName.shapekeyId.split("_")
          const shape = shapekeyIdArr[shapekeyIdArr.length - 1];
          shapeListRight[page][`sr_${shape}`]['isSelected'] = e.currentTarget.checked;

        }
        // for()

      }
    }
    setDeepICRCTX({ ...deepICRCTX, shapeListRight: shapeListRight })
    const checkTableOrLine = keyName?.shapekeyId.split("_")[0]
    if (deepICRCTX.fileSize.length === deepICRCTX.outputJson.original_output.pages.length) {
      const selecetedRegions = deepICRCTX.selectedRegion;
      const selectedRegionsPages = selecetedRegions.pages;
      // console.log(checkTableOrLine);
      if (checkTableOrLine === "t") {
        const pagesShapeIndex =
          selectedRegionsPages[pageNumber - 1].regions[shapeIndex][keyName.shapekeyId];
        pagesShapeIndex.isSelected = e.currentTarget.checked;
        setDeepICRCTX({
          ...deepICRCTX,
          selectedRegion: selecetedRegions,
          // shapeListRight: shapeListRight
        });

      } else {
        const lineObject = selectedRegionsPages[pageNumber - 1].regions[shapeIndex][keyName.shapekeyId];
        for (let i of lineObject) {
          if (Object.keys(i)[0] === "objectInfo") {
            i.objectInfo.isSelected = e.currentTarget.checked
          }
        }
        setDeepICRCTX({
          ...deepICRCTX,
          selectedRegion: selecetedRegions,
          // shapeListRight: shapeListRight
        });
      }

    }

    else {
      // console.log("same size na");
      const key = keyName.shapekeyId;
      const pageInfo = pageNumber;
      const selecetedRegions = deepICRCTX.selectedRegion;
      const selectedRegionsPages = selecetedRegions.pages;
      for (let page of selectedRegionsPages) {
        for (let region in page) {
          for (let item of page[region]) {
            if (Object.keys(item).includes(key)) {
              let targatedObject = item[key]
              if (key.split("_")[0] === "l") {
                const objectInfo = getLineObjectInfo(targatedObject);
                if (parseInt(pageInfo) === parseInt(objectInfo)) {
                  for (let info of targatedObject) {
                    if (Object.keys(info)[0] === "objectInfo") {
                      info['objectInfo'].isSelected = e.currentTarget.checked;
                    }
                  }

                }
              }
              else {
                const tablePageInfo = targatedObject.pageInfo.split("_")
                if (parseInt(pageInfo) === parseInt(tablePageInfo[tablePageInfo.length - 1])) {

                  targatedObject.isSelected = e.currentTarget.checked;

                }
              }
            }
          }
        }
      }
      // console.log(selectedRegionsPages);

      setDeepICRCTX({
        ...deepICRCTX,
        selectedRegion: selecetedRegions,
      });


    }


  }
  //format deepICRCTX.slectedregion data in page wise
  function formatDataForPreview(data) {
    let finalObject = {};
    for (let page of data) {
      for (let region in page) {
        for (let item in page[region]) {
          if (!hasMultipleObjects(page[region][item])) {
            const tableOrLine = Object.keys(page[region][item])[0];
            //for table
            if (tableOrLine.split("_")[0] === "t") {
              // console.log("from 36",page[region][item][tableOrLine]['pageInfo']);
              const splitingPageInfo = page[region][item][tableOrLine]['pageInfo']?.split("_");
              const pageInfo = deepICRCTX.pdfBase64 ? splitingPageInfo[splitingPageInfo.length - 1] : "1";
              const newData = {
                page: pageInfo,
                shapekeyId: tableOrLine,
                ...page[region][item][tableOrLine]
              }
              if (pageInfo in finalObject) {
                finalObject[pageInfo].push(newData);
                finalObject[pageInfo].sort((a, b) => parseInt(a.shapekeyId.split("_")[3]) - parseInt(b.shapekeyId.split("_")[3]))
              } else {
                finalObject[pageInfo] = [newData]

              }

            }
            //for line data 
            else {
              const pageInfo = deepICRCTX.pdfBase64 ? getLineObjectInfo(page[region][item][tableOrLine]) : "1"
              const newData = {
                page: pageInfo,
                shapekeyId: tableOrLine,
                ...page[region][item][tableOrLine]
              }
              if (pageInfo in finalObject) {
                finalObject[pageInfo].push(newData);
                finalObject[pageInfo].sort((a, b) => parseInt(a.shapekeyId.split("_")[3]) - parseInt(b.shapekeyId.split("_")[3]))
              } else {
                finalObject[pageInfo] = [newData]

              }
            }
          }
          else {
            for (let key of Object.keys(page[region][item])) {
              if (key.split("_").includes("line")) {
                const pageInfo = deepICRCTX.pdfBase64 ? getLineObjectInfo(page[region][item][key]) : "1"
                const newData = {
                  page: pageInfo,
                  shapekeyId: key,
                  ...page[region][item][key]
                }
                if (pageInfo in finalObject) {
                  finalObject[pageInfo].push(newData);
                  finalObject[pageInfo].sort((a, b) => parseInt(a.shapekeyId.split("_")[3]) - parseInt(b.shapekeyId.split("_")[3]))
                } else {
                  finalObject[pageInfo] = [newData]

                }
              }
            }
          }

        }
      }
    }

    // console.log("final object", finalObject);
    return finalObject;
  }

  //check all object
  function checkALlObject() {
    const selecetedRegions = deepICRCTX.selectedRegion.pages;
    const shapeListRight = deepICRCTX.shapeListRight;
    for (let page in shapeListRight) {
      for (let shape in shapeListRight[page]) {
        shapeListRight[page][shape]['isSelected'] = true
      }
    }

    for (let p of selecetedRegions) {

      if (p.regions) {
        for (let obj of p.regions) {
          for (let item in obj) {
            let checkLineOrTable = item.split("_")[0]
            if (checkLineOrTable === "t") {
              obj[item].isSelected = true;
            }
            if (checkLineOrTable === "l") {
              for (let i of obj[item]) {
                if (Object.keys(i)[0] === "objectInfo") {
                  i.objectInfo.isSelected = true;

                }

              }

            }
          }
        }
      }
    }

    setDeepICRCTX({
      ...deepICRCTX,
      selectedRegion: { "pages": selecetedRegions },
      shapeListRight: shapeListRight
    })

  }

  //uncheck all object
  function unCheckALlObject() {
    const selecetedRegions = deepICRCTX.selectedRegion.pages;
    const shapeListRight = deepICRCTX.shapeListRight;
    for (let page in shapeListRight) {
      for (let shape in shapeListRight[page]) {
        shapeListRight[page][shape]['isSelected'] = false
      }
    }
    for (let p of selecetedRegions) {

      if (p.regions) {
        for (let obj of p.regions) {
          for (let item in obj) {
            let checkLineOrTable = item.split("_")[0]
            if (checkLineOrTable === "t") {
              obj[item].isSelected = false;
            }
            if (checkLineOrTable === "l") {
              for (let i of obj[item]) {
                if (Object.keys(i)[0] === "objectInfo") {
                  i.objectInfo.isSelected = false;

                }

              }

            }
          }
        }
      }
    }

    setDeepICRCTX({
      ...deepICRCTX,
      selectedRegion: { "pages": selecetedRegions },
      shapeListRight: shapeListRight
    })
  }


  // checking all sellected or all unsleected
  function isAllChecked() {
    let isAllCheck = true;
    let isAllUnCheck = true;

    const selecetedRegions = deepICRCTX.selectedRegion.pages;

    for (let p of selecetedRegions) {
      if (p.regions) {
        for (let obj of p.regions) {
          if (!hasMultipleObjects(obj)) {
            for (let item in obj) {
              if (item.split("_")[0] === "t") {
                if (obj[item].isSelected === false) {
                  isAllCheck = false;
                  break;
                }
              } else {
                for (let i of obj[item]) {
                  if (Object.keys(i)[0] === "objectInfo" && i['objectInfo'].isSelected === false) {
                    isAllCheck = false;
                    break;
                  }
                }

              }
            }

          } else {
            // console.log("obj", obj)
            // if line contains select line
            for (let key of Object.keys(obj)) {
              if (key.split("_").includes("line")) {
                for (let i of obj[key]) {
                  if (Object.keys(i)[0] === "objectInfo" && i['objectInfo'].isSelected === false) {
                    isAllCheck = false;
                    break;
                  }
                }
              }
            }

          }
        }
      }
    }


    for (let p of selecetedRegions) {
      if (p.regions) {
        for (let obj of p.regions) {
          if (!hasMultipleObjects(obj)) {
            for (let item in obj) {
              if (item.split("_")[0] === "t") {
                if (obj[item].isSelected === true) {
                  isAllUnCheck = false;
                  break;
                }
              } else {
                for (let i of obj[item]) {
                  if (Object.keys(i)[0] === "objectInfo" && i['objectInfo'].isSelected === true) {
                    isAllUnCheck = false;
                    break;
                  }
                }

              }
            }

          } else {
            // console.log("obj", obj)
            // if line contains select line
            for (let key of Object.keys(obj)) {
              if (key.split("_").includes("line")) {
                for (let i of obj[key]) {
                  if (Object.keys(i)[0] === "objectInfo" && i['objectInfo'].isSelected === true) {
                    isAllUnCheck = false;
                    break;
                  }
                }
              }
            }

          }
        }
      }
    }

    setCheck(isAllCheck);
    setUncheck(isAllUnCheck);
  }



  //findining line  data stating postion
  function findTextCordination(data) {
    let [x, y] = [Infinity, Infinity];
    let yMax = -Infinity;
    let textData = [];
    let meta = "";
    let isSelected;
    for (let lineData in data) {
      if (typeof data[lineData] === "object") {
        for (let individualLine in data[lineData]) {
          if (individualLine !== "objectInfo") {

            textData.push(data[lineData][individualLine])
            x = Math.min(x, data[lineData][individualLine].x);
            y = Math.min(y, data[lineData][individualLine].y);
            yMax = Math.max(yMax, data[lineData][individualLine].y)
          }
          if (individualLine === "objectInfo") {
            meta = data[lineData][individualLine].meta
            isSelected = data[lineData][individualLine].isSelected

          }
        }
      }
    }
    return [x, y, textData, yMax - y, meta, isSelected]
  }
  //finding table cell min value of x, y cordination
  function tableCellCordination(data) {
    let [xMin, yMin] = [Infinity, Infinity];

    for (let cell of data.cells) {
      xMin = Math.min(xMin, cell.x)
      yMin = Math.min(yMin, cell.y)
    }
    return [xMin, yMin]
  }



  // useEffect(() => {
  //   // isAllChecked();
  //   let promiseFunc = new Promise(function (resolve, reject) {
  //     resolve(setShapeWithData(formatDataForPreview(deepICRCTX.selectedRegion.pages))
  //     )
  // })

  // promiseFunc.then(() => {
  //     isAllChecked()
  // })
  // }, [ deepICRCTX]);
  useEffect(() => {
    setShapeWithData(formatDataForPreview(deepICRCTX.selectedRegion.pages));
    isAllChecked();
  }, [deepICRCTX])

  useEffect(() => {
    if (deepICRCTX.outputTab === 2) {
      document.getElementById("previewOutputDiv")?.scrollTo({
        top: 0,
        left: 0,
        behavior: "auto"
      })

    }
  }, [])

  //chanking overfollow
  // console.log("selection output", selectionOutput);
  if (deepICRCTX.outputSw === false && deepICRCTX.documentId === "") {
    return <div style={{ fontSize: `${deepICRCTX.size}px` }} />;
  }
  let pageNumber = 1;
  if (deepICRCTX.file.type === "application/pdf") {
    pageNumber = deepICRCTX.pdfPage;
  }

  let ratio = deepICRCTX.imageScale;
  let width = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
  let height = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

  if (pageNumber in deepICRCTX.originalOutputData.data) {
    ratio = (width * deepICRCTX.imageScale) / deepICRCTX.originalOutputData.data[pageNumber].width;
  }

  global.inputViewerWidth = width;
  global.inputViewerHeight = height;
  let fontsize =
    72 * deepICRCTX.imageScale * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale;
  if (fontsize > 20) fontsize = 20;
  if (!isthereAnyShape(deepICRCTX.selectedRegion))
    return (
      <div style={{ fontSize: fontsize + 10, margin: "auto" }}>{t("stringNoDataToPreview")}</div>
    );

  return (
    <div
      key={deepICRCTX.isImage}
      data-status={checkChange}
      id={"previewOutputDiv"}
      style={{
        width: deepICRCTX.inputViewerBounds.bounds.width,
        height: deepICRCTX.inputViewerBounds.bounds.height,
        overflow: "auto",
        backgroundColor: "#F8F8F8",
      }}
      data-change={checkChange}
    >
      <Toolbar style={{ paddingLeft: 0, paddingRight: 0, borderBottom: "1px solid #EAEAF0", backgroundColor: "#fff", }}>
        <div style={{ flexGrow: 1, position: "fixed", zIndex: 99, width: "49.6%", background: "#fff", minHeight: "40px", border: "1px solid #EAEAF0" }}>
          <FormGroup className={styles.styleCheckUncheck} row>
            <FormControlLabel
              control={<Checkbox checked={check} onClick={checkALlObject} name="checkedA" />}
              label={t("stringSelectAll")}
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={uncheck}
                  onChange={unCheckALlObject}
                  name="checkedB"
                />
              }
              label={t("stringUnSelectAll")}
            />
          </FormGroup>
        </div>

      </Toolbar>
      <div
        id={"previewOutputViewer"}
        style={{
          position: "relative",
          width: deepICRCTX.inputViewerBounds.bounds.width - 50,
          minHeight: height * deepICRCTX.imageScale,
          marginLeft: "10px",
        }}
      >



        {isthereAnyShape(deepICRCTX.selectedRegion) > 0 ? (
          <>
            {Object.keys(shapeWithData).map((page, pi) => {
              if (shapeWithData[page].length) {
                return (
                  <div key={pi} className={styles.styleShape}  >
                    <div className={styles.styleShapeWrapper}></div>
                    <p className={styles.stylePageInfo}>
                      {t("stringPage")} {page}
                    </p>
                    <hr style={{ width: "95%", }} />

                    {shapeWithData[page]?.map((shape, si) => {
                      let lineSx, lineSy;
                      let textData = [];
                      let diff = 0
                      let meta
                      let isSelected
                      let xMin, yMin
                      if (shape.type !== "Table") {
                        [lineSx, lineSy, textData, diff, meta, isSelected,] = findTextCordination(shape)

                      }
                      else {
                        [xMin, yMin] = tableCellCordination(shape);

                      }
                      return shape.type === "Table" ? (
                        <div
                          id={`preview_${shape.page}_${shape?.shapekeyId}`}
                          className="preview_tab_objects"
                          key={si}
                        >
                          <div
                            style={{
                              fontWeight: "bold",
                              padding: "4px 10px",
                              fontSize: fontsize,
                              position: "relative",
                              display: "block",
                              width: "90%",
                              height: "auto",
                              overflow: "auto",
                            }}
                          >
                            <span>
                              <Checkbox
                                onChange={(e) => { shapeSelectionForExport(e, page, si, shape); }}
                                type="checkbox"
                                checked={shape?.isSelected}

                              />
                            </span>
                            {shape.shapekeyId.split("_")[3]}. {shape?.meta}{" "}
                          </div>

                          <div
                            data_height={shape.cells.reduce(
                              (acc, currentVal, currentInd, allCells) =>
                              (acc +=
                                currentVal?.row_no !== allCells[currentInd - 1]?.row_no
                                  ? currentVal?.height
                                  : 0),
                              0
                            ) * ratio}
                            style={{
                              display: "block",
                              position: "relative",
                              marginTop: "10px",
                              marginLeft: "20px",
                              height:
                              10 + 100 * ratio +
                               // shape.cells.reduce(
                               //   (acc, currentVal, currentInd, allCells) =>
                               //   (acc +=
                               //     currentVal?.row_no !== allCells[currentInd - 1]?.row_no
                               //       ? currentVal?.height
                               //       : 0),
                               //   0
                               // )
                               tableHeight(shape)
                               *
                               ratio +
                               "px",
                            }}
                          >
                            {shape?.cells?.map((c, i, all) => {
                              return (
                                <div
                                  id={`${c.row_no}-${c.col_no}`}
                                  style={{
                                    position: "absolute",
                                    border: "1px solid black",
                                    left: (c.x - xMin) * ratio,
                                    top: (c.y - yMin) * ratio,
                                    width: c.width * ratio,
                                    height: c.height * ratio,
                                  }}
                                ></div>
                              );
                            })}
                            {shape.cells?.map((c) => {
                              return c.cell.map((l) => {
                                return (
                                  <div
                                    style={{
                                      position: "absolute",
                                      left: l.x * ratio - xMin * ratio,
                                      top: l.y * ratio - yMin * ratio,
                                      width: l.width * ratio,
                                      height: l.height * ratio,
                                      fontSize:
                                        l.height *
                                        ratio *
                                        deepICRCTX.originalOutputFontScale *
                                        deepICRCTX.fontScale,
                                      whiteSpace: "nowrap",

                                    }}
                                  >
                                    {l.words.map((w) => w.text).join(" ")}
                                  </div>
                                );
                              });
                            })}
                          </div>
                        </div>
                      ) :

                        (
                          /**************************************************************************** */
                          // line objects data population on preview tab
                          /**************************************************************************** */
                          <div
                            id={`preview_${shape.page}_${shape?.shapekeyId}_line`}
                            className="preview_tab_objects"
                            key={si}

                          >
                            <div
                              style={{
                                fontWeight: "bold",
                                padding: "4px 10px",
                                fontSize: fontsize,
                                position: "relative",
                                display: "block",
                                width: "90%",
                                height: "auto",
                                overflow: "auto",
                              }}
                            >
                              <span>
                                <Checkbox
                                  onChange={(e) => { shapeSelectionForExport(e, page, si, shape); }}
                                  type="checkbox"
                                  checked={isSelected}

                                />
                              </span>
                              {shape.shapekeyId.split("_")[3]}. {meta}{" "}
                            </div>



                            <div
                              style={{
                                display: "block",
                                position: "relative",
                                marginTop: "10px",
                                marginLeft: "20px",
                                height: (diff < 0) ? 10 * ratio : (diff + 100) * ratio + "px"
                              }}

                            >
                              {textData?.map((vt) => (

                                <div
                                  style={{
                                    position: "absolute",
                                    left: Math.abs(vt.x * ratio - lineSx * ratio),
                                    top: Math.abs(vt.y * ratio - lineSy * ratio),
                                    width: vt.width * ratio,
                                    height: vt.height * ratio,
                                    fontSize: vt.height * ratio * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale,
                                    whiteSpace: "nowrap",

                                  }}

                                >
                                  {vt?.text}

                                </div>
                              ))}

                            </div>

                          </div>

                        );
                    })}
                  </div>
                );
              } else return "";
            })}
          </>
        ) : (
          ""
        )}
      </div>
    </div>
  );
};

export default ExtractedOutput;
