import React, { useContext } from "react";
import { makeStyles } from "@material-ui/core";
import IconButton from "@material-ui/core/IconButton";
import createSvgIcon from "@material-ui/icons/utils/createSvgIcon";

// import resource files
import DeepICRContext from "../resources/DeepICRContext";

// Style Sheet
const useStyles = makeStyles((theme) => ({
  styleButton: {},
}));

// =A(SVG)
const IconEqualA = createSvgIcon(
  <>
    <text transform="translate(0 18) scale(0.7 0.7)">=</text>
    <text transform="translate(10 20) scale(1 1)">A</text>
  </>,
  "Copy"
);

// [React function component]
// Reset Output View Font size
const ButtonResetFont = (props) => {
  const styles = useStyles();
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const { value } = props;

  // Reset Font size
  const resetFont = (e) => {
    if (deepICRCTX.outputSw === false && deepICRCTX.documentId === "") {
      return;
    }

    if (value === 0) {
      setDeepICRCTX({
        ...deepICRCTX,
        size: deepICRCTX.defaultSize,
      });
    } else if (value === 1) {
      setDeepICRCTX({
        ...deepICRCTX,
        originalOutputFontScale: 1,
      });
    }
  };

  return (
    <div className={styles.styleButton}>
      <IconButton onClick={resetFont}>
        <IconEqualA />
      </IconButton>
    </div>
  );
};

export default ButtonResetFont;
