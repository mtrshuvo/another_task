import React, { useContext, useEffect, useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { objectSize, deepCopy, cropImage, GetPointsFromShape } from '../resources/CommonMethods';
import { makeStyles } from '@material-ui/core';
import { withSnackbar, useSnackbar } from "notistack";
// import react components
import DeepICRContext from '../resources/DeepICRContext';
import PopupDialogOutput from './PopupDialogOutput';
import { useLocation } from 'react-router-dom';
// Making stylesheet
const useStyles = makeStyles(theme => ({
    handle: {
        stroke: "#DA291C",
        strokeWidth: "1",
        fill: "#fff",
        cursor: "crosshair",
    },
    rect: {
        stroke: "#ED8B00",
        strokeWidth: "2",
        // fill: "transparent",
        cursor: "default",
        fill: "#ff00660f",
        "&:hover": {
            cursor: "pointer",
            // fill: ""
            stroke: "#DA291C",
            "& + $text": {
                display: "none !important"
            }
        }

    },
    rectBlock: {
        stroke: "#ED8B00",
        strokeWidth: "2",
        // fill: "transparent",
        cursor: "default",
        fill: "#ff00660f",
        "&:hover": {
            cursor: "pointer",
            // fill: ""
            stroke: "#DA291C",
            // "& + $text": {
            //     display: "none !important"
            // }
        }

    },
    ellipse: {
        stroke: "#f06",
        strokeWidth: "2",
        // fill: "transparent",
        fill: "#ff00660f",
    },
    polygon: {
        stroke: "#f06",
        strokeWidth: "2",
        // fill: "transparent",
        fill: "#ff00660f",
    },
    circle: {
        stroke: "orange",
        strokeWidth: "1",
        fill: "orange",
    },
}));


// let isSwitch = false
// [React function component]
// Original output component
const CroppingOutput = (props) => {

    const { enqueueSnackbar } = useSnackbar()
    const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
    const [selectionOutput, setSelectionOutput] = useState({});
    const [checkChange, setCheckChange] = useState(false);
    const [cropImages, setCropImages] = useState({});

    const [isStart, setIsStart] = useState(false);
    const [isHandle, setIsHandle] = useState(false);
    const [isSelected, setIsSelected] = useState(false);
    const [handleId, setHandleId] = useState();
    const [startX, setStartX] = useState(0);
    const [startY, setStartY] = useState(0);
    const [clickX, setClickX] = useState(0);
    const [clickY, setClickY] = useState(0);
    const [prevPosX, setPrevPosX] = useState(0);
    const [prevPosY, setPrevPosY] = useState(0);
    const [currentTarget, setCurrentTarget] = useState(null);
    const [startPoint, setStartPoint] = useState({ x: 0, y: 0 })
    const [endPoint, setEndPoint] = useState({ x: "", y: "" })
    const [characterWidths, setCharacterWidths] = useState([]);
    const [tempText, setTempText] = useState([])
    const [isTriggerredCharacterSegmentation, setIsTriggerredCharacterSegmentation] = useState(true)

    // const [label, setLabel] = useState("line");
    const [meta, setMeta] = useState("");
    const [shouldJsonTriggered, setShouldJsonTriggered] = useState(false)


    let height = props.height;
    let width = props.width;
    let image_id = props.imageIndex;
    let isSwitch = props.isSwitch
    let page_index = "p_" + width + "_" + height + "_" + (image_id + 1);


    const location = useLocation();
    // console.log({ location });

    // for multiple language
    const [t] = useTranslation();
    const svgRef = useRef();
    const timerRef = useRef(null);

    function formatOutputJson() {
        let isSel = false;
        if (objectSize(deepICRCTX.originalOutputData.data) > 0) {

            for (let i in deepICRCTX.originalOutputData.data) {
                let textData = deepICRCTX.originalOutputData.data[i].data;
                let tableData = deepICRCTX.originalOutputTable.data[i].data;
                let selOutput = {};

                for (let ti in textData) {
                    let td = textData[ti];
                    if ("shape_id" in td && td["shape_id"] !== undefined) {
                        let shape_id = td["shape_id"];
                        if (td.type === "Image") {
                            let key = td.key;

                            if (key in deepICRCTX.croppedImages) {
                                let shape_info = deepICRCTX.croppedImages[key];
                                let page_number = key.split("-")[0];
                                let image = deepICRCTX.fileBase64[page_number];

                                cropImage(image, shape_info).then(dataUrl => {
                                    let temp = cropImages;
                                    temp[key] = dataUrl;
                                    setCropImages({ ...cropImages, temp });
                                    deepICRCTX.croppedImages[key]["data"] = dataUrl;
                                }).catch(error => {
                                    // Error: Can not crop shape from image
                                    if (deepICRCTX.debug === true) console.error(error)
                                })

                                // cropImageFromCanvas(image, shape_info, function (dataUrl) {
                                //   let temp = cropImages;
                                //   temp[key] = dataUrl;
                                //   setCropImages({ ...cropImages, temp });
                                //   deepICRCTX.croppedImages[key]["data"] = dataUrl;
                                // });
                            }
                        }
                        if (shape_id in selOutput && "text" in selOutput[shape_id]) {
                            selOutput[shape_id].text.push(td);
                        }
                        else if (shape_id in selOutput && !("text" in selOutput[shape_id])) {
                            selOutput[shape_id]["text"] = [td];
                        }
                        else {
                            selOutput[shape_id] = {};
                            selOutput[shape_id]["text"] = [td];
                        }

                        isSel = true;
                    }
                }

                for (let tj in tableData) {
                    let td = tableData[tj];
                    if ("shape_id" in td && td["shape_id"] !== undefined) {
                        let shape_id = td["shape_id"];
                        if (shape_id in selOutput && "cell" in selOutput[shape_id]) {
                            selOutput[shape_id].cell.push(td);
                        }
                        else if (shape_id in selOutput && !("cell" in selOutput[shape_id])) {
                            selOutput[shape_id]["cell"] = [td];
                        }
                        else {
                            selOutput[shape_id] = {};
                            selOutput[shape_id]["cell"] = [td];
                        }
                        isSel = true;
                    }
                }
                if (isSel === true) {
                    for (let key in selOutput) {
                        let selection = selOutput[key];
                        let x = Infinity, y = Infinity, w = -Infinity, h = -Infinity;
                        let meta = "";
                        if ("text" in selection) {
                            let texts = selection['text'];
                            for (let i = 0; i < texts.length; i++) {
                                if (x > texts[i].x) x = texts[i].x;
                                if (w < (texts[i].x + texts[i].width)) w = texts[i].x + texts[i].width;
                                if (y > texts[i].y) y = texts[i].y;
                                if (h < (texts[i].y + texts[i].height)) h = texts[i].y + texts[i].height;
                                meta = texts[i].meta;
                            }
                        }
                        if ("cell" in selection) {
                            let cells = selection["cell"];
                            for (let i = 0; i < cells.length; i++) {
                                if (x > cells[i].x) x = cells[i].x;
                                if (w < (cells[i].x + cells[i].width)) w = cells[i].x + cells[i].width;
                                if (y > cells[i].y) y = cells[i].y;
                                if (h < (cells[i].y + cells[i].height)) h = cells[i].y + cells[i].height;
                                meta = cells[i].meta;
                            }
                        }
                        selOutput[key]['x'] = x;
                        selOutput[key]['y'] = y;
                        selOutput[key]['width'] = w - x;
                        selOutput[key]['height'] = h - y;
                        selOutput[key]['height'] = h - y;
                        selOutput[key]['meta'] = meta;
                    }
                    var sortable = [];
                    for (var shape_id in selOutput) {
                        sortable.push([shape_id, selOutput[shape_id]]);
                    }

                    sortable.sort(function (a, b) {
                        return a[0].split("_")[1] - b[0].split("_")[1];
                    });

                    var output = {};
                    for (var x = 0; x < sortable.length; x++) {
                        output["" + sortable[x][0]] = deepCopy(sortable[x][1]);
                    }
                    selectionOutput[i] = output;
                }
            }
        }
        if (isSel) {
            setSelectionOutput(selectionOutput);
            setDeepICRCTX({
                ...deepICRCTX,
                isSelection: true,
            })
        }
        else {
            setDeepICRCTX({
                ...deepICRCTX,
                isSelection: false,
            })
        }
        setCheckChange(!checkChange);
    }

    function handleMouseClick(e) {
        e.persist();
        // e.preventDefault();
        // console.log("Clicked click");
        // console.log("e check", e.target.tagName);
        // For Single Click
        if (e.detail === 1) {
            // console.log("e datails", e.detail);
            const timer = setTimeout(() => {
                if (deepICRCTX.selectedButton === true) {
                    // console.log("check target",e.target);
                    if (e.target.tagName === "rect" || e.target.tagName === "ellipse" || e.target.tagName === "polygon") {
                        let shape_index = e.target.getAttribute("id");
                        if (shape_index) {
                            if (shape_index.split(",").length === 3) {
                                shape_index = shape_index.split(",")[2];
                            }

                            let shape = deepICRCTX.shapeListRight[page_index][shape_index];
                            shape['image_id'] = page_index;
                            shape['shape_id'] = shape_index;

                            // let shapes = orderShapeSelectionLayer(deepICRCTX.shapeListRight, page_index, shape_index);
                            setDeepICRCTX({
                                ...deepICRCTX,
                                // shapeListRight: shapes,
                                selectedShapeRight: [shape],
                            });
                        }
                    }
                    else {
                        setDeepICRCTX({
                            ...deepICRCTX,
                            selectedShapeRight: [],
                        });
                    }
                }
            }, 300);
            timerRef.current = timer;
        }
        // For double click
        else if (e.detail === 2) {
            clearTimeout(timerRef.current);
            let x = e.nativeEvent.offsetX / deepICRCTX.imageScale;
            let y = e.nativeEvent.offsetY / deepICRCTX.imageScale;
            let wx = e.nativeEvent.clientX;
            let wy = e.nativeEvent.clientY;

            let shape = deepICRCTX.selectedShapeRight;

            let image_id = "";
            let shape_id = "";

            let points = [];

            let epx = 9999; // Extreame x point 
            let intersectCounter = 0;


            if ((shape !== null || shape !== undefined) && shape.length > 0) {
                image_id = shape[0]['image_id'];
                shape_id = shape[0]['shape_id'];

                let label = shape[0]['label'];
                let selectedMeta = shape[0]['meta'];


                points = GetPointsFromShape(deepICRCTX, shape[0]);

                if (shape[0].type === "rect") {
                    let inside = false;
                    for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
                        let xi = points[i][0], yi = points[i][1];
                        let xj = points[j][0], yj = points[j][1];

                        let intersect = ((yi > y) !== (yj > y))
                            && (x < (xj - xi) * (y - yi) / (yj - yi) + xi);
                        if (intersect) inside = !inside;
                    }
                    if (inside === true) {
                        // if (wy + 240 > window.innerHeight) {
                        //     wy = wy - 240;
                        // }

                        if (wy + 240 > window.innerHeight) {
                            wy = wy - 440;
                        }
                        if (wx + 240 > window.innerWidth) {
                            wx = wx - 284;
                        }

                        // let region = deepICRCTX.selectedRegion.pages[deepICRCTX.pdfPage - 1].regions

                        // function updateMetaValue(dataArray, keyToUpdate, newMetaValue) {
                        //     for (let i = 0; i < dataArray.length; i++) {
                        //         const obj = dataArray[i];

                        //         if (Object.keys(obj)[0].includes(keyToUpdate)) {
                        //             obj[Object.keys(obj)[0]].meta = newMetaValue;
                        //             console.log(obj[keyToUpdate]);
                        //         }
                        //     }
                        // }

                        // updateMetaValue(region, shape_id, meta)

                        setDeepICRCTX({
                            ...deepICRCTX,
                            popUpDialog: {
                                image_id: image_id,
                                shape_id: shape_id,
                                label: label,
                                meta: selectedMeta,
                                left: wx,
                                top: wy,
                                testShow: true,
                                metaModification: true
                            },
                        });
                    }
                    else {
                        setDeepICRCTX({
                            ...deepICRCTX,
                            selectedShapeRight: [],
                            popUpDialog: {
                                image_id: "",
                                shape_id: "",
                                label: "",
                                meta: "",
                                left: 0,
                                top: 0,
                                testShow: false,
                                metaModification: true
                            },
                        });
                    }
                }
            }

        }
    }

    function handleMouseDown(e) {
        // setLabel('Line')
        // e.stopImmediatePropagation()
        // e.persist()
        // setTimeout(() => {
        // e.preventDefault();
        // console.log("Clicked Down");
        const svg = document.getElementById('mySVG');
        const svgRect = svg.getBoundingClientRect();
        const divRect = e.target.getBoundingClientRect();

        // console.log("Svg Rect", svgRect, "divRect", divRect, "ClientX", e.clientX, "clientY", e.clientY);
        const x = (e.clientX - svgRect.left) - 1;
        const y = (e.clientY - svgRect.top) - 1;
        // setStartPoint({ x: e.nativeEvent.offsetX, y: e.nativeEvent.offsetY })
        setStartPoint({ x: x, y: y })
        // console.log("Handle Mouse Down Test Output Component x ,y: ", e.nativeEvent.offsetX, e.nativeEvent.offsetY, "Calculated x,y", x, y);
        // e.preventDefault();
        if (isStart === false) {
            setIsStart(true);
            // setStartX(e.nativeEvent.offsetX);
            // setStartY(e.nativeEvent.offsetY);
            setStartX(x);
            setStartY(y);

            let shp_id = "";
            let shape = deepICRCTX.selectedShapeRight;
            // console.log("shape check", shape,e.target.tagName);
            if ((shape !== null || shape !== undefined) && shape.length > 0) {
                // console.log("entered");
                shp_id = shape[0]['shape_id'];
            }

            if (e.target.tagName === "rect" && e.target.getAttribute('data-id') === "handle") {

                let shape_id = e.target.getAttribute("id").split(",")[0];
                let index = shape_id.split("_")[1];
                setIsHandle(true);
                setHandleId(index);
                setStartX(e.nativeEvent.offsetX);
                setStartY(e.nativeEvent.offsetY);
            }
            else if (deepICRCTX.croppingToolId !== 1 && e.target.getAttribute("id") === shp_id && (e.target.tagName === 'rect' || e.target.tagName === 'ellipse' || e.target.tagName === 'polygon')) {
                setIsSelected(true);
                setPrevPosX(e.nativeEvent.offsetX);
                setPrevPosY(e.nativeEvent.offsetY);
                e.target.style.cursor = 'grab';
                setCurrentTarget(e.target);
                // currentTarget.style.cursor = "grab";
            }
            else if (isSelected === true && deepICRCTX.croppingToolId === 3) {
                // console.log("entered");
                document.getElementById('mySVG').style.cursor = 'default';
                setDeepICRCTX({
                    ...deepICRCTX,
                    currentShapeRight: [{ type: "rect", x: e.clientX, y: e.clientY, width: 0, height: 0 }],
                });

            }
            else if (deepICRCTX.croppingToolId === 4) {
                document.getElementById('mySVG').style.cursor = 'default';
                setDeepICRCTX({
                    ...deepICRCTX,
                    currentShapeRight: [{ type: "ellipse", cx: startX, cy: startY, rx: 0, ry: 0 }],
                });
            } else {
                // console.log("Inner else");
            }
        } else {
            // console.log("Outer else");
        }
        // }, 100);
    }

    const SelectedShape = () => {
        const [deepICRCTX] = useContext(DeepICRContext);
        const styles = useStyles();

        let items = [];
        let padding = 3;
        let distance = 6;
        let shape = deepICRCTX.selectedShapeRight;

        let image_id = "";
        let shape_id = "";
        let points = [];

        if ((shape !== null || shape !== undefined) && shape.length > 0) {

            image_id = shape[0]['image_id'];
            shape_id = shape[0]['shape_id'];
            points = GetPointsFromShape(deepICRCTX, shape[0]);
        }

        for (var p = 0; p < points.length; p++) {
            let x = parseInt(points[p][0] * deepICRCTX.imageScale);
            let y = parseInt(points[p][1] * deepICRCTX.imageScale);
            items.push(<rect data-id="handle" key={"sp_" + p} id={"sp_" + p + "," + image_id + "," + shape_id} x={x - padding} y={y - padding} width={distance} height={distance} className={styles.handle} />)
        }

        return items;
    }

    const AllShapes = (props) => {
        const styles = useStyles();
        const [deepICRCTX] = useContext(DeepICRContext);
        const [t] = useTranslation();

        let shapes = []
        const items = [];

        let fontsize = 72 * deepICRCTX.imageScale * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale;
        if (fontsize > 20) fontsize = 20;

        let page_index = "p_" + props.width + "_" + props.height + "_" + (props.imageIndex + 1);

        if (deepICRCTX.shapeListRight !== undefined && page_index in deepICRCTX.shapeListRight) {
            shapes = deepICRCTX.shapeListRight[page_index];
        }

        for (const key in shapes) {
            let item = shapes[key];
            let label = " " + key.split("_")[1] + ". ";

            if ("label" in item && item.label !== undefined && item.label !== "") {
                // console.log("item label", item.label);
                if (item.label === "Blank") { label += t("") }
                else if (item.label === "Line") { label += t("stringLine") }
                else if (item.label === "Multi Line") { label += t("stringMultiline") }
                else if (item.label === "Table") { label += t("stringTable") }
            }

            if ("meta" in item && item.meta !== undefined && item.meta !== "") {
                label += " : " + item.meta;
            }

            if (label.length > 50) {
                label = label.substr(0, 50) + "...";
            }

            if (item.type === 'rect') {
                let x = parseInt(item.x * deepICRCTX.imageScale);
                let y = parseInt(item.y * deepICRCTX.imageScale);
                let w = parseInt(item.width * deepICRCTX.imageScale);
                let h = parseInt(item.height * deepICRCTX.imageScale);
                // deepICRCTX?.selectedShapeRight[0]?.shape_id === key?styles.rectBlock:
                items.push(<rect key={key} id={key} x={x} y={y} width={w} height={h} className={styles.rect} style={{
                    stroke: deepICRCTX?.selectedShapeRight[0]?.shape_id === key ? "#ED8B00" : "#3B9424"
                }} />)
                // console.log("items", items);
                if (y < fontsize)
                    items.push(<text key={"t" + key}
                        filter={deepICRCTX?.selectedShapeRight[0]?.shape_id === key ? "url(#orange)" : "url(#solid)"}

                        x={x} y={fontsize} textAnchor="start" fill="white" fontSize={fontsize}

                    >{label}</text>)
                else
                    items.push(<text key={"t" + key}
                        filter={deepICRCTX?.selectedShapeRight[0]?.shape_id === key ? "url(#orange)" : "url(#solid)"}
                        style={{
                            backgroundColor: deepICRCTX?.selectedShapeRight[0]?.shape_id === key ? '#ED8B00' : "#3B9424",
                        }}
                        className={key}
                        x={x} y={y - 4} textAnchor="start" fill="white" fontSize={fontsize}>{label}</text>)
            }

        }
        return items;
    }

    const CurrentShape = (props) => {
        const [deepICRCTX] = useContext(DeepICRContext);
        let shapes = deepICRCTX.currentShapeRight;
        let items = [];

        const styles = useStyles();

        let i = 0;

        for (let shape in shapes) {
            let item = shapes[shape];
            // console.log("crop",item);
            if (item.type === 'rect') {
                let x = parseInt(item.x);
                let y = parseInt(item.y);
                let w = parseInt(item.width);
                let h = parseInt(item.height);
                items.push(<rect key={i} x={x} y={y} width={w} height={h} className={`${styles.rect} rect_selected`} />);
            }

            i++;
        }
        return items;
    }

    function moveShape(direction) {
        let shapes = deepICRCTX.selectedShapeRight;
        // console.log("Shapes", shapes);
        let wh = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
        let ht = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

        for (let s in shapes) {
            let shape = shapes[s];
            let shp_type = shape.type;
            if (shp_type === "rect") {
                if (parseInt(shapes[s].x + direction[1]) >= 0 && parseInt(shapes[s].x + direction[1] + shapes[s].width) < wh) {
                    shapes[s].x = parseInt(shapes[s].x + direction[1]);
                }
                if (parseInt(shapes[s].y + direction[0]) >= 0 && parseInt(shapes[s].y + direction[0] + shapes[s].height) < ht) {
                    shapes[s].y = parseInt(shapes[s].y + direction[0]);
                }
            }
        }
        setDeepICRCTX({
            ...deepICRCTX,
            selectedShapeRight: shapes,
        })
    }
    //  console.log("Bounder top", deepICRCTX.inputViewerBounds.bounds.top);
    function handleMouseMove(e) {
        // console.log("Mouse Moved");
        // console.log("mouse move call",e.target);
        e.stopPropagation();
        // if (deepICRCTX.croppingToolId === 2 && deepICRCTX.currentShapeRight.length > 0) {
        //     let endX = parseInt(e.nativeEvent.offsetX);
        //     let endY = parseInt(e.nativeEvent.offsetY);
        //     let points = "";

        //     if (deepICRCTX.currentShapeRight.length > 0) {
        //         points = deepICRCTX.currentShapeRight[0].points;
        //     }
        //     setDeepICRCTX({
        //         ...deepICRCTX,
        //         selectedShapeRight: [],
        //         currentShapeRight: [{ type: "polygon", points: points, handle: endX + "," + endY }],
        //     });

        // }
        if (isStart === true && isHandle === true) {

            const svgRect = svgRef.current.getBoundingClientRect();

            let endX = e.clientX - svgRect.left;
            // parseInt(e.nativeEvent.offsetX);
            let endY = e.clientY - svgRect.top;
            // parseInt(e.nativeEvent.offsetY);

            // console.log({endX},":",{endY});

            let shapeList = deepICRCTX.shapeListRight;
            let shape = deepICRCTX.selectedShapeRight;

            let points = GetPointsFromShape(deepICRCTX, shape[0]);
            points[handleId] = [parseInt(endX / deepICRCTX.imageScale), parseInt(endY / deepICRCTX.imageScale)];

            let image_id = shape[0]['image_id'];
            let shape_id = shape[0]['shape_id'];

            if (shape[0]['type'] === "rect") {
                let selectedRect = document.getElementById(shape[0]['shape_id'])
                let rectHeight = parseFloat(getComputedStyle(selectedRect)?.height)
                let rectWidth = parseFloat(getComputedStyle(selectedRect)?.width)
                if (handleId !== null) {
                    // console.log("Mouse Moved",handleId);
                    if (handleId === "0") {
                        points[3][0] = parseInt(endX / deepICRCTX.imageScale);
                        points[1][1] = parseInt(endY / deepICRCTX.imageScale);
                        // console.log("Selected Rect", selectedRect);
                        let drawBoxX1 = endX
                        let drawBoxY1 = endY
                        let drawBoxX2 = drawBoxX1 + rectWidth
                        let drawBoxY2 = drawBoxY1 + rectHeight
                        // updatedDataExtraction(drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2, shape[0]['shape_id'])
                    }
                    else if (handleId === "1") {
                        points[2][0] = parseInt(endX / deepICRCTX.imageScale);
                        points[0][1] = parseInt(endY / deepICRCTX.imageScale);
                        let drawBoxX1 = endX - rectWidth
                        let drawBoxY1 = endY
                        let drawBoxX2 = drawBoxX1 + rectWidth
                        let drawBoxY2 = drawBoxY1 + rectHeight
                        // updatedDataExtraction(drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2, shape[0]['shape_id'])
                    }

                    else if (handleId === "2") {
                        points[1][0] = parseInt(endX / deepICRCTX.imageScale);
                        points[3][1] = parseInt(endY / deepICRCTX.imageScale);
                        let drawBoxX1 = endX - rectWidth
                        let drawBoxY1 = endY - rectHeight
                        let drawBoxX2 = drawBoxX1 + rectWidth
                        let drawBoxY2 = drawBoxY1 + rectHeight
                        // updatedDataExtraction(drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2, shape[0]['shape_id'])
                    }

                    else if (handleId === "3") {
                        points[0][0] = parseInt(endX / deepICRCTX.imageScale);
                        points[2][1] = parseInt(endY / deepICRCTX.imageScale);
                        let drawBoxX1 = endX
                        let drawBoxY1 = endY - rectHeight
                        let drawBoxX2 = drawBoxX1 + rectWidth
                        let drawBoxY2 = drawBoxY1 + rectHeight
                        // updatedDataExtraction(drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2, shape[0]['shape_id'])
                    }

                    let x = points[0][0];
                    let y = points[0][1];
                    let w = Math.abs(points[2][0] - points[0][0]);
                    let h = Math.abs(points[2][1] - points[0][1]);

                    if (points[0][1] + 6 < points[2][1] && points[0][0] + 6 < points[2][0]) {
                        shapeList[image_id][shape_id]["x"] = x;
                        shapeList[image_id][shape_id]["y"] = y;
                        shapeList[image_id][shape_id]["width"] = w;
                        shapeList[image_id][shape_id]["height"] = h;

                        shape[0]["x"] = x;
                        shape[0]["y"] = y;
                        shape[0]["width"] = w;
                        shape[0]["height"] = h;
                    }
                }
                else {
                    if (deepICRCTX.debug === true) console.log("handle:", handleId);
                }
            }

            setDeepICRCTX({
                ...deepICRCTX,
                shapeListRight: shapeList,
                selectedShapeRight: shape,
            })
        }
        // else if (deepICRCTX.croppingToolId !== 1 && isStart === true && isSelected === true) {

        //     let endX = e.nativeEvent.offsetX;
        //     let endY = e.nativeEvent.offsetY;

        //     let dx = endX - prevPosX;
        //     let dy = endY - prevPosY;

        //     setPrevPosX(endX);
        //     setPrevPosY(endY);
        // moveShape([dy / deepICRCTX.imageScale, dx / deepICRCTX.imageScale]);
        //     if (currentTarget !== null || currentTarget !== undefined) {
        //         currentTarget.style.cursor = "grabbing";
        //     }
        // }
        else if (isStart === true) {
            // console.log("Is select");
            const svg = document.getElementById('mySVG');
            const svgRect = svg.getBoundingClientRect();

            // let endX = e.nativeEvent.offsetX;
            // let endY = e.nativeEvent.offsetY;
            const endX = (e.clientX - svgRect.left) - 1;
            const endY = (e.clientY - svgRect.top) - 1;

            var x = Math.min(startX, endX);
            var y = Math.min(startY, endY);
            var w = Math.abs(endX - startX);
            var h = Math.abs(endY - startY);


            if (deepICRCTX.croppingToolId === 1) {
                document.getElementById('croppingOutputDiv').scrollLeft += startX - endX;
                document.getElementById('croppingOutputDiv').scrollTop += startY - endY;
                document.getElementById('mySVG').style.cursor = 'grabbing';
            }
            else if (deepICRCTX.croppingToolId === 3) {
                // console.log("Moving");
                setDeepICRCTX({
                    ...deepICRCTX,
                    currentShapeRight: [{ type: "rect", x: x, y: y, width: w, height: h }],
                });
            }
            else if (deepICRCTX.croppingToolId === 4) {
                var wh = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width * deepICRCTX.imageScale;
                var ht = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height * deepICRCTX.imageScale;

                x = startX;
                y = startY;

                if (x - w < 0) w = x;
                if (y - h < 0) h = y;
                if (x + w > wh) w = Math.abs(wh - x);
                if (y + h > ht) h = Math.abs(ht - y);

            }
        }
    }

    function getIOU(bb1, bb2) {

        // Determine the coordinates of the intersection rectangle
        const xLeft = Math.max(bb1.x1, bb2.x1);
        const yTop = Math.max(bb1.y1, bb2.y1);
        const xRight = Math.min(bb1.x2, bb2.x2);
        const yBottom = Math.min(bb1.y2, bb2.y2);

        // Calculate dimensions of intersection area
        const intersectionWidth = xRight - xLeft;
        const intersectionHeight = yBottom - yTop;
        const intersectionArea = Math.max(0, intersectionWidth) * Math.max(0, intersectionHeight);

        // Calculate the percentage of bb2's area covered by bb1
        const bb2Area = (bb2.x2 - bb2.x1) * (bb2.y2 - bb2.y1);
        const iou = (intersectionArea / bb2Area)
        if (iou < 0.0 || iou > 1.0) {
            // throw new Error("IoU value must be in the range [0, 1].");
            iou = 0
        }
        return iou;
    }

    const chechkIOU = (dBox, tBox, div) => {
        const drawBoxX1 = dBox[0]
        const drawBoxX2 = dBox[2]
        const drawBoxY1 = dBox[1]
        const drawBoxY2 = dBox[3]

        // const textX1 = tBox[0]
        // const textX2 = tBox[2]
        // const textY1 = tBox[1]
        // const textY2 = tBox[3]

        const textX1 = parseFloat(getComputedStyle(div)?.left)
        const textY1 = parseFloat(getComputedStyle(div)?.top)
        const textX2 = parseFloat(getComputedStyle(div)?.left) + parseFloat(getComputedStyle(div)?.width)
        const textY2 = parseFloat(getComputedStyle(div)?.top) + parseFloat(getComputedStyle(div)?.height)

        const drawBox = { x1: drawBoxX1, y1: drawBoxY1, x2: drawBoxX2, y2: drawBoxY2 };
        const textBox = { x1: textX1, y1: textY1, x2: textX2, y2: textY2 };
        // console.log("Draw Box ", dBox, [textX1, textY1, textX2, textY2], div);
        // [textX1,textY1,textX2,textY2]
        // const iou = getIOU(drawBox, textBox);


        if (((((drawBoxX1 <= textX1) && (textX1 <= drawBoxX2)) || ((drawBoxX1 <= textX2) && (textX2 <= drawBoxX2))) && (((drawBoxY1 <= textY1) && (textY1 <= drawBoxY2)) || ((drawBoxY1 <= textY2) && (textY2 <= drawBoxY2))))) {
            // console.log("Entered");
            // if (div.getAttribute('table')) {

            const iou = getIOU(drawBox, textBox);

            if (iou * 100 > 50) {
                // console.log("iou", iou, "inside iou", div);
                return div
            }
            // } 
            // else {
            //     return div
            // }
        }
        // else{
        //     console.log("Rejected div",div);
        // }

    }

    // Function to find the index of the object containing the keyName
    function findIndexForKeyName(array, keyName) {
        const index = array.findIndex(obj => obj.hasOwnProperty(keyName));
        return index;
    }

    // Draw box modified in the existed shape id
    function findIndexForModifiedKeyName(array, keyName) {
        // console.log("sent array", array);
        const index = array.findIndex(obj => Object.keys(obj).some(key => key.includes(keyName)));
        // const index = array.findIndex(obj => obj.includes(keyName));
        return index;
    }

    function insertValueWithBlanks(array, index, value) {
        // console.log("page no", index);
        // Fill all previous indexes with blank objects
        for (let i = 0; i < index; i++) {
            if (typeof array[i] === 'undefined') {
                array[i] = {};
            }
        }
        // Insert the value at the specified index
        array[index] = value;

        return array
    }

    const updateLineOutputJson = (selectedDivs, shape_index, drawBoxX2, drawBoxX1, drawBoxY1, drawBoxY2, status, importedMeta, isSelected) => {
        // console.log("selectd divs", selectedDivs);
        // console.log("Line",{isSelected});
        const updatedJson = deepICRCTX.outputJson

        if (status === 'Modified') {

            var regionLineIndex = findIndexForModifiedKeyName(deepICRCTX.selectedRegion.pages[deepICRCTX.pdfPage - 1]?.regions || [],
                shape_index)
            // console.log({ regionLineIndex });
            if (regionLineIndex === -1) {
                enqueueSnackbar(`${t("stingEmptyRegions")}`, {
                    variant: "error",
                    anchorOrigin: { vertical: "top", horizontal: "right" },
                }
                )
                return
            }
            // console.log("Modified value", status);
            let page_index = "p_" + props.width + "_" + props.height + "_" + (props.imageIndex + 1);
            deepICRCTX.shapeListRight[page_index][shape_index].label = 'Line'
            let lineKey = `l_line_${shape_index}`
            // console.log({ regionLineIndex }, { lineKey }, deepICRCTX.selectedRegion.pages[deepICRCTX.pdfPage - 1]?.regions[regionLineIndex]?.[lineKey]);
            // let newLine = 
            let actualPage = deepICRCTX.file.type === 'application/pdf' ? selectedDivs[0]?.getAttribute('info')?.split('-')[0] : 0
            if (deepICRCTX.file.type === 'application/pdf' && selectedDivs.length < 1) {
                let currentActualPage = document.getElementById('0')
                //console.log({currentActualPage});
                actualPage = currentActualPage?.getAttribute('info')?.split('-')[0]
            }

            deepICRCTX.selectedRegion.pages[deepICRCTX.pdfPage - 1].regions[regionLineIndex][lineKey] = [{
                objectInfo: {
                    selection_id: shape_index,
                    angle: 0,
                    selection_type: "rect",
                    meta: importedMeta,
                    pageInfo: updatedJson?.original_output.pages[actualPage]?.id,
                    isSelected: isSelected
                }
            }]
            // }

            setDeepICRCTX({
                ...deepICRCTX,
                selectedRegion: {
                    pages: deepICRCTX.selectedRegion.pages
                },
            })
        }

        for (let i = 0; i < selectedDivs.length; i++) {
            const singleDiv = selectedDivs[i]

            if (singleDiv === undefined) {
                // console.log("Single Div", singleDiv);
            } else {
                const attributeTable = singleDiv.getAttribute('info')?.split('-')
                // console.log("else Single Div", singleDiv, attributeTable);
                let actualPage
                let pageNo
                let lineNo
                let wordNo
                let cellNo
                let wordX
                let wordY
                let wordHeight
                let wordWidth
                if (attributeTable?.length === 3) {
                    pageNo = attributeTable && attributeTable[0]
                    let tempActualPage = updatedJson.original_output.pages[pageNo].id.split('_')
                    actualPage = deepICRCTX.file.type === 'application/pdf' ? tempActualPage[tempActualPage.length - 1] - 1 : 0
                    // console.log({actualPage});
                    lineNo = attributeTable && attributeTable[1]
                    wordX = updatedJson.original_output.pages[pageNo]?.regions[lineNo]?.x
                    wordY = updatedJson.original_output.pages[pageNo]?.regions[lineNo]?.y
                    wordHeight = updatedJson.original_output.pages[pageNo]?.regions[lineNo]?.height
                    wordWidth = updatedJson.original_output.pages[pageNo]?.regions[lineNo]?.width
                } else {
                    pageNo = attributeTable && attributeTable[0]
                    let tempActualPage = updatedJson.original_output.pages[pageNo].id.split('_')
                    actualPage = deepICRCTX.file.type === 'application/pdf' ? tempActualPage[tempActualPage.length - 1] - 1 : 0
                    // console.log({actualPage});
                    lineNo = attributeTable && attributeTable[1]
                    cellNo = attributeTable && attributeTable[2]
                    wordNo = attributeTable && attributeTable[3]
                    wordX = updatedJson.original_output.pages[pageNo]?.regions[lineNo]?.cells[cellNo]?.cell[wordNo]?.x
                    wordY = updatedJson.original_output.pages[pageNo]?.regions[lineNo]?.cells[cellNo]?.cell[wordNo]?.y
                    wordHeight = updatedJson.original_output.pages[pageNo]?.regions[lineNo]?.cells[cellNo]?.cell[wordNo]?.height
                    wordWidth = updatedJson.original_output.pages[pageNo]?.regions[lineNo]?.cells[cellNo]?.cell[wordNo]?.width
                }

                const lineKey = `l_${'line'}_${shape_index}`
                const lineIdentifier = `l_${lineNo}`

                // const pageKey = `p_${pageNo}`
                var regionIndex = findIndexForKeyName(deepICRCTX.selectedRegion.pages[actualPage]?.regions || [], lineKey)
                // console.log({regionIndex});
                if (regionIndex === -1) {
                    let page_index = "p_" + props.width + "_" + props.height + "_" + (props.imageIndex + 1);
                    deepICRCTX.shapeListRight[page_index][shape_index].label = 'Line'
                    // console.log("New table shape create if", deepICRCTX.selectedRegion);
                    let destructuredArr = (deepICRCTX.selectedRegion.pages[actualPage] === undefined || deepICRCTX.selectedRegion.pages[actualPage] === {}) ? [] : deepICRCTX.selectedRegion.pages[actualPage].hasOwnProperty('regions') ? deepICRCTX.selectedRegion.pages[actualPage].regions : []
                    // console.log("Destructered Array", destructuredArr);
                    let obj = {
                        [lineKey]: [
                            {
                                [lineIdentifier]: {
                                    type: "Line",
                                    class_type: "Text",
                                    x: wordX,
                                    y: wordY,
                                    width: wordWidth,
                                    height: wordHeight,
                                    text: singleDiv.textContent
                                }
                            },
                            {
                                objectInfo: {
                                    selection_id: shape_index,
                                    angle: 0,
                                    selection_type: "rect",
                                    meta: importedMeta !== undefined ? importedMeta : meta,
                                    pageInfo: updatedJson?.original_output.pages[pageNo]?.id,
                                    isSelected: isSelected !== undefined ? isSelected : true
                                }
                            }
                        ]
                    }
                    let savedData = insertValueWithBlanks(deepICRCTX.selectedRegion.pages, actualPage, { regions: [...destructuredArr, obj] })
                    // console.log("saved data", savedData);
                    setDeepICRCTX({
                        ...deepICRCTX,
                        selectedRegion: {
                            pages: savedData
                        }
                    })
                } else {

                    var lineIndex = findIndexForKeyName(deepICRCTX.selectedRegion.pages[actualPage]?.regions?.[regionIndex][lineKey] || [], lineIdentifier)
                    // console.log({lineIndex},{pageNo});
                    if (lineIndex === -1) {
                        // console.log("Single div text",singleDiv.innerHTML);
                        deepICRCTX.selectedRegion.pages[actualPage].regions[regionIndex][lineKey].push(

                            {
                                [lineIdentifier]: {
                                    type: "Line",
                                    class_type: "Text",
                                    x: wordX,
                                    y: wordY,
                                    width: wordWidth,
                                    height: wordHeight,
                                    text: singleDiv.textContent
                                }
                            }

                        )
                    } else {
                        // console.log( deepICRCTX.selectedRegion.pages[pageNo].regions[regionIndex][lineKey][lineIndex][lineIdentifier].text.concat(singleDiv.innerHTML),"test");
                        // console.log("Single div text", singleDiv.innerHTML);
                        let text
                        if (singleDiv.innerHTML === '&amp;') {
                            text = '&'
                        } else {
                            text = singleDiv.textContent
                        }
                        deepICRCTX.selectedRegion.pages[actualPage].regions[regionIndex][lineKey][lineIndex][lineIdentifier].text = deepICRCTX.selectedRegion.pages[actualPage].regions[regionIndex][lineKey][lineIndex][lineIdentifier].text.concat(text)
                    }

                    setDeepICRCTX({
                        ...deepICRCTX,
                        selectedRegion: {
                            pages: deepICRCTX.selectedRegion.pages
                        }
                    })
                }
            }
        }

        setDeepICRCTX((prev) => ({
            ...prev,
            tempShape: ""
        }))

    }

    const updateOutputJson = (tableDiv, shape_index, drawBoxX2, drawBoxX1, drawBoxY1, drawBoxY2, status, importedMeta, isSelected) => {
        // console.log({ status }, { shape_index });
        // console.log("Selected table",tableDiv);
        // console.log("Table",{isSelected});
        // console.log({ importedMeta });
        const updatedJson = deepICRCTX.outputJson

        if (status === 'Modified') {
            var regionIndex = findIndexForModifiedKeyName(deepICRCTX.selectedRegion.pages[deepICRCTX.pdfPage - 1]?.regions || [], shape_index)
            // console.log("Entered", deepICRCTX.selectedRegion.pages[deepICRCTX.pdfPage - 1]?.regions[regionIndex], regionIndex);
            let page_index = "p_" + props.width + "_" + props.height + "_" + (props.imageIndex + 1);
            if (regionIndex === -1) {
                deepICRCTX.shapeListRight[page_index][shape_index].label = 'Blank'
                enqueueSnackbar(`${t("stingEmptyRegions")}`, {
                    variant: "error",
                    anchorOrigin: { vertical: "top", horizontal: "right" },
                }
                )
                return
            }
            let cells
            // let page_index = "p_" + props.width + "_" + props.height + "_" + (props.imageIndex + 1);
            deepICRCTX.shapeListRight[page_index][shape_index].label = 'Table'
            let tempActualPage = tableDiv[0]?.getAttribute('table')?.split('-')[0]

            if (deepICRCTX.file.type === 'application/pdf' && tableDiv.length < 1) {
                let currentActualPage = document.getElementById('0')
                // console.log({currentActualPage});
                tempActualPage = currentActualPage?.getAttribute('info')?.split('-')[0]
            }
            let splitActualPage = updatedJson.original_output.pages[tempActualPage].id.split('_')
            let actualPage = deepICRCTX.file.type === 'application/pdf' ? splitActualPage[splitActualPage.length - 1] - 1 : 0

            for (let key in deepICRCTX.selectedRegion.pages[actualPage]?.regions[regionIndex]) {
                // console.log("key",deepICRCTX.selectedRegion.pages[deepICRCTX.pdfPage - 1]?.regions[regionIndex][key].cells);
                cells = deepICRCTX.selectedRegion.pages[actualPage]?.regions[regionIndex][key].cells
                cells = []
            }
            for (let i = 0; i < tableDiv.length; i++) {
                const singleDiv = tableDiv[i]
                // console.log("Single Div", singleDiv);
                const attributeTable = singleDiv.getAttribute('table').split('-')
                const pageNo = attributeTable[0]
                const tableNo = attributeTable[1]
                const cellNo = attributeTable[2]

                const tableKey = `t_${tableNo}_${shape_index}`
                // console.log({tableKey});
                // console.log("cells",deepICRCTX.selectedRegion.pages[pageNo].regions[regionIndex][tableKey]);
                cells?.push(updatedJson.original_output.pages[pageNo]?.regions[tableNo]?.cells[cellNo])

                if (deepICRCTX.selectedRegion.pages[actualPage].regions[regionIndex][tableKey] === undefined) {
                    return
                } else {

                    deepICRCTX.selectedRegion.pages[actualPage].regions[regionIndex][tableKey].cells = [...cells]
                }
                // deepICRCTX.selectedRegion.pages[pageNo].regions[regionIndex][tableKey] === 'undefined'?
                // const data = [...cells]

                // cells.push(updatedJson.original_output.pages[pageNo].regions[tableNo].cells[cellNo])
                // deepICRCTX.selectedRegion.pages[pageNo].regions[regionIndex][tableKey].cells = [...cells]

                setDeepICRCTX({
                    ...deepICRCTX,
                    selectedRegion: {
                        pages: deepICRCTX.selectedRegion.pages
                    }
                })
            }
        }
        else {
            for (let i = 0; i < tableDiv.length; i++) {
                const singleDiv = tableDiv[i]
                // console.log("Single Div", singleDiv);
                const attributeTable = singleDiv.getAttribute('table').split('-')
                const pageNo = attributeTable[0]
                let tempActualPage = updatedJson.original_output.pages[pageNo].id.split('_')
                let actualPage = deepICRCTX.file.type === 'application/pdf' ? tempActualPage[tempActualPage.length - 1] - 1 : 0
                const tableNo = attributeTable[1]
                const cellNo = attributeTable[2]

                const tableKey = `t_${tableNo}_${shape_index}`
                // const pageKey = `p_${pageNo}`
                var regionIndex = findIndexForKeyName(deepICRCTX.selectedRegion.pages[actualPage]?.regions || [], tableKey)
                if (regionIndex === -1) {
                    let page_index = "p_" + props.width + "_" + props.height + "_" + (props.imageIndex + 1);
                    deepICRCTX.shapeListRight[page_index][shape_index].label = 'Table'
                    // console.log("New table shape create if", deepICRCTX.selectedRegion);
                    let destructuredArr = (deepICRCTX.selectedRegion.pages[actualPage] === undefined || deepICRCTX.selectedRegion.pages[actualPage] === {}) ? [] : deepICRCTX.selectedRegion.pages[actualPage].hasOwnProperty('regions') ? deepICRCTX.selectedRegion.pages[actualPage].regions : []
                    // console.log("Destructered Array", destructuredArr);

                    let obj = {
                        [tableKey]: {
                            type: "Table",
                            width: drawBoxX2 - drawBoxX1,
                            x: drawBoxX1,
                            y: drawBoxY1,
                            height: drawBoxY2 - drawBoxY1,
                            row: updatedJson.original_output.pages[pageNo].regions[tableNo].row,
                            column: updatedJson.original_output.pages[pageNo].regions[tableNo].column,
                            cells: [
                                updatedJson.original_output.pages[pageNo].regions[tableNo].cells[cellNo]
                            ],
                            selected_type: [
                                "Table"
                            ],
                            selection_id: shape_index,
                            angle: 0,
                            selection_type: "rect",
                            meta: importedMeta !== undefined ? importedMeta : meta,
                            pageInfo: updatedJson.original_output.pages[pageNo].id,
                            isSelected: isSelected !== undefined ? isSelected : true
                        }
                    }

                    let savedData = insertValueWithBlanks(deepICRCTX.selectedRegion.pages, actualPage, { regions: [...destructuredArr, obj] })
                    // console.log("saved data", savedData);
                    setDeepICRCTX({
                        ...deepICRCTX,
                        selectedRegion: {
                            pages: savedData
                        }
                    })

                } else {
                    deepICRCTX.selectedRegion.pages[actualPage].regions[regionIndex][tableKey].cells.push(updatedJson.original_output.pages[pageNo].regions[tableNo].cells[cellNo])

                    setDeepICRCTX({
                        ...deepICRCTX,
                        selectedRegion: {
                            pages: deepICRCTX.selectedRegion.pages
                        }
                    })
                }
            }
            // console.log("New table shape create else", deepICRCTX.selectedRegion);
            // console.log("Final updated Json", pages);
        }

    }

    function fetchLineValue(selectedDivs) {
        let resultArr = []
        for (let i = 0; i < selectedDivs.length; i++) {
            const div = selectedDivs[i]
            // console.log("Line div", div);
            const textY1 = parseFloat(getComputedStyle(div)?.top)
            const textY2 = parseFloat(getComputedStyle(div)?.top) + parseFloat(getComputedStyle(div)?.height)
            const marginLine = (textY1 + textY2) / 2
            const group = [div.innerHTML]
            for (let j = i + 1; j < selectedDivs.length; j++) {
                const otherDiv = selectedDivs[j];
                const otherTextY1 = parseFloat(getComputedStyle(otherDiv)?.top)
                const otherTextY2 = parseFloat(getComputedStyle(otherDiv)?.top) + parseFloat(getComputedStyle(otherDiv)?.height)

                if (otherTextY1 === textY1 || (otherTextY1 > textY1 && otherTextY2 < textY2) || (otherTextY1 < textY1 && (otherTextY2 > textY1 && otherTextY2 < textY2) && otherTextY2 >= marginLine) || (otherTextY2 > textY2 && (otherTextY1 > textY1 && otherTextY1 < textY2) && otherTextY1 <= marginLine)) {
                    group.push(otherDiv.innerHTML);
                    i++
                }
                else {
                    break;
                }
            }
            resultArr.push(group)
        }
        return resultArr
    }

    function fetchTable(selectedTables, drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2) {
        let overLappedTable = []

        for (let i = 0; i < selectedTables.length; i++) {
            const div = selectedTables[i]
            const tableX1 = parseFloat(getComputedStyle(div)?.left)
            const tableX2 = parseFloat(getComputedStyle(div)?.left) + parseFloat(getComputedStyle(div)?.width)
            const tableY1 = parseFloat(getComputedStyle(div)?.top)
            const tableY2 = parseFloat(getComputedStyle(div)?.top) + parseFloat(getComputedStyle(div)?.height)

            const overLappedDiv = chechkIOU([drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2], [tableX1, tableY1, tableX2, tableY2], div)
            // console.log("Selected Overlapped div", overLappedDiv);
            overLappedDiv !== undefined && overLappedTable.push(overLappedDiv)
        }

        return overLappedTable

    }

    function updatedDataExtraction(drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2, sr, im, shapeMeta, shapeSelected) {

        let resultArr = []
        let overLappedTable
        let selectedTables
        let selectedDivs
        // console.log({label});
        // console.log(drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2,);
        selectedTables = Array.from(document.querySelectorAll('foreignObject div')).filter((div) => div.getAttribute('table') !== null)
        overLappedTable = fetchTable(selectedTables, drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2)
        // console.log({ overLappedTable });
        if (overLappedTable.length < 1) {
            selectedDivs = Array.from(document.querySelectorAll('foreignObject div')).filter((div) => {
                const textX1 = parseFloat(getComputedStyle(div)?.left)
                const textY1 = parseFloat(getComputedStyle(div)?.top)
                const textX2 = parseFloat(getComputedStyle(div)?.left) + parseFloat(getComputedStyle(div)?.width)
                const textY2 = parseFloat(getComputedStyle(div)?.top) + parseFloat(getComputedStyle(div)?.height)

                const IOU = chechkIOU([drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2], [textX1, textY1, textX2, textY2], div)
                return (
                    IOU
                );
            });
            resultArr = fetchLineValue(selectedDivs)
            // if (resultArr.length < 1) {
            //     let page_index = "p_" + props.width + "_" + props.height + "_" + (props.imageIndex + 1);
            // deepICRCTX.shapeListRight[page_index][sr].label = ''
            //     enqueueSnackbar(`${t("No content selected")}`, {
            //         variant: "error",
            //         anchorOrigin: { vertical: "top", horizontal: "right" },
            //     })
            // }
        }

        let shape_index = sr;

        let differentRegion = findIndexForModifiedKeyName(deepICRCTX.selectedRegion.pages[deepICRCTX.pdfPage - 1]?.regions || [],
            shape_index)
        // console.log({differentRegion});
        let propertyName = deepICRCTX.selectedRegion.pages[deepICRCTX.pdfPage - 1]?.regions[differentRegion]

        //  If a line draw box is dragged over a table then show a warning
        if (propertyName?.hasOwnProperty(`l_line_${shape_index}`) && overLappedTable.length > 0) {
            enqueueSnackbar(`${t("stringInvalidTextRegions")}`, {
                variant: "error",
                anchorOrigin: { vertical: "top", horizontal: "right" },
            })
            return;
        }
        // setDeepICRCTX({
        //     ...deepICRCTX,
        //     tempShape:'no_shape'
        // })
        // "Modified"
        overLappedTable.length > 0 ? updateOutputJson(overLappedTable, shape_index, drawBoxX2, drawBoxX1, drawBoxY1, drawBoxY2, im === 'import' ? '' : "Modified", shapeMeta, shapeSelected) : updateLineOutputJson(selectedDivs, shape_index, drawBoxX2, drawBoxX1, drawBoxY1, drawBoxY2, im === 'import' ? '' : "Modified", shapeMeta, shapeSelected);
    }

    function jsonImportDataExtraction(x1, y1, x2, y2, shape, importedMeta, isSelected) {
        const drawBoxX1 = x1
        const drawBoxY1 = y1
        const drawBoxX2 = x2
        const drawBoxY2 = y2

        let resultArr = []
        let overLappedTable
        let selectedTables
        let selectedDivs
        // console.log({label});
        selectedTables = Array.from(document.querySelectorAll('foreignObject div')).filter((div) => div.getAttribute('table') !== null)
        overLappedTable = fetchTable(selectedTables, drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2)
        // console.log({ overLappedTable });
        if (overLappedTable.length < 1) {
            selectedDivs = Array.from(document.querySelectorAll('foreignObject div')).filter((div) => {
                const textX1 = parseFloat(getComputedStyle(div)?.left)
                const textY1 = parseFloat(getComputedStyle(div)?.top)
                const textX2 = parseFloat(getComputedStyle(div)?.left) + parseFloat(getComputedStyle(div)?.width)
                const textY2 = parseFloat(getComputedStyle(div)?.top) + parseFloat(getComputedStyle(div)?.height)

                const IOU = chechkIOU([drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2], [textX1, textY1, textX2, textY2], div)

                return (
                    IOU
                );
            });
            resultArr = fetchLineValue(selectedDivs)
            // console.log("result array", resultArr);
            if (resultArr.length < 1) {
                let page_index = "p_" + props.width + "_" + props.height + "_" + (props.imageIndex + 1);
                deepICRCTX.shapeListRight[page_index][shape].label = ''
                enqueueSnackbar(`${t("stingEmptyRegions")}`, {
                    variant: "error",
                    anchorOrigin: { vertical: "top", horizontal: "right" },
                })
            }
            // console.log("Formatted text from line", resultArr);
        }

        overLappedTable.length > 0 ? updateOutputJson(overLappedTable, shape, drawBoxX2, drawBoxX1, drawBoxY1, drawBoxY2, '', importedMeta, isSelected) : updateLineOutputJson(selectedDivs, shape, drawBoxX2, drawBoxX1, drawBoxY1, drawBoxY2, '', importedMeta, isSelected);

    }

    function dataExtraction() {

        const drawBoxX1 = startPoint.x
        const drawBoxY1 = startPoint.y
        const drawBoxX2 = endPoint.x
        const drawBoxY2 = endPoint.y
        let shape = deepICRCTX.selectedShapeRight
        let selectedShapeId = shape[0]['shape_id']
        let firstPoint = document.getElementById(`sp_0,${page_index},${selectedShapeId}`)
        let lastPoint = document.getElementById(`sp_2,${page_index},${selectedShapeId}`)
        let sortedX1 = parseFloat(getComputedStyle(firstPoint)?.x) + 3
        let sortedY1 = parseFloat(getComputedStyle(firstPoint)?.y) + 3
        let sortedX2 = parseFloat(getComputedStyle(lastPoint)?.x) + 3
        let sortedY2 = parseFloat(getComputedStyle(lastPoint)?.y) + 3
        // console.log({sortedX1},{sortedY1},{sortedX2},{sortedY2});
        // console.log("Checking position first", drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2);

        // console.log("Selected Table",selectedTables);
        // console.log("Selected tables",selectedTables);
        let resultArr = []
        let overLappedTable
        let selectedTables
        let selectedDivs
        // console.log({label});
        selectedTables = Array.from(document.querySelectorAll('foreignObject div')).filter((div) => div.getAttribute('table') !== null)
        overLappedTable = fetchTable(selectedTables, sortedX1, sortedY1, sortedX2, sortedY2)
        // console.log({ overLappedTable });
        if (overLappedTable.length < 1) {
            selectedDivs = Array.from(document.querySelectorAll('foreignObject div')).filter((div) => {
                const textX1 = parseFloat(getComputedStyle(div)?.left)
                const textY1 = parseFloat(getComputedStyle(div)?.top)
                const textX2 = parseFloat(getComputedStyle(div)?.left) + parseFloat(getComputedStyle(div)?.width)
                const textY2 = parseFloat(getComputedStyle(div)?.top) + parseFloat(getComputedStyle(div)?.height)

                const IOU = chechkIOU([sortedX1, sortedY1, sortedX2, sortedY2], [textX1, textY1, textX2, textY2], div)

                return (
                    IOU
                );
            });
            resultArr = fetchLineValue(selectedDivs)
            if (resultArr.length < 1) {
                enqueueSnackbar(`${t("stingEmptyRegions")}`, {
                    variant: "error",
                    anchorOrigin: { vertical: "top", horizontal: "right" },
                })
            }
            // console.log("Formatted text from line", resultArr);
        }


        let shapes = deepICRCTX.shapeListRight;

        let counter = objectSize(shapes[page_index]);
        let shape_index = "sr_" + counter;
        const imageId = deepICRCTX.popUpDialog.image_id
        const shapeId = deepICRCTX.popUpDialog.shape_id;
        shapes[imageId][shapeId]["label"] = overLappedTable.length > 0 ? "Table" : resultArr.length < 1 ? "" : "Line";
        shapes[imageId][shapeId]["meta"] = meta;
        shapes[imageId][shapeId]["image_id"] = imageId;
        shapes[imageId][shapeId]["shape_id"] = shapeId;

        overLappedTable.length > 0 ? updateOutputJson(overLappedTable, shape_index, drawBoxX2, drawBoxX1, drawBoxY1, drawBoxY2) : updateLineOutputJson(selectedDivs, shape_index, drawBoxX2, drawBoxX1, drawBoxY1, drawBoxY2);

        setShouldJsonTriggered(false)

        setDeepICRCTX({
            ...deepICRCTX,
            shapeListRight: shapes,
            selectedShapeRight: [shapes[imageId][shapeId]],
            popUpDialog: {
                image_id: "",
                shape_id: "",
                label: "Save",
                meta: "",
                left: 0,
                top: 0,
                testShow: false,
            },
        });
    }

    function handleMouseUp(e) {
        const svg = document.getElementById('mySVG');
        const svgRect = svg.getBoundingClientRect();
        // console.log("Svg Rect",svgRect,"ClientX",e.clientX,"clientY",e.clientY);
        // console.log("checking e",e.target);
        const ux = (e.clientX - svgRect.left) - 1;
        const uy = (e.clientY - svgRect.top) - 1;

        e.stopPropagation();
        if (isStart === true && isHandle === true) {
            //  if (isHandle === true){
            let dragEndX = parseInt(e.nativeEvent.offsetX);
            let dragEndY = parseInt(e.nativeEvent.offsetY);

            // console.log({dragEndX},":",{dragEndY});

            let shapeList = deepICRCTX.shapeListRight;
            let shape = deepICRCTX.selectedShapeRight;
            // console.log({shape});

            let points = GetPointsFromShape(deepICRCTX, shape[0]);
            points[handleId] = [parseInt(dragEndX / deepICRCTX.imageScale), parseInt(dragEndY / deepICRCTX.imageScale)];

            let image_id = shape[0]['image_id'];
            let shape_id = shape[0]['shape_id'];
            let shape_meta = shape[0]['meta']
            let shape_selected = shape[0]['isSelected']

            if (shape[0]['type'] === "rect") {
                let selectedRect = document.getElementById(shape[0]['shape_id'])
                let rectHeight = parseFloat(getComputedStyle(selectedRect)?.height)
                let rectWidth = parseFloat(getComputedStyle(selectedRect)?.width)
                if (handleId !== null) {
                    // console.log("Mouse Moved",handleId);
                    if (handleId === "0") {
                        points[3][0] = parseInt(dragEndX / deepICRCTX.imageScale);
                        points[1][1] = parseInt(dragEndY / deepICRCTX.imageScale);
                        // console.log("Selected Rect", selectedRect);
                        let drawBoxX1 = dragEndX
                        let drawBoxY1 = dragEndY
                        let drawBoxX2 = drawBoxX1 + rectWidth
                        let drawBoxY2 = drawBoxY1 + rectHeight
                        updatedDataExtraction(drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2, shape[0]['shape_id'], '', shape_meta, shape_selected)
                    }
                    else if (handleId === "1") {
                        points[2][0] = parseInt(dragEndX / deepICRCTX.imageScale);
                        points[0][1] = parseInt(dragEndY / deepICRCTX.imageScale);
                        let drawBoxX1 = dragEndX - rectWidth
                        let drawBoxY1 = dragEndY
                        let drawBoxX2 = drawBoxX1 + rectWidth
                        let drawBoxY2 = drawBoxY1 + rectHeight
                        updatedDataExtraction(drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2, shape[0]['shape_id'], '', shape_meta, shape_selected)
                    }

                    else if (handleId === "2") {
                        points[1][0] = parseInt(dragEndX / deepICRCTX.imageScale);
                        points[3][1] = parseInt(dragEndY / deepICRCTX.imageScale);
                        let drawBoxX1 = dragEndX - rectWidth
                        let drawBoxY1 = dragEndY - rectHeight
                        let drawBoxX2 = drawBoxX1 + rectWidth
                        let drawBoxY2 = drawBoxY1 + rectHeight
                        updatedDataExtraction(drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2, shape[0]['shape_id'], '', shape_meta, shape_selected)
                    }

                    else if (handleId === "3") {
                        points[0][0] = parseInt(dragEndX / deepICRCTX.imageScale);
                        points[2][1] = parseInt(dragEndY / deepICRCTX.imageScale);
                        let drawBoxX1 = dragEndX
                        let drawBoxY1 = dragEndY - rectHeight
                        let drawBoxX2 = drawBoxX1 + rectWidth
                        let drawBoxY2 = drawBoxY1 + rectHeight
                        updatedDataExtraction(drawBoxX1, drawBoxY1, drawBoxX2, drawBoxY2, shape[0]['shape_id'], '', shape_meta, shape_selected)
                    }

                    let x = points[0][0];
                    let y = points[0][1];
                    let w = Math.abs(points[2][0] - points[0][0]);
                    let h = Math.abs(points[2][1] - points[0][1]);

                    if (points[0][1] + 6 < points[2][1] && points[0][0] + 6 < points[2][0]) {
                        shapeList[image_id][shape_id]["x"] = x;
                        shapeList[image_id][shape_id]["y"] = y;
                        shapeList[image_id][shape_id]["width"] = w;
                        shapeList[image_id][shape_id]["height"] = h;

                        shape[0]["x"] = x;
                        shape[0]["y"] = y;
                        shape[0]["width"] = w;
                        shape[0]["height"] = h;
                    }
                }
                else {
                    if (deepICRCTX.debug === true) console.log("handle:", handleId);
                }
            }
            //     setIsHandle(false);
            //     setHandleId(null);
            //     setIsStart(false);
            // }
            setIsHandle(false);
            setIsStart(false);
            setHandleId(null);
        }
        // else if (deepICRCTX.croppingToolId !== 1 && isStart === true && isSelected === true) {
        //     console.log("First Else if");
        //     let endX = e.nativeEvent.offsetX;
        //     let endY = e.nativeEvent.offsetY;

        //     let dx = endX - prevPosX;
        //     let dy = endY - prevPosY;

        //     setPrevPosX(endX);
        //     setPrevPosY(endY);
        //     moveShape([dy / deepICRCTX.imageScale, dx / deepICRCTX.imageScale]);
        //     setIsStart(false);
        //     setIsSelected(false);
        //     if (currentTarget !== null || currentTarget !== undefined) {
        //         setCurrentTarget(null);
        //         currentTarget.style.cursor = "default";
        //     }
        // }
        else if (isStart) {
            // setEndPoint({ x: e.clientX, y: e.clientY })
            setEndPoint({ x: ux, y: uy })
            setIsStart(false);
            setIsSelected(false);
            // let endX = e.nativeEvent.offsetX;
            // let endY = e.nativeEvent.offsetY;
            let endX = ux;
            let endY = uy;
            let wx = e.nativeEvent.clientX;
            let wy = e.nativeEvent.clientY;
            // let wx = ux;
            // let wy = uy
            // console.log("SVG output", endX, endY, wx, wy);
            var x = Math.min(startX, endX) / deepICRCTX.imageScale;
            var y = Math.min(startY, endY) / deepICRCTX.imageScale;
            var w = Math.abs(endX - startX) / deepICRCTX.imageScale;
            var h = Math.abs(endY - startY) / deepICRCTX.imageScale;

            if (deepICRCTX.croppingToolId === 1) {
                document.getElementById("croppingOutputDiv").scrollLeft += startX - endX;
                document.getElementById("croppingOutputDiv").scrollTop += startY - endY;
                document.getElementById("mySVG").style.cursor = "grab";
            }

            if (deepICRCTX.croppingToolId === 3) {

                if (w > 5 && h > 5) {
                    const padding = 4
                    // const currentX = e.nativeEvent.offsetX
                    // const currentY = e.nativeEvent.offsetY
                    const currentX = ux
                    const currentY = uy

                    let shapes = deepICRCTX.shapeListRight;

                    let counter = objectSize(shapes[page_index]) + 1;
                    let shape_index = "sr_" + counter;

                    // label === 'Table' ? updateOutputJson(overLappedTable, shape_index, drawBoxX2, drawBoxX1, drawBoxY1) : console.log();

                    if (page_index in shapes) {
                        shapes[page_index][shape_index] = { type: "rect", x: x, y: y, width: w, height: h, label: "", meta: "", isSelected: true };
                    }
                    else {
                        shapes[page_index] = {}
                        shapes[page_index][shape_index] = { type: "rect", x: x, y: y, width: w, height: h, label: "", meta: "", isSelected: true };
                    }

                    let shape = deepCopy(shapes[page_index][shape_index]);
                    shape['image_id'] = page_index;
                    shape['shape_id'] = shape_index;
                    shape['label'] = "Blank";

                    if (wy + 240 > window.innerHeight) {
                        wy = wy - 440;
                    }
                    if (wx + 240 > window.innerWidth) {
                        wx = wx - 284;
                    }
                    // const selectedText = extractSelectedText()
                    // console.log("Selected Text", selectedText);
                    setDeepICRCTX({
                        ...deepICRCTX,
                        shapeCounter: counter,
                        currentShapeRight: [],
                        selectedShapeRight: [shape],
                        shapeListRight: shapes,
                        popUpDialog: {
                            image_id: page_index,
                            shape_id: shape_index,
                            label: "Blank",
                            meta: "",
                            left: wx,
                            top: wy,
                            testShow: true,
                        },
                    });
                }
                else {
                    setDeepICRCTX({
                        ...deepICRCTX,
                        currentShapeRight: [],
                    });
                }
            }
        }

    }
    // console.log("width boundary",deepICRCTX.inputViewerBounds.bounds.width);

    function orderShapeSelectionLayer(shapeList, image_id, shape_id) {
        // console.log("this is order layer");
        for (let i in shapeList) {
            if (i === image_id) {
                let temp = {};
                let filter = {}
                for (let s in shapeList[i]) {
                    if (s === shape_id) {
                        temp[s] = shapeList[i][s];
                    }
                    else {
                        filter[s] = shapeList[i][s];
                    }
                }
                shapeList[i] = Object.assign(temp, filter);
            }
        }
        return shapeList;
    }

    function isTwoLineIntersect(a, b, c, d, p, q, r, s) {
        // console.log("this is twi liner");
        var det, gamma, lambda;
        det = (c - a) * (s - q) - (r - p) * (d - b);
        if (det === 0) {
            return false;
        }
        else {
            lambda = ((s - q) * (r - a) + (p - r) * (s - b)) / det;
            gamma = ((b - d) * (r - a) + (c - a) * (s - b)) / det;
            return (0 < lambda && lambda < 1) && (0 < gamma && gamma < 1);
        }
    }

    // useEffect(()=>{
    //     setDeepICRCTX({...deepICRCTX,pageVisited:deepICRCTX.pageVisited})
    // },[deepICRCTX.pageVisited])

    useEffect(() => {
        if (deepICRCTX.jsonImported === false) {
            setDeepICRCTX({
                ...deepICRCTX,
                pageVisited: {}
            })
        }
        if (deepICRCTX.jsonImported === true) {
            // console.log("entered");
            // console.log("pageVisited",deepICRCTX.pageVisited);
            if (deepICRCTX.pageVisited[deepICRCTX.pdfPage] === undefined || deepICRCTX.pageVisited[deepICRCTX.pdfPage] !== 'visited') {
                let shape = deepICRCTX.shapeListRight
                for (let s in shape) {
                    let pageNo = s.split('_')[3]
                    // console.log({ pageNo });
                    if (pageNo == deepICRCTX.pdfPage) {
                        let page = shape[s]
                        for (let sr in page) {
                            let x1 = page[sr].x * deepICRCTX.imageScale
                            let x2 = x1 + (page[sr].width * deepICRCTX.imageScale)
                            let y1 = page[sr].y * deepICRCTX.imageScale
                            let y2 = y1 + (page[sr].height * deepICRCTX.imageScale)
                            let shape_id = page[sr].shape_id
                            let meta = page[sr].meta
                            let isSelected = page[sr].isSelected
                            if (typeof deepICRCTX.originalOutputData.data[deepICRCTX.pdfPage] !== 'undefined') {
                                jsonImportDataExtraction(x1, y1, x2, y2, shape_id, meta, isSelected)
                            }
                        }
                    }
                }
                let pageVisited = { ...deepICRCTX.pageVisited, [deepICRCTX.pdfPage]: 'visited' }
                setDeepICRCTX({
                    ...deepICRCTX,
                    pageVisited: pageVisited
                })
            }
        }

        // ,deepICRCTX.pageVisited
    }, [deepICRCTX.jsonImported, deepICRCTX.pdfPage, deepICRCTX.trackImport])

    useEffect(() => {
        if (document.getElementById("mySVG")) {
            if (deepICRCTX.croppingToolId === 1) {
                document.getElementById("mySVG").style.cursor = "grab";
            } else {
                document.getElementById("mySVG").style.cursor = "default";
            }
        }
    }, [deepICRCTX.croppingToolId]);

    useEffect(() => {
        if (shouldJsonTriggered) {
            dataExtraction()
        }
    }, [shouldJsonTriggered])

    useEffect(
        formatOutputJson,
        [
            JSON.stringify(deepICRCTX.croppedImages),
            JSON.stringify(deepICRCTX.originalOutputData),
            JSON.stringify(deepICRCTX.originalOutputTable)
        ]
    );

    // if(location.state === 'template-library'){
    //     setIsTriggerredCharacterSegmentation(!isTriggerredCharacterSegmentation)
    // }

    useEffect(() => {
        const elem = document.getElementById('outerdiv')
        // console.log("Element", elem);
        const characterDivs = elem?.getElementsByClassName("character");
        // Create a range object
        const range = document.createRange();
        const updateCharacterWidths = () => {
            const updatedWidths = [];
            const getText = []
            // Iterate over each character div
            for (let i = 0; i < characterDivs?.length; i++) {
                const characterDiv = characterDivs[i];
                // console.log("Character:", characterDiv);
                // Set the range to encompass the parent div's contents
                range.selectNodeContents(characterDiv);
                getText.push(range.toString())
                // console.log(range.toString());
                // Set the range start position to the current character index
                range.setStart(characterDiv, 0);

                // // Set the range end position to the next character index
                range.setEnd(characterDiv, 1);

                // // Get the client rect of the range
                const clientRect = range.getClientRects()[0];
                // console.log("Client Rect",clientRect);

                // // The width of the character
                const characterWidth = clientRect?.width;
                // Update the widths array with the character width
                if (characterWidth === undefined) {
                    updatedWidths.push(2)
                } else {
                    updatedWidths.push(characterWidth);
                }
                // console.log("Character Width", characterWidth);
            }
            setCharacterWidths(updatedWidths)
            setTempText(getText)
        }

        let promiseFunc = new Promise(function (resolve, reject) {
            resolve(updateCharacterWidths())
        })

        promiseFunc.then(() => {
            if (deepICRCTX.tempShape && deepICRCTX.tempShape !== "") {
                updatedDataExtraction(deepICRCTX.textModify.dbx1, deepICRCTX.textModify.dby1, deepICRCTX.textModify.dbx2, deepICRCTX.textModify.dby2, deepICRCTX.tempShape, 'Modified', deepICRCTX.textModify.meta, deepICRCTX.textModify.isSelected)
            }
        })

    }, [isSwitch, deepICRCTX.pdfPage, deepICRCTX.imageScale, location.key])


    // ,deepICRCTX.imageScale
    // console.log("Initial context checking",deepICRCTX.textModify);
    var index = -1

    if ((deepICRCTX.outputSw === false) && (deepICRCTX.documentId === "")) {
        return (
            <div style={{ fontSize: `${deepICRCTX.size}px` }} />
        );
    }
    let pageNumber = 1;
    if (deepICRCTX.file.type === 'application/pdf') {
        pageNumber = deepICRCTX.pdfPage;
    }

    if (typeof deepICRCTX.originalOutputData.data[pageNumber] === 'undefined') {
        return (
            <div style={{ fontSize: deepICRCTX.defaultSize * deepICRCTX.originalOutputFontScale + 10, margin: "auto" }}>
                {t('infoNotSpecified')}
            </div>
        );
    } else {
        let ratio = deepICRCTX.imageScale;
        let width = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
        let height = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

        if (pageNumber in deepICRCTX.originalOutputData.data) {
            ratio = width * deepICRCTX.imageScale / deepICRCTX.originalOutputData.data[pageNumber].width;
        }

        global.inputViewerWidth = width;
        global.inputViewerHeight = height;
        let fontsize = 72 * deepICRCTX.imageScale * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale;
        if (fontsize > 20) fontsize = 20;

        // console.log("Table data",deepICRCTX.originalOutputTable);
        return (
            <div
                className={'croppingOutputDiv'}
                id='croppingOutputDiv'
                style={{
                    width: deepICRCTX.inputViewerBounds.bounds.width,
                    height: deepICRCTX.inputViewerBounds.bounds.height,
                    overflow: "auto",
                }}
                onScroll={(e) => {
                    if (deepICRCTX.outputSw === true && deepICRCTX.isSelection === false) {
                        document.getElementById('imgDiv').scrollLeft = document.querySelector('.croppingOutputDiv').scrollLeft;
                        document.getElementById('imgDiv').scrollTop = document.querySelector('.croppingOutputDiv').scrollTop;
                    }
                }}
            >
                {
                    deepICRCTX.selectedButton ? 
                    <svg
                        id="mySVG"
                        height={height * deepICRCTX.imageScale}
                        width={width * deepICRCTX.imageScale}
                        style={{ boxShadow: "0px 0px 0px 1px #e3e3e3", }}
                        ref={svgRef}
                        onClick={(e) => handleMouseClick(e)}
                        key={deepICRCTX.isImage}
                        data-status={checkChange}
                        data-change={checkChange}
                    >
                        <foreignObject
                            x="0" y="0"
                            width="100%" height="100%"
                        >
                            <div
                                id={'originalOutputViewer'}
                                style={{
                                    position: 'relative',
                                    width: width * deepICRCTX.imageScale,
                                    minHeight: height * deepICRCTX.imageScale,
                                }}
                            >
                                {
                                    deepICRCTX.isSelection === false && <div
                                        id="outerdiv"
                                        style={{
                                            position: 'relative',
                                            left: 0,
                                            top: 0,
                                            width: width * deepICRCTX.imageScale,
                                            height: height * deepICRCTX.imageScale,
                                            border: '1px solid #ddd',
                                        }}>
                                        {deepICRCTX.originalOutputData.data[pageNumber].data.map((data) => {
                                            var dx = (data.x * ratio)
                                            return data?.text ? (

                                                Array.from(data.text).map((currElem, ind, array) => {
                                                    index = index + 1
                                                    dx = ind === 0 ? dx : characterWidths && characterWidths[index - 1] + dx
                                                    return (
                                                        <div
                                                            key={ind}
                                                            style={{
                                                                position: 'absolute',
                                                                left: dx,
                                                                top: data.y * ratio,
                                                                width: characterWidths[index],
                                                                height: data.height * ratio,
                                                                fontSize: data.height * ratio * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale,
                                                                whiteSpace: 'nowrap',
                                                                color: deepICRCTX.searchText !== "" && data.text !== undefined && data.text.indexOf !== undefined && data.text.indexOf(deepICRCTX.searchText) >= 0 ? "#000" : data.color,
                                                                padding: 0,
                                                                margin: 0,
                                                                backgroundColor: deepICRCTX.searchText !== "" && data.text !== undefined && data.text.indexOf !== undefined && data.text.indexOf(deepICRCTX.searchText) >= 0 ? "#F5FF5B" : "inherit",
                                                            }}
                                                            // key={data.key}
                                                            id={data.uniqueKey}
                                                            info={data.key}
                                                            className={"character"}
                                                            count={index}
                                                        >
                                                            {currElem}
                                                        </div>
                                                    )
                                                })
                                            ) : ""
                                        }
                                        )
                                        }
                                        {
                                            deepICRCTX.originalOutputTable.data[pageNumber].data.map((table, ind) =>

                                                <div
                                                    style={{
                                                        position: 'absolute',
                                                        left: table.x * ratio,
                                                        top: table.y * ratio,
                                                        width: table.width * ratio,
                                                        height: table.height * ratio,
                                                        border: '1px solid #272727',
                                                        whiteSpace: 'nowrap',
                                                        padding: 0,
                                                        margin: 0,
                                                    }}
                                                    key={table.key}
                                                    id={table.uniqueKey}
                                                    table={table.key}
                                                    row_no={table.row_no}
                                                    col_no={table.col_no}
                                                    col_span={table.col_span}
                                                    row_span={table.row_span}
                                                >
                                                    {''}
                                                </div>
                                                // }
                                            )
                                        }

                                    </div>
                                }
                            </div>
                            {/* </div> */}
                        </foreignObject>
                        <AllShapes {...props} />
                        <CurrentShape imageIndex={props.imageIndex} />
                        <SelectedShape imageIndex={props.imageIndex} />
                    </svg> :
                        <svg
                            id="mySVG"
                            height={height * deepICRCTX.imageScale}
                            width={width * deepICRCTX.imageScale}
                            style={{ boxShadow: "0px 0px 0px 1px #e3e3e3", }}
                            ref={svgRef}
                            // onClick={(e) => handleMouseClick(e)}
                            onMouseUp={(e) => { handleMouseUp(e) }}
                            onMouseDown={(e) => { handleMouseDown(e) }}
                            onMouseMove={(e) => handleMouseMove(e)}
                            key={deepICRCTX.isImage}
                            data-status={checkChange}
                            data-change={checkChange}
                        >
                            <foreignObject
                                x="0" y="0"
                                width="100%" height="100%"

                            >
                                <div
                                    id={'originalOutputViewer'}
                                    style={{
                                        position: 'relative',
                                        width: width * deepICRCTX.imageScale,
                                        minHeight: height * deepICRCTX.imageScale,
                                    }}
                                >

                                    {deepICRCTX.isSelection === false && <div
                                        id="outerdiv"
                                        style={{
                                            position: 'relative',
                                            left: 0,
                                            top: 0,
                                            width: width * deepICRCTX.imageScale,
                                            height: height * deepICRCTX.imageScale,
                                            border: '1px solid #ddd',
                                        }}>
                                        {deepICRCTX.originalOutputData.data[pageNumber].data.map((data) => {
                                            // console.log({data});
                                            var dx = (data.x * ratio)
                                            return data?.text ? (
                                                Array.from(data.text).map((currElem, ind, array) => {
                                                    index = index + 1
                                                    dx = ind === 0 ? dx : characterWidths && characterWidths[index - 1] + dx
                                                    return (
                                                        <div
                                                            key={ind}
                                                            style={{
                                                                position: 'absolute',
                                                                left: dx,
                                                                top: data.y * ratio,
                                                                width: characterWidths[index],
                                                                height: data.height * ratio,
                                                                fontSize: data.height * ratio * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale,
                                                                whiteSpace: 'nowrap',
                                                                color: deepICRCTX.searchText !== "" && data.text !== undefined && data.text.indexOf !== undefined && data.text.indexOf(deepICRCTX.searchText) >= 0 ? "#000" : data.color,
                                                                padding: 0,
                                                                margin: 0,
                                                                backgroundColor: deepICRCTX.searchText !== "" && data.text !== undefined && data.text.indexOf !== undefined && data.text.indexOf(deepICRCTX.searchText) >= 0 ? "#F5FF5B" : "inherit",
                                                            }}
                                                            // key={data.key}
                                                            id={data.uniqueKey}
                                                            info={data.key}
                                                            count={index}
                                                            className={"character"}
                                                        >
                                                            {currElem}
                                                        </div>
                                                    )
                                                })
                                            ) : ""
                                        }
                                        )
                                        }
                                        {
                                            deepICRCTX.originalOutputTable.data[pageNumber].data.map((table, ind) =>

                                                <div
                                                    style={{
                                                        position: 'absolute',
                                                        left: table.x * ratio,
                                                        top: table.y * ratio,
                                                        width: table.width * ratio,
                                                        height: table.height * ratio,
                                                        border: '1px solid #272727',
                                                        whiteSpace: 'nowrap',
                                                        padding: 0,
                                                        margin: 0,
                                                    }}
                                                    key={table.key}
                                                    id={table.uniqueKey}
                                                    table={table.key}
                                                    row_no={table.row_no}
                                                    col_no={table.col_no}
                                                    col_span={table.col_span}
                                                    row_span={table.row_span}
                                                >
                                                    {''}
                                                </div>
                                                // }
                                            )
                                        }
                                    </div>
                                    }
                                </div>
                                {/* </div> */}
                            </foreignObject>
                            <AllShapes {...props} />
                            <CurrentShape imageIndex={props.imageIndex} />
                            <SelectedShape imageIndex={props.imageIndex} />

                        </svg>
                }
                {/* label={label} setLabel={setLabel} pass below as parameter */}
                {deepICRCTX.popUpDialog.testShow && <PopupDialogOutput meta={meta} setMeta={setMeta} setShouldJsonTriggered={setShouldJsonTriggered} />}
            </div>
        );
    }
}


export default withSnackbar(CroppingOutput);
