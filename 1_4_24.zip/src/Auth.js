import React, { useContext } from "react";
import { Redirect } from "react-router-dom";

// import resource files
import DeepICRContext from "./resources/DeepICRContext";

// [React function component]
// Authentication Wrapper component
export const Auth = (props) => {
  const [deepICRCTX] = useContext(DeepICRContext);
  return deepICRCTX.isLogin ? props.children : <Redirect to={"/login"} />;
};

export default Auth;
