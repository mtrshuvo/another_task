import React, { useContext, useState, useEffect, useRef } from "react";
import IconButton from "@material-ui/core/IconButton";
import { useTranslation } from "react-i18next";
import { Backdrop, Dialog, Fade, Menu, MenuItem, Modal, makeStyles, withStyles } from "@material-ui/core";
import { withSnackbar } from "notistack";
import Toolbar from "@material-ui/core/Toolbar";
import Divider from "@material-ui/core/Divider";
import Typography from "@material-ui/core/Typography";
import MenuBar from "../MenuBar/MenuBar";

import Button from "@material-ui/core/Button";
import { Link } from 'react-router-dom';
import { useHistory } from "react-router-dom";


import { Table, Checkbox, TableHead, TableRow, TableCell, TableBody, TablePagination, TextField } from '@material-ui/core';

//icons
import DeleteIcon from '@material-ui/icons/Delete';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import DeepICRContext from "../resources/DeepICRContext";
import ArrowUpwardIcon from '@material-ui/icons/ArrowUpward';
import ArrowDownwardIcon from '@material-ui/icons/ArrowDownward';
import { BsUpload } from "react-icons/bs";
import FolderOpenIcon from '@material-ui/icons/FolderOpen';
import FileCopyIcon from '@material-ui/icons/FileCopy';
import useSetInfo from "../useHook/setInfo";

const useStyles = makeStyles((theme) => ({

    blueTableCell: {
        backgroundColor: "#4169E1",
        color: '#fff',
        padding: '8px',
        alignItems: 'center',
    },
    styleToolBar: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',

        minHeight: '100vh',
        backgroundColor: 'white',
        [theme.breakpoints.down('sm')]: {
            flexDirection: 'column',
        }
    },
    styleDivToolbar: {
        width: "49.6%",
        display: "flex",
        margin: "auto",
        backgroundColor: "#ffffff",
        padding: ".3rem 0"
    },
    styleDivider: {
        margin: theme.spacing(1),
    },

    styleSpacer: { flexGrow: 1 },
    styleFileUpload: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,
        "&:hover": {
            color: theme.palette.deepICR.blue4
        },
        marginRight: 20
    },
    stylePageNumberInputRoot: {
        color: "inherit",
        fontSize: "0.9rem",
    },
    stylePageNumberInput: {
        padding: theme.spacing(1, 1, 1, 2),
        transition: theme.transitions.create("width"),
        width: "100%",
    },
    styleConvert: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,
        "&:hover": {
            color: theme.palette.deepICR.blue4
        }
    },
    styleOkButton: {
        color: theme.palette.deepICR.modalCancelColor,
        borderRadius: 2,
        "&:hover": {
            color: theme.palette.deepICR.blue4
        }
    },
    styleCancelButton: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,
        borderColor: theme.palette.deepICR.blue4,
        "&:hover": {
            color: theme.palette.deepICR.blue4
        }
    },
    styleFormat: {
        border: `1px solid #e2e2e2`,
        padding: "0 .5rem",
        borderRadius: "5px",
        "& .MuiSelect-icon": {
            color: theme.palette.deepICR.blue4,
        },
        "& .MuiInput-underline": {
            borderBottom: "none",
        },
        "& .MuiInput-underline:hover": {
            borderBottom: "none",
        },
        "& .MuiInputBase-root:hover .MuiInput-underline": {
            borderBottom: "none",
        },
    },
    inputUnderline: {
        '&.MuiInput-underline:before': {
            borderBottom: `none`,
        },
        "&.MuiInput-root:hover .MuiInput-underline ": {
            border: "none"
        },
    },
    styleType: {},
    styleExport: {
        color: theme.palette.deepICR.color,
        backgroundColor: theme.palette.deepICR.blue4,
        borderRadius: 2,
        "&:hover": {
            color: theme.palette.deepICR.blue4,
        }
    },
    modalContainer: {
        width: '60%',
        height: '80%',
        marginBottom: '100px',
        [theme.breakpoints.down('md')]: {
            width: '80%',
        },
        [theme.breakpoints.down('sm')]: {
            width: '90%',
            height: 'auto',
            marginBottom: '50px',
        },
    },
    modalHeader: {
        marginBottom: theme.spacing(2),
        display: 'flex',
        justifyContent: 'space-between',
    },


}));
// Customizing Button component with disabled styles
const CustomButton = withStyles({
    outlined: {
        "&$disabled": {
            color: "#ffffff",
            backgroundColor: "#888888",
        },
    },
    disabled: {},
})(Button);


function TemplateLibraryPage(props) {
    const [templateData, setTemplateData] = useState([]);
    const [selectAllChecked, setSelectAllChecked] = useState(false);
    const [anyCheckboxChecked, setAnyCheckboxChecked] = useState(false);
    const [rowsPerPage, setRowsPerPage] = useState(5);
    const [pageNumber, setPageNumber] = useState(1);
    const [selectedRows, setSelectedRows] = useState([]);
    const [totalPages, setTotalPages] = useState(null);
    const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
    const [anchorEl, setAnchorEl] = React.useState(null);
    const [t] = useTranslation(); // for multiple language
    const [abortController, setAbortController] = useState(null);
    const [totalData, setTotalData] = useState(null);
    const [sortKey, setSortKey] = useState("template_name");
    const [sortOrder, setSortOrder] = useState("ASC");
    
    const {getData} = useSetInfo()


    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };
    // Styles hook
    const styles = useStyles();


    // History hook for navigation
    const history = useHistory();

    // Function to handle return navigation
    const handleReturn = () => {
        history.push("/deepICR", "template-library");
    };

    // PageNumber and rowsperpage change -> call fetch API
    useEffect(() => {
        handleFetchData(pageNumber);
        return ()=> {
            if(abortController){
                abortController.abort()
            }
        } 
    }, [pageNumber, sortKey, sortOrder]);


    // Effect to check if any checkbox is checked
    useEffect(() => {
        const checked = templateData.some(template => template.selected);
        setAnyCheckboxChecked(checked);
    }, [templateData]);


 

    //handling FetchData to manage API calls
    // If frequent API call then abort previous API request
    const handleFetchData = (pageNum, rowsPerP) => {
        fetchData(pageNum, rowsPerP);

    };

    //  Fetching data according to page no and limit
    const fetchData = async (pageNum, rowsPerP) => {
        let abortController = new AbortController();
        setAbortController(abortController);
        try {
            const userInfo = getData()
            // const requestBody = {
            //     "contract_id" : userInfo.contract_id,
            //     "user_id" : userInfo.user_id,
            //     "page_no" : pageNumber,
            //     "limit" : rowsPerPage,
            //     "sort_key" : sortInfo.sortKey,
            //     "sort_order": sortInfo.sortOrder
            // }

            //for local
            const requestBody = {
                "contract_id" : "55p04s09ma85e5gjcnb8g1tsthu",
                "user_id" : "546546521",
                "page_no" : pageNumber,
                "limit" : rowsPerPage,
                "sort_key" : sortKey,
                "sort_order": sortOrder
            };
            const response = await fetch(
                deepICRCTX.apiUrlBase + deepICRCTX.apitemplateLibrary,
                { 
                    method: "POST",
                mode: "cors",
                body:JSON.stringify(requestBody),
                headers: {
                    "Content-Type": "application/json",
                    "x-api-key": "bt0PdkDK7z7Adzg0qpIlo87gzVcdUunO4J0NH4C4"
                },
                    signal: abortController.signal }
            );
            if (!response.ok) {
                throw new Error('Failed to fetch data');
            }
            const data = await response.json();
            console.log("data", data);
            // Map over the fetched data to transform it into the required format
            const updatedData = data.templates.map(todo => ({
                templateName: todo.template_name,
                status: todo.Status,
                userId: todo.user_id,
                updateTime: todo.update_time,
                selected: selectedRows.some(row => row.templateName === todo.id)
            }));
            const allChecked = updatedData.every(row => row.selected);
            setSelectAllChecked(allChecked);
            setTemplateData(updatedData);
            setTotalData(data.total_templates);
        } catch (error) {
            console.error('Error loading template data:', error);
        }
    };

    // Function to handle deletion of a row
    const handleDeleteRow = (id) => {
        setTemplateData(prevData => prevData.filter(template => template.id !== id));
    };


    // Function to handle selecting all checkboxes
    const handleSelectAll = (event) => {
        const checked = event.target.checked;
        setSelectAllChecked(checked);
        // Updating the template data with the selected state of all checkboxes
        const updatedTemplateData = templateData.map(template => ({
            ...template,
            selected: checked
        }));
        setTemplateData(updatedTemplateData);
        // Updating the selected rows state based on the select all checkbox state
        if (checked) {
            setSelectedRows(updatedTemplateData);
        } else {
            setSelectedRows([]);
        }
    };

    // Function to handle deletion of all selected rows
    const handleDeleteAll = () => {
        const updatedTemplateData = templateData.filter(template => !template.selected);
        setTemplateData(updatedTemplateData);
        setSelectAllChecked(false);
        setAnyCheckboxChecked(false);
    };

    // Function to handle change in row checkbox
    const handleRowCheckboxChange = (id, checked) => {
        // Updating the template data with the selected state of the checkbox
        const updatedTemplateData = templateData.map(template => {
            if (template.id === id) {
                return { ...template, selected: checked };
            }
            return template;
        });
        setTemplateData(updatedTemplateData);

        // Updating the selected rows based on the checkbox state
        if (checked) {
            setSelectedRows(prevRows => [...prevRows, { id }]);
        } else {
            setSelectedRows(prevRows => prevRows.filter(row => row.id !== id));
        }

        // Check if any row is selected
        const anyRowSelected = updatedTemplateData.some(template => template.selected);
        setAnyCheckboxChecked(anyRowSelected);
    };



    // Function to handle rows per page change
    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value));
        handleFetchData(pageNumber, parseInt(event.target.value))
    };


    // Function to check if any row is selected
    const isAnyRowSelected = selectedRows.length > 0;


    // Effect to calculate total pages based on rows per page
    useEffect(() => {
        const totalPagesCount = Math.ceil(totalData / rowsPerPage);
        setTotalPages(totalPagesCount);
    }, [rowsPerPage, totalData]);

    // Effect to render page buttons
    useEffect(() => {
        renderPageButtons();
    }, [totalPages, pageNumber]);

    // Function to render pagination buttons
    const renderPageButtons = () => {
        const pageButtons = [];
        const maxButtons = 7;
        const sideButtons = Math.floor((maxButtons - 3) / 2);
        const visiblePages = Math.min(totalPages, maxButtons);

        let startPage = 1;
        let endPage = visiblePages;
        // Adjust start and end page numbers based on current page number
        if (pageNumber > sideButtons + 2) {
            startPage = Math.min(pageNumber - sideButtons, totalPages - maxButtons + 3);
            endPage = Math.min(pageNumber + sideButtons, totalPages);
        }
        // Add the first page button
        pageButtons.push(
            <IconButton key={1} onClick={() => { setPageNumber(1); handleFetchData(1) }} style={pageNumber === 1 ? { backgroundColor: '#26890d' } : {}}>
                1
            </IconButton>
        );

        if (startPage > 2) {
            pageButtons.push(
                <IconButton key="ellipsis-left" disabled >
                    .....
                </IconButton>
            );
        }
        // Add page buttons for the range of visible pages
        for (let i = startPage + 1; i < endPage; i++) {
            pageButtons.push(
                <IconButton key={i} onClick={() => { setPageNumber(i); handleFetchData(i) }} style={pageNumber === i ? { backgroundColor: '#26890d' } : {}}>
                    {i}
                </IconButton>
            );
        }
        // console.log(pageNumber);
        if (endPage < totalPages) {
            pageButtons.push(
                <IconButton key="ellipsis-right" disabled >
                    .....
                </IconButton>
            );
        }
        // Add the last page button if there are multiple pages
        if (totalPages > 1) {
            pageButtons.push(
                <IconButton key={totalPages} onClick={() => { setPageNumber(totalPages); handleFetchData(totalPages) }} style={pageNumber === totalPages ? { backgroundColor: '#26890d' } : {}}>
                    {totalPages}
                </IconButton>
            );
        }

        return pageButtons;
    };

    // Effect to trigger upload button on enter key press
    // useEffect(() => {
    //     setDeepICRCTX({
    //         ...deepICRCTX,
    //         outputTab: 0
    //     })
    //     const handleKeyPress = (event) => {
    //         if (event.key === 'Enter') {
    //             alert('Upload button is triggered');
    //             document.getElementById('uploadButton').click();
    //         }
    //     };
    //     document.body.addEventListener('keydown', handleKeyPress);

    //     return () => {
    //         document.body.removeEventListener('keydown', handleKeyPress);
    //     };
    // }, []);


    // Function to handle sorting by title
    const handleSortByTitle = (sortBy) => {
        if(sortBy === sortKey){
            setSortKey(sortBy)
            setSortOrder(sortOrder === "ASC"? "DESC": "ASC")
        }else{
            setSortKey(sortBy)
            setSortOrder("DESC")
        }
    };

    // file upload
    const filesUpload = async(e, filesOrFolder) => {
        console.log(e.target.files);
        
        let files = e.target.files;
        if(Array.from(e.target.files).length <= 0 ) {
            props.enqueueSnackbar(t("No files selected"), {
                variant: "error",
                anchorOrigin: { vertical: "top", horizontal: "right" },
              });
              return;
        }
        if(filesOrFolder === "files"){
            files = Array.from(files).filter((f)=> f.type === "application/zip");
        }
        if(filesOrFolder === "folder"){
            const parentFolderName = files[0].webkitRelativePath.split("/")[0];
            console.log("paren folder name", parentFolderName);
            const subfolderRegex = new RegExp(`^${parentFolderName}/[^/]+\.zip$`);
            files = Array.from(files).filter(v=> subfolderRegex.test(v.webkitRelativePath))
            // console.log("files", files);
            if (files.length <= 0) {
                props.enqueueSnackbar(t("No files selected"), {
                    variant: "error",
                    anchorOrigin: { vertical: "top", horizontal: "right" },
                  });
                  return;
            }
        }
        
        const snackbarUploading = props.enqueueSnackbar(t("Uploading template files…"), {
            variant: "success",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
        for (let file of files){
            console.log(file);
            uploadFile(file).then(async res=> {            
                props.enqueueSnackbar(t("File Uploaded successfully"), {
                    variant: "success",
                    anchorOrigin: { vertical: "top", horizontal: "right" },
                  }); 
            }).catch(err=> {
                props.enqueueSnackbar(t("Upload unsuccessful"), {
                    variant: "success",
                    anchorOrigin: { vertical: "top", horizontal: "right" },
                  });
            })
        }
        props.closeSnackbar(snackbarUploading);
        props.enqueueSnackbar(t("All template files have been uploaded. NEED TO CHECK successfully uploaded"), {
            variant: "success",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          }); 
    }
           
   async function uploadFile(file){
    
    //get presigned url
    const generatedURL = await presignedUrlGenerator("dummy", "keys", "userhash", "PUT");

    await fetch(generatedURL, {
        method: "PUT",
        mode: "cors",
        // headers: {}
        body: file
    })



    //upload object with the presigned url



    //return path if success or return file name if failed

  };

  /**
   * 
   * @param {string} bucket 
   * @param {string} keys 
   * @param {string} operation // get or put
   */
  const presignedUrlGenerator = async (bucket, keys, userHash, operation) => {
    const requestBody = {
        keys: ["files" + "/" + "" ],
        operation

    }
    const request = await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
       method: "POST",
       mode: "cors",
       headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
        body: JSON.stringify(requestBody),
    })
  }


    return (
        <div>
            <MenuBar />


            <div className={styles.styleToolBar}>


                <div className={styles.modalContainer}>
                    <div style={{ marginBottom: '50px', width: "60%" }}>
                        {/* <input
                            type="file"
                            webkitdirectory
                            mozdirectory
                            multiple
                            accept="/.json"
                            style={{ display: "none" }}
                            id="fileUploadInputButton"
                            onChange={filesUpload}

                        />
                        <label htmlFor="fileUploadInputButton">
                            <Button
                                id="uploadButton"
                                startIcon={<BsUpload />}
                                className={styles.styleFileUpload} variant="outlined" component="h6">
                                <Typography variant="h6">Upload</Typography>
                            </Button>
                        </label> */}

                     


                        <CustomButton variant="outlined" className={styles.styleFileUpload} disabled={!anyCheckboxChecked}>
                            <Typography variant="h6">Download</Typography>
                        </CustomButton>

                        <CustomButton onClick={handleDeleteAll} variant="outlined" className={styles.styleFileUpload} disabled={!anyCheckboxChecked}>
                            <Typography variant="h6">Delete</Typography>
                        </CustomButton>


                    </div>

                    <div style={{ maxHeight: "calc(100vh - 25%)", overflowY: "auto" }}>


                        <Table style={{ marginBottom: '70px' }}>
                            <TableHead>
                                <TableRow>
                                    <TableCell style={{ fontSize: '17px' }} className={styles.blueTableCell}>
                                        <Checkbox
                                            checked={selectAllChecked}
                                            onChange={handleSelectAll}
                                        />
                                        Select All
                                    </TableCell>
                                   
                                    <TableCell className={styles.blueTableCell} style={{ fontSize: '17px' }}>Template Name <IconButton onClick={()=> handleSortByTitle("template_name")} style={{ color: '#fff' }}>
                                        {
                                           (sortKey==="template_name" && sortOrder === 'ASC') ?
                                                <ArrowUpwardIcon  /> :
                                                <ArrowDownwardIcon />
                                        }
                                    </IconButton></TableCell>
                                    <TableCell className={styles.blueTableCell} style={{ fontSize: '17px' }}>Status</TableCell>
                                    <TableCell className={styles.blueTableCell} style={{ fontSize: '17px' }}>Update Time <IconButton onClick={()=> handleSortByTitle("update_time")} style={{ color: '#fff' }}>
                                        {
                                          ( sortKey === "update_time" &&  sortOrder === 'ASC') ?
                                                <ArrowUpwardIcon /> :
                                                <ArrowDownwardIcon />
                                        }
                                    </IconButton></TableCell>
                                    <TableCell className={styles.blueTableCell} style={{ fontSize: '17px' }}>User</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {templateData.map(template => (
                                    <TableRow key={template.id}>
                                        <TableCell>
                                            <Checkbox
                                                checked={template.selected}
                                                onChange={(event) => handleRowCheckboxChange(template.id, event.target.checked)}
                                            />
                                        </TableCell>
                                        <TableCell style={{ fontSize: '17px' }}>{template.templateName}</TableCell>
                                        <TableCell style={{ fontSize: '17px' }}>{template.status}</TableCell>
                                        <TableCell style={{ fontSize: '17px' }}>{template.updateTime}</TableCell>
                                        <TableCell style={{ fontSize: '17px' }}>{template.userId}</TableCell>
                                        {/* <TableCell>
                                            <IconButton aria-label="delete" onClick={() => handleDeleteRow(template.id)}>
                                                <DeleteIcon />
                                            </IconButton>
                                        </TableCell> */}
                                    </TableRow>
                                ))}
                            </TableBody>


                        </Table>
                    </div>

                    <TablePagination
                        rowsPerPageOptions={""}
                        component="div"
                        labelRowsPerPage=""
                        count={templateData.length}
                        rowsPerPage={rowsPerPage}
                        style={{ fontSize: '12px' }}
                        onChangeRowsPerPage={handleChangeRowsPerPage}
                        labelDisplayedRows={({ from, to, count }) => null}
                        backIconButtonProps={{ style: { display: 'none' } }}
                        nextIconButtonProps={{ style: { display: 'none' } }}
                    />

                    <Button variant="outlined" className={styles.styleFileUpload} onClick={() => handleReturn()}><Typography variant="h6">Return</Typography></Button>
                    <br />
                    {/* Arrow Pagination */}
                    <div style={{ display: 'flex', justifyContent: 'center' }}>
                        <IconButton onClick={() => { setPageNumber(pageNumber - 1); handleFetchData(pageNumber - 1) }} disabled={pageNumber === 1}>
                            <ArrowBackIcon />
                        </IconButton>
                        {renderPageButtons()}
                        <IconButton onClick={() => { setPageNumber(pageNumber + 1); handleFetchData(pageNumber + 1)}} >
                            <ArrowForwardIcon />
                        </IconButton>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default withSnackbar(TemplateLibraryPage);
