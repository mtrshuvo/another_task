// Dependencies
import React, { useState, useRef, useContext, useEffect } from "react";
import { makeStyles } from "@material-ui/core";
import { useTranslation } from "react-i18next";

// Context
import DeepICRContext from "../resources/DeepICRContext";

// Components
import {
  GetPointsFromShape,
  orderShapeSelectionLayer,
  deepCopy,
  objectSize,
} from "../resources/CommonMethods";

// Making stylesheet
const useStyles = makeStyles((theme) => ({
  tvContainer: {
    display: "block",
    maxHeight: 100,
    padding: "0 10px",
    backgroundColor: "#fff",
  },
  tvHeader: {
    display: "block",
    width: "100%",
    height: 26,
    lineHeight: "26px",
  },
  tvToggler: {
    outline: "none",
    border: "none",
    color: "#26890d",
    background: "none",
    lineHeight: "26px",
    cursor: "pointer",
    padding: 0,
  },
  tvBody: {
    display: "block",
    width: "100%",
    height: 72,
    lineHeight: 72,
    background: "#fff",
  },
  tvItem: {
    position: "relative",
    display: "inline",
    width: "100px",
    height: "70px",
    float: "left",
    background: "#fff",
    lineHeight: "70px",
    marginRight: 10,
    border: "1px solid #ddd",
    textAlign: "center",
    overflow: "hidden",
  },

  selectedItem: {
    border: "1px solid green",
  },
  itemNumber: {
    left: 0,
    top: 0,
    position: "absolute",
    background: "#ff0066a8",
    display: "inlne-block",
    fontSize: 12,
    color: "#fff",
    lineHeight: "14px",
    padding: "2px 8px",
    borderBottomRightRadius: 999,
  },
  itemSvg: {
    display: "inline-block",
    verticalAlign: "middle",
  },
}));

const Thumbnail = (props) => {
  const styles = useStyles();
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [draggingElementId, setDraggingElementId] = useState(null);

  const width = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
  const height = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;
  const page_index = "p_" + props.width + "_" + props.height + "_" + (deepICRCTX.pdfPage - 1 + 1);

  let shapes = [];
  let items = [];

  if (deepICRCTX.shapeList !== undefined && deepICRCTX.shapeList[page_index] !== undefined) {
    shapes = deepICRCTX.shapeList[page_index];
  }

  for (let ind = 0; ind < objectSize(shapes); ind++) {
    let key = "s_" + (ind + 1);
    let shape = shapes[key];
    let points = GetPointsFromShape(deepICRCTX, shape);
    let x = Infinity,
      y = Infinity,
      w = -Infinity,
      h = -Infinity;

    for (let i = 0; i < points.length; i++) {
      let px = parseInt(points[i][0]);
      let py = parseInt(points[i][1]);

      if (px < x) x = px;
      if (py < y) y = py;
      if (px > w) w = px;
      if (py > h) h = py;
    }
    w = Math.abs(w - x);
    h = Math.abs(h - y);

    let scale;

    if (w > (10 / 7) * h) scale = 100 / w;
    else scale = 70 / h;

    x = parseInt(x * scale);
    y = parseInt(y * scale);
    w = parseInt(w * scale);
    h = parseInt(h * scale);

    let nw = Math.abs(width * scale);
    let nh = Math.abs(height * scale);

    let viewBox = "0 0 " + w + " " + h;

    let style = "";
    if (deepICRCTX.selectedShape.length > 0) {
      if (key === deepICRCTX.selectedShape[0].shape_id) {
        style = "1px solid #f06";
      }
    }

    if (shape.type === "rect") {
      items.push({
        type: "rect",
        x: x,
        y: y,
        w: w,
        h: h,
        nw: nw,
        nh: nh,
        id: key,
        viewBox: viewBox,
        style: style,
      });
    } else if (shape.type === "ellipse") {
      let rx = parseInt(w / 2);
      let ry = parseInt(h / 2);
      items.push({
        type: "ellipse",
        cx: rx,
        cy: ry,
        rx: rx,
        ry: ry,
        x: x,
        y: y,
        w: w,
        h: h,
        nw: nw,
        nh: nh,
        id: key,
        viewBox: viewBox,
        style: style,
      });
    } else if (shape.type === "polygon") {
      let str_points = "";
      for (let i = 0; i < points.length; i++) {
        let px = parseInt(points[i][0] * scale) - x;
        let py = parseInt(points[i][1] * scale) - y;
        if (i === points.length - 1) {
          str_points += px + "," + py;
        } else {
          str_points += px + "," + py + " ";
        }
      }
      items.push({
        type: "polygon",
        points: str_points,
        x: x,
        y: y,
        w: w,
        h: h,
        nw: nw,
        nh: nh,
        id: key,
        viewBox: viewBox,
        style: style,
      });
    }
  }

  function reorderThumbnail(page_index, s1, s2) {
    let s1_index = parseInt(s1.split("_")[1]);
    let s2_index = parseInt(s2.split("_")[1]);

    let pages = deepICRCTX.shapeList;
    let shapes = pages[page_index];

    if (s1_index < s2_index) {
      let temp = deepCopy(shapes["s_" + s1_index]);
      for (let i = s1_index; i < s2_index; i++) {
        shapes["s_" + i] = deepCopy(shapes["s_" + (i + 1)]);
      }
      shapes["s_" + s2_index] = temp;
    } else if (s1_index > s2_index) {
      let temp = deepCopy(shapes["s_" + s1_index]);
      for (let i = s1_index; i > s2_index; i--) {
        shapes["s_" + i] = deepCopy(shapes["s_" + (i - 1)]);
      }
      shapes["s_" + s2_index] = temp;
    }

    pages[page_index] = shapes;

    setDeepICRCTX({
      ...deepICRCTX,
      selectedShape: [],
      shapeList: pages,
    });
  }

  function handleClick(e) {
    let imageId = e.currentTarget.getAttribute("data-page");
    let shapeId = e.currentTarget.getAttribute("data-shape");

    let shape = deepICRCTX.shapeList[imageId][shapeId];
    shape["image_id"] = imageId;
    shape["shape_id"] = shapeId;

    let shapes = orderShapeSelectionLayer(deepICRCTX.shapeList, imageId, shapeId);

    setDeepICRCTX({
      ...deepICRCTX,
      shapeList: shapes,
      selectedShape: [shape],
    });
  }

  function dragStart(ev) {
    ev.currentTarget.style.border = "1px solid #f06";
    setDraggingElementId(ev.currentTarget.getAttribute("data-shape"));
  }

  function dragEnter(ev) {
    ev.currentTarget.style.border = "1px solid #f06";
  }

  function dragOver(ev) {
    ev.preventDefault();
    ev.currentTarget.style.border = "1px solid #f06";
  }

  function dragLeave(ev) {
    ev.currentTarget.style.border = "1px solid #ddd";
  }

  function dragEnd(ev) {
    ev.currentTarget.style.border = "1px solid #ddd";
  }

  function drop(ev) {
    ev.preventDefault();
    ev.currentTarget.style.border = "1px solid #ddd";
    let droppingElementId = ev.currentTarget.getAttribute("data-shape");
    reorderThumbnail(page_index, draggingElementId, droppingElementId);
  }

  return (
    <div className={styles.tvBody}>
      {items.map((item) => (
        <div
          className={styles.tvItem}
          key={item.id}
          data-page={page_index}
          data-shape={item.id}
          draggable="true"
          onClick={(e) => handleClick(e)}
          onDragStart={(e) => dragStart(e)}
          onDragEnter={(e) => dragEnter(e)}
          onDragOver={(e) => dragOver(e)}
          onDragLeave={(e) => dragLeave(e)}
          onDragEnd={(e) => dragEnd(e)}
          onDrop={(e) => drop(e)}
          style={{ border: item.style }}
        >
          <span className={styles.itemNumber}>{item.id.split("_")[1] + "."}</span>
          <svg x={0} y={0} width={item.w} height={item.h} className={styles.itemSvg}>
            {/* <clipPath id="rect">  
                            <rect x={0} y={0} width={item.w} height={item.h} stroke="#f06" strokeWidth="2" fill="red"/>  
                        </clipPath>  */}
            <image
              clipPath={"url(#t" + item.id + ")"}
              x={-item.x}
              y={-item.y}
              width={item.nw}
              height={item.nh}
              xlinkHref={deepICRCTX.fileBase64[deepICRCTX.pdfPage - 1]}
            />
            {item.type === "rect" && (
              <clipPath id={"t" + item.id} style={{ border: "1px solid red" }}>
                <rect
                  x={0}
                  y={0}
                  width={item.w}
                  height={item.h}
                  stroke="blue"
                  strokeWidth="1"
                  fill="transparent"
                />
              </clipPath>
            )}
            {item.type === "ellipse" && (
              <clipPath id={"t" + item.id} style={{ border: "1px solid red" }}>
                <ellipse
                  cx={item.cx}
                  cy={item.cy}
                  rx={item.rx}
                  ry={item.ry}
                  stroke="blue"
                  strokeWidth="1"
                  fill="transparent"
                />
              </clipPath>
            )}
            {item.type === "polygon" && (
              <clipPath id={"t" + item.id} style={{ border: "1px solid red" }}>
                <polygon points={item.points} stroke="blue" strokeWidth="1" fill="transparent" />
              </clipPath>
            )}
          </svg>
        </div>
      ))}
    </div>
  );
};

const ThumbnailView = (props) => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [buttonTitle, setButtonTitle] = useState("[ ↓ ] ");

  const [t] = useTranslation();

  const styles = useStyles();
  const tvcRef = useRef(null);

  useEffect(() => {
    if (deepICRCTX.isThumbnailOpen === false) {
      const tvc = tvcRef.current;
      tvc.style.height = "100px";
      setButtonTitle("[ ↓ ] ");
    } else {
      const tvc = tvcRef.current;
      tvc.style.height = "30px";
      setButtonTitle("[ ↑ ] ");
    }
  }, [deepICRCTX.isThumbnailOpen]);

  return (
    <div className={styles.tvContainer} ref={tvcRef}>
      <div className={styles.tvHeader}>
        <button
          className={styles.tvToggler}
          onClick={() =>
            setDeepICRCTX({ ...deepICRCTX, isThumbnailOpen: !deepICRCTX.isThumbnailOpen })
          }
        >
          {buttonTitle + t("stringThumbnailButton")}
        </button>
        <small> {t("stringThumbnailDescription")}</small>
      </div>
      {!deepICRCTX.isThumbnailOpen && (
        <Thumbnail height={global.inputViewerHeight} width={global.inputViewerWidth} />
      )}
    </div>
  );
};

export default ThumbnailView;
