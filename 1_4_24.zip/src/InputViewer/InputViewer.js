import React, { useContext } from "react";
import { useTranslation } from "react-i18next";
import { makeStyles } from "@material-ui/core";
import { withSnackbar } from "notistack";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from "@material-ui/core/IconButton";
import ZoomIn from "@material-ui/icons/ZoomIn";
import ZoomOut from "@material-ui/icons/ZoomOut";
import ZoomOutMap from "@material-ui/icons/ZoomOutMap";
import FirstPage from "@material-ui/icons/FirstPage";
import LastPage from "@material-ui/icons/LastPage";
import NavigateBefore from "@material-ui/icons/NavigateBefore";
import NavigateNext from "@material-ui/icons/NavigateNext";
import RotateLeft from "@material-ui/icons/RotateLeft";
import RotateRight from "@material-ui/icons/RotateRight";
import Typography from "@material-ui/core/Typography";
import Measure from "react-measure";
import { deepICRRotate, } from "../deepICRCommon";

// import resource files
import DeepICRContext from "../resources/DeepICRContext";
import { objectSize } from "../resources/CommonMethods";
import SvgImage from "./SvgImage";

// pdfjs Setting
// pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

// Style Sheet
const useStyles = makeStyles((theme) => ({
  styleInputViewer: {
    backgroundColor: theme.palette.deepICR.color,
    color: theme.palette.deepICR.backgroundColor,
    boxSizing: "border-box",
    height: "99.5%",
    display: "flex",
    flexDirection: "column",
    flex: 1,
    overflow: "hidden",
  },
  styleImage: {
    display: "flex",
    flexDirection: "column",
    flexGrow: 1,
    backgroundColor: theme.palette.deepICR.imageBackground,
    margin: theme.spacing(0, 0, 0, 0),
    boxSizing: "border-box",
    height: "100%",
    overflow: "hidden",
  },
  toolBtn: {
    padding: 8,
  },
  button: {
    padding: "3px 6px",
    fontSize: "0.9rem",
  },
  menuItem: {
    padding: "3px 32px 3px 32px",
    fontSize: "0.9rem",
  },
  style_next_prev: {
    color: theme.palette.deepICR.blue4
  }
}));

// [React function component]
// Document viewer component
const DocumentViewer = () => {
  const [deepICRCTX] = useContext(DeepICRContext);
  if (deepICRCTX.file.type === "application/pdf" || deepICRCTX.file.type === "image/jpeg") {
    let width = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
    let height = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

    global.inputViewerWidth = width;
    global.inputViewerHeight = height;

    return (
      <div
        id={"imgDiv"}
        style={{
          width: deepICRCTX.inputViewerBounds.bounds.width,
          height: deepICRCTX.inputViewerBounds.bounds.height,
          overflow: "auto",
        }}
      // onScroll={(e) => {
      //   if(deepICRCTX.outputSw === true && deepICRCTX.isSelection === false){
      //     document.getElementById('originalOutputDiv').scrollLeft = document.getElementById('imgDiv').scrollLeft;
      //     document.getElementById('originalOutputDiv').scrollTop = document.getElementById('imgDiv').scrollTop;
      //   }
      // }}
      >
        <SvgImage height={height} width={width} imageIndex={deepICRCTX.pdfPage - 1} />
      </div>
    );
  } else {
    return <div />;
  }
};

// [React function component]
// Input viewer component

const InputViewer = (props) => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);

  let width = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
  let height = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

  if (deepICRCTX.debug === true) {
    console.log("inputViewer");
  }

  const [t] = useTranslation(); // for multiple language
  const styles = useStyles(); // for material ui style



  return (
    <div className={styles.styleInputViewer}>
      
       <Toolbar style={{ paddingLeft: 0, paddingRight: 0, borderBottom: "1px solid #EAEAF0" }}>
        <div style={{ flexGrow: 1 }}>
         
        </div>
    
        <div>
          <IconButton
            className={styles.toolBtn}
            disabled={typeof deepICRCTX.file.name === "undefined" || deepICRCTX.file.name === ""}
            onClick={() => {
              if (deepICRCTX.imageScale < 2) {
                setDeepICRCTX({
                  ...deepICRCTX,
                  imageScale: deepICRCTX.imageScale + 0.1,
                });
              }
            }}
          >
            <ZoomIn />
          </IconButton>
          <IconButton
            className={styles.toolBtn}
            disabled={typeof deepICRCTX.file.name === "undefined" || deepICRCTX.file.name === ""}
            onClick={() => {
              if (deepICRCTX.imageScale > 0.15) {
                setDeepICRCTX({
                  ...deepICRCTX,
                  imageScale: deepICRCTX.imageScale - 0.1,
                });
              }
            }}
          >
            <ZoomOut />
          </IconButton>
          <IconButton
            className={styles.toolBtn}
            disabled={typeof deepICRCTX.file.name === "undefined" || deepICRCTX.file.name === ""}
            onClick={() => {
              setDeepICRCTX({
                ...deepICRCTX,
                // imageScale: 1,
                imageScale:
                  deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.fileSize[0].width,
              });
            }}
          >
            <ZoomOutMap />
          </IconButton>
          <IconButton
            className={styles.toolBtn}
            disabled={
              deepICRCTX.outputSw === true ||
              deepICRCTX.documentId !== "" ||
              typeof deepICRCTX.file.name === "undefined" ||
              deepICRCTX.file.name === "" ||
              (objectSize(deepICRCTX.shapeList) > 0 &&
                deepICRCTX.shapeList["p_" + width + "_" + height + "_" + deepICRCTX.pdfPage] !==
                undefined &&
                objectSize(
                  deepICRCTX.shapeList["p_" + width + "_" + height + "_" + deepICRCTX.pdfPage]
                ) > 0)
            }
            onClick={() => {
              const dataUrls = deepICRCTX.fileBase64;
              dataUrls[deepICRCTX.pdfPage - 1] = deepICRRotate(
                deepICRCTX.fileBase64[deepICRCTX.pdfPage - 1],
                -90,
                deepICRCTX.fileSize[deepICRCTX.pdfPage - 1]
              );
              const fileSizes = deepICRCTX.fileSize;
              fileSizes[deepICRCTX.pdfPage - 1] = {
                height: deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width,
                width: deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height,
              };
              global.rotation[deepICRCTX.pdfPage - 1] =
                global.rotation[deepICRCTX.pdfPage - 1] - 90;
              if (global.rotation[deepICRCTX.pdfPage - 1] === -360) {
                global.rotation[deepICRCTX.pdfPage - 1] = 0;
              }
              setDeepICRCTX({
                ...deepICRCTX,
                // imageScale: 1,
                fileBase64: dataUrls,
                fileSize: fileSizes,
                imageScale:
                  deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.fileSize[0].width,
              });
            }}
          >
            <RotateLeft />
          </IconButton>
          <IconButton
            // data-id={(objectSize(deepICRCTX.shapeList) > 0)+" "+ (deepICRCTX.shapeList["p_" + width + "_" + height + "_" + (deepICRCTX.pdfPage)] !== undefined )+" "+ (objectSize(deepICRCTX.shapeList["p_" + width + "_" + height + "_" + (deepICRCTX.pdfPage)]) > 0)}
            className={styles.toolBtn}
            disabled={
              deepICRCTX.outputSw === true ||
              deepICRCTX.documentId !== "" ||
              typeof deepICRCTX.file.name === "undefined" ||
              deepICRCTX.file.name === "" ||
              (objectSize(deepICRCTX.shapeList) > 0 &&
                deepICRCTX.shapeList["p_" + width + "_" + height + "_" + deepICRCTX.pdfPage] !==
                undefined &&
                objectSize(
                  deepICRCTX.shapeList["p_" + width + "_" + height + "_" + deepICRCTX.pdfPage]
                ) > 0)
            }
            onClick={() => {
              const dataUrls = deepICRCTX.fileBase64;
              dataUrls[deepICRCTX.pdfPage - 1] = deepICRRotate(
                deepICRCTX.fileBase64[deepICRCTX.pdfPage - 1],
                90,
                deepICRCTX.fileSize[deepICRCTX.pdfPage - 1]
              );
              const fileSizes = deepICRCTX.fileSize;
              fileSizes[deepICRCTX.pdfPage - 1] = {
                height: deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width,
                width: deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height,
              };
              global.rotation[deepICRCTX.pdfPage - 1] =
                global.rotation[deepICRCTX.pdfPage - 1] + 90;
              if (global.rotation[deepICRCTX.pdfPage - 1] === 360) {
                global.rotation[deepICRCTX.pdfPage - 1] = 0;
              }
              setDeepICRCTX({
                ...deepICRCTX,
                // imageScale: 1,
                fileBase64: dataUrls,
                fileSize: fileSizes,
                imageScale:
                  deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.fileSize[0].width,
              });
            }}
          >
            <RotateRight />
          </IconButton>
        </div>
        <div style={{ align: "right" }}>
          <IconButton
            className={styles.toolBtn}
            onClick={() => {
              let pageNumber = deepICRCTX.pdfPage - 1;
              if (pageNumber >= 1) {
                setDeepICRCTX({
                  ...deepICRCTX,
                  pdfPage: pageNumber,
                  selectedShape: [],
                  selectedShapeRight: []
                });
              }
            }}
          >
            <NavigateBefore className={(  deepICRCTX.fileBase64.length > 0) && styles.style_next_prev} />
          </IconButton>
        </div>
        <div>
          <Typography variant="h6" style={{ whiteSpace: "nowrap" }}>
            {deepICRCTX.pdfPage} {"/"} {deepICRCTX.pdfPages}
          </Typography>
        </div>
        <div>
          <IconButton
            className={styles.toolBtn}
            onClick={() => {
              let pageNumber = deepICRCTX.pdfPage + 1;
              if (pageNumber <= deepICRCTX.pdfPages) {
                setDeepICRCTX({
                  ...deepICRCTX,
                  pdfPage: pageNumber,
                  selectedShape: [],
                  selectedShapeRight: []
                });
              }
            }}
          >
            <NavigateNext className={ (deepICRCTX.fileBase64.length > 0) && styles.style_next_prev} />
          </IconButton>
        </div>
      </Toolbar>
      <Toolbar style={{ paddingLeft: 0, paddingRight: 0, borderBottom: "1px solid #EAEAF0" }}>
        <div style={{ flexGrow: 1}}>
          <Typography variant="h6" align="left" style={{ paddingLeft: 8 }}>
            {/* {t("stringInputViewerTitle")} */}
            {
              
            typeof deepICRCTX.file.name !== "undefined" &&
              deepICRCTX.file.name !== "" &&
              deepICRCTX.file.name.length > 110 &&
              deepICRCTX.file.name.substr(0, 95) 
              +
              "..." +
              deepICRCTX.file.name.substr(
                deepICRCTX.file.name.length - 15,
                deepICRCTX.file.name.length
              )
              }
            {typeof deepICRCTX.file.name !== "undefined" &&
              deepICRCTX.file.name !== "" &&
              deepICRCTX.file.name.length < 109 &&
              deepICRCTX.file.name}
          </Typography>
        </div>

      </Toolbar>
      <Measure
        bounds
        onResize={(contentRect) => {
          contentRect.bounds.height = parseInt(contentRect.bounds.height) - 0;
          contentRect.bounds.width = parseInt(contentRect.bounds.width) - 0;
          global.inputViewerBounds = contentRect;
          setDeepICRCTX({
            ...deepICRCTX,
            inputViewerBounds: contentRect,
          });
        }}
      >
        {({ measureRef }) => (
          <div className={styles.styleImage} ref={measureRef}>
            <DocumentViewer />
          </div>
        )}
      </Measure>
      {/* <div className={styles.styleImage}>
        			<DocumentViewer />
      		</div> */}
      <footer style={{ display: "none" }}>
        <Toolbar style={{ paddingLeft: 0, paddingRight: 0 }}>
          <div style={{ paddingLeft: "172px", flexGrow: 1 }}>
            <Typography variant="h6">
              {t("stringInputViewerFile")} 
              {deepICRCTX.file.name}
            </Typography>
          </div>
          <div style={{ align: "right" }}>
            <IconButton
              className={styles.toolBtn}
              onClick={() => {
                let pageNumber = deepICRCTX.pdfPage - 1;
                if (pageNumber >= 1) {
                  setDeepICRCTX({
                    ...deepICRCTX,
                    pdfPage: pageNumber,
                  });
                }
              }}
            >
              <NavigateBefore />
            </IconButton>
          </div>
          <div>
            <IconButton
              className={styles.toolBtn}
              onClick={() => {
                if (deepICRCTX.pdfPage !== 1) {
                  setDeepICRCTX({
                    ...deepICRCTX,
                    pdfPage: 1,
                  });
                }
              }}
            >
              <FirstPage />
            </IconButton>
          </div>
          <div>
            <Typography variant="h6">
              {deepICRCTX.pdfPage} of {deepICRCTX.pdfPages}
            </Typography>
          </div>
          <div>
            <IconButton
              className={styles.toolBtn}
              onClick={() => {
                if (deepICRCTX.pdfPage !== deepICRCTX.pdfPages) {
                  setDeepICRCTX({
                    ...deepICRCTX,
                    pdfPage: deepICRCTX.pdfPages,
                  });
                }
              }}
            >
              <LastPage />
            </IconButton>
          </div>
          <div>
            <IconButton
              className={styles.toolBtn}
              onClick={() => {
                let pageNumber = deepICRCTX.pdfPage + 1;
                if (pageNumber <= deepICRCTX.pdfPages) {
                  setDeepICRCTX({
                    ...deepICRCTX,
                    pdfPage: pageNumber,
                  });
                }
              }}
            >
              <NavigateNext />
            </IconButton>
          </div>
        </Toolbar>
      </footer>
    </div>
  );
};

export default withSnackbar(InputViewer);
