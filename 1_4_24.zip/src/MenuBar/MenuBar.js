import React, { useContext } from "react";
import { useTranslation } from "react-i18next";
import { makeStyles } from "@material-ui/core";
import Toolbar from "@material-ui/core/Toolbar";
import Divider from "@material-ui/core/Divider";
import Typography from "@material-ui/core/Typography";
import { deepICRNow } from "../deepICRCommon";
import { Link } from "react-router-dom"; 


// import react components
import ButtonSwitchLang from "./ButtonSwitchLang";

// import resource files
import DeepICRContext from "../resources/DeepICRContext";
import deepICRLogging from "../Logging/deepICRLogging";
import { MdOutlineLogout } from "react-icons/md"
import PopupModal from "../PopUpModal/PopupModal";
import useCustomModal from "../PopUpModal/useModal";
import { isthereAnyShape } from "../resources/CommonMethods";
// Style Sheet
const useStyles = makeStyles((theme) => ({
  styleMenuBar: {
    flexGrow: 1,
    backgroundColor: theme.palette.deepICR.backgroundColor,
    margin: theme.spacing(0, 0, 0, 0),
    padding: theme.spacing(1, 0, 1, 0),
  },
  styleDivider: {
    height: theme.palette.deepICR.dividerHeight,
    margin: theme.palette.deepICR.dividerMargin,
  },
  styleLogout: {
    color: theme.palette.deepICR.color,
    cursor: "pointer",
    display: "flex",
    alignItems: "center",
    // justifyContent: "center",
    "&:hover": { textDecoration: "underline" },
  },
  styleSpacer: { flexGrow: 1 },
}));

// [React function component]
// Menu bar component
const MenuBar = () => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  if (deepICRCTX.debug === true) {
    console.log("MenuBar");
  }

  const [t] = useTranslation(); // for multiple language
  const styles = useStyles(); // for material ui style
  // convert modal
  const {
    openModal,
    closeModal,
    isOpen
  } = useCustomModal()


  // Do logout (Change isLogin Context to false)
  const doLogout = async () => {


    const [, unixtime, microsec] = deepICRNow();
    let requestJson = {
      type: "request",
      head: {
        command: "signout",
        format_version: deepICRCTX.apiFormatVersion,
        service_id: deepICRCTX.apiServiceId,
        transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
        unix_time: unixtime,
        micro_seconds: microsec,
        time_zone: deepICRCTX.apiTimeZone,
      },
    };
    await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiSignout, {
      method: "POST",
      mode: "cors",
      headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
      body: JSON.stringify(requestJson),
    })
      .then((res) => {
        return res.json();
      })
      .then((json) => {
        if (deepICRCTX.debug === true) {
          console.log(json);
        }
      })
      .catch((err) => {
        if (deepICRCTX.debug === true) {
          console.log("[ToolBar - logout] signout catch error");
        }
        if (deepICRCTX.debug === true) {
          console.log(err);
        }
        deepICRLogging({
          LogType: "ERROR",
          ErrType: "SingOutCatchEror",
          Message: "Sign out catch error",
          Src: "Menubar.js",
          Line: 0,
          Column: 0,
          Stack: "",
        });
      });

    global.accessToken = "";
    global.refreshToken = "";
    global.rotation = [];
    setDeepICRCTX({
      ...deepICRCTX,
      isLogin: false,
      isTerms: false,
      isContract: false,
      changePassword: false,
      documentId: "",
      cognitoUser: {},
      // accessToken: "",
      // refreshToken: "",
      inputViewerBounds: {
        bounds: { height: 100, width: 100, top: 0, bottom: 100, left: 0, right: 100 },
      },
      imageScale: 1,
      outputTab: 0,
      file: {},
      requestedFile: "",
      fileBase64: [],
      fileSize: [{ height: 0, width: 0 }],
      pdfBase64: "",
      pdfPage: 1,
      pdfPages: 1,
      targetPages: "",
      size: 12,
      originalOutputFontScale: 1,
      outputSw: false,
      outputLinkSw: false,
      originalOutputSize: { height: 0, width: 0 },
      originalOutputData: { data: [] },
      originalOutputTable: { data: [] },
      extractedOutputData: { data: [] },
      extractedOutputTable: { data: [] },
      searchText: "",
    });
  }


  const checkBeforeLogOut = () => {
    if (isthereAnyShape(deepICRCTX.selectedRegion)) {
      openModal();
    } else {
      doLogout();
    }
  }

  // Debug
  const debug = () => {
    const json = { ...deepICRCTX, termsOfService: [] };
    console.log(JSON.stringify(json, null, 1));
  };

  return (
    <div className={styles.styleMenuBar}>
      <Toolbar style={{ paddingLeft: 10, paddingRight: 10 }}>
        {/* <img alt="Deloitte. Logo" src="/DEL_g_SEC_RGB.jpg" width="142" height="44" /> */}
        {/* Making the Deloitte Logo Clickable which navigates to DeepICR home page */}
        <Link to="/deepICR">
          <img alt="Deloitte. Logo" src="/DEL_g_SEC_RGB.jpg" width="142" height="44" />
        </Link>

        <Typography className={styles.styleSpacer}></Typography>
        <ButtonSwitchLang className={styles.styleButtonSwithLang} />
        <Divider orientation="vertical" className={styles.styleDivider} />
        <font className={styles.styleLogout} onClick={checkBeforeLogOut}>
          <span style={{ marginTop: ".2rem" }}> <MdOutlineLogout /> </span>

          <Typography variant="h6">  {t("stringMenuBarLogout")}</Typography>
        </font>
        <font
          className={styles.styleLogout}
          onClick={debug}
          style={{ display: deepICRCTX.debugButton === true ? "inherit" : "none" }}
        >
          <Typography variant="h6">{t("stringDebug")}</Typography>
        </font>
      </Toolbar>
      <PopupModal isOpen={isOpen} closeModal={closeModal} cb={doLogout} textBtnInfo={{alertTitle:"stringPopUpMessage",positiveBtn:"stringPopUpMessageOk",negativeBtn:"stringPopUpMessageCancel"}}/>
    </div>
  );
};

export default MenuBar;
