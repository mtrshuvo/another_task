// useCustomModal.js

import { useState} from 'react';

const useCustomModal = () => {
    const [isOpen, setIsOpen] = useState(false);

  const openModal = () => {

   setIsOpen(true)
  };

  const closeModal = () => {
    setIsOpen(false)
  };

  const handleYesClick = (cb) => {
    // Handle the 'Yes' button click based on the selected case
    // ...
    cb();

    // Close the modal after handling the action
    closeModal();
  };

  return {
    openModal,
    closeModal,
    handleYesClick,
    isOpen
  };
};

export default useCustomModal;
