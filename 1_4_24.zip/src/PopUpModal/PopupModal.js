import React, { useRef, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Fade from '@material-ui/core/Fade';
import { useContext } from 'react';
import DeepICRContext from '../resources/DeepICRContext';
import { useTranslation } from 'react-i18next';
import { Button, Dialog, Typography } from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
  modal: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  paper: {
    backgroundColor: theme.palette.background.paper,
    border: `1px solid ${theme.palette.deepICR.blue4}`,
    boxShadow: theme.shadows[5],
    padding: theme.spacing(2, 4, 3),
    color: "black"
  },
  styleOkButton: {
    color: theme.palette.deepICR.modalCancelColor,
    backgroundColor: theme.palette.deepICR.color,
    borderRadius: 2,
    "&:hover": {
      color: theme.palette.deepICR.blue4
    }
  },
  styleCancelButton: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
    "&:hover": {
      color: theme.palette.deepICR.blue4
    }
  },
}));


export default function PopupModal({ isOpen, closeModal, cb, handleClick, textBtnInfo, templateName,isTemplateLibrary}) {
  // console.log({templateName});
  const { alertTitle, positiveBtn, negativeBtn } = textBtnInfo
  const classes = useStyles();
  const [deepICRCTX] = useContext(DeepICRContext);
  const cancelRefButton = useRef(null);
  // const {handleYesClick, closeModal} = useCustomModal();
  const [t] = useTranslation(); // for multiple language
  const styles = useStyles(); // for metarial ui theme
  //focusing on cancel button
  const onEntered = () => cancelRefButton?.current?.focusVisible();
  const fileInputRef = useRef(null);

  useEffect(() => {
    const handleFileInputChange = (e) => {
     cb(e)
    };

    if (fileInputRef.current) {
      fileInputRef.current.addEventListener('change', handleFileInputChange);
    }

    // Cleanup: remove event listener when component unmounts
    return () => {
      if (fileInputRef.current) {
        fileInputRef.current.removeEventListener('change', handleFileInputChange);
      }
    };
  }, [fileInputRef, cb]);

  return (
    <div>

      <Dialog
        className={classes.modal}
        open={isOpen}
        onClose={closeModal}
        TransitionProps={{ onEntered }}

      >
        <Fade in={isOpen}>
          <div className={classes.paper}>
            <p id="transition-modal-description">{t(`${alertTitle}`)}</p>

            {templateName && <p>{templateName}</p>}

            {
              (isTemplateLibrary === true && templateName === '') ?
                <>
                  <label htmlFor="fileUploadInputButtonJSon">
                    <Button
                      style={{
                        minWidth: deepICRCTX.language === "en" ? "49%" : "",
                      }}
                      action={(actions) => isTemplateLibrary === true && (cancelRefButton.current = actions)}
                      className={isTemplateLibrary === true ? styles.styleCancelButton : styles.styleOkButton}
                      onClick={(e) => {
                        fileInputRef.current.click()
                        closeModal();
                      }}
                      variant="outlined" component="span">

                      <Typography
                        style={{
                          letterSpacing: deepICRCTX.language === "en" ? "1px" : "",
                          fontWeight: deepICRCTX.language === "en" ? "600" : "initial"
                        }}
                        variant="h6">{t(`${positiveBtn}`)}

                      </Typography>


                    </Button>
                  </label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept=".json"
                    style={{ display: 'none' }}
                  />
                </>

                :
                <Button
                  style={{
                    minWidth: deepICRCTX.language === "en" ? "49%" : "",
                  }}
                  action={(actions) => isTemplateLibrary === true && (cancelRefButton.current = actions)}
                  className={isTemplateLibrary === true ? styles.styleCancelButton : styles.styleOkButton}
                  onClick={(e) => {
                    cb();
                    closeModal();
                  }}
                  variant="outlined" component="span">

                  <Typography
                    style={{
                      letterSpacing: deepICRCTX.language === "en" ? "1px" : "",
                      fontWeight: deepICRCTX.language === "en" ? "600" : "initial"
                    }}
                    variant="h6">{t(`${positiveBtn}`)}

                  </Typography>

                </Button>

            }


            <Button
              style={{
                minWidth: deepICRCTX.language === "en" ? "49%" : "",
              }}
              action={(actions) => isTemplateLibrary !== true && (cancelRefButton.current = actions)}
              className={isTemplateLibrary !== true ? styles.styleCancelButton : styles.styleOkButton}
              onClick={closeModal}
              variant="outlined" component="span">
              <Typography
                style={{
                  letterSpacing: deepICRCTX.language === "en" ? "1px" : "",
                  fontWeight: deepICRCTX.language === "en" ? "600" : "initial"
                }}
                variant="h6">{t(`${negativeBtn}`)}</Typography>
            </Button>
          </div>
        </Fade>
      </Dialog>
    </div>
  );
}
