import { useState } from "react";


const useSetInfo = () => {
    // console.log("global ac", global.accessToken);
    const [data, setData] = useState({contract_id:"",user_id:"",file_path:"",file_name:""});

    // console.log("useHook data",data);
    const storeData = (newData) => {
        setData({...data,...newData});
    };

    const getData = () => {
        return data;
    };

    return { storeData, getData };
}

export default useSetInfo

