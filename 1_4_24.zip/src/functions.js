const uploadAndConvert = async () => {
    // console.log("Same file name", deepICRCTX.file.name, "Requested file", deepICRCTX.requestedFile);
    if ((deepICRCTX.file.name === deepICRCTX.requestedFile)) {
      props.enqueueSnackbar(
        t('errorRequestSameFile'),
        { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
      );
      deepICRLogging({
        "LogType": "ERROR",
        "ErrType": "RequestSameFileError",
        "Message": t('errorRequestSameFile'),
        "Src": "Toolbar.js",
        "Line": 0,
        "Column": 0,
        "Stack": ""
      });
      return;
    }
    const snackbarDoConvert = props.enqueueSnackbar(
      t('infoDoConvert') + deepICRCTX.file.name,
      {
        variant: 'info',
        persist: true,
        anchorOrigin: { vertical: 'bottom', horizontal: 'right' }
      }
    );
    const isContract = false;
    const [yyyymmddhhmmss, unixtime, microsec] = deepICRNow();
    // console.log(unixtime, microsec, isContract);

    let putFileName = deepICRCTX.file.name;

    let pagesArray = [];
    if (deepICRCTX.targetPages !== "") {
      deepICRCTX.targetPages.split(',').forEach((item) => {
        pagesArray.push(isNaN(item) ? item : Number(item));
      });
    }
    // console.log("Rotation Value:", global.rotation);

    const inputJson = {
      "bucket_name": deepICRCTX.s3Bucket,
      "img_path": deepICRCTX.s3Path,
      "img_file_name": putFileName,
      "output_path": deepICRCTX.s3Path,
      "output_json_name": deepICRCTX.file.name.match(/(.*)(?:\.([^.]+$))/)[1] + '_out.json',
      "target_type": type,
      "custom_pages": pagesArray,
      "pdf_pages": deepICRCTX.file.type === 'application/pdf' ? deepICRCTX.pdfPages : 0,
      "pdf_rotations": global.rotation,
      "file_size": deepICRCTX.file.size,
      "selection_info": deepICRCTX.shapeList,
    };

    setDeepICRCTX({
      ...deepICRCTX,
      documentId: "",
      isContract: false,
      requestedFile: deepICRCTX.file.name,
      originalOutputFontScale: 1,
      originalOutputSize: { height: 0, width: 0 },
      originalOutputData: { data: [] },
      originalOutputTable: { data: [] },
      extractedOutputData: { data: [] },
      extractedOutputTable: { data: [] },
      searchText: "",
      outputSw: false,
    });

    // Upload Reqest Json
    let file_name = deepICRCTX.file.name.split(".");
    file_name[file_name.length - 1] = "json";
    file_name = file_name.join(".");

    fetch('http://' + host_address + ':5000?json=' + JSON.stringify(inputJson, null, 2) + "&filename=" + encodeURI(file_name), {
      method: "GET",
      mode: "cors",
      rejectUnauthorized: false
    })
      .then(response => {
        return response.json();
      }).then(json => {
        // console.log(json);
        if (json["Status"] === "Success") {
          console.log("Selection json load Successfully");
          fetch('http://' + host_address + ':5000/input/' + file_name)
            .then(response => {
              console.log("Selection Response: ", response)
              return response.json();
            })
            .then(json => {
              let shape_list = JSON.parse(JSON.stringify(json)).selection_info;
              // console.log("Shape List:", shape_list);
              setDeepICRCTX({
                ...deepICRCTX,
                shapeList: shape_list,
              });
              checkDeepStorage(deepICRCTX.setTimeoutTime, 100, 1);
            })
            .catch(er => {
              deepICRLogging({
                "LogType": "ERROR",
                "ErrType": "NetworkError",
                "Message": er.message,
                "Src": "Toolbar.js",
                "Line": 0,
                "Column": 0,
                "Stack": ""
              });
              return;
            })
        }
      })
      .catch(er => {
        console.log("TEST2:", er.message, er.stack);
        deepICRLogging({
          "LogType": "ERROR",
          "ErrType": "NetworkError",
          "Message": er.message,
          "Src": "Toolbar.js",
          "Line": 0,
          "Column": 0,
          "Stack": ""
        });
        return;
      })

    const checkDeepStorage = (time, limit, counter) => {
      setTimeout(() => {
        console.log("polling...");
        fetch('http://' + host_address + ':5000/output/' + encodeURI(file_name))
          .then(response => {
            return response.json();
          })
          .then(json => {
            // console.log(json);
            let outputJson = JSON.parse(JSON.stringify(json));
            setJson(outputJson);

            const file = deepICRCTX.file;
            file.yyyymmddhhmmss = yyyymmddhhmmss

            let oDataHeight = 0;
            let oDataWidth = 0;
            let oData = {};
            let oTable = {};
            let eData = [];
            let eTable = [];
            let shapes = {};

            [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes] = parseOutputJson(outputJson);

            // console.log("aaa", oDataHeight, oDataWidth,);
            // console.log("aaa", oData,);
            // console.log("aaa", oTable,);
            // console.log("aaa", eData,);
            // console.log("aaa", eTable,);
            // console.log("aaa", shapes);


            props.closeSnackbar(snackbarDoConvert);

            setDeepICRCTX({
              ...deepICRCTX,
              // accessToken: newAccessToken,
              outputJson: outputJson,
              isContract: isContract,
              outputTab: 0,
              file: file,
              // requestedFile: "",
              originalOutputSize: { height: oDataHeight, width: oDataWidth },
              originalOutputData: { data: oData },
              originalOutputTable: { data: oTable },
              extractedOutputData: { data: eData },
              extractedOutputTable: { data: eTable },
              croppedImages: shapes,
              outputSw: true,
              selectedRegion: {
                pages: []
              },
              selectedShapeRight: [],
              shapeListRight: {},
              selectedButton: false,
              requestedFile: deepICRCTX.file.name,
            });
          })
          .catch(err => {
            console.log(err);
            counter++;
            if (counter < limit) {
              checkDeepStorage(time, limit, counter);
            }
            else {
              console.log("ERROR:", [err]);
              deepICRLogging({
                "LogType": "ERROR",
                "ErrType": "NetworkError",
                "Message": err.message,
                "Src": "Toolbar.js",
                "Line": 0,
                "Column": 0,
                "Stack": ""
              });
              const errorSnackBar = props.enqueueSnackbar(
                "Time Out.. please convert again",
                {
                  variant: 'error',
                  persist: true,
                  anchorOrigin: { vertical: 'bottom', horizontal: 'right' }
                }
              );
              props.closeSnackbar(errorSnackBar);
            }
          });
      }, time);
    }

  }