import React from "react";

import { generateMessageFromError } from "../resources/CommonMethods";
import deepICRLogging from "./deepICRLogging";

const ErrorComponent = () => {
  const styles = {
    container: {
      margin: 0,
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      display: "flex",
      flexDirection: "column",
    },
    main: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      flexDirection: "column",
      height: "100%",
    },
    section: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "40px",
      flexDirection: "row",
    },
    span: {
      height: "100%",
      lineHeight: "40px",
      fontSize: "24px",
      fontWeight: 500,
      display: "block",
      borderBottom: "none",
      borderRight: "1px solid #EAEAEA",
      textAlign: "center",
      width: "100px",
    },
    p: {
      height: "100%",
      lineHeight: "40px",
      fontSize: "14px",
      fontWeight: 400,
      paddingLeft: 20,
    },
  };
  return (
    <div style={styles.container}>
      <div style={styles.main}>
        <div style={styles.section}>
          <span style={styles.span}>404</span>
          <p style={styles.p}>Rendering Error, Please reload again.</p>
        </div>
      </div>
    </div>
  );
};

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
    };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    let message = generateMessageFromError(error);
    deepICRLogging(message);
  }
  render() {
    const hasError = this.state.hasError;
    const { children } = this.props;
    return hasError ? <ErrorComponent /> : children;
  }
}
export default ErrorBoundary;
