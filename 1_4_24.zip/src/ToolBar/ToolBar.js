import React, { useContext, useState, useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import { Dialog, Fade, makeStyles, withStyles } from "@material-ui/core";
import { withSnackbar } from "notistack";
import Toolbar from "@material-ui/core/Toolbar";
import Divider from "@material-ui/core/Divider";
import Typography from "@material-ui/core/Typography";
import InputBase from "@material-ui/core/InputBase";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import SvgIcon from "@material-ui/core/SvgIcon";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import crypto from "crypto";
import JSZip from "jszip";
import { pdfjs } from "react-pdf";
import { jsPDF } from "jspdf";
import { deepICRDownload, deepICRtoBlobWithBom, deepICRNow } from "../deepICRCommon";
import AWS from 'aws-sdk';
// importing useHistory push for return button
import { useHistory } from "react-router-dom";
import { jwtDecode } from "jwt-decode";


//icons
// import {} from "@material-ui/icons"
// import resource files
import DeepICRContext from "../resources/DeepICRContext";
import CroppingTool from "./CroppingTool";
import { objectSize, deepCopy, commaRemovingFromNumberValue, isthereAnyShape, formatYYYYMMDDHHMMSS, isSelectedLineData, findLinesAndSort, hasMultipleObjects, ODataForCSV } from "../resources/CommonMethods";
import deepICRLogging from "../Logging/deepICRLogging";
import { BsUpload, BsDownload } from "react-icons/bs"
import { PiPathFill } from "react-icons/pi"
import PopupModal from "../PopUpModal/PopupModal";
import useCustomModal from "../PopUpModal/useModal";
import { ArrowLeftRounded, TrainRounded } from "@material-ui/icons";
import useSetInfo from "../useHook/setInfo";


// const files = this.readDirectory('/home/nsl46/Saimom/All_Tools/manual_cropping_liverpool/codebase/deep_icr_client_liverpool/data/pdf');
// console.log({files});
// pdfjs Setting
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

//local_environment
const host_address = "172.16.16.230"
// Style Sheet
const useStyles = makeStyles((theme) => ({
  styleToolBar: {
    flexGrow: 1,
    padding: "5px 0",
  },
  styleDivToolbar: {
    width: "49.6%",
    display: "flex",
    margin: "auto",
    backgroundColor: "#ffffff",
    padding: ".3rem 0"
  },
  styleDivider: {
    margin: theme.spacing(1),
  },
  styleSpacer: { flexGrow: 1 },
  styleFileUpload: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
    "&:hover": {
      color: theme.palette.deepICR.blue4
    }
  },
  stylePageNumberInputRoot: {
    color: "inherit",
    // borderBottom: `1px solid ${theme.palette.deepICR.blue4}`,
    fontSize: "0.9rem",
    [theme.breakpoints.down("1530")]: {
      width: "280px",

    },
    [theme.breakpoints.down("1350")]: {
      width: "250px",
      // "&:focus": {
      //   width: "260px",
      //   backgroundColor: theme.palette.deepICR.input,
      // },
    },
    [theme.breakpoints.down("1270")]: {
      width: "200px",
      // "&:focus": {
      //   width: "210px",
      //   backgroundColor: theme.palette.deepICR.input,
      // },
    },
  },
  stylePageNumberInput: {
    padding: theme.spacing(1, 1, 1, 2),
    transition: theme.transitions.create("width"),
    width: "100%",


    [theme.breakpoints.down("1530")]: {
      "&:focus": {
        // width: "290px",
        // backgroundColor: theme.palette.deepICR.input,
      },
    },
    [theme.breakpoints.down("1350")]: {
      "&:focus": {
        // width: "260px",
        // backgroundColor: theme.palette.deepICR.input,
      },
    },
    [theme.breakpoints.down("1270")]: {
      "&:focus": {
        // width: "210px",
        // backgroundColor: theme.palette.deepICR.input,
      },
    },
    [theme.breakpoints.up("sm")]: {
      width: theme.palette.deepICR.pageNumberInputSize,
      "&:focus": {
        // width: theme.palette.deepICR.pageNumberInputSizeFocus,
        // backgroundColor: theme.palette.deepICR.input,
      },

    },
  },
  styleConvert: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
    "&:hover": {
      color: theme.palette.deepICR.blue4
    }
  },
  styleOkButton: {
    color: theme.palette.deepICR.modalCancelColor,
    // backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
    "&:hover": {
      color: theme.palette.deepICR.blue4
    }
  },
  styleCancelButton: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
    borderColor: theme.palette.deepICR.blue4,
    "&:hover": {
      color: theme.palette.deepICR.blue4
    }
  },
  styleFormat: {
    border: `1px solid #e2e2e2`,
    padding: "0 .5rem",
    borderRadius: "5px",
    "& .MuiSelect-icon": {
      // color: theme.palette.deepICR.blue4,
    },
    "& .MuiInput-underline": {
      borderBottom: "none",
    },
    "& .MuiInput-underline:hover": {
      borderBottom: "none",
    },
    "& .MuiInputBase-root:hover .MuiInput-underline": {
      borderBottom: "none",

    },



  },
  styleFormatActive: {
    border: `1px solid #e2e2e2`,
    padding: "0 .5rem",
    borderRadius: "5px",
    "& .MuiSelect-icon": {
      color: theme.palette.deepICR.blue4,
    },
    "& .MuiInput-underline": {
      borderBottom: "none",
    },
    "& .MuiInput-underline:hover": {
      borderBottom: "none",
    },
    "& .MuiInputBase-root:hover .MuiInput-underline": {
      borderBottom: "none",

    },



  },
  inputUnderline: {
    '&.MuiInput-underline:before': {
      borderBottom: `none`, // Change the color and style to your preference
    },
    "&.MuiInput-root:hover .MuiInput-underline ": {
      border: "none"
    },

  },
  styleType: {},
  styleExport: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
    "&:hover": {
      color: theme.palette.deepICR.blue4,

    }
  },

  modal: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  paper: {
    backgroundColor: theme.palette.background.paper,
    border: `1px solid ${theme.palette.deepICR.blue4}`,
    boxShadow: theme.shadows[5],
    padding: theme.spacing(2, 4, 3),
    color: "black"
  },
}));
const CustomButton = withStyles({
  outlined: {
    "&$disabled": {
      color: "#ffffff",
      backgroundColor: "#888888",
    },
  },
  disabled: {},
})(Button);


// [React function component]
// Tool bar component
const ToolBar = (props) => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [format, setFormat] = useState("csv_full");
  const [type, setType] = useState("invoice");
  const [json, setJson] = useState("");
  const [inputPages, setInputPages] = useState("");
  const cancelRefButton = useRef(null)
  const [isCsvChanged, setIsCSVChanged] = useState(false);
  const [isDisableConvert, setIsDisableConvert] = useState(false)
  const [files, setFiles] = useState([])

  const [t] = useTranslation(); // for multiple language
  const styles = useStyles(); // for metarial ui theme

  const { storeData } = useSetInfo();

  if (deepICRCTX.debug === true) {
    console.log("ToolBar");
  }

  const [isSelection, setIsSelection] = useState(true);

  //modal 
  const [isOpen, setIsOpen] = useState(false)
  //focusing on cancel button
  const onEntered = () => cancelRefButton?.current?.focusVisible();


  const openModal = () => {
    setIsOpen(true)
  }
  const closeModal = () => {
    setIsOpen(false)
  }

  // convert modal
  const {
    openModal: openModalC,
    closeModal: closeModalC,
    isOpen: isOpenC
  } = useCustomModal()

  // console.log({format},{isCsvChanged});
  let effectSelectedRegion = JSON.stringify(deepICRCTX.selectedRegion)
  useEffect(() => {
    if (deepICRCTX.fileSize.length) {
      if (isthereAnyShape(deepICRCTX.selectedRegion) === false) {
        // console.log("Manuaaly changed and region is empty");
        setFormat("csv_full");
      }
      else {
        // console.log("Region is not empty");
        format === 'csv_rpa' ? setFormat("csv_rpa") : setFormat('csv')
      }

    }
  }, [effectSelectedRegion, isCsvChanged])

  // Logout
  const logout = async () => {
    const [, unixtime, microsec] = deepICRNow();
    let requestJson = {
      type: "request",
      head: {
        command: "signout",
        format_version: deepICRCTX.apiFormatVersion,
        service_id: deepICRCTX.apiServiceId,
        transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
        unix_time: unixtime,
        micro_seconds: microsec,
        time_zone: deepICRCTX.apiTimeZone,
      },
    };
    await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiSignout, {
      method: "POST",
      mode: "cors",
      headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
      body: JSON.stringify(requestJson),
    })
      .then((res) => {
        return res.json();
      })
      .then((json) => {
        if (deepICRCTX.debug === true) {
          console.log(json);
        }
      })
      .catch((err) => {
        if (deepICRCTX.debug === true) {
          console.log("[ToolBar - logout] signout catch error");
        }
        if (deepICRCTX.debug === true) {
          console.log(err);
        }

        deepICRLogging({
          LogType: "ERROR",
          ErrType: "SignoutCatchError",
          Message: "Signout catch error",
          Src: "Toolbar.js",
          Line: 0,
          Column: 0,
          Stack: "",
        });
      });

    global.accessToken = "";
    global.refreshToken = "";
    global.rotation = [];
    setDeepICRCTX({
      ...deepICRCTX,
      isLogin: false,
      isTerms: false,
      isContract: false,
      changePassword: false,
      documentId: "",
      cognitoUser: {},
      // accessToken: "",
      // refreshToken: "",
      inputViewerBounds: {
        bounds: { height: 100, width: 100, top: 0, bottom: 100, left: 0, right: 100 },
      },
      imageScale: 1,
      outputTab: 0,
      file: {},
      requestedFile: "",
      fileBase64: [],
      fileSize: [{ height: 0, width: 0 }],
      pdfBase64: "",
      pdfPage: 1,
      pdfPages: 1,
      targetPages: "",
      size: 12,
      originalOutputFontScale: 1,
      outputSw: false,
      outputLinkSw: false,
      originalOutputSize: { height: 0, width: 0 },
      originalOutputData: { data: [] },
      originalOutputTable: { data: [] },
      extractedOutputData: { data: [] },
      extractedOutputTable: { data: [] },
      searchText: "",
    });
  };


  // format table for RPA----------------------------- start -------------------
  // key nam issue solve
  function sortedTableFormat(obj) {
    function sortObjectKeys(obj) {
      if (typeof obj !== 'object' || Array.isArray(obj)) {
        return obj;
      }

      const sortedKeys = Object.keys(obj)
        .map(Number)
        .sort((a, b) => a - b);

      const sortedObj = {};
      sortedKeys.forEach((key, index) => {
        sortedObj[index] = sortObjectKeys(obj[key]);
      });

      return sortedObj;
    }

    const sortedKeys = Object.keys(obj)
      .map(Number)
      .sort((a, b) => a - b);

    const formattedData = {};
    sortedKeys.forEach((key, index) => {
      formattedData[index] = sortObjectKeys(obj[key]);
    });


    return formattedData;

  }

  function updatedTableRowColSpan(table) {
    let cells = table.cells;
    let uniqueX = getUniqueXPostion(cells);
    let uniqueY = getUniqueYPostion(cells);

    for (let [index, cell] of cells.entries()) {
      let [rowSpan, colSpan, row_no, col_no] = getRowColSpan(cell, uniqueX, uniqueY);
      cell.row_span = rowSpan;
      cell.col_span = colSpan;
      cell.row_no = row_no;
      cell.col_no = col_no;

    }
    // console.log({table});
    return table;
  }

  function getRowColSpan(cell, uniqueX, uniqueY) {
    let by1 = cell.y;
    let by2 = cell.y + cell.height;
    let bx1 = cell.x;
    let bx2 = cell.x + cell.width;
    let rowSpan = 1;
    let colSpan = 1;
    let row_no = null;
    let col_no = null;
    // console.log(by1, by2, bx1, bx2);
    for (let [ind, x] of uniqueX.entries()) {
      if (x === bx1) col_no = ind;
      if (bx1 !== x && (bx1 < x && x < bx2)) {
        colSpan += 1
      }
    }
    for (let [ind, y] of uniqueY.entries()) {
      if (y === by1) row_no = ind
      if (by1 !== y && (by1 < y && y < by2)) {
        rowSpan += 1
      }
    }

    return [rowSpan, colSpan, row_no, col_no]
  }

  function getUniqueXPostion(cells) {
    let x = cells.map((v) => v.x);
    return [...new Set(x)].sort((a, b) => a - b);
  }
  function getUniqueYPostion(cells) {
    let y = cells.map((v) => v.y);
    return [...new Set(y)].sort((a, b) => a - b);
  }

  function findMinRowAndCol(data) {
    let minRow = Infinity;
    let minCol = Infinity;

    data.forEach((row) => {
      minRow = Math.min(minRow, row.row_no);
      minCol = Math.min(minCol, row.col_no);
    });

    return { minRow, minCol };
  }
  // prev
  // function formatTable(tableInfo) {
  //   let tableFormat = {};
  //   const { minRow, minCol } = findMinRowAndCol(tableInfo.cells);

  //   for (let cells of tableInfo.cells) {
  //     // console.log(cells);
  //     let adjustRow = cells.row_no - minRow;
  //     let adjustCol = cells.col_no - minCol;

  //     // Handle rowspan
  //     for (let i = 0; i < cells.row_span; i++) {
  //       if (!tableFormat[adjustRow + i]) {
  //         tableFormat[adjustRow + i] = {};
  //       }

  //       // Handle colspan
  //       for (let j = 0; j < cells.col_span; j++) {
  //         const colIndex = adjustCol + j;
  //         tableFormat[adjustRow + i][colIndex] = cells.cell_text ? cells.cell_text : "＿";
  //       }
  //     }
  //   }
  //   return sortedTableFormat(tableFormat);
  // }
  // format table for RPA----------------------------- end ---------------------

  //-------------------------------------------------------------------------------------------------
  // Get Specified Document ID
  //-------------------------------------------------------------------------------------------------

  function formatNewTable(table) {
    let tableFormat = {};

    for (let cell of table.cells) {
      for (let i = 0; i < cell.row_span; i++) {
        if (!tableFormat[i + cell.row_no]) {
          tableFormat[i + cell.row_no] = {};
        }

        for (let j = 0; j < cell.col_span; j++) {
          tableFormat[i + cell.row_no][j + cell.col_no] = cell.cell_text ? cell.cell_text : "＿"
        }
      }

    }

    return fillMissingKeys(tableFormat);
  }
  function fillMissingKeys(obj) {
    const keysSet = new Set();
    for (const key in obj) {
      for (const innerKey in obj[key]) {
        keysSet.add(innerKey);
      }
    }

    for (const key of keysSet) {
      for (const innerKey in obj) {
        if (!obj[innerKey].hasOwnProperty(key)) {
          obj[innerKey][key] = "＿";
        }
      }
    }
    return obj
  }
  let documentId = "";

  if (
    deepICRCTX.outputLinkSw === false &&
    !(typeof props.documentId === "undefined") &&
    global.documentIdFileNotFound === false
  ) {
    documentId = props.documentId;
    const yyyymmddhhmmss = documentId.substr(0, 14);
    const fileName = documentId.substr(14);

    // Parse output json file
    const parseOutputJson = (outputJson, fileSize) => {
      // console.log("naki etai");
      if (
        outputJson === undefined ||
        outputJson.original_output === undefined ||
        outputJson.original_output.pages === undefined
      ) {
        deepICRLogging({
          Type: "UndefinedError",
          Message: "pages key not found in json file",
          Src: "ToolBar.js",
          Line: 0,
          Column: 0,
          Stack: "",
        });

        return [0, 0, {}, {}, [], [], {}];
      }
      if (
        outputJson.statusCode === null ||
        outputJson.statusCode === undefined ||
        outputJson.statusCode.length === 0 ||
        (outputJson.statusCode.length > 0 && outputJson.statusCode[0] !== 200) ||
        outputJson.statusCode !== 200
      ) {
        if (deepICRCTX.language === "ja") {
          for (let i = 0; i < outputJson.statusDescription.length; i++) {
            let msg = outputJson.statusDescription[i].split("|")[0];
            props.enqueueSnackbar(msg, {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
          }
        } else if (deepICRCTX.language === "en") {
          for (let i = 0; i < outputJson.statusDescription.length; i++) {
            let msg = outputJson.statusDescription[i].split("|")[1];
            props.enqueueSnackbar(msg, {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
          }
        }
        return [0, 0, {}, {}, [], [], {}];
      }
      const oResultArray = outputJson.original_output.pages;
      const oDataHeight = outputJson.original_output.pages[0].height;
      const oDataWidth = outputJson.original_output.pages[0].width;
      const documentName = outputJson.original_output.document_name;
      const prefixArray = documentName.split(".");
      prefixArray.pop();
      const prefix = prefixArray.join(".");
      let id = 1;

      let shapes = {};
      let isSel = false;

      const oData = { documentName: documentName };
      const oTable = { documentName: documentName };
      for (let i = 0; i < oResultArray.length; i++) {
        let uniqueKeyForData = 0;
        if (oResultArray[i].id !== prefix) {
          id = oResultArray[i].id.replace(prefix + "_page_", "");

        }
        oData[id] = {
          id: oResultArray[i].id,
          height: oResultArray[i].height,
          width: oResultArray[i].width,
          data: [],
        };
        oTable[id] = {
          id: oResultArray[i].id,
          data: [],
        };
        for (let j = 0; j < oResultArray[i].regions.length; j++) {
          if (oResultArray[i].regions[j].selection_id !== undefined) isSel = true;
          if (
            oResultArray[i].regions[j].type === "Single Line" ||
            oResultArray[i].regions[j].type === "Line"
          ) {
            for (let k = 0; k < oResultArray[i].regions[j].words.length; k++) {
              oData[id].data.push({
                shape_id: oResultArray[i].regions[j].selection_id,
                shape_type: oResultArray[i].regions[j].selection_type,
                meta: oResultArray[i].regions[j].meta,
                x: oResultArray[i].regions[j].words[k].x,
                y: oResultArray[i].regions[j].words[k].y,
                width: oResultArray[i].regions[j].words[k].width,
                height: oResultArray[i].regions[j].words[k].height,
                text: oResultArray[i].regions[j].words[k].text,
                confidence: oResultArray[i].regions[j].words[k].confidence,
                key: i + "-" + j + "-" + k,
                color: oResultArray[i].regions[j].words[k].confidence < 0.9 ? "red" : "black",
                originalText: "",
                type: "dataFromLine",
                uniqueKey: uniqueKeyForData,
              });


              uniqueKeyForData++;
            }
          }
          // else if (oResultArray[i].regions[j].type === "Image") {
          //   // const img = deepICRCTX.fileBase64[i];
          //   const ratio = fileSize[i].width / oResultArray[i].width;

          //   let shape_info = {};
          //   let points = "";

          //   if (oResultArray[i].regions[j].selection_type === "rect") {
          //     let x = oResultArray[i].regions[j].x;
          //     let y = oResultArray[i].regions[j].y;
          //     let w = oResultArray[i].regions[j].width;
          //     let h = oResultArray[i].regions[j].height;
          //     shape_info = { type: "rect", x: x * ratio, y: y * ratio, w: w * ratio, h: h * ratio };
          //   } else if (oResultArray[i].regions[j].selection_type === "ellipse") {
          //     let x = oResultArray[i].regions[j].x;
          //     let y = oResultArray[i].regions[j].y;
          //     let w = oResultArray[i].regions[j].width;
          //     let h = oResultArray[i].regions[j].height;
          //     shape_info = {
          //       type: "ellipse",
          //       x: x * ratio,
          //       y: y * ratio,
          //       w: w * ratio,
          //       h: h * ratio,
          //     };
          //   } else if (oResultArray[i].regions[j].selection_type === "polygon") {
          //     points = oResultArray[i].regions[j].points;

          //     let points_arr = points.split(" ");
          //     let points_dic = [];
          //     for (let p = 0; p < points_arr.length; p++) {
          //       let point = points_arr[p].split(",");
          //       points_dic.push({ x: point[0] * ratio, y: point[1] * ratio });
          //     }
          //     shape_info = { type: "polygon", points: points_dic };
          //   }
          //   oData[id].data.push({
          //     shape_id: oResultArray[i].regions[j].selection_id,
          //     shape_type: oResultArray[i].regions[j].selection_type,
          //     meta: oResultArray[i].regions[j].meta,
          //     x: oResultArray[i].regions[j].x,
          //     y: oResultArray[i].regions[j].y,
          //     width: oResultArray[i].regions[j].width,
          //     height: oResultArray[i].regions[j].height,
          //     key: i + "-" + j,
          //     points: oResultArray[i].regions[j].points,
          //     type: "Image",
          //     uniqueKey: uniqueKeyForData,
          //   });

          //   shapes[i + "-" + j] = shape_info;
          //   uniqueKeyForData++;
          // } 
          else if (oResultArray[i].regions[j].type === "Blank") {
            oData[id].data.push({
              shape_id: oResultArray[i].regions[j].selection_id,
              shape_type: oResultArray[i].regions[j].selection_type,
              meta: oResultArray[i].regions[j].meta,
              x: oResultArray[i].regions[j].x,
              y: oResultArray[i].regions[j].y,
              width: oResultArray[i].regions[j].width,
              height: oResultArray[i].regions[j].height,
              key: i + "-" + j,
              points: oResultArray[i].regions[j].points,
              type: "Blank",
              uniqueKey: uniqueKeyForData,
            });
            uniqueKeyForData++;
          } else if (oResultArray[i].regions[j].type === "Multi Line") {
            for (let k = 0; k < oResultArray[i].regions[j].lines.length; k++) {
              for (let l = 0; l < oResultArray[i].regions[j].lines[k].words.length; l++) {
                oData[id].data.push({
                  shape_id: oResultArray[i].regions[j].selection_id,
                  shape_type: oResultArray[i].regions[j].selection_type,
                  meta: oResultArray[i].regions[j].meta,
                  x: oResultArray[i].regions[j].lines[k].words[l].x,
                  y: oResultArray[i].regions[j].lines[k].words[l].y,
                  width: oResultArray[i].regions[j].lines[k].words[l].width,
                  height: oResultArray[i].regions[j].lines[k].words[l].height,
                  text: oResultArray[i].regions[j].lines[k].words[l].text,
                  confidence: oResultArray[i].regions[j].lines[k].words[l].confidence,
                  key: i + "-" + j + "-" + k + "-" + l,
                  color:
                    oResultArray[i].regions[j].lines[k].words[l].confidence < 0.9 ? "red" : "black",
                  originalText: "",
                  type: "dataFromLine",
                  uniqueKey: uniqueKeyForData,
                });
                uniqueKeyForData++;
              }
            }
          } else if (oResultArray[i].regions[j].type === "Handwritten") {
            if ("lines" in oResultArray[i].regions[j]) {
              for (let k = 0; k < oResultArray[i].regions[j].lines.length; k++) {
                for (let l = 0; l < oResultArray[i].regions[j].lines[k].words.length; l++) {
                  oData[id].data.push({
                    shape_id: oResultArray[i].regions[j].selection_id,
                    shape_type: oResultArray[i].regions[j].selection_type,
                    meta: oResultArray[i].regions[j].meta,
                    x: oResultArray[i].regions[j].lines[k].words[l].x,
                    y: oResultArray[i].regions[j].lines[k].words[l].y,
                    width: oResultArray[i].regions[j].lines[k].words[l].width,
                    height: oResultArray[i].regions[j].lines[k].words[l].height,
                    text: oResultArray[i].regions[j].lines[k].words[l].text,
                    confidence: oResultArray[i].regions[j].lines[k].words[l].confidence,
                    key: i + "-" + j + "-" + k + "-" + l,
                    color:
                      oResultArray[i].regions[j].lines[k].words[l].confidence < 0.9
                        ? "red"
                        : "black",
                    originalText: "",
                    type: "dataFromLine",
                    uniqueKey: uniqueKeyForData,
                  });
                  uniqueKeyForData++;
                }
              }
            }
          }
          //} else if(oResultArray[i].regions[j].type.match(/_Table/)) {
          else if (
            ((oResultArray[i].regions[j].type === "Table" ||
              oResultArray[i].regions[j].type.match(/_Table/)) && oResultArray[i].regions[j].type !== 'Borderless_Table')
          ) {
            for (let k = 0; k < oResultArray[i].regions[j].cells.length; k++) {
              oTable[id].data.push({
                shape_id: oResultArray[i].regions[j].selection_id,
                shape_type: oResultArray[i].regions[j].selection_type,
                meta: oResultArray[i].regions[j].meta,
                x: oResultArray[i].regions[j].cells[k].x,
                y: oResultArray[i].regions[j].cells[k].y,
                width: oResultArray[i].regions[j].cells[k].width,
                height: oResultArray[i].regions[j].cells[k].height,
                row_no: oResultArray[i].regions[j].cells[k].row_no,
                col_no: oResultArray[i].regions[j].cells[k].col_no,
                row_span: oResultArray[i].regions[j].cells[k].row_span,
                col_span: oResultArray[i].regions[j].cells[k].col_span,
                key: i + "-" + j + "-" + k,
                type: "borderFromTable",
              });
              for (let l = 0; l < oResultArray[i].regions[j].cells[k].cell.length; l++) {
                for (let m = 0; m < oResultArray[i].regions[j].cells[k].cell[l].words.length; m++) {
                  if (oResultArray[i].regions[j].cells[k].cell[l].words[m].text !== "") {
                    oData[id].data.push({
                      shape_id: oResultArray[i].regions[j].selection_id,
                      shape_type: oResultArray[i].regions[j].selection_type,
                      meta: oResultArray[i].regions[j].meta,
                      x: oResultArray[i].regions[j].cells[k].cell[l].words[m].x,
                      y: oResultArray[i].regions[j].cells[k].cell[l].words[m].y,
                      width: oResultArray[i].regions[j].cells[k].cell[l].words[m].width,
                      height: oResultArray[i].regions[j].cells[k].cell[l].words[m].height,
                      text: oResultArray[i].regions[j].cells[k].cell[l].words[m].text,
                      confidence: oResultArray[i].regions[j].cells[k].cell[l].words[m].confidence,
                      key: i + "-" + j + "-" + k + "-" + l + "-" + m,
                      color:
                        oResultArray[i].regions[j].cells[k].cell[l].words[m].confidence < 0.9
                          ? "red"
                          : "black",
                      originalText: "",
                      type: "dataFromTable",
                      uniqueKey: uniqueKeyForData,
                    });
                    uniqueKeyForData++;
                  }
                }
              }
            }
          }
        }
      }
      if (isSel) setFormat("crop");
      else setFormat("csv"); //tsv

      setDeepICRCTX({
        ...deepICRCTX,
        isSelection: isSel,
      });

      const eData = {};
      const eTable = {};
      const eResultArray = outputJson.extracted_output;
      Object.keys(eResultArray).forEach((key) => {
        if (key === "details") {
          for (let p in eResultArray[key].values) {
            let tables = {};
            for (let t in eResultArray[key].values[p]) {
              let rows = [];
              for (let i = 0; i < eResultArray[key].values[p][t].length; i++) {
                let cols = [];
                for (let j = 0; j < eResultArray[key].values[p][t][i].length; j++) {
                  cols.push({
                    row: i,
                    column: j,
                    value: eResultArray[key].values[p][t][i][j],
                    originalValue: "",
                    color: "black",
                    null: eResultArray[key].values[p][t][i][j] === "" ? true : false,
                  });
                }
                rows.push(cols);
              }
              tables[t] = rows;
            }
            eTable[p] = tables;
          }
        } else {
          eData[key] = [];
          if (eResultArray[key] !== undefined) {
            if (
              eResultArray[key].values !== undefined &&
              typeof eResultArray[key].values === "string"
            ) {
              eData[key] = {
                en_label: eResultArray[key].en_label,
                jp_label: eResultArray[key].jp_label,
                values: [
                  {
                    key: 0,
                    value: eResultArray[key].values,
                    originalValue: "",
                    color: "black",
                    null: eResultArray[key].values === "" ? true : false,
                  },
                ],
              };
            } else {
              if (eResultArray[key].values === undefined || eResultArray[key].values.length === 0) {
                eData[key] = {
                  en_label: eResultArray[key].en_label,
                  jp_label: eResultArray[key].jp_label,
                  values: [
                    {
                      key: 0,
                      value: "",
                      originalValue: "",
                      color: "black",
                      null: true,
                    },
                  ],
                };
              } else {
                let values = [];
                if (eResultArray[key].values !== undefined) {
                  for (let i = 0; i < eResultArray[key].values.length; i++) {
                    values.push({
                      key: i,
                      value: eResultArray[key].values[i],
                      originalValue: "",
                      color: "black",
                      null: eResultArray[key].values[i] === "" ? true : false,
                    });
                  }
                }
                eData[key] = {
                  en_label: eResultArray[key].en_label,
                  jp_label: eResultArray[key].jp_label,
                  values: values,
                };
              }
            }
          }
        }
      });
      return [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes];
    };

    const [, unixtime, microsec] = deepICRNow(); // Get image file from S3
    const md5 = crypto.createHash("md5"); // Get hash of Username
    const md5hash = md5.update(deepICRCTX.cognitoUser.Username, "binary").digest("hex");

    // Get Presigned URL for image file
    let requestJson = {
      type: "request",
      head: {
        command: "getPresignedUrl",
        format_version: deepICRCTX.apiFormatVersion,
        service_id: deepICRCTX.apiServiceId,
        transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
        unix_time: unixtime,
        micro_seconds: microsec,
        time_zone: deepICRCTX.apiTimeZone,
      },
      body: {
        keys: [
          deepICRCTX.s3Path +
          "/" +
          md5hash +
          "/" +
          yyyymmddhhmmss +
          "/" +
          (fileName.substr(-4) === ".pdf"
            ? fileName.substr(0, fileName.length - 4) + ".zip"
            : fileName),
        ],
        operation: "GET",
      },
    };

    global.documentIdFileNotFound = true;

    Promise.resolve()
      .then(() => {
        return new Promise((resolve, reject) => {
          fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
            method: "POST",
            mode: "cors",
            // headers: {Authorization: `${deepICRCTX.accessToken}`, "Content-Type": "application/json"},
            headers: { Authorization: `${global.accessToken}`, "Content-Type": "application/json" },
            body: JSON.stringify(requestJson),
          })
            .then((res) => {
              return res.json();
            })
            .then((json) => {
              if (json.body.status !== "OK") {
                deepICRLogging({
                  LogType: "ERROR",
                  ErrType: "TokenRefreshError",
                  Message: "token-refresh error after convert failure",
                  Src: "Toolbar.js",
                  Line: 0,
                  Column: 0,
                  Stack: "",
                });
                reject("error");
              } else {
                resolve(json.body.result.urls[0]);
              }
            })
            .catch((err) => {
              deepICRLogging({
                LogType: "ERROR",
                ErrType: "TokenRefreshError",
                Message: "token-refresh catch error after convert failure",
                Src: "Toolbar.js",
                Line: 0,
                Column: 0,
                Stack: "",
              });
              reject(err);
            });
        });
      })
      .then((presignedUrl) => {
        return new Promise((resolve, reject) => {
          fetch(presignedUrl, {
            method: "GET",
            mode: "cors",
          })
            .then((res) => {
              if (res.ok) {
                return res.blob();
              } else {
                if (deepICRCTX.debug === true) {
                  console.log("[ToolBar - documentId] fetch 404 error for image file");
                }
                if (deepICRCTX.debug === true) {
                  console.log(res);
                }
                props.enqueueSnackbar(t("errorFileNotFound"), {
                  variant: "error",
                  anchorOrigin: { vertical: "top", horizontal: "right" },
                });

                deepICRLogging({
                  LogType: "ERROR",
                  ErrType: "FileNotFoundError",
                  Message: "Fetch 404 error for image file.",
                  Src: "Toolbar.js",
                  Line: 0,
                  Column: 0,
                  Stack: "",
                });

                reject("fileNotFound");
              }
            })
            .then((blob) => {
              resolve(blob);
            })
            .catch((err) => {
              deepICRLogging({
                LogType: "ERROR",
                ErrType: "ImageFileCatchError",
                Message: "Catch 404 error for image file ",
                Src: "Toolbar.js",
                Line: 0,
                Column: 0,
                Stack: "",
              });
              reject(err);
            });
        });
      })
      .then((blob) => {
        return new Promise((resolve, reject) => {
          function readAsDataURL(blob) {
            return new Promise((resolve, reject) => {
              let reader = new FileReader();
              reader.onload = () => {
                resolve(reader.result);
              };
              reader.onerror = () => {
                reject(reader.error);
              };
              reader.readAsDataURL(blob);
            });
          }
          readAsDataURL(blob)
            .then((dataUrl) => {
              resolve([blob.type, dataUrl]);
            })
            .catch((err) => {
              deepICRLogging({
                LogType: "ERROR",
                ErrType: "NetworkError",
                Message: err.message,
                Src: "Toolbar.js",
                Line: 0,
                Column: 0,
                Stack: "",
              });
              reject(err);
            });
        });
      })
      .then(([contentType, fileBase64]) => {
        requestJson.body.keys = [
          deepICRCTX.s3Path +
          "/" +
          md5hash +
          "/" +
          yyyymmddhhmmss +
          "/" +
          fileName.match(/(.*)(?:\.([^.]+$))/)[1] +
          "_out.json",
        ];
        return new Promise((resolve, reject) => {
          fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
            method: "POST",
            mode: "cors",
            // headers: {Authorization: `${deepICRCTX.accessToken}`, "Content-Type": "application/json"},
            headers: { Authorization: `${global.accessToken}`, "Content-Type": "application/json" },
            body: JSON.stringify(requestJson),
          })
            .then((res) => {
              return res.json();
            })
            .then((json) => {
              if (json.body.status !== "OK") {
                reject("error");
              } else {
                resolve([json.body.result.urls[0], contentType, fileBase64]);
              }
            })
            .catch((err) => {
              reject(err);
            });
        });
      })
      .then(([presignedUrl, contentType, fileBase64]) => {
        return new Promise((resolve, reject) => {
          fetch(presignedUrl, {
            method: "GET",
            mode: "cors",
          })
            .then((res) => {
              if (res.ok) {
                return res.text();
              } else {
                if (deepICRCTX.debug === true) {
                  console.log("[ToolBar - documentId] fetch 404 error for output json file");
                }
                if (deepICRCTX.debug === true) {
                  console.log(res);
                }
                props.enqueueSnackbar(t("errorFileNotFound"), {
                  variant: "error",
                  anchorOrigin: { vertical: "top", horizontal: "right" },
                });
                deepICRLogging({
                  LogType: "ERROR",
                  ErrType: "FileNotFoundError",
                  Message: "Fetch 404 error for output json file",
                  Src: "Toolbar.js",
                  Line: 0,
                  Column: 0,
                  Stack: "",
                });
                reject("fileNotFound");
              }
            })
            .then((text) => {
              let outputJson = JSON.parse(text);
              if (
                outputJson.statusCode === null ||
                outputJson.statusCode === undefined ||
                outputJson.statusCode.length === 0 ||
                (outputJson.statusCode.length > 0 && outputJson.statusCode[0] !== 200) ||
                (typeof outputJson.statusCode !== "object" && outputJson.statusCode !== 200)
              ) {
                if (deepICRCTX.debug === true) {
                  console.log("[ToolBar - uploadAndConvert] fetch error for output json file");
                }
                if (deepICRCTX.debug === true) {
                  console.log(JSON.stringify(outputJson, null, 1));
                }
                props.enqueueSnackbar(t("errorConvert"), {
                  variant: "error",
                  persist: true,
                  anchorOrigin: { vertical: "top", horizontal: "right" },
                });
                deepICRLogging({
                  LogType: "ERROR",
                  ErrType: "ConvertError",
                  Message: t("errorConvert"),
                  Src: "Toolbar.js",
                  Line: 0,
                  Column: 0,
                  Stack: "",
                });
                setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
                // isError = true;
                return;
              }
              const isContract = outputJson.target_type === "contract" ? true : false;
              setJson(outputJson);
              let oDataHeight = 0;
              let oDataWidth = 0;
              let oData = {};
              let oTable = {};
              let eData = [];
              let eTable = [];
              let shapes = {};

              if (contentType === "image/jpeg") {
                const img = new Image();
                img.onload = () => {
                  if (
                    deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height !== img.height &&
                    deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width !== img.width
                  ) {
                    [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes] =
                      parseOutputJson(outputJson, [{ height: img.height, width: img.width }]);
                    setDeepICRCTX({
                      ...deepICRCTX,
                      isContract: isContract,
                      documentId: yyyymmddhhmmss,
                      inputViewerBounds: global.inputViewerBounds,
                      imageScale: global.inputViewerBounds.bounds.width / img.width,
                      file: { type: contentType, name: fileName },
                      fileBase64: [fileBase64],
                      fileSize: [{ height: img.height, width: img.width }],
                      pdfBase64: "",
                      originalOutputSize: { height: oDataHeight, width: oDataWidth },
                      originalOutputData: { data: oData },
                      originalOutputTable: { data: oTable },
                      extractedOutputData: { data: eData },
                      extractedOutputTable: { data: eTable },
                      shapeList: outputJson.selection_info,
                      croppedImages: shapes,
                      outputSw: true,
                      outputLinkSw: true,
                    });
                  }
                };
                // asynchronous
                img.src = fileBase64;
              } else {
                JSZip.loadAsync(fileBase64.split(",")[1], { base64: true })
                  .then((zip) => {
                    let promises = [];
                    let fileNames = [];
                    let fileBase64 = [];
                    let pdfBase64 = "";
                    let fileSize = [];
                    let pdfIndex = 0;
                    let pdfPages = 0;
                    Object.keys(zip.files).forEach((fileName) => {
                      promises.push(zip.file(fileName).async("base64"));
                      fileNames.push(fileName);
                    });
                    Promise.all(promises)
                      .then((zips) => {
                        for (let i = 0; i < promises.length; i++) {
                          if (fileNames[i].substr(-4) === ".pdf") {
                            pdfBase64 = "data:application/pdf;base64," + zips[i];
                            pdfIndex = i;
                          } else if (fileNames[i].substr(-4) === ".jpg") {
                            fileBase64.push("data:image/jpeg;base64," + zips[i]);
                            pdfPages++;
                          } else if (fileNames[i].substr(-4) === ".txt") {
                            fileSize = JSON.parse(window.atob(zips[i]));
                          }
                        }
                        [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes] =
                          parseOutputJson(outputJson, fileSize);
                        setDeepICRCTX({
                          ...deepICRCTX,
                          isContract: isContract,
                          documentId: yyyymmddhhmmss,
                          inputViewerBounds: global.inputViewerBounds,
                          imageScale: global.inputViewerBounds.bounds.width / fileSize[0].width,
                          file: { type: "application/pdf", name: fileNames[pdfIndex] },
                          fileBase64: fileBase64,
                          fileSize: fileSize,
                          pdfBase64: pdfBase64,
                          pdfPages: pdfPages,
                          originalOutputSize: { height: oDataHeight, width: oDataWidth },
                          originalOutputData: { data: oData },
                          originalOutputTable: { data: oTable },
                          extractedOutputData: { data: eData },
                          extractedOutputTable: { data: eTable },
                          shapeList: outputJson.selection_info,
                          croppedImages: shapes,
                          outputSw: true,
                          outputLinkSw: true,
                        });
                      })
                      .catch((err) => {
                        if (deepICRCTX.debug === true) {
                          console.log(err);
                        }
                        props.enqueueSnackbar(t("errorZipProcess"), {
                          variant: "error",
                          anchorOrigin: { vertical: "top", horizontal: "right" },
                        });
                        deepICRLogging({
                          LogType: "ERROR",
                          ErrType: "ZipProcessError",
                          Message: t("errorZipProcess"),
                          Src: "Toolbar.js",
                          Line: 0,
                          Column: 0,
                          Stack: "",
                        });
                        global.documentIdFileNotFound = true;
                      });
                  })
                  .catch((err) => {
                    if (deepICRCTX.debug === true) {
                      console.log(err);
                    }
                    props.enqueueSnackbar(t("errorZipProcess"), {
                      variant: "error",
                      anchorOrigin: { vertical: "top", horizontal: "right" },
                    });
                    deepICRLogging({
                      LogType: "ERROR",
                      ErrType: "ZipProcessError",
                      Message: t("errorZipProcess"),
                      Src: "Toolbar.js",
                      Line: 0,
                      Column: 0,
                      Stack: "",
                    });
                    global.documentIdFileNotFound = true;
                  });
              }
            })
            .catch((err) => {
              reject(err);
            });
        });
      })
      .catch((err) => {
        if (err !== "fileNotFound") {
          props.enqueueSnackbar(t("errorSystemError"), {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          deepICRLogging({
            LogType: "ERROR",
            ErrType: "FileNotFoundError",
            Message: t("errorFileNotFound"),
            Src: "Toolbar.js",
            Line: 0,
            Column: 0,
            Stack: "",
          });
        } else {
          global.documentIdFileNotFound = true;
        }
      });
  }

  //-------------------------------------------------------------------------------------------------
  // Get File
  //-------------------------------------------------------------------------------------------------
  const getFile = (e) => {
    const VALIDFILETYPES = ["application/pdf", "image/jpg", "image/jpeg"]

    if (typeof e.target.files[0] === "undefined") {
      return;
    }

    if (deepICRCTX.requestedFile !== "") {
      props.enqueueSnackbar(t("errorCannotChange"), {
        variant: "error",
        anchorOrigin: { vertical: "top", horizontal: "right" },
      });
      return;
    }
    if (!VALIDFILETYPES.includes(e.target.files[0].type)) {
      props.enqueueSnackbar(`${t("stringUnsupportedMessage")}`, {
        variant: "error",
        anchorOrigin: { vertical: "top", horizontal: "right" },
      }
      )
      return;
    }
    // if more than 20MB
    if (parseInt(e.target.files[0].size) / 1000000 > 20) {
      props.enqueueSnackbar(`${t("errorFileExceedsMoreThan20MB")}`, {
        variant: "error",
        anchorOrigin: { vertical: "top", horizontal: "right" },
      }
      )
      return
    }
    // convert pdf file to jpeg images
    const pdfToJpeg = async (dataUrl) => {
      const tmpBase64 = dataUrl.split(",", 2)[1];
      const dataUrls = [];
      const fileSizes = [];
      const pdf = await pdfjs.getDocument({
        data: atob(tmpBase64),
        cMapUrl: `//cdn.jsdelivr.net/npm/pdfjs-dist@${pdfjs.version}/cmaps/`,
        cMapPacked: true,
      }).promise;
      let page;
      if (pdf._pdfInfo.numPages > 100) {
        throw new Error("pageMorethan100")

      }
      for (let i = 0; i < pdf.numPages; i++) {
        page = await pdf.getPage(i + 1);
        const oList = await page.getOperatorList();
        let j;
        const jpegs = [];
        for (j = 0; j < oList.fnArray.length; j++) {
          if (oList.fnArray[j] === pdfjs.OPS.paintJpegXObject) {
            jpegs.push(j);
          }
        }
        let scale = 1;
        let canvasHeight = 0;
        let canvasWidth = 0;
        // if(jpegs.length === 1){
        //     // Jpeg file in pdf
        //   const j = jpegs[0];
        //   const op = oList.argsArray[j][0];
        //   const img = page.objs.get(op);
        //   if(img.height > img.width){
        //     scale = img.height / page.getViewport({scale: 1}).height;
        //   }else{
        //     scale = img.width / page.getViewport({scale: 1}).width;
        //   }
        //   canvasHeight = img.height;
        //   canvasWidth = img.width;
        // }else{
        // Not jpeg file in pdf
        const viewportPdf = await page.getViewport({ scale: 1 });
        if (viewportPdf.height > viewportPdf.width) {
          scale = deepICRCTX.pdfDefaultHeight / viewportPdf.height;
          canvasHeight = deepICRCTX.pdfDefaultHeight;
          canvasWidth = Math.ceil(viewportPdf.width * scale);
        } else {
          scale = deepICRCTX.pdfDefaultHeight / viewportPdf.width;
          canvasWidth = deepICRCTX.pdfDefaultHeight;
          canvasHeight = Math.ceil(viewportPdf.height * scale);
        }
        // }
        const canvas = document.createElement("canvas");
        const viewport = await page.getViewport({ scale: scale });
        canvas.height = canvasHeight;
        canvas.width = canvasWidth;
        const context = canvas.getContext("2d");
        const task = page.render({
          canvasContext: context,
          viewport: viewport,
        });
        try {
          await task.promise;
        } catch (e) {
          if (deepICRCTX.debug === true) {
            console.log(e);
          }
        }
        dataUrls.push(canvas.toDataURL("image/jpeg"));
        fileSizes.push({ height: canvasHeight, width: canvasWidth });
      }
      return [dataUrls, fileSizes, pdf.numPages];
    };

    const file = e.target.files[0];
    // console.group("file");
    // console.log({ file });
    // console.groupEnd();
    // console.log({file});

    // For locally upload the file in backend

    const options = {
      mode: "cors",
      headers: {
        'filename': encodeURI(file.name),
        'content-type': file.type,
      },
      method: 'PUT',
      body: file,
      rejectUnauthorized: false
    }

    if (file !== null) {
      fetch('http://' + host_address + ':5000/fileUpload',
        options
      )
        .then((response) => {

          return response.json();
        })
        .then((data) => {
          if (deepICRCTX.debug === true) console.log(data);
        })
        .catch(error => {
          if (deepICRCTX.debug === true) console.error(error)
        })
    }

    // Locally upload function ends

    const reader = new FileReader();
    setDeepICRCTX({ ...deepICRCTX, targetPages: "" })
    setInputPages("")
    reader.readAsDataURL(file);
    reader.onload = (e) => {

      // if(file.type === 'image/jpeg' || file.type === 'image/png') {
      if (file.type === "image/jpeg") {
        const img = new Image();
        img.onload = () => {
          setIsCSVChanged(false)
          global.rotation = [0];
          setDeepICRCTX({
            ...deepICRCTX,
            isContract: false,
            documentId: "",
            imageScale: deepICRCTX.inputViewerBounds.bounds.width / img.width,
            file: file,
            requestedFile: "",
            fileBase64: [reader.result],
            fileSize: [{ height: img.height, width: img.width }],
            pdfBase64: "",
            pdfPage: 1,
            pdfPages: 1,
            targetPages: "",
            searchTextValue: "",
            size: 12,
            originalOutputFontScale: 1,
            originalOutputSize: { height: 0, width: 0 },
            originalOutputData: { data: [] },
            originalOutputTable: { data: [] },
            extractedOutputData: { data: [] },
            extractedOutputTable: { data: [] },
            selectedRegion: {
              pages: []
            },
            shapeListRight: {},
            currentShapeRight: [],
            selectedShapeRight: [],
            outputJson: {},
            searchText: "",
            outputSw: false,
            croppingToolId: 3,
            selectedButton: false,
            outputTab: 0,
            shapeList: {},
            currentShape: [],
            selectedShape: [],
            shapeCounter: 0,
            pointCounter: 0,
            selectionPoints: [],
            popUpDialog: {
              image_id: "",
              shape_id: "",
              label: "",
              meta: "",
              left: 0,
              top: 0,
              show: false,
              testShow: false
            },
            templateJsonName: "",

          });
        };
        img.src = e.target.result;
        setIsCSVChanged(false);

      } else if (file.type === "application/pdf") {
        Promise.resolve()
          .then(() => {
            return new Promise((resolve, reject) => {
              resolve(pdfToJpeg(reader.result));
            });
          })
          .then(([dataUrls, fileSizes, pdfPages]) => {
            setFormat("csv_full");
            setIsCSVChanged(false)
            global.rotation = [];
            for (let i = 0; i < pdfPages; i++) {
              global.rotation.push(0);
            }

            setDeepICRCTX({
              ...deepICRCTX,
              isContract: false,
              documentId: "",
              imageScale: deepICRCTX.inputViewerBounds.bounds.width / fileSizes[0].width,
              file: file,
              requestedFile: "",
              fileBase64: dataUrls,
              fileSize: fileSizes,
              pdfBase64: reader.result,
              pdfPage: 1,
              pdfPages: pdfPages,
              targetPages: "",
              searchText: "",
              size: 12,
              originalOutputFontScale: 1,
              originalOutputSize: { height: 0, width: 0 },
              originalOutputData: { data: [] },
              originalOutputTable: { data: [] },
              extractedOutputData: { data: [] },
              extractedOutputTable: { data: [] },
              searchTextValue: "",
              outputSw: false,
              croppingToolId: 3,
              selectedButton: false,
              outputTab: 0,
              selectedRegion: {
                pages: []
              },
              shapeListRight: {},
              currentShapeRight: [],
              selectedShapeRight: [],
              outputJson: {},
              shapeList: {},
              currentShape: [],
              selectedShape: [],
              shapeCounter: 0,
              pointCounter: 0,
              selectionPoints: [],
              popUpDialog: {
                image_id: "",
                shape_id: "",
                label: "",
                meta: "",
                left: 0,
                top: 0,
                show: false,
              },
              jsonImported: false,
              templateJsonName: "",

            });
            setIsCSVChanged(false);


          })
          .catch((e) => {
            // console.log("e", e.message);
            if (e.message === "pageMorethan100") {
              props.enqueueSnackbar(`${t("errorFileExceedsMoreThan100Pages")}`, {
                variant: "error",
                anchorOrigin: { vertical: "top", horizontal: "right" },
              }
              )
              return
            }
            if (e.name === "PasswordException" || e.message === "fileSizeError") {
              props.enqueueSnackbar(`${t("stringUnsupportedMessage")}`, {
                variant: "error",
                anchorOrigin: { vertical: "top", horizontal: "right" },
              }
              )
              return
            }
            if (deepICRCTX.debug === true)
              if (deepICRCTX.debug === true) {
                console.log(e);
              }
            props.enqueueSnackbar(t("errorPdfToJpegProcess"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "PdfToJpegProcessError",
              Message: t("errorPdfToJpegProcess"),
              Src: "Toolbar.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
          });
        return
      }
    };
    document.getElementById("fileUploadInputButton").value = "";
  };

  //-------------------------------------------------------------------------------------------------
  // Validate input of pdf pages
  //-------------------------------------------------------------------------------------------------
  const validatePdfPages = (e) => {
    const inputText = e.target.value;
    if (inputText !== "") {
      if (typeof deepICRCTX.file.type === "undefined") {
        e.target.value = "";
        props.enqueueSnackbar(t("errorBeforeSetFile"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
      } else if (deepICRCTX.file.type !== "application/pdf") {
        e.target.value = "";
        props.enqueueSnackbar(t("errorNotPDF"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
      } else {
        if (!/^[0-9,-]+$/.test(inputText)) {
          // e.target.value = "";
          props.enqueueSnackbar(t("errorInputType") + "(" + inputText + ")", {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
        } else {
          let checkArray1 = [];
          let checkArray2 = {};
          const inputTextArray = inputText.split(",");
          inputTextArray.forEach((item) => {
            if (/^[1-9]\d*-[1-9]\d*$/.test(item)) {
              const [start, end] = item.split("-");
              if (Number(start) >= Number(end)) {
                // e.target.value = "";
                props.enqueueSnackbar(t("errorInputSequence") + "(" + item + ")", {
                  variant: "error",
                  anchorOrigin: { vertical: "top", horizontal: "right" },
                });
              }
              for (let i = Number(start); i <= Number(end); i++) {
                checkArray1.push(i);
                checkArray2[i] = "";
              }
            } else {
              if (!/^[1-9]\d*$/.test(item)) {
                // e.target.value = "";
                props.enqueueSnackbar(t("errorInputPattern") + "(" + item + ")", {
                  variant: "error",
                  anchorOrigin: { vertical: "top", horizontal: "right" },
                });
              } else {
                checkArray1.push(Number(item));
                checkArray2[Number(item)] = "";
              }
            }
          });
          if (e.target.value !== "") {
            const newCheckArray2 = Object.keys(checkArray2);
            if (checkArray1.length !== newCheckArray2.length) {
              // e.target.value = "";
              props.enqueueSnackbar(t("errorDuplicate") + "(" + inputText + ")", {
                variant: "error",
                anchorOrigin: { vertical: "top", horizontal: "right" },
              });
            } else {
              checkArray1.sort((a, b) => {
                return a - b;
              });
              let checkArray = [];
              let addText = "";
              checkArray1.forEach((n) => {
                if (n > deepICRCTX.pdfPages) {
                  if (checkArray.length < 10) {
                    checkArray.push(n);
                  } else {
                    addText = "...";
                  }
                }
              });
              if (checkArray.length !== 0) {
                if (addText !== "") {
                  checkArray.push(addText);
                }
                // e.target.value = "";
                props.enqueueSnackbar(t("errorOverPDFPages") + "(" + checkArray.join(",") + ")", {
                  variant: "error",
                  anchorOrigin: { vertical: "top", horizontal: "right" },
                });
              } else {
                setDeepICRCTX({ ...deepICRCTX, targetPages: checkArray1.join(",") });
              }
            }
          }
        }
      }
    }
  };

  //-------------------------------------------------------------------------------------------------
  // Parse output json file
  //-------------------------------------------------------------------------------------------------
  const parseOutputJson = (outputJson) => {
    if (outputJson.original_output.pages === undefined) return [0, 0, {}, {}, [], [], {}];
    const oResultArray = outputJson.original_output.pages;
    const oDataHeight = outputJson.original_output.pages[0].height;
    const oDataWidth = outputJson.original_output.pages[0].width;
    const documentName = outputJson.original_output.document_name;
    const prefixArray = documentName.split(".");
    prefixArray.pop();
    const prefix = prefixArray.join(".");
    // console.log("prefix", prefix);
    let id = 1;
    // let uniqueKeyForData = 0;
    let shapes = {};
    let isSel = false;

    const oData = { documentName: documentName };
    const oTable = { documentName: documentName };
    // console.log("result array", oResultArray);
    for (let i = 0; i < oResultArray.length; i++) {
      //  i = parseInt(oResultArray[i].id.replace(prefix + "_page_", "")) - 1;
      // let pageNo = oResultArray[i].id.split("_");
      // i = parseInt(pageNo[pageNo.length - 1] - 1);

      let uniqueKeyForData = 0;

      // const pag = oResultArray[i].id;
      // let pagLength = pag.split("_")
      // let pageNo = pagLength[pagLength.length - 1];
      // let i = parseInt(pageNo - 1);
      // console.log("page no", pageNo);
      // console.log("oresid", oResultArray[i].id);

      if (oResultArray[i].id !== prefix) {
        id = oResultArray[i].id.replace(prefix + "_page_", "");

      }
      oData[id] = {
        id: oResultArray[i].id,
        height: oResultArray[i].height,
        width: oResultArray[i].width,
        data: [],
      };
      oTable[id] = {
        id: oResultArray[i].id,
        data: [],
      };

      for (let j = 0; j < oResultArray[i].regions.length; j++) {
        // console.log("before",oResultArray[i].regions);
        // const sortedRegions = oResultArray[i].regions.sort((shapeA, shapeB) => {
        //   if (shapeA.y < shapeB.y) return -1;
        //   if (shapeA.y > shapeB.y) return 1;
        //   if (shapeA.x < shapeB.x) return -1;
        //   if (shapeA.x > shapeB.x) return 1;
        //   return 0;
        // })
        // console.log("after",sortedRegions);
        if (oResultArray[i].regions[j].selection_id !== undefined) isSel = true;
        if (
          oResultArray[i].regions[j].type === "Single Line" ||
          oResultArray[i].regions[j].type === "Line"
        ) {
          for (let k = 0; k < oResultArray[i].regions[j].words.length; k++) {
            oData[id].data.push({
              shape_id: oResultArray[i].regions[j].selection_id,
              shape_type: oResultArray[i].regions[j].selection_type,
              meta: oResultArray[i].regions[j].meta,
              x: oResultArray[i].regions[j].words[k].x,
              y: oResultArray[i].regions[j].words[k].y,
              width: oResultArray[i].regions[j].words[k].width,
              height: oResultArray[i].regions[j].words[k].height,
              text: oResultArray[i].regions[j].words[k].text,
              confidence: oResultArray[i].regions[j].words[k].confidence,
              key: i + "-" + j + "-" + k,
              color: oResultArray[i].regions[j].words[k].confidence < 0.9 ? "red" : "black",
              originalText: "",
              type: "dataFromLine",
              uniqueKey: uniqueKeyForData,
            });
            uniqueKeyForData++;
          }
        }
        // else if (oResultArray[i].regions[j].type === "Image") {
        //   // const img = deepICRCTX.fileBase64[i];
        //   const ratio = deepICRCTX.fileSize[i].width / oResultArray[i].width;

        //   let shape_info = {};
        //   let points = "";

        //   if (oResultArray[i].regions[j].selection_type === "rect") {
        //     let x = oResultArray[i].regions[j].x;
        //     let y = oResultArray[i].regions[j].y;
        //     let w = oResultArray[i].regions[j].width;
        //     let h = oResultArray[i].regions[j].height;
        //     shape_info = { type: "rect", x: x * ratio, y: y * ratio, w: w * ratio, h: h * ratio };
        //     // console.log("from 1396", shape_info);
        //   } else if (oResultArray[i].regions[j].selection_type === "ellipse") {
        //     let x = oResultArray[i].regions[j].x;
        //     let y = oResultArray[i].regions[j].y;
        //     let w = oResultArray[i].regions[j].width;
        //     let h = oResultArray[i].regions[j].height;
        //     shape_info = {
        //       type: "ellipse",
        //       x: x * ratio,
        //       y: y * ratio,
        //       w: w * ratio,
        //       h: h * ratio,
        //     };
        //   } else if (oResultArray[i].regions[j].selection_type === "polygon") {
        //     points = oResultArray[i].regions[j].points;

        //     let points_arr = points.split(" ");
        //     let points_dic = [];
        //     for (let p = 0; p < points_arr.length; p++) {
        //       let point = points_arr[p].split(",");
        //       points_dic.push({ x: point[0] * ratio, y: point[1] * ratio });
        //     }
        //     shape_info = { type: "polygon", points: points_dic };
        //   }
        //   oData[id].data.push({
        //     shape_id: oResultArray[i].regions[j].selection_id,
        //     shape_type: oResultArray[i].regions[j].selection_type,
        //     meta: oResultArray[i].regions[j].meta,
        //     x: oResultArray[i].regions[j].x,
        //     y: oResultArray[i].regions[j].y,
        //     width: oResultArray[i].regions[j].width,
        //     height: oResultArray[i].regions[j].height,
        //     key: i + "-" + j,
        //     points: oResultArray[i].regions[j].points,
        //     type: "Image",
        //     uniqueKey: uniqueKeyForData,
        //   });

        //   shapes[i + "-" + j] = shape_info;
        //   uniqueKeyForData++;
        // } 
        else if (oResultArray[i].regions[j].type === "Blank") {
          oData[id].data.push({
            shape_id: oResultArray[i].regions[j].selection_id,
            shape_type: oResultArray[i].regions[j].selection_type,
            meta: oResultArray[i].regions[j].meta,
            x: oResultArray[i].regions[j].x,
            y: oResultArray[i].regions[j].y,
            width: oResultArray[i].regions[j].width,
            height: oResultArray[i].regions[j].height,
            key: i + "-" + j,
            points: oResultArray[i].regions[j].points,
            type: "Blank",
            uniqueKey: uniqueKeyForData,
          });
          uniqueKeyForData++;
        } else if (oResultArray[i].regions[j].type === "Multi Line") {
          for (let k = 0; k < oResultArray[i].regions[j].lines.length; k++) {
            for (let l = 0; l < oResultArray[i].regions[j].lines[k].words.length; l++) {
              oData[id].data.push({
                shape_id: oResultArray[i].regions[j].selection_id,
                shape_type: oResultArray[i].regions[j].selection_type,
                meta: oResultArray[i].regions[j].meta,
                x: oResultArray[i].regions[j].lines[k].words[l].x,
                y: oResultArray[i].regions[j].lines[k].words[l].y,
                width: oResultArray[i].regions[j].lines[k].words[l].width,
                height: oResultArray[i].regions[j].lines[k].words[l].height,
                text: oResultArray[i].regions[j].lines[k].words[l].text,
                confidence: oResultArray[i].regions[j].lines[k].words[l].confidence,
                key: i + "-" + j + "-" + k + "-" + l,
                color:
                  oResultArray[i].regions[j].lines[k].words[l].confidence < 0.9 ? "red" : "black",
                originalText: "",
                type: "dataFromLine",
                uniqueKey: uniqueKeyForData,
              });
              uniqueKeyForData++;
            }
          }
        } else if (oResultArray[i].regions[j].type === "Handwritten") {
          if ("lines" in oResultArray[i].regions[j]) {
            for (let k = 0; k < oResultArray[i].regions[j].lines.length; k++) {
              for (let l = 0; l < oResultArray[i].regions[j].lines[k].words.length; l++) {
                oData[id].data.push({
                  shape_id: oResultArray[i].regions[j].selection_id,
                  shape_type: oResultArray[i].regions[j].selection_type,
                  meta: oResultArray[i].regions[j].meta,
                  x: oResultArray[i].regions[j].lines[k].words[l].x,
                  y: oResultArray[i].regions[j].lines[k].words[l].y,
                  width: oResultArray[i].regions[j].lines[k].words[l].width,
                  height: oResultArray[i].regions[j].lines[k].words[l].height,
                  text: oResultArray[i].regions[j].lines[k].words[l].text,
                  confidence: oResultArray[i].regions[j].lines[k].words[l].confidence,
                  key: i + "-" + j + "-" + k + "-" + l,
                  color:
                    oResultArray[i].regions[j].lines[k].words[l].confidence < 0.9 ? "red" : "black",
                  originalText: "",
                  type: "dataFromLine",
                  uniqueKey: uniqueKeyForData,
                });
                uniqueKeyForData++;
              }
            }
          }
        }
        //} else if(oResultArray[i].regions[j].type.match(/_Table/)) {
        else if (
          ((oResultArray[i].regions[j].type === "Table" ||
            oResultArray[i].regions[j].type.match(/_Table/)) && oResultArray[i].regions[j].type !== 'Borderless_Table')
        ) {
          for (let k = 0; k < oResultArray[i].regions[j].cells.length; k++) {
            oTable[id].data.push({
              shape_id: oResultArray[i].regions[j].selection_id,
              shape_type: oResultArray[i].regions[j].selection_type,
              meta: oResultArray[i].regions[j].meta,
              x: oResultArray[i].regions[j].cells[k].x,
              y: oResultArray[i].regions[j].cells[k].y,
              width: oResultArray[i].regions[j].cells[k].width,
              height: oResultArray[i].regions[j].cells[k].height,
              row_no: oResultArray[i].regions[j].cells[k].row_no,
              col_no: oResultArray[i].regions[j].cells[k].col_no,
              row_span: oResultArray[i].regions[j].cells[k].row_span,
              col_span: oResultArray[i].regions[j].cells[k].col_span,
              key: i + "-" + j + "-" + k,
              type: "borderFromTable",
            });
            for (let l = 0; l < oResultArray[i].regions[j].cells[k].cell.length; l++) {
              // console.log("table cell text", oResultArray[i].regions[j].cells[k].cell_text);
              for (let m = 0; m < oResultArray[i].regions[j].cells[k].cell[l].words.length; m++) {
                if (oResultArray[i].regions[j].cells[k].cell[l].words[m].text !== "") {
                  oData[id].data.push({
                    shape_id: oResultArray[i].regions[j].selection_id,
                    shape_type: oResultArray[i].regions[j].selection_type,
                    meta: oResultArray[i].regions[j].meta,
                    x: oResultArray[i].regions[j].cells[k].cell[l].words[m].x,
                    y: oResultArray[i].regions[j].cells[k].cell[l].words[m].y,
                    width: oResultArray[i].regions[j].cells[k].cell[l].words[m].width,
                    height: oResultArray[i].regions[j].cells[k].cell[l].words[m].height,
                    text: oResultArray[i].regions[j].cells[k].cell[l].words[m].text,
                    confidence: oResultArray[i].regions[j].cells[k].cell[l].words[m].confidence,
                    key: i + "-" + j + "-" + k + "-" + l + "-" + m,  //page: i, regions: j, cells: k, cell: l, words: m
                    color:
                      oResultArray[i].regions[j].cells[k].cell[l].words[m].confidence < 0.9
                        ? "red"
                        : "black",
                    originalText: "",
                    type: "dataFromTable",
                    uniqueKey: uniqueKeyForData,
                  });
                  uniqueKeyForData++;
                }
              }
            }
          }
        }
      }
    }
    if (isSel) setFormat("crop");
    // else setFormat("csv"); //tsv

    setDeepICRCTX({
      ...deepICRCTX,
      isSelection: isSel,
    });

    const eData = {};
    const eTable = {};
    const eResultArray = outputJson.extracted_output;
    Object.keys(eResultArray).forEach((key) => {
      if (key === "details") {
        for (let p in eResultArray[key].values) {
          let tables = {};
          for (let t in eResultArray[key].values[p]) {
            let rows = [];
            for (let i = 0; i < eResultArray[key].values[p][t].length; i++) {
              let cols = [];
              for (let j = 0; j < eResultArray[key].values[p][t][i].length; j++) {
                cols.push({
                  row: i,
                  column: j,
                  value: eResultArray[key].values[p][t][i][j],
                  originalValue: "",
                  color: "black",
                  null: eResultArray[key].values[p][t][i][j] === "" ? true : false,
                });
              }
              rows.push(cols);
            }
            tables[t] = rows;
          }
          eTable[p] = tables;
        }
      } else {
        eData[key] = [];
        if (eResultArray[key] !== undefined) {
          if (
            eResultArray[key].values !== undefined &&
            typeof eResultArray[key].values === "string"
          ) {
            eData[key] = {
              en_label: eResultArray[key].en_label,
              jp_label: eResultArray[key].jp_label,
              values: [
                {
                  key: 0,
                  value: eResultArray[key].values,
                  originalValue: "",
                  color: "black",
                  null: eResultArray[key].values === "" ? true : false,
                },
              ],
            };
          } else {
            if (eResultArray[key].values === undefined || eResultArray[key].values.length === 0) {
              eData[key] = {
                en_label: eResultArray[key].en_label,
                jp_label: eResultArray[key].jp_label,
                values: [
                  {
                    key: 0,
                    value: "",
                    originalValue: "",
                    color: "black",
                    null: true,
                  },
                ],
              };
            } else {
              let values = [];
              if (eResultArray[key].values !== undefined) {
                for (let i = 0; i < eResultArray[key].values.length; i++) {
                  values.push({
                    key: i,
                    value: eResultArray[key].values[i],
                    originalValue: "",
                    color: "black",
                    null: eResultArray[key].values[i] === "" ? true : false,
                  });
                }
              }
              eData[key] = {
                en_label: eResultArray[key].en_label,
                jp_label: eResultArray[key].jp_label,
                values: values,
              };
            }
          }
        }
      }
    });
    return [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes];
  };


  // Upload file to S3 and Convert by Deep ICR
  
  // const uploadAndConvert = async () => {
  //   setIsDisableConvert(true)
  //   if (typeof deepICRCTX.file.name === "undefined" || deepICRCTX.file.name === "") {
  //     props.enqueueSnackbar(t("errorBeforeSetFile"), {
  //       variant: "error",
  //       anchorOrigin: { vertical: "top", horizontal: "right" },
  //     });
  //     deepICRLogging({
  //       LogType: "ERROR",
  //       ErrType: "BeforeSetFileError",
  //       Message: t("errorBeforeSetFile"),
  //       Src: "Toolbar.js",
  //       Line: 0,
  //       Column: 0,
  //       Stack: "",
  //     });
  //     setIsDisableConvert(false)
  //     return;
  //   }

  //   if (deepICRCTX.file.name === deepICRCTX.requestedFile) {
  //     props.enqueueSnackbar(t("errorRequestSameFile"), {
  //       variant: "error",
  //       anchorOrigin: { vertical: "top", horizontal: "right" },
  //     });
  //     deepICRLogging({
  //       LogType: "ERROR",
  //       ErrType: "RequestSameFileError",
  //       Message: t("errorRequestSameFile"),
  //       Src: "Toolbar.js",
  //       Line: 0,
  //       Column: 0,
  //       Stack: "",
  //     });
  //     setIsDisableConvert(false)
  //     return;
  //   }

  //   // Upload image data and input json to S3
  //   const snackbarDoConvert = props.enqueueSnackbar(t("infoDoConvert") + deepICRCTX.file.name, {
  //     variant: "info",
  //     persist: true,
  //     anchorOrigin: { vertical: "bottom", horizontal: "right" },
  //   });
  //   const [yyyymmddhhmmss, unixtime, microsec] = deepICRNow();
  //   // Get hash of Username
  //   const md5 = crypto.createHash("md5");
  //   const md5hash = md5.update(deepICRCTX.cognitoUser.Username, "binary").digest("hex");

  //   // Refresh token
  //   let isError = false;
  //   let newAccessToken = "";
  //   let requestJson = {
  //     type: "request",
  //     head: {
  //       command: "refreshToken",
  //       format_version: deepICRCTX.apiFormatVersion,
  //       service_id: deepICRCTX.apiServiceId,
  //       transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
  //       unix_time: unixtime,
  //       micro_seconds: microsec,
  //       time_zone: deepICRCTX.apiTimeZone,
  //     },
  //     //      "body": {refreshToken: deepICRCTX.refreshToken, username: deepICRCTX.cognitoUser.Username}
  //     body: { refreshToken: global.refreshToken, username: deepICRCTX.cognitoUser.Username },
  //   };
  //   await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTokenRefresh, {
  //     method: "POST",
  //     mode: "cors",
  //     //        headers: {Authorization: deepICRCTX.accessToken, "Content-Type": "application/json"},
  //     headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
  //     body: JSON.stringify(requestJson),
  //   })
  //     .then((res) => {
  //       return res.json();
  //     })
  //     .then((json) => {
  //       // Timeout access token
  //       if (json.message === "Unauthorized") {
  //         props.closeSnackbar(snackbarDoConvert);
  //         props.enqueueSnackbar(t("errorLoginTimeout"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "LoginTimeoutError",
  //           Message: t("errorLoginTimeout"),
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         logout();
  //         isError = true;
  //         return;
  //       }
  //       if (json.body.status !== "OK") {
  //         if (json.body.error.message === "Token do not match") {
  //           props.closeSnackbar(snackbarDoConvert);
  //           props.enqueueSnackbar(t("errorLoginDuplicate"), {
  //             variant: "error",
  //             anchorOrigin: { vertical: "top", horizontal: "right" },
  //           });
  //           deepICRLogging({
  //             LogType: "ERROR",
  //             ErrType: "DuplicateLoginError",
  //             Message: t("errorLoginDuplicate"),
  //             Src: "Toolbar.js",
  //             Line: 0,
  //             Column: 0,
  //             Stack: "",
  //           });
  //           logout();
  //           isError = true;
  //           return;
  //         } else {
  //           if (deepICRCTX.debug === true) {
  //             console.log("[ToolBar - updateJson] token-refresh error for output json file");
  //           }
  //           if (deepICRCTX.debug === true) {
  //             console.log(JSON.stringify(json, null, 1));
  //           }
  //           props.closeSnackbar(snackbarDoConvert);
  //           props.enqueueSnackbar(t("errorSystemError"), {
  //             variant: "error",
  //             anchorOrigin: { vertical: "top", horizontal: "right" },
  //           });
  //           deepICRLogging({
  //             LogType: "ERROR",
  //             ErrType: "TokenRefreshFetchError",
  //             Message: "token-refresh error for output json file",
  //             Src: "Toolbar.js",
  //             Line: 0,
  //             Column: 0,
  //             Stack: "",
  //           });
  //           isError = true;
  //           return;
  //         }
  //       }
  //       newAccessToken = json.body.result.accessToken;
  //       global.accessToken = newAccessToken;
  //       // setDeepICRCTX({
  //       //   ...deepICRCTX,
  //       //   accessToken: json.body.result.accessToken
  //       // });
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - updateJson] token-refresh catch error for output json file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.closeSnackbar(snackbarDoConvert);
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "TokenRefreshCatchError",
  //         Message: "token-refresh catch error for output json file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });
  //   if (isError) {
  //     setIsDisableConvert(false)
  //     return;
  //   }

  //   // Get Presigned URL for image file
  //   let presignedUrl = "";
  //   requestJson.head.command = "getPresignedUrl";
  //   let putFileName = deepICRCTX.file.name;
  //   let putFileNamePre = "";
  //   if (deepICRCTX.file.type === "application/pdf") {
  //     let parts = deepICRCTX.file.name.split(".");
  //     parts.pop();
  //     putFileNamePre = parts.join(".");
  //     putFileName = putFileNamePre + ".zip";
  //   }
  //   requestJson.body = {
  //     keys: [deepICRCTX.s3Path + "/" + md5hash + "/" + yyyymmddhhmmss + "/" + putFileName],
  //     operation: "PUT",
  //   };
  //   await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
  //     method: "POST",
  //     mode: "cors",
  //     headers: { Authorization: newAccessToken, "Content-Type": "application/json" },
  //     body: JSON.stringify(requestJson),
  //   })
  //     .then((res) => {
  //       return res.json();
  //     })
  //     .then((json) => {
  //       if (json.body.status !== "OK") {
  //         if (deepICRCTX.debug === true) {
  //           console.log("[ToolBar - uploadAndConvert] get-signed-url error for image file");
  //         }
  //         if (deepICRCTX.debug === true) {
  //           console.log(JSON.stringify(json, null, 1));
  //         }
  //         props.enqueueSnackbar(t("errorSystemError"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "SignedUrlFetchError",
  //           Message: "get-signed-url error for image file",
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         isError = true;
  //         return;
  //       }
  //       presignedUrl = json.body.result.urls[0];
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - uploadAndConvert] get-signed-url catch error for image file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.closeSnackbar(snackbarDoConvert);
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "SignedUrlCatchError",
  //         Message: "get-signed-url catch error for image file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });
  //   if (isError) {
  //     setIsDisableConvert(false)
  //     return;
  //   }

  //   // Put image file to S3
  //   let binFile = "";
  //   let contentType = deepICRCTX.file.type;
  //   if (deepICRCTX.file.type === "image/jpeg") {
  //     const encodedFile = deepICRCTX.fileBase64[0].replace(/^data:\w+\/\w+;base64,/, "");
  //     binFile = new Buffer(encodedFile, "base64");
  //   } else {
  //     // Create Zip file
  //     const zip = new JSZip();
  //     const now = new Date();
  //     const dateWithOffset = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  //     try {
  //       zip.file(deepICRCTX.file.name, deepICRCTX.pdfBase64.replace(/^data:\w+\/\w+;base64,/, ""), {
  //         date: dateWithOffset,
  //         base64: true,
  //       });
  //       for (let i = 1; i <= deepICRCTX.pdfPages; i++) {
  //         zip.file(
  //           `${putFileNamePre}_${i}.jpg`,
  //           deepICRCTX.fileBase64[i - 1].replace(/^data:\w+\/\w+;base64,/, ""),
  //           { date: dateWithOffset, base64: true }
  //         );
  //       }
  //       zip.file(putFileNamePre + ".txt", JSON.stringify(deepICRCTX.fileSize), {
  //         date: dateWithOffset,
  //       });
  //       binFile = await zip.generateAsync({ type: "arraybuffer" });
  //       contentType = "application/zip";
  //     } catch (e) {
  //       if (deepICRCTX.debug === true) {
  //         if (deepICRCTX.debug === true) {
  //           console.log(e);
  //         }
  //       }
  //       props.closeSnackbar(snackbarDoConvert);
  //       props.enqueueSnackbar(t("errorZipProcess"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "ZipProcessError",
  //         Message: t("errorZipProcess"),
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     }
  //   }
  //   await fetch(presignedUrl, {
  //     method: "PUT",
  //     mode: "cors",
  //     headers: { "Content-Type": contentType },
  //     body: binFile,
  //   })
  //     .then((json) => {
  //       if (json.ok !== true) {
  //         if (deepICRCTX.debug === true) {
  //           console.log("[ToolBar - uploadAndConvert] fetch error for image file");
  //         }
  //         if (deepICRCTX.debug === true) {
  //           console.log(JSON.stringify(json, null, 1));
  //         }
  //         props.closeSnackbar(snackbarDoConvert);
  //         props.enqueueSnackbar(t("errorUpload"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "UploadError",
  //           Message: t("errorUpload"),
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         isError = true;
  //         return;
  //       }
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - uploadAndConvert] fetch catch error for image file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.closeSnackbar(snackbarDoConvert);
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       isError = true;
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "ImageFileCatchError",
  //         Message: "fetch catch error for image file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       return;
  //     });
  //   if (isError) {
  //     setIsDisableConvert(false)
  //     return;
  //   }
  //   // await fetch(deepICRCTX.apiUrlBase + '/template-selection/import-template', {
  //   //   method: "POST",
  //   //   mode: "cors",
  //   //   headers: { Authorization: newAccessToken, "Content-Type": "application/json" },
  //   //   body: JSON.stringify({
  //   //     "contract_id" : "23453678",
  //   //     "user_id" : "dddd",
  //   //     "input_file_info":{

  //   //         "bucket_name" : "bucket 1",
  //   //         "file_path" : "auto/template/files", 
  //   //         "file_name" : "test1.pdf", 
  //   //         "custom_pages" : [2,3,4,5]
  //   //         }
  //   // }),
  //   // })
  //   //   .then((res) => {
  //   //     return res.json();
  //   //   })
  //   //   .then((json)=>{
  //   //     console.log("Response",json);
  //   //   })
  //   // Get Presigned URL for input json file
  //   presignedUrl = "";
  //   requestJson.head.command = "getPresignedUrl";
  //   requestJson.body = {
  //     keys: [
  //       deepICRCTX.s3Path +
  //       "/" +
  //       md5hash +
  //       "/" +
  //       yyyymmddhhmmss +
  //       "/" +
  //       deepICRCTX.file.name.match(/(.*)(?:\.([^.]+$))/)[1] +
  //       "_in.json",
  //     ],
  //     operation: "PUT",
  //   };
  //   await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
  //     method: "POST",
  //     mode: "cors",
  //     headers: { Authorization: newAccessToken, "Content-Type": "application/json" },
  //     body: JSON.stringify(requestJson),
  //   })
  //     .then((res) => {
  //       return res.json();
  //     })
  //     .then((json) => {
  //       if (json.body.status !== "OK") {
  //         if (deepICRCTX.debug === true) {
  //           console.log("[ToolBar - uploadAndConvert] get-signed-url error for input json file");
  //         }
  //         if (deepICRCTX.debug === true) {
  //           console.log(JSON.stringify(json, null, 1));
  //         }
  //         props.closeSnackbar(snackbarDoConvert);
  //         props.enqueueSnackbar(t("errorSystemError"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "SignedUrlFetchError",
  //           Message: "get-signed-url error for input json file",
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         isError = true;
  //         return;
  //       }
  //       presignedUrl = json.body.result.urls[0];
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log(
  //           "[ToolBar - uploadAndConvert] get-signed-url catch error for input json file"
  //         );
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.closeSnackbar(snackbarDoConvert);
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "SignedUrlCatchError",
  //         Message: "get-signed-url catch error for input json file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });

  //   if (isError) {
  //     setIsDisableConvert(false)
  //     return;
  //   }

  //   // Put input json file to S3
  //   let pagesArray = [];
  //   if (deepICRCTX.targetPages !== "") {
  //     deepICRCTX.targetPages.split(",").forEach((item) => {
  //       pagesArray.push(isNaN(item) ? item : Number(item));
  //     });
  //   }
  //   const inputJson = {
  //     bucket_name: deepICRCTX.s3Bucket,
  //     img_path: deepICRCTX.s3Path + "/" + md5hash + "/" + yyyymmddhhmmss,
  //     img_file_name: putFileName,
  //     output_path: deepICRCTX.s3Path + "/" + md5hash + "/" + yyyymmddhhmmss,
  //     output_json_name: deepICRCTX.file.name.match(/(.*)(?:\.([^.]+$))/)[1] + "_out.json",
  //     target_type: type,
  //     custom_pages: pagesArray,
  //     pdf_pages: deepICRCTX.file.type === "application/pdf" ? deepICRCTX.pdfPages : 0,
  //     pdf_rotations: global.rotation,
  //     file_size: deepICRCTX.file.size,
  //     selection_info: deepICRCTX.shapeList,
  //   };
  //   const decoded = jwtDecode(global.accessToken);
  //   let contract_id = decoded.client_id
  //   let user_id = decoded.username
    
  //   storeData({file_path:deepICRCTX.s3Path + "/" + md5hash + "/" + yyyymmddhhmmss, file_name: putFileName,contract_id,user_id})

  //   await fetch(presignedUrl, {
  //     method: "PUT",
  //     mode: "cors",
  //     headers: { "Content-Type": "application/json" },
  //     body: JSON.stringify(inputJson, null, 4),
  //   })
  //     .then((json) => {
  //       if (json.ok !== true) {
  //         if (deepICRCTX.debug === true) {
  //           console.log("[ToolBar - uploadAndConvert] fetch error for input json file");
  //         }
  //         if (deepICRCTX.debug === true) {
  //           console.log(JSON.stringify(json, null, 1));
  //         }
  //         props.closeSnackbar(snackbarDoConvert);
  //         props.enqueueSnackbar(t("errorUpload"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "UploadError",
  //           Message: t("errorUpload"),
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         isError = true;
  //         return;
  //       }
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - uploadAndConvert] fetch catch error for input json file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.closeSnackbar(snackbarDoConvert);
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "ImageFileCatchError",
  //         Message: "fetch catch error for input json file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });

  //   if (isError) {
  //     setIsDisableConvert(false)
  //     return;
  //   }

  //   setDeepICRCTX({
  //     ...deepICRCTX,
  //     documentId: "",
  //     requestedFile: deepICRCTX.file.name,
  //     originalOutputFontScale: 1,
  //     originalOutputSize: { height: 0, width: 0 },
  //     originalOutputData: { data: [] },
  //     originalOutputTable: { data: [] },
  //     extractedOutputData: { data: [] },
  //     extractedOutputTable: { data: [] },
  //     searchText: "",
  //     outputSw: false,
  //   });

  //   // Check response from Deep ICR
  //   requestJson.body = {
  //     key:
  //       deepICRCTX.s3Path +
  //       "/" +
  //       md5hash +
  //       "/" +
  //       yyyymmddhhmmss +
  //       "/" +
  //       deepICRCTX.file.name.match(/(.*)(?:\.([^.]+$))/)[1] +
  //       "_out.json",
  //   };
  //   const checkS3 = (time, limit, counter) => {
  //     setTimeout(() => {
  //       console.log("polling...");
  //       fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiPolling, {
  //         method: "POST",
  //         mode: "cors",
  //         headers: { Authorization: newAccessToken, "Content-Type": "application/json" },
  //         body: JSON.stringify(requestJson),
  //       })
  //         .then((res) => {
  //           return res.json();
  //         })
  //         .then((json) => {
  //           if (json.body.status !== "OK") {
  //             if (deepICRCTX.debug === true) {
  //               console.log("[ToolBar - uploadAndConvert] polling error");
  //             }
  //             if (deepICRCTX.debug === true) {
  //               console.log(JSON.stringify(json, null, 1));
  //             }
  //             props.closeSnackbar(snackbarDoConvert);
  //             props.enqueueSnackbar(t("errorSystemError"), {
  //               variant: "error",
  //               anchorOrigin: { vertical: "top", horizontal: "right" },
  //             });
  //             deepICRLogging({
  //               LogType: "ERROR",
  //               ErrType: "PollingError",
  //               Message: "Polling error",
  //               Src: "Toolbar.js",
  //               Line: 0,
  //               Column: 0,
  //               Stack: "",
  //             });
  //             setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //             isError = true;
  //             return;
  //           } else if (json.body.result === "Exists") {
  //             props.closeSnackbar(snackbarDoConvert);

  //             // Get Presigned URL for input json file
  //             requestJson.body = {
  //               keys: [
  //                 deepICRCTX.s3Path +
  //                 "/" +
  //                 md5hash +
  //                 "/" +
  //                 yyyymmddhhmmss +
  //                 "/" +
  //                 deepICRCTX.file.name.match(/(.*)(?:\.([^.]+$))/)[1] +
  //                 "_out.json",
  //               ],
  //               operation: "GET",
  //             };
  //             presignedUrl = "";
  //             Promise.resolve()
  //               .then(() => {
  //                 return new Promise((resolve, reject) => {
  //                   fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
  //                     method: "POST",
  //                     mode: "cors",
  //                     headers: {
  //                       Authorization: newAccessToken,
  //                       "Content-Type": "application/json",
  //                     },
  //                     body: JSON.stringify(requestJson),
  //                   })
  //                     .then((res) => {
  //                       return res.json();
  //                     })
  //                     .then((json) => {
  //                       if (json.body.status !== "OK") {
  //                         if (deepICRCTX.debug === true) {
  //                           console.log(
  //                             "[ToolBar - uploadAndConvert] get-signed-url error for output json file"
  //                           );
  //                         }
  //                         if (deepICRCTX.debug === true) {
  //                           console.log(JSON.stringify(json, null, 1));
  //                         }
  //                         deepICRLogging({
  //                           LogType: "ERROR",
  //                           ErrType: "SignedUrlFetchError",
  //                           Message: "get-signed-url error for output json file",
  //                           Src: "Toolbar.js",
  //                           Line: 0,
  //                           Column: 0,
  //                           Stack: "",
  //                         });
  //                         reject("error");
  //                       } else {
  //                         resolve(json.body.result.urls[0]);
  //                       }
  //                     })
  //                     .catch((err) => {
  //                       if (deepICRCTX.debug === true) {
  //                         console.log(
  //                           "[ToolBar - uploadAndConvert] get-signed-url catch error for output json file"
  //                         );
  //                       }
  //                       if (deepICRCTX.debug === true) {
  //                         console.log(err);
  //                       }
  //                       deepICRLogging({
  //                         LogType: "ERROR",
  //                         ErrType: "SignedUrlCatchError",
  //                         Message: "get-signed-url catch error for output json file",
  //                         Src: "Toolbar.js",
  //                         Line: 0,
  //                         Column: 0,
  //                         Stack: "",
  //                       });
  //                       reject(err);
  //                     });
  //                 });
  //               })
  //               .then((presignedUrl) => {
  //                 return new Promise((resolve, reject) => {
  //                   fetch(presignedUrl, {
  //                     method: "GET",
  //                     mode: "cors",
  //                   })
  //                     .then((res) => {
  //                       return res.text();
  //                     })
  //                     .then((text) => {
  //                       let outputJson = JSON.parse(text);
  //                       if (
  //                         outputJson.statusCode === null ||
  //                         outputJson.statusCode === undefined ||
  //                         outputJson.statusCode.length === 0 ||
  //                         (outputJson.statusCode.length > 0 && outputJson.statusCode[0] !== 200) ||
  //                         (typeof outputJson.statusCode !== "object" &&
  //                           outputJson.statusCode !== 200)
  //                       ) {
  //                         if (deepICRCTX.debug === true) {
  //                           console.log(
  //                             "[ToolBar - uploadAndConvert] fetch error for output json file"
  //                           );
  //                         }
  //                         if (deepICRCTX.debug === true) {
  //                           console.log(JSON.stringify(outputJson, null, 1));
  //                         }
  //                         props.enqueueSnackbar(t("errorConvert"), {
  //                           variant: "error",
  //                           persist: true,
  //                           anchorOrigin: { vertical: "top", horizontal: "right" },
  //                         });
  //                         deepICRLogging({
  //                           LogType: "ERROR",
  //                           ErrType: "ConvertError",
  //                           Message: t("errorConvert"),
  //                           Src: "Toolbar.js",
  //                           Line: 0,
  //                           Column: 0,
  //                           Stack: "",
  //                         });
  //                         setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //                         isError = true;
  //                         return;
  //                       }

  //                       // Refresh token
  //                       requestJson.head.command = "refreshToken";
  //                       //                  requestJson.body = {refreshToken: deepICRCTX.refreshToken, username: deepICRCTX.cognitoUser.Username};
  //                       requestJson.body = {
  //                         refreshToken: global.refreshToken,
  //                         username: deepICRCTX.cognitoUser.Username,
  //                       };
  //                       fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTokenRefresh, {
  //                         method: "POST",
  //                         mode: "cors",
  //                         //                      headers: {Authorization: deepICRCTX.accessToken, "Content-Type": "application/json"},
  //                         headers: {
  //                           Authorization: global.accessToken,
  //                           "Content-Type": "application/json",
  //                         },
  //                         body: JSON.stringify(requestJson),
  //                       })
  //                         .then((res) => {
  //                           return res.json();
  //                         })
  //                         .then((json) => {
  //                           // Timeout access token
  //                           if (json.message === "Unauthorized") {
  //                             props.enqueueSnackbar(t("errorLoginTimeout"), {
  //                               variant: "error",
  //                               anchorOrigin: { vertical: "top", horizontal: "right" },
  //                             });
  //                             deepICRLogging({
  //                               LogType: "ERROR",
  //                               ErrType: "LoginTimeoutError",
  //                               Message: t("errorLoginTimeout"),
  //                               Src: "Toolbar.js",
  //                               Line: 0,
  //                               Column: 0,
  //                               Stack: "",
  //                             });
  //                             logout();
  //                             isError = true;
  //                             return;
  //                           }
  //                           if (json.body.status !== "OK") {
  //                             if (json.body.error.message === "Token do not match") {
  //                               props.enqueueSnackbar(t("errorLoginDuplicate"), {
  //                                 variant: "error",
  //                                 anchorOrigin: { vertical: "top", horizontal: "right" },
  //                               });
  //                               deepICRLogging({
  //                                 LogType: "ERROR",
  //                                 ErrType: "DuplicateLoginError",
  //                                 Message: t("errorLoginDuplicate"),
  //                                 Src: "Toolbar.js",
  //                                 Line: 0,
  //                                 Column: 0,
  //                                 Stack: "",
  //                               });
  //                               logout();
  //                               isError = true;
  //                               return;
  //                             } else {
  //                               if (deepICRCTX.debug === true) {
  //                                 console.log(
  //                                   "[ToolBar - uploadAndConvert] token-refresh error after convert success"
  //                                 );
  //                               }
  //                               if (deepICRCTX.debug === true) {
  //                                 console.log(JSON.stringify(json, null, 1));
  //                               }
  //                               props.enqueueSnackbar(t("errorSystemError"), {
  //                                 variant: "error",
  //                                 anchorOrigin: { vertical: "top", horizontal: "right" },
  //                               });
  //                               deepICRLogging({
  //                                 LogType: "ERROR",
  //                                 ErrType: "TokenRefreshFetchError",
  //                                 Message: t("tracFetchError"),
  //                                 Src: "Toolbar.js",
  //                                 Line: 0,
  //                                 Column: 0,
  //                                 Stack: "",
  //                               });
  //                               setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //                               isError = true;
  //                               return;
  //                             }
  //                           }
  //                           newAccessToken = json.body.result.accessToken;
  //                           global.accessToken = newAccessToken;

  //                           const isContract = outputJson.target_type === "contract" ? true : false;
  //                           setJson(outputJson);
  //                           let oDataHeight = 0;
  //                           let oDataWidth = 0;
  //                           let oData = {};
  //                           let oTable = {};
  //                           let eData = [];
  //                           let eTable = [];
  //                           let shapes = {};
  //                           [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes] =
  //                             parseOutputJson(outputJson);
  //                           const file = deepICRCTX.file;
  //                           file.yyyymmddhhmmss = yyyymmddhhmmss;
  //                           setDeepICRCTX({
  //                             ...deepICRCTX,
  //                             //                      accessToken: newAccessToken,
  //                             outputJson: outputJson,
  //                             isContract: isContract,
  //                             outputTab: 0,
  //                             file: file,
  //                             requestedFile: "",
  //                             originalOutputSize: { height: oDataHeight, width: oDataWidth },
  //                             originalOutputData: { data: oData },
  //                             originalOutputTable: { data: oTable },
  //                             extractedOutputData: { data: eData },
  //                             extractedOutputTable: { data: eTable },
  //                             croppedImages: shapes,
  //                             outputSw: true,
  //                             selectedRegion: {
  //                               pages: []
  //                             },
  //                             selectedShapeRight: [],
  //                             shapeListRight: {},
  //                             selectedButton: false,
  //                             jsonImported: false,
  //                             searchTextValue: "",
  //                             searchText: ""
  //                           });
  //                           setIsCSVChanged(false)
  //                           setIsDisableConvert(false)
  //                         })
  //                         .catch((err) => {
  //                           if (deepICRCTX.debug === true) {
  //                             console.log(
  //                               "[ToolBar - uploadAndConvert] token-refresh catch error after convert success"
  //                             );
  //                           }
  //                           if (deepICRCTX.debug === true) {
  //                             console.log(err);
  //                           }
  //                           props.enqueueSnackbar(t("errorSystemError"), {
  //                             variant: "error",
  //                             anchorOrigin: { vertical: "top", horizontal: "right" },
  //                           });
  //                           deepICRLogging({
  //                             LogType: "ERROR",
  //                             ErrType: "TokenRefreshCatchError",
  //                             Message: "token-refresh catch error after convert success",
  //                             Src: "Toolbar.js",
  //                             Line: 0,
  //                             Column: 0,
  //                             Stack: "",
  //                           });
  //                           setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //                           isError = true;
  //                           return;
  //                         });
  //                       if (isError) {
  //                         setIsDisableConvert(false)
  //                         return;
  //                       }
  //                     })
  //                     .catch((err) => {
  //                       if (deepICRCTX.debug === true) {
  //                         console.log(
  //                           "[ToolBar - uploadAndConvert] fetch catch error for output json file"
  //                         );
  //                       }
  //                       if (deepICRCTX.debug === true) {
  //                         console.log(err);
  //                       }
  //                       deepICRLogging({
  //                         LogType: "ERROR",
  //                         ErrType: "OutputJsonCatchError",
  //                         Message: "fetch catch error for output json file",
  //                         Src: "Toolbar.js",
  //                         Line: 0,
  //                         Column: 0,
  //                         Stack: "",
  //                       });
  //                       reject(err);
  //                     });
  //                 });
  //               })
  //               .catch((err) => {
  //                 if (deepICRCTX.debug === true) {
  //                   console.log(
  //                     "[ToolBar - uploadAndConvert] get-signed-url catch error for output json file"
  //                   );
  //                 }
  //                 if (deepICRCTX.debug === true) {
  //                   console.log(err);
  //                 }
  //                 props.enqueueSnackbar(t("errorSystemError"), {
  //                   variant: "error",
  //                   anchorOrigin: { vertical: "top", horizontal: "right" },
  //                 });
  //                 deepICRLogging({
  //                   LogType: "ERROR",
  //                   ErrType: "SignedUrlCatchError",
  //                   Message: "get-signed-url catch error for output json file",
  //                   Src: "Toolbar.js",
  //                   Line: 0,
  //                   Column: 0,
  //                   Stack: "",
  //                 });
  //                 setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //                 isError = true;
  //                 return;
  //               });
  //           } else {
  //             if (counter < limit) {
  //               counter++;
  //               checkS3(time, limit, counter);
  //             } else {
  //               props.closeSnackbar(snackbarDoConvert);
  //               props.enqueueSnackbar(t("errorCannotConvert"), {
  //                 variant: "error",
  //                 persist: true,
  //                 anchorOrigin: { vertical: "top", horizontal: "right" },
  //               });
  //               deepICRLogging({
  //                 LogType: "ERROR",
  //                 ErrType: "CovertError",
  //                 Message: t("errorCannotConvert"),
  //                 Src: "Toolbar.js",
  //                 Line: 0,
  //                 Column: 0,
  //                 Stack: "",
  //               });

  //               // Refresh token
  //               requestJson.head.command = "refreshToken";
  //               // requestJson.body = {refreshToken: deepICRCTX.refreshToken, username: deepICRCTX.cognitoUser.Username};
  //               requestJson.body = {
  //                 refreshToken: global.refreshToken,
  //                 username: deepICRCTX.cognitoUser.Username,
  //               };

  //               fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTokenRefresh, {
  //                 method: "POST",
  //                 mode: "cors",
  //                 // headers: {Authorization: deepICRCTX.accessToken, "Content-Type": "application/json"},
  //                 headers: {
  //                   Authorization: global.accessToken,
  //                   "Content-Type": "application/json",
  //                 },
  //                 body: JSON.stringify(requestJson),
  //               })
  //                 .then((res) => {
  //                   return res.json();
  //                 })
  //                 .then((json) => {
  //                   // Timeout access token
  //                   if (json.message === "Unauthorized") {
  //                     props.enqueueSnackbar(t("errorLoginTimeout"), {
  //                       variant: "error",
  //                       anchorOrigin: { vertical: "top", horizontal: "right" },
  //                     });
  //                     deepICRLogging({
  //                       LogType: "ERROR",
  //                       ErrType: "LoginTimeoutError",
  //                       Message: t("errorLoginTimeout"),
  //                       Src: "Toolbar.js",
  //                       Line: 0,
  //                       Column: 0,
  //                       Stack: "",
  //                     });
  //                     logout();
  //                     isError = true;
  //                     return;
  //                   }
  //                   if (json.body.status !== "OK") {
  //                     if (json.body.error.message === "Token do not match") {
  //                       props.enqueueSnackbar(t("errorLoginDuplicate"), {
  //                         variant: "error",
  //                         anchorOrigin: { vertical: "top", horizontal: "right" },
  //                       });
  //                       deepICRLogging({
  //                         LogType: "ERROR",
  //                         ErrType: "DuplicateLoginError",
  //                         Message: t("errorLoginDuplicate"),
  //                         Src: "Toolbar.js",
  //                         Line: 0,
  //                         Column: 0,
  //                         Stack: "",
  //                       });
  //                       logout();
  //                       isError = true;
  //                       return;
  //                     } else {
  //                       if (deepICRCTX.debug === true) {
  //                         console.log(
  //                           "[ToolBar - uploadAndConvert] token-refresh error after convert failure"
  //                         );
  //                       }
  //                       if (deepICRCTX.debug === true) {
  //                         console.log(JSON.stringify(json, null, 1));
  //                       }
  //                       props.enqueueSnackbar(t("errorSystemError"), {
  //                         variant: "error",
  //                         anchorOrigin: { vertical: "top", horizontal: "right" },
  //                       });
  //                       deepICRLogging({
  //                         LogType: "ERROR",
  //                         ErrType: "TokenRefreshError",
  //                         Message: "token-refresh error after convert failure",
  //                         Src: "Toolbar.js",
  //                         Line: 0,
  //                         Column: 0,
  //                         Stack: "",
  //                       });
  //                       setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //                       isError = true;
  //                       return;
  //                     }
  //                   }
  //                   global.accessToken = json.body.result.accessToken;
  //                   // setDeepICRCTX({
  //                   //   ...deepICRCTX,
  //                   //   accessToken: json.body.result.accessToken
  //                   // });
  //                 })
  //                 .catch((err) => {
  //                   if (deepICRCTX.debug === true) {
  //                     console.log(
  //                       "[ToolBar - uploadAndConvert] token-refresh catch error after convert failure"
  //                     );
  //                   }
  //                   if (deepICRCTX.debug === true) {
  //                     console.log(err);
  //                   }
  //                   props.enqueueSnackbar(t("errorSystemError"), {
  //                     variant: "error",
  //                     anchorOrigin: { vertical: "top", horizontal: "right" },
  //                   });
  //                   deepICRLogging({
  //                     LogType: "ERROR",
  //                     ErrType: "TokenRefreshError",
  //                     Message: "token-refresh catch error after convert failure",
  //                     Src: "Toolbar.js",
  //                     Line: 0,
  //                     Column: 0,
  //                     Stack: "",
  //                   });
  //                   setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //                   isError = true;
  //                   return;
  //                 });
  //               if (isError) {
  //                 setIsDisableConvert(false)
  //                 return;
  //               }
  //             }
  //           }
  //         })
  //         .catch((err) => {
  //           if (deepICRCTX.debug === true) {
  //             console.log("[ToolBar - uploadAndConvert] polling catch error");
  //           }
  //           if (deepICRCTX.debug === true) {
  //             console.log(err);
  //           }
  //           props.closeSnackbar(snackbarDoConvert);
  //           props.enqueueSnackbar(t("errorSystemError"), {
  //             variant: "error",
  //             anchorOrigin: { vertical: "top", horizontal: "right" },
  //           });
  //           deepICRLogging({
  //             LogType: "ERROR",
  //             ErrType: "PollingCatchError",
  //             Message: "Polling Catch Error",
  //             Src: "Toolbar.js",
  //             Line: 0,
  //             Column: 0,
  //             Stack: "",
  //           });

  //           setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //           isError = true;
  //           return;
  //         });
  //       if (isError) {
  //         setIsDisableConvert(false)
  //         return;
  //       }
  //     }, time);
  //   };
  //   checkS3(deepICRCTX.setTimeoutTime, deepICRCTX.setTimeoutLimit, 1);
  // };

  //-------------------------------------------------------------------------------------------------
  //local_environment
  //-------------------------------------------------------------------------------------------------




  const history = useHistory();
  const handleReturn = () => {
    history.push("/template-library");
  }

  // Upload and convert local

  const uploadAndConvert = async () => {
    // console.log("Same file name", deepICRCTX.file.name, "Requested file", deepICRCTX.requestedFile);
    if ((deepICRCTX.file.name === deepICRCTX.requestedFile)) {
      props.enqueueSnackbar(
        t('errorRequestSameFile'),
        { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
      );
      deepICRLogging({
        "LogType": "ERROR",
        "ErrType": "RequestSameFileError",
        "Message": t('errorRequestSameFile'),
        "Src": "Toolbar.js",
        "Line": 0,
        "Column": 0,
        "Stack": ""
      });
      return;
    }
    const snackbarDoConvert = props.enqueueSnackbar(
      t('infoDoConvert') + deepICRCTX.file.name,
      {
        variant: 'info',
        persist: true,
        anchorOrigin: { vertical: 'bottom', horizontal: 'right' }
      }
    );
    const isContract = false;
    const [yyyymmddhhmmss, unixtime, microsec] = deepICRNow();
    // console.log(unixtime, microsec, isContract);
    let putFileName = deepICRCTX.file.name;

    let pagesArray = [];
    if (deepICRCTX.targetPages !== "") {
      deepICRCTX.targetPages.split(',').forEach((item) => {
        pagesArray.push(isNaN(item) ? item : Number(item));
      });
    }
    // console.log("Rotation Value:", global.rotation);

    const inputJson = {
      "bucket_name": deepICRCTX.s3Bucket,
      "img_path": deepICRCTX.s3Path,
      "img_file_name": encodeURIComponent(putFileName),
      "output_path": deepICRCTX.s3Path,
      "output_json_name": encodeURIComponent(deepICRCTX.file.name.match(/(.*)(?:\.([^.]+$))/)[1] + '_out.json'),
      "target_type": type,
      "custom_pages": pagesArray,
      "pdf_pages": deepICRCTX.file.type === 'application/pdf' ? deepICRCTX.pdfPages : 0,
      "pdf_rotations": global.rotation,
      "file_size": deepICRCTX.file.size,
      "selection_info": deepICRCTX.shapeList,
    };

    setDeepICRCTX({
      ...deepICRCTX,
      documentId: "",
      isContract: false,
      requestedFile: deepICRCTX.file.name,
      originalOutputFontScale: 1,
      originalOutputSize: { height: 0, width: 0 },
      originalOutputData: { data: [] },
      originalOutputTable: { data: [] },
      extractedOutputData: { data: [] },
      extractedOutputTable: { data: [] },
      searchText: "",
      outputSw: false,

    });

    // Upload Reqest Json
    let file_name = deepICRCTX.file.name.split(".");
    file_name[file_name.length - 1] = "json";
    file_name = file_name.join(".");
    // console.log({file_name});
    fetch('http://' + host_address + ':5000?json=' + JSON.stringify(inputJson, null, 2) + "&filename=" + encodeURIComponent(file_name), {
      method: "GET",
      mode: "cors",
      rejectUnauthorized: false
    })
      .then(response => {
        return response.json();
      }).then(json => {
        console.log(json);
        if (json["Status"] === "Success") {
          console.log("Selection json load Successfully");
          fetch('http://' + host_address + ':5000/input/' + encodeURIComponent(file_name))
            .then(response => {
              console.log("Selection Response: ", response)
              return response.json();
            })
            .then(json => {
              let shape_list = JSON.parse(JSON.stringify(json)).selection_info;
              // console.log("Shape List:", shape_list);
              setDeepICRCTX({
                ...deepICRCTX,
                shapeList: shape_list,
              });
              checkDeepStorage(deepICRCTX.setTimeoutTime, 180, 1);
            })
            .catch(er => {
              deepICRLogging({
                "LogType": "ERROR",
                "ErrType": "NetworkError",
                "Message": er.message,
                "Src": "Toolbar.js",
                "Line": 0,
                "Column": 0,
                "Stack": ""
              });
              return;
            })
        }
      })
      .catch(er => {
        console.log("TEST2:", er.message, er.stack);
        deepICRLogging({
          "LogType": "ERROR",
          "ErrType": "NetworkError",
          "Message": er.message,
          "Src": "Toolbar.js",
          "Line": 0,
          "Column": 0,
          "Stack": ""
        });
        return;
      })

    const checkDeepStorage = (time, limit, counter) => {
      setIsDisableConvert(true)
      setTimeout(() => {
        console.log("polling...");
        fetch('http://' + host_address + ':5000/output/' + encodeURI(file_name))
          .then(response => {
            return response.json();
          })
          .then(json => {
            console.log(json);
            let outputJson = JSON.parse(JSON.stringify(json));
            setJson(outputJson);

            const file = deepICRCTX.file;
            file.yyyymmddhhmmss = yyyymmddhhmmss

            let oDataHeight = 0;
            let oDataWidth = 0;
            let oData = {};
            let oTable = {};
            let eData = [];
            let eTable = [];
            let shapes = {};

            [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes] = parseOutputJson(outputJson);

            // console.log("aaa", oDataHeight, oDataWidth,);
            // console.log("aaa", oData,);
            // console.log("aaa", oTable,);
            // console.log("aaa", eData,);
            // console.log("aaa", eTable,);
            // console.log("aaa", shapes);


            props.closeSnackbar(snackbarDoConvert);

            setDeepICRCTX({
              ...deepICRCTX,
              // accessToken: newAccessToken,
              outputJson: outputJson,
              isContract: isContract,
              outputTab: 0,
              file: file,
              requestedFile: "",
              originalOutputSize: { height: oDataHeight, width: oDataWidth },
              originalOutputData: { data: oData },
              originalOutputTable: { data: oTable },
              extractedOutputData: { data: eData },
              extractedOutputTable: { data: eTable },
              croppedImages: shapes,
              outputSw: true,
              selectedRegion: {
                pages: []
              },
              selectedShapeRight: [],
              shapeListRight: {},
              selectedButton: false,
              jsonImported: false,
              searchTextValue: "",
              searchText: "",
            });
            setIsCSVChanged(false)
            setIsDisableConvert(false)
          })
          .catch(err => {
            // console.log(err);
            counter++;
            if (counter < limit) {
              checkDeepStorage(time, limit, counter);
            }
            else {
              console.log("ERROR:", [err]);
              deepICRLogging({
                "LogType": "ERROR",
                "ErrType": "NetworkError",
                "Message": err.message,
                "Src": "Toolbar.js",
                "Line": 0,
                "Column": 0,
                "Stack": ""
              });
              const errorSnackBar = props.enqueueSnackbar(
                "Time Out.. please convert again",
                {
                  variant: 'error',
                  persist: true,
                  anchorOrigin: { vertical: 'bottom', horizontal: 'right' }
                }
              );
              setIsDisableConvert(false)
              props.closeSnackbar(errorSnackBar);
            }
          });
      }, time);
    }

  }






  //-------------------------------------------------------------------------------------------------
  // Set select value/type
  //-------------------------------------------------------------------------------------------------
  const setSelectValue = (e) => { setFormat(e.target.value); setIsCSVChanged(true) };
  // const setSelectType = (e) => setType(e.target.value);

  //-------------------------------------------------------------------------------------------------
  // Download TSV/HTML/JSON file
  //-------------------------------------------------------------------------------------------------
  const downloadCSV = () => {
    if (deepICRCTX.outputSw === false && deepICRCTX.documentId === "") {
      props.enqueueSnackbar(t("errorDownloadNothing"), {
        variant: "error",
        anchorOrigin: { vertical: "top", horizontal: "right" },
      });
      deepICRLogging({
        LogType: "ERROR",
        ErrType: "DownloadError",
        Message: t("errorDownloadNothing"),
        Src: "Toolbar.js",
        Line: 0,
        Column: 0,
        Stack: "",
      });
      return;
    }

    let fileNameArray = deepICRCTX.file.name.split(".");
    fileNameArray.pop();
    let filename = fileNameArray.join(".");
    let data = "";

    // Process by format (TSV=default/HTML/HTML(Zip)/JSON)
    if (format === "html" || format === "htmlzip") {
      // Download HTML data
      const title = filename;
      filename += ".html";
      const ratio =
        deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.originalOutputData.data[1].width;

      let startPosition = format === "html" ? 8 : 40;

      // html head
      let html = "<!DOCTYPE html>\n";
      html += '<html lang="ja">\n';
      html += "<head>\n";
      html += '<meta charset="utf-8" />\n';
      html += '<meta name="viewport" content="width=device-width, initial-scale=1" />\n';
      html += '<meta name="description" content="Deep ICR" />\n';
      html += "<title>" + title + "</title>\n";
      html += "</head>\n";

      // html body
      html += "<body>\n";
      if (format === "htmlzip") {
        html +=
          '<a href="' +
          encodeURI(deepICRCTX.file.name) +
          `" target="_brank">${deepICRCTX.file.name}</a>\n`;
      }
      if (deepICRCTX.isSelection) {
        let selectionOutput = {};
        if (objectSize(deepICRCTX.originalOutputData.data) > 0) {
          for (let i in deepICRCTX.originalOutputData.data) {
            let textData = deepICRCTX.originalOutputData.data[i].data;
            let tableData = deepICRCTX.originalOutputTable.data[i].data;
            let selOutput = {};

            for (let ti in textData) {
              let td = textData[ti];
              if ("shape_id" in td) {
                let shape_id = td["shape_id"];
                if (shape_id in selOutput && "text" in selOutput[shape_id]) {
                  selOutput[shape_id].text.push(td);
                } else if (shape_id in selOutput && !("text" in selOutput[shape_id])) {
                  selOutput[shape_id]["text"] = [td];
                } else {
                  selOutput[shape_id] = {};
                  selOutput[shape_id]["text"] = [td];
                }
              }
            }

            for (let tj in tableData) {
              let td = tableData[tj];
              if ("shape_id" in td) {
                let shape_id = td["shape_id"];
                if (shape_id in selOutput && "cell" in selOutput[shape_id]) {
                  selOutput[shape_id].cell.push(td);
                } else if (shape_id in selOutput && !("cell" in selOutput[shape_id])) {
                  selOutput[shape_id]["cell"] = [td];
                } else {
                  selOutput[shape_id] = {};
                  selOutput[shape_id]["cell"] = [td];
                }
              }
            }

            for (let key in selOutput) {
              let selection = selOutput[key];
              let x = Infinity,
                y = Infinity,
                w = -Infinity,
                h = -Infinity;
              let meta = "";
              if ("text" in selection) {
                let texts = selection["text"];
                for (let i = 0; i < texts.length; i++) {
                  if (x > texts[i].x) x = texts[i].x;
                  if (w < texts[i].x + texts[i].width) w = texts[i].x + texts[i].width;
                  if (y > texts[i].y) y = texts[i].y;
                  if (h < texts[i].y + texts[i].height) h = texts[i].y + texts[i].height;
                  meta = texts[i].meta;
                }
              }
              if ("cell" in selection) {
                let cells = selection["cell"];
                for (let i = 0; i < cells.length; i++) {
                  if (x > cells[i].x) x = cells[i].x;
                  if (w < cells[i].x + cells[i].width) w = cells[i].x + cells[i].width;
                  if (y > cells[i].y) y = cells[i].y;
                  if (h < cells[i].y + cells[i].height) h = cells[i].y + cells[i].height;
                  meta = cells[i].meta;
                }
              }
              selOutput[key]["x"] = x;
              selOutput[key]["y"] = y;
              selOutput[key]["width"] = w - x;
              selOutput[key]["height"] = h - y;
              selOutput[key]["meta"] = meta;
            }
            let sortable = [];
            for (let shape_id in selOutput) {
              sortable.push([shape_id, selOutput[shape_id]]);
            }

            sortable.sort(function (a, b) {
              return a[0].split("_")[1] - b[0].split("_")[1];
            });

            let output = {};
            for (let x = 0; x < sortable.length; x++) {
              output["" + sortable[x][0]] = deepCopy(sortable[x][1]);
            }
            selectionOutput[i] = output;
          }

          for (let page in selectionOutput) {
            html +=
              '<div style="padding:10px;position:absolute;left:8px;top:' +
              startPosition +
              "px;width:" +
              deepICRCTX.originalOutputData.data[page].width * ratio +
              "px;min-height:" +
              deepICRCTX.originalOutputData.data[page].height * ratio +
              'px;border:1px solid #ddd;margin-bottom:8px;">';
            for (let s in selectionOutput[page]) {
              let texts = selectionOutput[page][s].text;
              let cells = selectionOutput[page][s].cell;

              let x = selectionOutput[page][s].x;
              let y = selectionOutput[page][s].y;
              let w = selectionOutput[page][s].width;
              let h = selectionOutput[page][s].height;
              let meta = selectionOutput[page][s].meta;

              html +=
                '<div style="margin-top:16px;display:block;position:relative;max-width:' +
                w * ratio +
                'px;height:auto;">' +
                meta +
                "</div>";
              html +=
                '<div style="border:1px solid #ddd;display:block;position:relative;width:' +
                w * ratio +
                "px;height:" +
                h * ratio +
                'px;">';

              if (cells) {
                for (let i = 0; i < cells.length; i++) {
                  let cx = cells[i].x;
                  let cy = cells[i].y;
                  let cw = cells[i].width;
                  let ch = cells[i].height;
                  html +=
                    '<div style="border:1px solid #000;position:absolute;left:' +
                    Math.abs(x - cx) * ratio +
                    "px;top:" +
                    Math.abs(y - cy) * ratio +
                    "px;width:" +
                    cw * ratio +
                    "px;height:" +
                    ch * ratio +
                    'px;"></div>';
                }
              }

              if (texts) {
                for (let i = 0; i < texts.length; i++) {
                  let tx = texts[i].x;
                  let ty = texts[i].y;
                  let tw = texts[i].width;
                  let th = texts[i].height;
                  let txt = texts[i].text;
                  if (texts[i].type === "Image") {
                    html +=
                      '<img src="' +
                      deepICRCTX.croppedImages[texts[i].key] +
                      '" style="position:absolute;left:' +
                      Math.abs(x - tx) * ratio +
                      "px;top:" +
                      Math.abs(y - ty) * ratio +
                      "px;width:" +
                      tw * ratio +
                      "px;height:" +
                      th * ratio +
                      'px;">';
                  } else {
                    html +=
                      '<div style="font-size:' +
                      th * ratio * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale +
                      "px;position:absolute;left:" +
                      Math.abs(x - tx) * ratio +
                      "px;top:" +
                      Math.abs(y - ty) * ratio +
                      "px;width:" +
                      tw * ratio +
                      "px;height:" +
                      th * ratio +
                      'px;">' +
                      txt +
                      "</div>";
                  }
                }
              }
              html += "</div>";
            }

            // for (let i in deepICRCTX.originalOutputTable.data[page].data) {
            //   html += '<div style="position:absolute;left:'
            //     + (8 + (deepICRCTX.originalOutputTable.data[page].data[i].x * ratio)) + 'px;top:'
            //     + (startPosition + (deepICRCTX.originalOutputTable.data[page].data[i].y * ratio)) + 'px;width:'
            //     + (deepICRCTX.originalOutputTable.data[page].data[i].width * ratio) + 'px;height:'
            //     + (deepICRCTX.originalOutputTable.data[page].data[i].height * ratio)
            //     + 'px;border:1px solid;"></div>\n';
            //}
            // for (let i in deepICRCTX.originalOutputData.data[page].data) {
            //   html += '<div style="position:absolute;left:'
            //     + (8 + (deepICRCTX.originalOutputData.data[page].data[i].x * ratio)) + 'px;top:'
            //     + (startPosition + (deepICRCTX.originalOutputData.data[page].data[i].y * ratio)) + 'px;width:'
            //     + (deepICRCTX.originalOutputData.data[page].data[i].width * ratio) + 'px;height:'
            //     + (deepICRCTX.originalOutputData.data[page].data[i].height * ratio) + 'px;font-size:'
            //     + (deepICRCTX.originalOutputData.data[page].data[i].height * ratio * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale) + 'px;color:'
            //     + deepICRCTX.originalOutputData.data[page].data[i].color + ';padding:0;margin:0;white-space:nowrap">'
            //     + deepICRCTX.originalOutputData.data[page].data[i].text + '</div>\n';
            //}

            html += "</div>\n";
            startPosition =
              startPosition + 8 + deepICRCTX.originalOutputData.data[page].height * ratio;
          }
        }
      } else {
        for (let page in deepICRCTX.originalOutputData.data) {
          html +=
            '<div style="position:absolute;left:8px;top:' +
            startPosition +
            "px;width:" +
            deepICRCTX.originalOutputData.data[page].width * ratio +
            "px;height:" +
            deepICRCTX.originalOutputData.data[page].height * ratio +
            'px;border:1px solid;margin-bottom:8px;"></div>\n';
          for (let i in deepICRCTX.originalOutputTable.data[page].data) {
            html +=
              '<div style="position:absolute;left:' +
              (8 + deepICRCTX.originalOutputTable.data[page].data[i].x * ratio) +
              "px;top:" +
              (startPosition + deepICRCTX.originalOutputTable.data[page].data[i].y * ratio) +
              "px;width:" +
              deepICRCTX.originalOutputTable.data[page].data[i].width * ratio +
              "px;height:" +
              deepICRCTX.originalOutputTable.data[page].data[i].height * ratio +
              'px;border:1px solid;"></div>\n';
          }
          for (let i in deepICRCTX.originalOutputData.data[page].data) {
            html +=
              '<div style="position:absolute;left:' +
              (8 + deepICRCTX.originalOutputData.data[page].data[i].x * ratio) +
              "px;top:" +
              (startPosition + deepICRCTX.originalOutputData.data[page].data[i].y * ratio) +
              "px;width:" +
              deepICRCTX.originalOutputData.data[page].data[i].width * ratio +
              "px;height:" +
              deepICRCTX.originalOutputData.data[page].data[i].height * ratio +
              "px;font-size:" +
              deepICRCTX.originalOutputData.data[page].data[i].height *
              ratio *
              deepICRCTX.originalOutputFontScale *
              deepICRCTX.fontScale +
              "px;color:" +
              deepICRCTX.originalOutputData.data[page].data[i].color +
              ';padding:0;margin:0;white-space:nowrap">' +
              deepICRCTX.originalOutputData.data[page].data[i].text +
              "</div>\n";
          }
          startPosition =
            startPosition + 8 + deepICRCTX.originalOutputData.data[page].height * ratio;
        }
      }
      html += "<br><br>\n";
      html += "</body>\n";
      html += "<html>\n";

      if (format === "html") {
        deepICRDownload(deepICRtoBlobWithBom(html, "text/html"), filename);
      } else {
        // format === 'htmlzip'
        const zip = new JSZip();
        const now = new Date();
        const dateWithOffset = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
        try {
          zip.file(filename, deepICRtoBlobWithBom(html, "text/html"), { date: dateWithOffset });
        } catch (e) {
          if (deepICRCTX.debug === true) {
            if (deepICRCTX.debug === true) {
              console.log(e);
            }
          }
          props.enqueueSnackbar(t("errorZipProcess"), {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          // deepICRLogging({
          //   LogType: "ERROR",
          //   ErrType: "ZipProcessError",
          //   Message: t("errorZipProcess"),
          //   Src: "Toolbar.js",
          //   Line: 0,
          //   Column: 0,
          //   Stack: "",
          // });
          return;
        }

        // Add pdf/jpeg file to zip
        if (deepICRCTX.file.type === "image/jpeg") {
          const base64Array = deepICRCTX.fileBase64[0].split(";base64,", 2);
          zip.file(deepICRCTX.file.name, base64Array[1], { date: dateWithOffset, base64: true });
        } else {
          let newPdf = "";
          try {
            let orientation =
              deepICRCTX.fileSize[0].width > deepICRCTX.fileSize[0].height
                ? "landscape"
                : "portrait";
            const pdf = new jsPDF({
              unit: "px",
              format: [deepICRCTX.fileSize[0].width, deepICRCTX.fileSize[0].height],
              orientation: orientation,
            });
            for (let i = 0; i < deepICRCTX.pdfPages; i++) {
              if (i > 0) {
                orientation =
                  deepICRCTX.fileSize[i].width > deepICRCTX.fileSize[i].height
                    ? "landscape"
                    : "portrait";
                pdf.addPage(
                  [deepICRCTX.fileSize[i].width, deepICRCTX.fileSize[i].height],
                  orientation
                );
              }
              pdf.addImage(
                deepICRCTX.fileBase64[i],
                "JPEG",
                0,
                0,
                deepICRCTX.fileSize[i].width,
                deepICRCTX.fileSize[i].height
              );
            }
            newPdf = pdf.output("datauristring", "new.pdf");
          } catch (e) {
            if (deepICRCTX.debug === true) {
              if (deepICRCTX.debug === true) {
                console.log(e);
              }
            }
            props.enqueueSnackbar(t("errorPdfToJpegProcess"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "PdfToJpegProcessError",
              Message: t("errorPdfToJpegProcess"),
              Src: "Toolbar.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
            return;
          }
          try {
            zip.file(
              deepICRCTX.file.type === "application/pdf" ? title + ".pdf" : title + ".jpg",
              newPdf.split(";base64,", 2)[1],
              { date: dateWithOffset, base64: true }
            );
          } catch (e) {
            if (deepICRCTX.debug === true) {
              console.log(e);
            }
            props.enqueueSnackbar(t("errorZipProcess"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "ZipProcessError",
              Message: t("errorZipProcess"),
              Src: "Toolbar.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
            return;
          }
        }

        // Create zip file
        zip
          .generateAsync({ type: "blob" })
          .then((blob) => deepICRDownload(blob, title + ".zip"))
          .catch((e) => {
            if (deepICRCTX.debug === true) {
              console.log(e);
            }
            props.enqueueSnackbar(t("errorZipProcess"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "ZipProcessError",
              Message: t("errorZipProcess"),
              Src: "Toolbar.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
            return;
          });
      }
    } else if (format === "json") {
      // Download JSON data
      filename += ".json";

      // Reflecting the change for Original Output Data
      const oChangeTextArray = deepICRCTX.originalOutputData.data;
      for (let keyPage in oChangeTextArray) {
        const numberRegexp = new RegExp(/^[0-9]+$/);
        if (!numberRegexp.test(keyPage)) continue;
        for (let keyItem in oChangeTextArray[keyPage].data) {
          if (!numberRegexp.test(keyItem)) continue;
          if (oChangeTextArray[keyPage].data[keyItem].color === "blue") {
            let i, j, k, l, m;
            if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromLine") {
              [i, j, k, l, m] = ["", "", "", "", ""];

              if (oChangeTextArray[keyPage].data[keyItem].key.split("-").length === 4) {
                [i, j, k, l] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              } else {
                [i, j, k] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              }

              if (
                json.original_output.pages[i].regions[j].type === "Multi Line" ||
                json.original_output.pages[i].regions[j].type === "Handwritten"
              ) {
                if (
                  json.original_output.pages[i].regions[j].lines[k].words[l].text !==
                  oChangeTextArray[keyPage].data[keyItem].originalText
                ) {
                  if (deepICRCTX.debug === true)
                    console.log(
                      "blue text unmatch " +
                      json.original_output.pages[i].regions[j].lines[k].words[l].text +
                      ":" +
                      oChangeTextArray[keyPage].data[keyItem].originalText
                    );
                }
                json.original_output.pages[i].regions[j].lines[k].words[l].text =
                  oChangeTextArray[keyPage].data[keyItem].text;
              } else {
                if (
                  json.original_output.pages[i].regions[j].words[k].text !==
                  oChangeTextArray[keyPage].data[keyItem].originalText
                ) {
                  if (deepICRCTX.debug === true)
                    console.log(
                      "blue text unmatch " +
                      json.original_output.pages[i].regions[j].words[k].text +
                      ":" +
                      oChangeTextArray[keyPage].data[keyItem].originalText
                    );
                }
                json.original_output.pages[i].regions[j].words[k].text =
                  oChangeTextArray[keyPage].data[keyItem].text;
              }
            } else if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromTable") {
              [i, j, k, l, m] = ["", "", "", "", ""];
              [i, j, k, l, m] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              if (
                json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text !==
                oChangeTextArray[keyPage].data[keyItem].originalText
              ) {
                if (deepICRCTX.debug === true)
                  console.log(
                    "blue text unmatch " +
                    json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text +
                    ":" +
                    oChangeTextArray[keyPage].data[keyItem].originalText
                  );
              }
              json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text =
                oChangeTextArray[keyPage].data[keyItem].text;
            }
          }
        }
      }

      // Reflecting the change for Extracted Output Data
      const eChangeTextArray = deepICRCTX.extractedOutputData.data;
      for (let key in eChangeTextArray) {
        for (let i = 0; i < eChangeTextArray[key].values.length; i++) {
          if (eChangeTextArray[key].values[i].originalValue !== "") {
            json.extracted_output[key].values[i] = eChangeTextArray[key].values[i].value;
          }
        }
      }
      const eChangeTableTextArray = deepICRCTX.extractedOutputTable.data;
      for (let page in eChangeTableTextArray) {
        for (let table in eChangeTableTextArray[page]) {
          for (let i = 0; i < eChangeTableTextArray[page][table].length; i++) {
            for (let j = 0; j < eChangeTableTextArray[page][table][i].length; j++) {
              if (eChangeTableTextArray[page][table][i][j] !== "") {
                json.extracted_output["details"].values[page][table][i][j] =
                  eChangeTableTextArray[page][table][i][j].value;
              }
            }
          }
        }
      }
      deepICRDownload(
        deepICRtoBlobWithBom(JSON.stringify(json, undefined, 1), "application/json"),
        filename
      );
    } else if (format === "crop") {
      const title = filename;
      const zip = new JSZip();
      const now = new Date();
      const dateWithOffset = new Date(now.getTime() - now.getTimezoneOffset() * 60000);

      const ratio =
        deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.originalOutputData.data[1].width;

      let startPosition = 8;

      // html head
      let html = "<!DOCTYPE html>\n";
      html += '<html lang="ja">\n';
      html += "<head>\n";
      html += '<meta charset="utf-8" />\n';
      html += '<meta name="viewport" content="width=device-width, initial-scale=1" />\n';
      html += '<meta name="description" content="Deep ICR" />\n';
      html += "<title>" + title + "</title>\n";
      html += "</head>\n";

      // html body
      html += "<body>\n";

      let selectionOutput = {};
      if (objectSize(deepICRCTX.originalOutputData.data) > 0) {
        for (let i in deepICRCTX.originalOutputData.data) {
          let textData = deepICRCTX.originalOutputData.data[i].data;
          let tableData = deepICRCTX.originalOutputTable.data[i].data;
          let selOutput = {};

          for (let ti in textData) {
            let td = textData[ti];
            if ("shape_id" in td) {
              let shape_id = td["shape_id"];
              if (shape_id in selOutput && "text" in selOutput[shape_id]) {
                selOutput[shape_id].text.push(td);
              } else if (shape_id in selOutput && !("text" in selOutput[shape_id])) {
                selOutput[shape_id]["text"] = [td];
              } else {
                selOutput[shape_id] = {};
                selOutput[shape_id]["text"] = [td];
              }
            }
          }

          for (let tj in tableData) {
            let td = tableData[tj];
            if ("shape_id" in td) {
              let shape_id = td["shape_id"];
              if (shape_id in selOutput && "cell" in selOutput[shape_id]) {
                selOutput[shape_id].cell.push(td);
              } else if (shape_id in selOutput && !("cell" in selOutput[shape_id])) {
                selOutput[shape_id]["cell"] = [td];
              } else {
                selOutput[shape_id] = {};
                selOutput[shape_id]["cell"] = [td];
              }
            }
          }

          for (let key in selOutput) {
            let selection = selOutput[key];
            let x = Infinity,
              y = Infinity,
              w = -Infinity,
              h = -Infinity;
            let meta = "";
            if ("text" in selection) {
              let texts = selection["text"];
              for (let i = 0; i < texts.length; i++) {
                if (x > texts[i].x) x = texts[i].x;
                if (w < texts[i].x + texts[i].width) w = texts[i].x + texts[i].width;
                if (y > texts[i].y) y = texts[i].y;
                if (h < texts[i].y + texts[i].height) h = texts[i].y + texts[i].height;
                meta = texts[i].meta;
              }
            }
            if ("cell" in selection) {
              let cells = selection["cell"];
              for (let i = 0; i < cells.length; i++) {
                if (x > cells[i].x) x = cells[i].x;
                if (w < cells[i].x + cells[i].width) w = cells[i].x + cells[i].width;
                if (y > cells[i].y) y = cells[i].y;
                if (h < cells[i].y + cells[i].height) h = cells[i].y + cells[i].height;
                meta = cells[i].meta;
              }
            }
            selOutput[key]["x"] = x;
            selOutput[key]["y"] = y;
            selOutput[key]["width"] = w - x;
            selOutput[key]["height"] = h - y;
            selOutput[key]["meta"] = meta;
          }
          let sortable = [];
          for (let shape_id in selOutput) {
            sortable.push([shape_id, selOutput[shape_id]]);
          }

          sortable.sort(function (a, b) {
            return a[0].split("_")[1] - b[0].split("_")[1];
          });

          let output = {};
          for (let x = 0; x < sortable.length; x++) {
            output["" + sortable[x][0]] = deepCopy(sortable[x][1]);
          }
          selectionOutput[i] = output;
        }
        let index = 1; //added to fix image loading issue in html output
        for (let page in selectionOutput) {
          if (page === "documentName") continue;

          let documentId = deepICRCTX.originalOutputData.data[index].id; //added to fix image loading issue in html output

          html +=
            '<div style="padding:10px;position:absolute;left:8px;top:' +
            startPosition +
            "px;width:" +
            deepICRCTX.originalOutputData.data[page].width * ratio +
            "px;min-height:" +
            deepICRCTX.originalOutputData.data[page].height * ratio +
            'px;border:1px solid #ddd;margin-bottom:8px;">';
          for (let s in selectionOutput[page]) {
            let texts = selectionOutput[page][s].text;
            let cells = selectionOutput[page][s].cell;

            let x = selectionOutput[page][s].x;
            let y = selectionOutput[page][s].y;
            let w = selectionOutput[page][s].width;
            let h = selectionOutput[page][s].height;
            let meta = selectionOutput[page][s].meta;

            html +=
              '<div style="margin-top:16px;display:block;position:relative;max-width:' +
              w * ratio +
              'px;height:auto;">' +
              meta +
              "</div>";
            html +=
              '<div style="border:1px solid #ddd;display:block;position:relative;width:' +
              w * ratio +
              "px;height:" +
              h * ratio +
              'px;">';

            if (cells) {
              for (let i = 0; i < cells.length; i++) {
                let cx = cells[i].x;
                let cy = cells[i].y;
                let cw = cells[i].width;
                let ch = cells[i].height;
                html +=
                  '<div style="border:1px solid #000;position:absolute;left:' +
                  Math.abs(x - cx) * ratio +
                  "px;top:" +
                  Math.abs(y - cy) * ratio +
                  "px;width:" +
                  cw * ratio +
                  "px;height:" +
                  ch * ratio +
                  'px;"></div>';
              }
            }

            if (texts) {
              for (let i = 0; i < texts.length; i++) {
                let tx = texts[i].x;
                let ty = texts[i].y;
                let tw = texts[i].width;
                let th = texts[i].height;
                let txt = texts[i].text;
                if (texts[i].type === "Image") {
                  html +=
                    '<img src="' +
                    documentId +
                    "__" +
                    s +
                    ".jpg" +
                    '" style="position:absolute;left:' +
                    Math.abs(x - tx) * ratio +
                    "px;top:" +
                    Math.abs(y - ty) * ratio +
                    "px;width:" +
                    tw * ratio +
                    "px;height:" +
                    th * ratio +
                    'px;"/>'; //added to fix image loading issue in html output
                } else {
                  html +=
                    '<div style="font-size:' +
                    th * ratio * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale +
                    "px;position:absolute;left:" +
                    Math.abs(x - tx) * ratio +
                    "px;top:" +
                    Math.abs(y - ty) * ratio +
                    "px;width:" +
                    tw * ratio +
                    "px;height:" +
                    th * ratio +
                    'px;">' +
                    txt +
                    "</div>";
                }
              }
            }
            html += "</div>";
          }
          html += "</div>";
          startPosition =
            startPosition + 8 + deepICRCTX.originalOutputData.data[page].height * ratio;
          index++; //added to fix image loading issue in html output
        }
      }

      html += "<br><br>\n";
      html += "</body>\n";
      html += "<html>\n";

      try {
        zip.folder(filename).file(filename + ".html", deepICRtoBlobWithBom(html, "text/html"), {
          date: dateWithOffset,
        });
      } catch (e) {
        if (deepICRCTX.debug === true) {
          console.log(e);
        }
        props.enqueueSnackbar(t("errorZipProcess"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        deepICRLogging({
          LogType: "ERROR",
          ErrType: "ZipProcessError",
          Message: t("errorZipProcess"),
          Src: "Toolbar.js",
          Line: 0,
          Column: 0,
          Stack: "",
        });
        return;
      }

      // Add pdf/jpeg file to zip
      const oChangeTextArray = deepICRCTX.originalOutputData.data;
      for (let keyPage in oChangeTextArray) {
        const numberRegexp = new RegExp(/^[0-9]+$/);
        if (!numberRegexp.test(keyPage)) continue;
        for (let keyItem in oChangeTextArray[keyPage].data) {
          if (!numberRegexp.test(keyItem)) continue;
          if (oChangeTextArray[keyPage].data[keyItem].color === "blue") {
            let i, j, k, l, m;
            if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromLine") {
              [i, j, k, l, m] = ["", "", "", "", ""];

              if (oChangeTextArray[keyPage].data[keyItem].key.split("-").length === 4) {
                [i, j, k, l] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              } else {
                [i, j, k] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              }

              if (
                json.original_output.pages[i].regions[j].type === "Multi Line" ||
                json.original_output.pages[i].regions[j].type === "Handwritten"
              ) {
                if (
                  json.original_output.pages[i].regions[j].lines[k].words[l].text !==
                  oChangeTextArray[keyPage].data[keyItem].originalText
                ) {
                  if (deepICRCTX.debug === true)
                    console.log(
                      "blue text unmatch " +
                      json.original_output.pages[i].regions[j].lines[k].words[l].text +
                      ":" +
                      oChangeTextArray[keyPage].data[keyItem].originalText
                    );
                }
                json.original_output.pages[i].regions[j].lines[k].words[l].text =
                  oChangeTextArray[keyPage].data[keyItem].text;
              } else {
                if (
                  json.original_output.pages[i].regions[j].words[k].text !==
                  oChangeTextArray[keyPage].data[keyItem].originalText
                ) {
                  if (deepICRCTX.debug === true)
                    console.log(
                      "blue text unmatch " +
                      json.original_output.pages[i].regions[j].words[k].text +
                      ":" +
                      oChangeTextArray[keyPage].data[keyItem].originalText
                    );
                }
                json.original_output.pages[i].regions[j].words[k].text =
                  oChangeTextArray[keyPage].data[keyItem].text;
              }
            } else if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromTable") {
              [i, j, k, l, m] = ["", "", "", "", ""];
              [i, j, k, l, m] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              if (
                json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text !==
                oChangeTextArray[keyPage].data[keyItem].originalText
              ) {
                if (deepICRCTX.debug === true)
                  console.log(
                    "blue text unmatch " +
                    json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text +
                    ":" +
                    oChangeTextArray[keyPage].data[keyItem].originalText
                  );
              }
              json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text =
                oChangeTextArray[keyPage].data[keyItem].text;
            }
          }
        }
      }

      try {
        zip
          .folder(filename)
          .file(
            filename + ".json",
            deepICRtoBlobWithBom(JSON.stringify(json, null, 2), "application/json"),
            { date: dateWithOffset }
          );
      } catch (e) {
        if (deepICRCTX.debug === true) {
          console.log(e);
        }
        props.enqueueSnackbar(t("errorZipProcess"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        deepICRLogging({
          LogType: "ERROR",
          ErrType: "ZipProcessError",
          Message: t("errorZipProcess"),
          Src: "Toolbar.js",
          Line: 0,
          Column: 0,
          Stack: "",
        });
        return;
      }

      if ("original_output" in json) {
        // console.log({ json });
        let originalOutput = json["original_output"];
        if ("document_name" in originalOutput) {
          if ("pages" in originalOutput) {
            let pages = originalOutput["pages"];

            for (let i = 0; i < pages.length; i++) {
              let page = pages[i];
              let page_id = page["id"];

              if ("regions" in page) {
                let regions = page["regions"];
                for (let j = 0; j < regions.length; j++) {
                  let region = regions[j];

                  let shape_id = "";
                  if ("selection_id" in region) {
                    shape_id = region["selection_id"];
                  }

                  let meta = "";
                  if ("meta" in region) {
                    meta = region["meta"];
                  }

                  if (region["type"] === "Single Line") {
                    let words = region["words"];
                    words.sort(function (a, b) {
                      return a.x - b.x;
                    });
                    let text = "" + meta + "\n";
                    for (let k = 0; k < words.length; k++) {
                      if (k === 0) text += '"' + words[k]["text"] + '"';
                      else text += `\t"${words[k]["text"]}"`;
                    }
                    try {
                      zip
                        .folder(filename)
                        .file(
                          page_id + "__" + shape_id + ".tsv",
                          deepICRtoBlobWithBom(text, "text/plain"),
                          { date: dateWithOffset }
                        );
                    } catch (e) {
                      if (deepICRCTX.debug === true) {
                        console.log(e);
                      }
                      props.enqueueSnackbar(t("errorZipProcess"), {
                        variant: "error",
                        anchorOrigin: { vertical: "top", horizontal: "right" },
                      });
                      deepICRLogging({
                        LogType: "ERROR",
                        ErrType: "ZipProcessError",
                        Message: t("errorZipProcess"),
                        Src: "Toolbar.js",
                        Line: 0,
                        Column: 0,
                        Stack: "",
                      });
                      return;
                    }
                  }
                  if (region["type"] === "Image") {
                    let key = i + "-" + j;

                    try {
                      if (
                        key in deepICRCTX.croppedImages &&
                        "data" in deepICRCTX.croppedImages[key]
                      ) {
                        const base64Array = deepICRCTX.croppedImages[key].data.split(";base64,", 2);
                        zip
                          .folder(filename)
                          .file(page_id + "__" + shape_id + ".jpg", base64Array[1], {
                            date: dateWithOffset,
                            base64: true,
                          });
                      }
                    } catch (e) {
                      if (deepICRCTX.debug === true) {
                        console.log(e);
                      }
                      props.enqueueSnackbar(t("errorZipProcess"), {
                        variant: "error",
                        anchorOrigin: { vertical: "top", horizontal: "right" },
                      });
                      deepICRLogging({
                        LogType: "ERROR",
                        ErrType: "ZipProcessError",
                        Message: t("errorZipProcess"),
                        Src: "Toolbar.js",
                        Line: 0,
                        Column: 0,
                        Stack: "",
                      });
                      return;
                    }
                  }
                  if (region["type"] === "Multi Line") {
                    if ("lines" in region) {
                      let lines = region["lines"];
                      lines.sort(function (a, b) {
                        return a["y"] - b["y"] || a["x"] - b["y"];
                      });
                      let text = "" + meta + "\n";
                      for (let i = 0; i < lines.length; i++) {
                        if ("words" in lines[i]) {
                          let words = lines[i]["words"];
                          words.sort(function (a, b) {
                            return a.x - b.x;
                          });

                          if (i !== 0) text += "\n";

                          for (let k = 0; k < words.length; k++) {
                            if (k === 0) text += '"' + words[k]["text"] + '"';
                            else text += `\t"${words[k]["text"]}"`;
                          }
                        }
                      }
                      try {
                        zip
                          .folder(filename)
                          .file(
                            page_id + "__" + shape_id + ".tsv",
                            deepICRtoBlobWithBom(text, "text/plain"),
                            { date: dateWithOffset }
                          );
                      } catch (e) {
                        if (deepICRCTX.debug === true) {
                          console.log(e);
                        }
                        props.enqueueSnackbar(t("errorZipProcess"), {
                          variant: "error",
                          anchorOrigin: { vertical: "top", horizontal: "right" },
                        });
                        deepICRLogging({
                          LogType: "ERROR",
                          ErrType: "ZipProcessError",
                          Message: t("errorZipProcess"),
                          Src: "Toolbar.js",
                          Line: 0,
                          Column: 0,
                          Stack: "",
                        });
                        return;
                      }
                    }
                  }
                  if (region["type"] === "Handwritten") {
                    if ("lines" in region) {
                      let lines = region["lines"];
                      lines.sort(function (a, b) {
                        return a["y"] - b["y"] || a["x"] - b["y"];
                      });
                      let text = "" + meta + "\n";
                      for (let i = 0; i < lines.length; i++) {
                        if ("words" in lines[i]) {
                          let words = lines[i]["words"];
                          words.sort(function (a, b) {
                            return a.x - b.x;
                          });

                          if (i !== 0) text += "\n";

                          for (let k = 0; k < words.length; k++) {
                            if (k === 0) text += '"' + words[k]["text"] + '"';
                            else text += `\t"${words[k]["text"]}"`;
                          }
                        }
                      }
                      try {
                        zip
                          .folder(filename)
                          .file(
                            page_id + "__" + shape_id + ".tsv",
                            deepICRtoBlobWithBom(text, "text/plain"),
                            { date: dateWithOffset }
                          );
                      } catch (e) {
                        console.log(e);
                        props.enqueueSnackbar(t("errorZipProcess"), {
                          variant: "error",
                          anchorOrigin: { vertical: "top", horizontal: "right" },
                        });
                        deepICRLogging({
                          LogType: "ERROR",
                          ErrType: "ZipProcessError",
                          Message: t("errorZipProcess"),
                          Src: "Toolbar.js",
                          Line: 0,
                          Column: 0,
                          Stack: "",
                        });
                        return;
                      }
                    }
                  }
                  if (region["type"] === "Table") {
                    let row = region["row"];
                    let col = region["column"];

                    let table = [];
                    for (let i = 0; i < row; i++) {
                      let row_val = [];
                      for (let j = 0; j < col; j++) {
                        let col_val = "";
                        row_val.push(col_val);
                      }
                      table.push(row_val);
                    }

                    if ("cells" in region) {
                      let cells = region["cells"];
                      for (let i = 0; i < cells.length; i++) {
                        let row_no = cells[i]["row_no"];
                        let col_no = cells[i]["col_no"];
                        let row_span = cells[i]["row_span"];
                        let col_span = cells[i]["col_span"];

                        if ("cell" in cells[i]) {
                          let lines = cells[i]["cell"];
                          lines.sort(function (a, b) {
                            return a["y"] - b["y"] || a["x"] - b["y"];
                          });
                          let text = "";
                          for (let i = 0; i < lines.length; i++) {
                            if ("words" in lines[i]) {
                              let words = lines[i]["words"];
                              words.sort(function (a, b) {
                                return a.x - b.x;
                              });
                              if (i !== 0) text += "\n";
                              for (let k = 0; k < words.length; k++) {
                                if (k === 0) text += words[k]["text"];
                                else text += " " + words[k]["text"];
                              }
                            }
                          }

                          for (let i = row_no; i < row_no + row_span; i++) {
                            for (let j = col_no; j < col_no + col_span; j++) {
                              table[i][j] = '"' + text + '"';
                            }
                          }
                        }
                      }
                    }
                    let table_text = "" + meta + "\n";
                    for (let i = 0; i < row; i++) {
                      if (i !== 0) table_text += "\n";
                      for (let j = 0; j < col; j++) {
                        if (j === 0) table_text += table[i][j];
                        else table_text += "\t" + table[i][j];
                      }
                    }
                    try {
                      zip
                        .folder(filename)
                        .file(
                          page_id + "__" + shape_id + ".tsv",
                          deepICRtoBlobWithBom(table_text, "text/plain"),
                          { date: dateWithOffset }
                        );
                    } catch (e) {
                      if (deepICRCTX.debug === true) {
                        console.log(e);
                      }
                      props.enqueueSnackbar(t("errorZipProcess"), {
                        variant: "error",
                        anchorOrigin: { vertical: "top", horizontal: "right" },
                      });
                      deepICRLogging({
                        LogType: "ERROR",
                        ErrType: "ZipProcessError",
                        Message: t("errorZipProcess"),
                        Src: "Toolbar.js",
                        Line: 0,
                        Column: 0,
                        Stack: "",
                      });
                      return;
                    }
                  }
                }
              }
            }
          }
        }
      }

      // Create zip file
      zip
        .generateAsync({ type: "blob" })
        .then((blob) => deepICRDownload(blob, title + ".zip"))
        .catch((e) => {
          if (deepICRCTX.debug === true) {
            console.log(e);
          }
          props.enqueueSnackbar(t("errorZipProcess"), {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          deepICRLogging({
            LogType: "ERROR",
            ErrType: "ZipProcessError",
            Message: t("errorZipProcess"),
            Src: "Toolbar.js",
            Line: 0,
            Column: 0,
            Stack: "",
          });
          return;
        });
    } else if (format === "csv" || format === "csv_full" || format === "csv_rpa") {

      function isAllChecked() {
        let isAllCheck = true;
        let isAllUnCheck = true;

        const selecetedRegions = deepICRCTX.selectedRegion.pages;

        // for(let p of selecetedRegions){
        //   if(p.regions){
        //     for(let obj of p.regions){
        //       if(!hasMultipleObjects(obj)){
        //         for( let item in obj){
        //           if(item.split("_")[0] === "t"){
        //             if(obj[item].isSelected === false){
        //               isAllCheck = false;
        //               break;
        //             }
        //           }else{
        //             for(let i of obj[item]){
        //               if(Object.keys(i)[0] === "objectInfo" && i['objectInfo'].isSelected === false  ){
        //                 isAllCheck = false;
        //                 break;
        //               }}

        //           }
        //         }

        //       }else{
        //         // console.log("obj", obj)
        //         // if line contains select line
        //         for(let key of Object.keys(obj)){
        //           if(key.split("_").includes("line")){
        //             for(let i of obj[key]){
        //               if(Object.keys(i)[0] === "objectInfo" && i['objectInfo'].isSelected === false  ){
        //                 isAllCheck = false;
        //                 break;
        //               }}              }
        //         }

        //       }
        //     }
        //   }
        // }


        for (let p of selecetedRegions) {
          if (p.regions) {
            for (let obj of p.regions) {
              if (!hasMultipleObjects(obj)) {
                for (let item in obj) {
                  if (item.split("_")[0] === "t") {
                    if (obj[item].isSelected === true) {
                      isAllUnCheck = false;
                      break;
                    }
                  } else {
                    for (let i of obj[item]) {
                      if (Object.keys(i)[0] === "objectInfo" && i['objectInfo'].isSelected === true) {
                        isAllUnCheck = false;
                        break;
                      }
                    }

                  }
                }

              } else {
                // console.log("obj", obj)
                // if line contains select line
                for (let key of Object.keys(obj)) {
                  if (key.split("_").includes("line")) {
                    for (let i of obj[key]) {
                      if (Object.keys(i)[0] === "objectInfo" && i['objectInfo'].isSelected === true) {
                        isAllUnCheck = false;
                        break;
                      }
                    }
                  }
                }

              }
            }
          }
        }

        return isAllUnCheck;
      }

      // console.log("Entered else lese", deepICRCTX.originalOutputData);
      filename += `_${formatYYYYMMDDHHMMSS(new Date())}.csv`;
      let pageName = deepICRCTX.outputJson.original_output.document_name.split(".")
      pageName.pop();
      pageName = pageName.join(".")
      //if shape  avaialble
      if (format === "csv") {
        if (isAllChecked()) {
          props.enqueueSnackbar(t("errorEmptyCsvDownload"), {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          return;
        }
        for (let i = 0; i < deepICRCTX.selectedRegion.pages.length; i++) {
          for (let j = 0; j < deepICRCTX.selectedRegion?.pages[i]?.regions?.length; j++) {
            let objData = deepICRCTX.selectedRegion.pages[i].regions[j];


            if (!hasMultipleObjects(objData)) {
              for (let item in objData) {
                const tableOrLine = item.split("_")[0]
                if (tableOrLine === "t") {
                  let oid = Object.keys(objData)[0].split("_")[3];
                  if (!objData[item].isSelected) break;
                  let objectInfo = `${pageName}_page_${deepICRCTX.pdfBase64 ? objData[item].pageInfo.split("_").pop() : 1}_object_${oid}${objData[item].meta ? "_" + objData[item].meta : ""}`
                  // console.log({oid}, {objectInfo});
                  let cellDataMerging = objData[item].cells.map(c => c.cell_text ? c.cell_text : null);
                  // console.log({ cellDataMerging });
                  let newObjectData = cellDataMerging.filter(v => v !== null).map(val => '"' + (val ? commaRemovingFromNumberValue(val).replace(/"/g, '""') : '') + '"').join(",");
                  data += '"' + objectInfo + '"' + "," + newObjectData + "\n";
                }
                else {
                  if (isSelectedLineData(objData[item]) === false) break;
                  for (let o in objData) {

                    let objectInfo = ""
                    let lineDataObj = []
                    for (let lineData of objData[o]) {
                      if (Object.keys(lineData).includes("objectInfo")) {
                        let oid = Object.keys(objData)[0].split("_")[3];
                        // console.log("page info",lineData.objectInfo.pageInfo);
                        objectInfo = `${deepICRCTX.pdfBase64 ? lineData.objectInfo.pageInfo : `${lineData.objectInfo.pageInfo}_page_1`}_object_${oid}${lineData.objectInfo.meta ? "_" + lineData.objectInfo.meta : ""}`;
                      } else {
                        // console.log(lineData);
                        lineDataObj = [...lineDataObj, ...Object.values(lineData).map((v) => v)]
                      }

                    }
                    // console.log({lineDataObj});
                    let lineDataObject = findLinesAndSort(lineDataObj, false).map(val => '"' + (val.text ? commaRemovingFromNumberValue(val.text).replace(/"/g, '""') : '') + '"').join(",");
                    data += '"' + objectInfo + '"' + "," + lineDataObject + "\n";

                  }
                }

              }

            } else {
              let keys = Object.keys(objData);
              for (let key of keys) {
                if (key.split("_")[0] === "l") {
                  // console.log("else", objData);
                  if (isSelectedLineData(objData[key]) === false) break;
                  let objectInfo = ""
                  let lineDataObj = []
                  for (let lineData of objData[key]) {
                    if (Object.keys(lineData).includes("objectInfo")) {
                      let oid = Object.keys(objData)[0].split("_")[3];

                      objectInfo = `${deepICRCTX.pdfBase64 ? lineData.objectInfo.pageInfo : `${lineData.objectInfo.pageInfo}_page_1`}_object_${oid}${lineData.objectInfo.meta ? "_" + lineData.objectInfo.meta : ""}`;
                    } else {
                      lineDataObj = [...lineDataObj, ...Object.values(lineData).map((v) => v)]
                    }

                  }
                  let lineDataObject = findLinesAndSort(lineDataObj, false).map(val => '"' + (val.text ? commaRemovingFromNumberValue(val.text).replace(/"/g, '""') : '') + '"').join(",");
                  data += '"' + objectInfo + '"' + "," + lineDataObject + "\n";

                }
              }


            }

          }
        }
        // console.log("data", data);
        deepICRDownload(deepICRtoBlobWithBom(data, "text/csv;charset=utf-18"), filename);

        return
      }
      // if (format === "csv_rpa") {
      //   if (isAllChecked()) {
      //     props.enqueueSnackbar(t("errorEmptyCsvDownload"), {
      //       variant: "error",
      //       anchorOrigin: { vertical: "top", horizontal: "right" },
      //     });
      //     return;
      //   }
      //   // let tableRowNo = 0;
      //   // let lineRowNo = 0;
      //   // let tableLineIndetation = 0;
      //   // let lineIndentation = 0;
      //   // let pageIndentation = null;
      //   function CsvRPA(pages) {
      //     // const data = "";
      //     // const jsonName = "";

      //     // const newLine = "\n";
      //     // let lastRowPosition;
      //     // let lastColPosition;
      //     // let objectId = 1
      //     let dataObject = {

      //     }
      //     let header = ["ファイル名", "ページ番号", "テンプレート名"];


      //     // let counter = 0;
      //     for (let page of pages) {
      //       let objectId = 1
      //       // counter += 1;
      //       if ("regions" in page) {
      //         for (let shape in page["regions"]) {
      //           // console.log("Obj.......",(page["regions"][shape]))
      //           if (!hasMultipleObjects(page['regions'][shape])) {
      //             for (let object in page["regions"][shape]) {

      //               ///////////////// object///////////

      //               let tableOrLine = object.split("_");
      //               // console.log("table or line", tableOrLine[3]);
      //               if (tableOrLine[0] === "l") {
      //                 // objectId++
      //                 if (getLineObjectInfos(page['regions'][shape][object]).isSelected === false) {
      //                   objectId++;
      //                   break;

      //                 };
      //                 const lineDataObj = page['regions'][shape][object]
      //                   .filter(obj => { return !obj.objectInfo })
      //                   .map(obj => {
      //                     const key = Object.keys(obj)[0];
      //                     const lineData = obj[key];
      //                     return {
      //                       type: lineData.type,
      //                       class_type: lineData.class_type,
      //                       x: lineData.x,
      //                       y: lineData.y,
      //                       width: lineData.width,
      //                       height: lineData.height,
      //                       text: lineData.text
      //                     };
      //                   });
      //                 const allLineData = findLinesAndSort(lineDataObj);
      //                 const mergedText = allLineData.map(lineArray => {
      //                   return lineArray.map(line => line.text).join("");
      //                 }).join('＿');
      //                 const linemeta = getLineObjectInfos(page['regions'][shape][object]).meta || `object_${tableOrLine[3]}_line`;
      //                 const { page: p, meta: m } = getLineObjectInfos(page['regions'][shape][object]);

      //                 dataObject[`p_${deepICRCTX.pdfBase64 ? getLineObjectInfos(page['regions'][shape][object]).page : 1}`] = {
      //                   ...dataObject[`p_${deepICRCTX.pdfBase64 ? getLineObjectInfos(page['regions'][shape][object]).page : 1}`],
      //                   [`object_${tableOrLine[3]}`]: { textData: mergedText, type: "line", page: deepICRCTX.pdfBase64 ? p : 1 }
      //                 }

      //                 header.push(linemeta);
      //                 objectId++;
      //               }
      //               else {
      //                 objectId++
      //                 if (page['regions'][shape][object].isSelected === false) {
      //                   objectId++;
      //                   break;
      //                 };
      //                 const tableMeta = page['regions'][shape][object].meta || `object_${tableOrLine[3]}_table`
      //                 const totalRowAndCol = findTotalRowAndCol(page['regions'][shape][object]);
      //                 // const { minRow, minCol } = findMinRowAndCol(page['regions'][shape][object].cells);

      //                 // console.log(totalRowAndCol, minRow, minCol);
      //                 const tableHeader = Array.from({ length: totalRowAndCol.totalCols }, (v, i) => `${tableMeta}_${i + 1}`);
      //                 const pt = deepICRCTX.pdfBase64 ? page['regions'][shape][object].pageInfo.split("_")[page['regions'][shape][object].pageInfo.split("_").length - 1] : 1;

      //                 dataObject[`p_${pt}`] = {
      //                   ...dataObject[`p_${pt}`],
      //                   [`object_${tableOrLine[3]}`]: {
      //                     textData: formatTable(page['regions'][shape][object]),
      //                     type: "table",
      //                     page: deepICRCTX.pdfBase64 ? page['regions'][shape][object].pageInfo : 1
      //                   }
      //                 }

      //                 header.push(...tableHeader);
      //                 objectId++;
      //               }
      //             }

      //           }
      //           else {
      //             for (let object in page["regions"][shape]) {

      //               ///////////////// object///////////

      //               let tableOrLine = object.split("_");
      //               if (tableOrLine[0] === "l") {
      //                 objectId++;
      //                 if (getLineObjectInfos(page['regions'][shape][object]).isSelected === false) {
      //                   objectId++;
      //                   break
      //                 };
      //                 const lineDataObj = page['regions'][shape][object]
      //                   .filter(obj => { return !obj.objectInfo })
      //                   .map(obj => {
      //                     const key = Object.keys(obj)[0];
      //                     const lineData = obj[key];
      //                     return {
      //                       type: lineData.type,
      //                       class_type: lineData.class_type,
      //                       x: lineData.x,
      //                       y: lineData.y,
      //                       width: lineData.width,
      //                       height: lineData.height,
      //                       text: lineData.text
      //                     };
      //                   });
      //                 const allLineData = findLinesAndSort(lineDataObj);
      //                 const mergedText = allLineData.map(lineArray => {
      //                   return lineArray.map(line => line.text).join("");
      //                 }).join('＿');
      //                 const linemeta = getLineObjectInfos(page['regions'][shape][object]).meta || `object_${objectId}_line`;
      //                 const { page: p, meta: m } = getLineObjectInfos(page['regions'][shape][object]);

      //                 dataObject[`p_${deepICRCTX.pdfBase64 ? getLineObjectInfos(page['regions'][shape][object]).page : 1}`] = {
      //                   ...dataObject[`p_${deepICRCTX.pdfBase64 ? getLineObjectInfos(page['regions'][shape][object]).page : 1}`],
      //                   [`object_${tableOrLine[3]}`]: { textData: mergedText, type: "line", page: deepICRCTX.pdfBase64 ? p : 1 }
      //                 }

      //                 header.push(linemeta);
      //                 objectId++;
      //               }
      //               // else {
      //               //   if(page['regions'][shape][object].isSelected === false) break;
      //               //   const tableMeta = page['regions'][shape][object].meta || `object_${objectId}_table`
      //               //   const totalRowAndCol = findTotalRowAndCol(page['regions'][shape][object]);
      //               //   const { minRow, minCol } = findMinRowAndCol(page['regions'][shape][object].cells);

      //               //   // console.log(totalRowAndCol, minRow, minCol);
      //               //   const tableHeader = Array.from({ length: totalRowAndCol.totalCols }, (v, i) => `${tableMeta}_${i + 1}`);
      //               //   const pt = page['regions'][shape][object].pageInfo.split("_")[page['regions'][shape][object].pageInfo.split("_").length - 1];

      //               //   dataObject[`p_${pt}`] = {
      //               //     ...dataObject[`p_${pt}`],
      //               //     [`object_${objectId}`]: {
      //               //       textData: formatTable(page['regions'][shape][object]),
      //               //       type: "table",
      //               //       page: page['regions'][shape][object].pageInfo
      //               //     }
      //               //   }

      //               //   header.push(...tableHeader);
      //               //   objectId++;
      //               // }
      //             }
      //           }
      //         }

      //       }
      //     }
      //     return { header, dataObject };

      //   }


      //   function getLineObjectInfos(lineData) {
      //     let page, meta, isSelected
      //     for (let item of lineData) {
      //       if (Object.keys(item)[0] === "objectInfo") {
      //         const splitingPageInfo = item['objectInfo'].pageInfo.split("_");
      //         page = splitingPageInfo[splitingPageInfo.length - 1];
      //         meta = item['objectInfo'].meta
      //         isSelected = item['objectInfo'].isSelected;

      //       }
      //     }
      //     return { page, meta, isSelected }
      //   }
      //   function findMinRowAndCol(data) {
      //     let minRow = Infinity;
      //     let minCol = Infinity;

      //     data.forEach((row) => {
      //       minRow = Math.min(minRow, row.row_no);
      //       minCol = Math.min(minCol, row.col_no);
      //     });

      //     return { minRow, minCol };
      //   }
      //   function findTotalRowAndCol(data) {
      //     const minRow = Math.min(...data.cells.map(cell => cell.row_no));
      //     const minCol = Math.min(...data.cells.map(cell => cell.col_no));

      //     let maxRow = -1;
      //     let maxCol = -1;

      //     data.cells.forEach(cell => {
      //       // const endRow = cell.row_no + (cell.row_span || 1) - 1; 
      //       // const endCol = cell.col_no + (cell.col_span || 1) - 1; 
      //       // maxRow = Math.max(maxRow, endRow);
      //       // maxCol = Math.max(maxCol, endCol);
      //       const adjustedRow = cell.row_no - minRow;
      //       const adjustedCol = cell.col_no - minCol;
      //       const endRow = adjustedRow + (cell.row_span || 1) - 1;
      //       const endCol = adjustedCol + (cell.col_span || 1) - 1;
      //       maxRow = Math.max(maxRow, endRow);
      //       maxCol = Math.max(maxCol, endCol);
      //     });

      //     const totalRows = maxRow + 1;
      //     const totalCols = maxCol + 1;
      //     // console.log("total rows", totalRows, totalCols);
      //     return { totalRows, totalCols }
      //   }
      //   // function generateCSV(number) {
      //   //   let str = "";

      //   //   for (let i = 0; i < number; i++) {
      //   //     str += '""' + ",";

      //   //   }
      //   //   return str
      //   // }
      //   function getMaxRowsAndColumns(data) {
      //     let maxRows = 1;
      //     let maxColumns = 0;

      //     for (const key in data) {
      //       if (data[key].type === "table" && data[key].textData) {
      //         const rows = Object.keys(data[key].textData).length;
      //         const columns = Object.keys(data[key].textData[0]).length;

      //         if (rows > maxRows) {
      //           maxRows = rows;
      //         }

      //         if (columns > maxColumns) {
      //           maxColumns = columns;
      //         }
      //       }
      //     }

      //     return { maxRows, maxColumns };
      //   }
      //   let initRow = 0

      //   const tempHeader = CsvRPA(deepICRCTX.selectedRegion.pages);
      //   // console.log("all", tempHeader);
      //   let data = tempHeader.header.map(v => '"' + (v ? v.replace(/"/g, '""') : '') + '"');
      //   // console.log("data", data);
      //   data += "\n"
      //   initRow += 1;

      //   const originalObject = JSON.parse(JSON.stringify(tempHeader.dataObject));
      //   // sorting object
      //   const sortedObject = Object.keys(originalObject).sort().reduce((acc, key) => {
      //     acc[key] = originalObject[key];
      //     return acc;
      //   }, {});

      //   // console.log({sortedObject});

      //   // new way
      //   let counter = 0;
      //   let colEnd = 3;
      //   // let colIn = 3;
      //   // let rowEnd = 1;
      //   let pageWiseList = [];
      //   for (let page in sortedObject) {
      //     counter += 1;
      //     let tempPage = [];
      //     let hashMap = {};
      //     let { maxRows } = getMaxRowsAndColumns(sortedObject[page])
      //     // console.log("max",maxRows, maxColumns);
      //     for (let i = 0; i < maxRows; i++) {
      //       for (let object in sortedObject[page]) {
      //         if (i > 0 && sortedObject[page][object].type === "line") {
      //           continue;
      //         } else {
      //           if (sortedObject[page][object].type === "line") {
      //             // console.log("4859", sortedObject[page][object]);
      //             let tempObj = {
      //               [`line_${object.split("_")[1]}_${colEnd}_1_${counter === 1 ? "start" : "end"}`]: {
      //                 "0": sortedObject[page][object].textData
      //               }
      //             }
      //             colEnd++;

      //             // console.log("tempObj", tempObj);
      //             tempPage.push(tempObj)

      //           }
      //           if (sortedObject[page][object].type === "table") {
      //             let tempObj = {}
      //             if (sortedObject[page][object]['textData'][i]) {
      //               let len = Object.values(sortedObject[page][object]['textData'][i]).length;
      //               if (`table_${object.split("_")[1]}` in hashMap) {
      //                 tempObj = {
      //                   [`table_${object.split("_")[1]}_${hashMap[`table_${object.split("_")[1]}`]}_${i + 1}_${counter === 1 ? "start" : "end"}`]: sortedObject[page][object]['textData'][i]

      //                 }
      //                 tempPage.push(tempObj)
      //               } else {
      //                 hashMap[`table_${object.split("_")[1]}`] = colEnd
      //                 tempObj = {
      //                   [`table_${object.split("_")[1]}_${colEnd}_${i + 1}_${counter === 1 ? "start" : "end"}`]: sortedObject[page][object]['textData'][i]

      //                 }
      //                 colEnd += len
      //                 tempPage.push(tempObj)


      //               }


      //             }
      //             else {
      //               continue;
      //             }


      //             // console.log("temp table obj", tempObj);
      //           }
      //         }
      //         // console.log("hashMap", hashMap);
      //       }
      //     }
      //     pageWiseList.push(tempPage)
      //     // console.log("tempage", tempPage); // ager format

      //     const resultArray = Array.from({ length: maxRows }, () => []);
      //     // console.log("result arr",resultArray);

      //     tempPage.forEach((entry, indexNo) => {
      //       // console.log({ entry });
      //       const key = Object.keys(entry)[0];
      //       const [types, x, y, z] = key.split('_').map(Number);
      //       const type = key.split('_')[0]
      //       // const isFirstPage = key.split('_').pop()
      //       // console.log({isFirstPage});
      //       // console.log([type, x, y, z]);

      //       // Add content to the result array
      //       if (type === "line") {
      //         for (let i = resultArray[z - 1].length === 0 ? 0 : resultArray[z - 1].length; i < y - 3; i++) {
      //           resultArray[z - 1][i] = "";
      //         }
      //         resultArray[0].push(entry[key][0]);
      //       }
      //       else if (type === "table") {

      //         // if(indexNo!==0 && isFirstPage !== 'start'){
      //         for (let i = resultArray[z - 1].length === 0 ? 0 : resultArray[z - 1].length; i < y - 3; i++) {
      //           resultArray[z - 1][i] = "";
      //         }
      //         // }

      //         for (let tableObj in entry[key]) {
      //           resultArray[z - 1].push(entry[key][tableObj])
      //         }

      //       }
      //     });
      //     // console.log(resultArray);

      //     for (let r of resultArray) {
      //       const nameSplitter = deepICRCTX.outputJson.original_output.document_name.split(".");
      //       let ext = nameSplitter.pop();
      //       r.unshift(deepICRCTX?.templateJsonName || "");
      //       r.unshift(page.split("_")[1]);
      //       r.unshift(
      //         deepICRCTX.pdfBase64 ? nameSplitter.join(".") + ".pdf" : nameSplitter.join(".") + "." + ext
      //       );

      //       // console.log(r);
      //       let str = "";
      //       for (let q of r) {
      //         str += '"' + commaRemovingFromNumberValue(q) + '"' + ",";
      //       }
      //       data += str;
      //       data += "\n";
      //     }

      //   }
      //   // console.log("page wise obj", pageWiseList);
      //   // console.log("data", data);

      //   deepICRDownload(deepICRtoBlobWithBom(data, "text/csv;charset=utf-18"), filename);
      //   return

      // }
      if (format === "csv_rpa") {
        if (isAllChecked()) {
          props.enqueueSnackbar(t("errorEmptyCsvDownload"), {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          return;
        }
  
        function CsvRPA(pages) {
          
          let dataObject = {

          }
          let header = ["ファイル名", "ページ番号", "テンプレート名"];


          // let counter = 0;
          for (let page of pages) {
            let objectId = 1
            // counter += 1;
            if ("regions" in page) {
              for (let shape in page["regions"]) {
                // console.log("Obj.......",(page["regions"][shape]))
                if (!hasMultipleObjects(page['regions'][shape])) {
                  for (let object in page["regions"][shape]) {

                    ///////////////// object///////////

                    let tableOrLine = object.split("_");
                    // console.log("table or line", tableOrLine[3]);
                    if (tableOrLine[0] === "l") {
                      // objectId++
                      if (getLineObjectInfos(page['regions'][shape][object]).isSelected === false) {
                        objectId++;
                        break;

                      };
                      const lineDataObj = page['regions'][shape][object]
                        .filter(obj => { return !obj.objectInfo })
                        .map(obj => {
                          const key = Object.keys(obj)[0];
                          const lineData = obj[key];
                          return {
                            type: lineData.type,
                            class_type: lineData.class_type,
                            x: lineData.x,
                            y: lineData.y,
                            width: lineData.width,
                            height: lineData.height,
                            text: lineData.text
                          };
                        });
                      const allLineData = findLinesAndSort(lineDataObj);
                      const mergedText = allLineData.map(lineArray => {
                        return lineArray.map(line => line.text).join("");
                      }).join('＿');
                      const linemeta = getLineObjectInfos(page['regions'][shape][object]).meta || `object_${tableOrLine[3]}_line`;
                      const { page: p, meta: m } = getLineObjectInfos(page['regions'][shape][object]);

                      dataObject[`p_${deepICRCTX.pdfBase64 ? getLineObjectInfos(page['regions'][shape][object]).page : 1}`] = {
                        ...dataObject[`p_${deepICRCTX.pdfBase64 ? getLineObjectInfos(page['regions'][shape][object]).page : 1}`],
                        [`object_${tableOrLine[3]}`]: { textData: mergedText, type: "line", page: deepICRCTX.pdfBase64 ? p : 1 }
                      }

                      header.push(linemeta);
                      objectId++;
                    }
                    else {
                      objectId++
                      if (page['regions'][shape][object].isSelected === false) {
                        objectId++;
                        break;
                      };
                      page['regions'][shape][object] = updatedTableRowColSpan(page['regions'][shape][object]);
                      const tableMeta = page['regions'][shape][object].meta || `object_${tableOrLine[3]}_table`
                      const totalRowAndCol = findTotalRowAndCol(page['regions'][shape][object]);
                      // const { minRow, minCol } = findMinRowAndCol(page['regions'][shape][object].cells);

                      // console.log(totalRowAndCol, minRow, minCol);
                      const tableHeader = Array.from({ length: totalRowAndCol.totalCols }, (v, i) => `${tableMeta}_${i + 1}`);
                      const pt = deepICRCTX.pdfBase64 ? page['regions'][shape][object].pageInfo.split("_")[page['regions'][shape][object].pageInfo.split("_").length - 1] : 1;

                      dataObject[`p_${pt}`] = {
                        ...dataObject[`p_${pt}`],
                        [`object_${tableOrLine[3]}`]: {
                          textData: formatNewTable(updatedTableRowColSpan(page['regions'][shape][object])),
                          type: "table",
                          page: deepICRCTX.pdfBase64 ? page['regions'][shape][object].pageInfo : 1
                        }
                      }

                      header.push(...tableHeader);
                      objectId++;
                    }
                  }

                }
                else {
                  for (let object in page["regions"][shape]) {

                    ///////////////// object///////////

                    let tableOrLine = object.split("_");
                    if (tableOrLine[0] === "l") {
                      objectId++;
                      if (getLineObjectInfos(page['regions'][shape][object]).isSelected === false) {
                        objectId++;
                        break
                      };
                      const lineDataObj = page['regions'][shape][object]
                        .filter(obj => { return !obj.objectInfo })
                        .map(obj => {
                          const key = Object.keys(obj)[0];
                          const lineData = obj[key];
                          return {
                            type: lineData.type,
                            class_type: lineData.class_type,
                            x: lineData.x,
                            y: lineData.y,
                            width: lineData.width,
                            height: lineData.height,
                            text: lineData.text
                          };
                        });
                      const allLineData = findLinesAndSort(lineDataObj);
                      const mergedText = allLineData.map(lineArray => {
                        return lineArray.map(line => line.text).join("");
                      }).join('＿');
                      const linemeta = getLineObjectInfos(page['regions'][shape][object]).meta || `object_${objectId}_line`;
                      const { page: p, meta: m } = getLineObjectInfos(page['regions'][shape][object]);

                      dataObject[`p_${deepICRCTX.pdfBase64 ? getLineObjectInfos(page['regions'][shape][object]).page : 1}`] = {
                        ...dataObject[`p_${deepICRCTX.pdfBase64 ? getLineObjectInfos(page['regions'][shape][object]).page : 1}`],
                        [`object_${tableOrLine[3]}`]: { textData: mergedText, type: "line", page: deepICRCTX.pdfBase64 ? p : 1 }
                      }

                      header.push(linemeta);
                      objectId++;
                    }
                    // else {
                    //   if(page['regions'][shape][object].isSelected === false) break;
                    //   const tableMeta = page['regions'][shape][object].meta || `object_${objectId}_table`
                    //   const totalRowAndCol = findTotalRowAndCol(page['regions'][shape][object]);
                    //   const { minRow, minCol } = findMinRowAndCol(page['regions'][shape][object].cells);

                    //   // console.log(totalRowAndCol, minRow, minCol);
                    //   const tableHeader = Array.from({ length: totalRowAndCol.totalCols }, (v, i) => `${tableMeta}_${i + 1}`);
                    //   const pt = page['regions'][shape][object].pageInfo.split("_")[page['regions'][shape][object].pageInfo.split("_").length - 1];

                    //   dataObject[`p_${pt}`] = {
                    //     ...dataObject[`p_${pt}`],
                    //     [`object_${objectId}`]: {
                    //       textData: formatTable(page['regions'][shape][object]),
                    //       type: "table",
                    //       page: page['regions'][shape][object].pageInfo
                    //     }
                    //   }

                    //   header.push(...tableHeader);
                    //   objectId++;
                    // }
                  }
                }
              }

            }
          }
          return { header, dataObject };

        }


        function getLineObjectInfos(lineData) {
          let page, meta, isSelected
          for (let item of lineData) {
            if (Object.keys(item)[0] === "objectInfo") {
              const splitingPageInfo = item['objectInfo'].pageInfo.split("_");
              page = splitingPageInfo[splitingPageInfo.length - 1];
              meta = item['objectInfo'].meta
              isSelected = item['objectInfo'].isSelected;

            }
          }
          return { page, meta, isSelected }
        }
        function findTotalRowAndCol(data) {
          // console.log({data});
          // data = updatedTableRowColSpan(data)
          const minRow = Math.min(...data.cells.map(cell => cell.row_no));
          const minCol = Math.min(...data.cells.map(cell => cell.col_no));

          let maxRow = -1;
          let maxCol = -1;

          data.cells.forEach(cell => {
            // const endRow = cell.row_no + (cell.row_span || 1) - 1; 
            // const endCol = cell.col_no + (cell.col_span || 1) - 1; 
            // maxRow = Math.max(maxRow, endRow);
            // maxCol = Math.max(maxCol, endCol);
            const adjustedRow = cell.row_no - minRow;
            const adjustedCol = cell.col_no - minCol;
            const endRow = adjustedRow + (cell.row_span || 1) - 1;
            const endCol = adjustedCol + (cell.col_span || 1) - 1;
            maxRow = Math.max(maxRow, endRow);
            maxCol = Math.max(maxCol, endCol);
          });

          const totalRows = maxRow + 1;
          const totalCols = maxCol + 1;
          // console.log("total rows", totalRows, totalCols);
          return { totalRows, totalCols }
        }
        function getMaxRowsAndColumns(data) {
          let maxRows = 1;
          let maxColumns = 0;

          for (const key in data) {
            if (data[key].type === "table" && data[key].textData) {
              const rows = Object.keys(data[key].textData).length;
              const columns = Object.keys(data[key].textData[0]).length;

              if (rows > maxRows) {
                maxRows = rows;
              }

              if (columns > maxColumns) {
                maxColumns = columns;
              }
            }
          }

          return { maxRows, maxColumns };
        }
        let initRow = 0

        const tempHeader = CsvRPA(deepICRCTX.selectedRegion.pages);
        // console.log("all", tempHeader);
        let data = tempHeader.header.map(v => '"' + (v ? v.replace(/"/g, '""') : '') + '"');
        // console.log("data", data);
        data += "\n"
        initRow += 1;

        const originalObject = JSON.parse(JSON.stringify(tempHeader.dataObject));
        // console.log({originalObject});
        // sorting object
        const sortedObject = Object.keys(originalObject).sort().reduce((acc, key) => {
          acc[key] = originalObject[key];
          return acc;
        }, {});

        // console.log({sortedObject});

        // new way
        let counter = 0;
        let colEnd = 3;
        // let colIn = 3;
        // let rowEnd = 1;
        let pageWiseList = [];
        for (let page in sortedObject) {
          counter += 1;
          let tempPage = [];
          let hashMap = {};
          let { maxRows } = getMaxRowsAndColumns(sortedObject[page])
          // console.log("max",maxRows, maxColumns);
          for (let i = 0; i < maxRows; i++) {
            for (let object in sortedObject[page]) {
              if (i > 0 && sortedObject[page][object].type === "line") {
                continue;
              } else {
                if (sortedObject[page][object].type === "line") {
                  // console.log("4859", sortedObject[page][object]);
                  let tempObj = {
                    [`line_${object.split("_")[1]}_${colEnd}_1_${counter === 1 ? "start" : "end"}`]: {
                      "0": sortedObject[page][object].textData
                    }
                  }
                  colEnd++;

                  // console.log("tempObj", tempObj);
                  tempPage.push(tempObj)

                }
                if (sortedObject[page][object].type === "table") {
                  let tempObj = {}
                  if (sortedObject[page][object]['textData'][i]) {
                    let len = Object.values(sortedObject[page][object]['textData'][i]).length;
                    if (`table_${object.split("_")[1]}` in hashMap) {
                      tempObj = {
                        [`table_${object.split("_")[1]}_${hashMap[`table_${object.split("_")[1]}`]}_${i + 1}_${counter === 1 ? "start" : "end"}`]: sortedObject[page][object]['textData'][i]

                      }
                      tempPage.push(tempObj)
                    } else {
                      hashMap[`table_${object.split("_")[1]}`] = colEnd
                      tempObj = {
                        [`table_${object.split("_")[1]}_${colEnd}_${i + 1}_${counter === 1 ? "start" : "end"}`]: sortedObject[page][object]['textData'][i]

                      }
                      colEnd += len
                      tempPage.push(tempObj)


                    }


                  }
                  else {
                    continue;
                  }


                  // console.log("temp table obj", tempObj);
                }
              }
              // console.log("hashMap", hashMap);
            }
          }
          pageWiseList.push(tempPage)
          // console.log("tempage", tempPage); // ager format

          const resultArray = Array.from({ length: maxRows }, () => []);
          // console.log("result arr",resultArray);

          tempPage.forEach((entry, indexNo) => {
            // console.log({ entry });
            const key = Object.keys(entry)[0];
            const [types, x, y, z] = key.split('_').map(Number);
            const type = key.split('_')[0]
            // const isFirstPage = key.split('_').pop()
            // console.log({isFirstPage});
            // console.log([type, x, y, z]);

            // Add content to the result array
            if (type === "line") {
              for (let i = resultArray[z - 1].length === 0 ? 0 : resultArray[z - 1].length; i < y - 3; i++) {
                resultArray[z - 1][i] = "";
              }
              resultArray[0].push(entry[key][0]);
            }
            else if (type === "table") {

              // if(indexNo!==0 && isFirstPage !== 'start'){
              for (let i = resultArray[z - 1].length === 0 ? 0 : resultArray[z - 1].length; i < y - 3; i++) {
                resultArray[z - 1][i] = "";
              }
              // }

              for (let tableObj in entry[key]) {
                resultArray[z - 1].push(entry[key][tableObj])
              }

            }
          });
          // console.log(resultArray);

          for (let r of resultArray) {
            const nameSplitter = deepICRCTX.outputJson.original_output.document_name.split(".");
            let ext = nameSplitter.pop();
            r.unshift(deepICRCTX?.templateJsonName || "");
            r.unshift(page.split("_")[1]);
            r.unshift(
              deepICRCTX.pdfBase64 ? nameSplitter.join(".") + ".pdf" : nameSplitter.join(".") + "." + ext
            );

            // console.log(r);
            let str = "";
            for (let q of r) {
              str += '"' + commaRemovingFromNumberValue(q) + '"' + ",";
            }
            data += str;
            data += "\n";
          }

        }
        // console.log("page wise obj", pageWiseList);
        // console.log("data", data);

        deepICRDownload(deepICRtoBlobWithBom(data, "text/csv;charset=utf-18"), filename);
        return

      }
      else {
        //fullpage csv download line wise
        const oData = ODataForCSV(deepICRCTX.outputJson);
        let keys = Object.keys(oData);
        for (let i = 0; i < keys.length; i++) {
          if (keys[i] !== "documentName") {
            // for csv
            const pageNumber = keys[i];
            // console.log("data", deepICRCTX.originalOutputData.data[pageNumber]);
            // console.log("data", oData[pageNumber].data)

            // data = data + '"' + oData[pageNumber].id + "\",";
            // console.log( deepICRCTX.pdfBase64 ? oData[pageNumber].id : `${oData[pageNumber].id}_page_1`);
            let pageInfo = deepICRCTX.pdfBase64 ? oData[pageNumber].id : `${oData[pageNumber].id}_page_1`;
            // console.log({test});
            data = data + '"' + pageInfo + '"' + ",";
            data = data + findLinesAndSort(oData[pageNumber].data, false).map(data => '"' + (data.text ?
              commaRemovingFromNumberValue(data.text)
                .replace(/"/g, '""') : '') + '"').join(",");
            data = data + "\n";
          }
        }
        // console.log("data", data);
        deepICRDownload(deepICRtoBlobWithBom(data, "text/csv"), filename);

      }

    }

    else {
      if (deepICRCTX.outputTab === 1) {
        // Download TSV of Extracted data
        filename += "_extracted.tsv";

        const dataArray = deepICRCTX.extractedOutputData.data;
        const tableArray = deepICRCTX.extractedOutputTable.data;
        for (let key in dataArray) {
          let d_val = dataArray[key].values.map((row) =>
            row.value
              ? typeof row.value === "string"
                ? '"' + row.value.replace(/"/g, '""') + '"'
                : row.value
              : ""
          );
          data += '"' + key + '"\t' + d_val.join("\t") + "\n";
        }
        for (let p in tableArray) {
          for (let t in tableArray[p]) {
            for (let i = 0; i < tableArray[p][t].length; i++) {
              let t_val = tableArray[p][t][i].map((row) =>
                row.value
                  ? typeof row.value === "string"
                    ? '"' + row.value.replace(/"/g, '""') + '"'
                    : row.value
                  : ""
              );
              data += t_val.join("\t") + "\n";
            }
            data += "\n";
          }
          data += "\n";
        }
      } else {
        filename += "_original.csv";

        let keys = Object.keys(deepICRCTX.originalOutputData.data);
        for (let i = 0; i < keys.length; i++) {
          if (keys[i] !== "documentName") {
            // const pageNumber = keys[i];
            // data = data + '"' + deepICRCTX.originalOutputData.data[pageNumber].id + '"\n';
            // data =
            //   data +
            //   deepICRCTX.originalOutputData.data[pageNumber].data
            //     .map((data) => '"' + (data.text ? data.text.replace(/"/g, '""') : "") + '"')
            //     .join("\n");
            // data = data + "\n";

            const pageNumber = keys[i];
            data = data + '"' + deepICRCTX.originalOutputData.data[pageNumber].id + '"\n';
            data =
              data +
              deepICRCTX.originalOutputData.data[pageNumber].data
                .map((data) => '"' + (data.text ? data.text.replace(/"/g, '""') : "") + '"')
                .join("\n");
            data = data + "\n";
          }
        }
      }
      deepICRDownload(deepICRtoBlobWithBom(data, "text/csv"), filename);
    }
  };

  //-------------------------------------------------------------------------------------------------
  // Update JSON file in S3
  //-------------------------------------------------------------------------------------------------
  // const updateJson = async () => {
  //   let fileNameArray = deepICRCTX.file.name.split(".");
  //   fileNameArray.pop();
  //   let filename = fileNameArray.join(".") + "_out.json";

  //   // Reflecting the change for Original Output Data
  //   const oChangeTextArray = deepICRCTX.originalOutputData.data;
  //   for (let keyPage in oChangeTextArray) {
  //     const numberRegexp = new RegExp(/^[0-9]+$/);
  //     if (!numberRegexp.test(keyPage)) continue;
  //     for (let keyItem in oChangeTextArray[keyPage].data) {
  //       if (!numberRegexp.test(keyItem)) continue;
  //       if (oChangeTextArray[keyPage].data[keyItem].color === "blue") {
  //         let i, j, k, l, m;
  //         if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromLine") {
  //           [i, j, k, l, m] = ["", "", "", "", ""];

  //           if (oChangeTextArray[keyPage].data[keyItem].key.split("-").length === 4) {
  //             [i, j, k, l] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
  //           } else {
  //             [i, j, k] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
  //           }

  //           if (
  //             json.original_output.pages[i].regions[j].type === "Multi Line" ||
  //             json.original_output.pages[i].regions[j].type === "Handwritten"
  //           ) {
  //             if (
  //               json.original_output.pages[i].regions[j].lines[k].words[l].text !==
  //               oChangeTextArray[keyPage].data[keyItem].originalText
  //             ) {
  //               if (deepICRCTX.debug === true)
  //                 console.log(
  //                   "blue text unmatch " +
  //                   json.original_output.pages[i].regions[j].lines[k].words[l].text +
  //                   ":" +
  //                   oChangeTextArray[keyPage].data[keyItem].originalText
  //                 );
  //             }
  //             json.original_output.pages[i].regions[j].lines[k].words[l].text =
  //               oChangeTextArray[keyPage].data[keyItem].text;
  //           } else {
  //             if (
  //               json.original_output.pages[i].regions[j].words[k].text !==
  //               oChangeTextArray[keyPage].data[keyItem].originalText
  //             ) {
  //               if (deepICRCTX.debug === true)
  //                 console.log(
  //                   "blue text unmatch " +
  //                   json.original_output.pages[i].regions[j].words[k].text +
  //                   ":" +
  //                   oChangeTextArray[keyPage].data[keyItem].originalText
  //                 );
  //             }
  //             json.original_output.pages[i].regions[j].words[k].text =
  //               oChangeTextArray[keyPage].data[keyItem].text;
  //           }
  //         } else if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromTable") {
  //           [i, j, k, l, m] = ["", "", "", "", ""];
  //           [i, j, k, l, m] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
  //           if (
  //             json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text !==
  //             oChangeTextArray[keyPage].data[keyItem].originalText
  //           ) {
  //             if (deepICRCTX.debug === true)
  //               console.log(
  //                 "blue text unmatch " +
  //                 json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text +
  //                 ":" +
  //                 oChangeTextArray[keyPage].data[keyItem].originalText
  //               );
  //           }
  //           json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text =
  //             oChangeTextArray[keyPage].data[keyItem].text;
  //         }
  //       }
  //     }
  //   }

  //   // Reflecting the change for Extracted Output Data
  //   const eChangeTextArray = deepICRCTX.extractedOutputData.data;
  //   for (let key in eChangeTextArray) {
  //     for (let i = 0; i < eChangeTextArray[key].values.length; i++) {
  //       if (eChangeTextArray[key].values[i].originalValue !== "") {
  //         json.extracted_output[key].values[i] = eChangeTextArray[key].values[i].value;
  //       }
  //     }
  //   }
  //   const eChangeTableTextArray = deepICRCTX.extractedOutputTable.data;
  //   for (let page in eChangeTableTextArray) {
  //     for (let table in eChangeTableTextArray[page]) {
  //       for (let i = 0; i < eChangeTableTextArray[page][table].length; i++) {
  //         for (let j = 0; j < eChangeTableTextArray[page][table][i].length; j++) {
  //           if (eChangeTableTextArray[page][table][i][j] !== "") {
  //             json.extracted_output["details"].values[page][table][i][j] =
  //               eChangeTableTextArray[page][table][i][j].value;
  //           }
  //         }
  //       }
  //     }
  //   }


  //   // Upload updated output JSON file to S3
  //   const [, unixtime, microsec] = deepICRNow();
  //   const yyyymmddhhmmss =
  //     typeof deepICRCTX.file.yyyymmddhhmmss === "undefined"
  //       ? deepICRCTX.documentId
  //       : deepICRCTX.file.yyyymmddhhmmss;
  //   const md5 = crypto.createHash("md5");
  //   const md5hash = md5.update(deepICRCTX.cognitoUser.Username, "binary").digest("hex");


  //   // Refresh token
  //   let isError = false;
  //   let newAccessToken = "";
  //   let requestJson = {
  //     type: "request",
  //     head: {
  //       command: "refreshToken",
  //       format_version: deepICRCTX.apiFormatVersion,
  //       service_id: deepICRCTX.apiServiceId,
  //       transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
  //       unix_time: unixtime,
  //       micro_seconds: microsec,
  //       time_zone: deepICRCTX.apiTimeZone,
  //     },
  //     // "body": {refreshToken: deepICRCTX.refreshToken, username: deepICRCTX.cognitoUser.Username}
  //     body: { refreshToken: global.refreshToken, username: deepICRCTX.cognitoUser.Username },
  //   };

  //   await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTokenRefresh, {
  //     method: "POST",
  //     mode: "cors",
  //     // headers: {Authorization: deepICRCTX.accessToken, "Content-Type": "application/json"},
  //     headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
  //     body: JSON.stringify(requestJson),
  //   })
  //     .then((res) => {
  //       return res.json();
  //     })
  //     .then((json) => {
  //       // Timeout access token
  //       if (json.message === "Unauthorized") {
  //         props.enqueueSnackbar(t("errorLoginTimeout"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "LoginTimeoutError",
  //           Message: t("errorLoginTimeout"),
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });

  //         logout();
  //         isError = true;
  //         return;
  //       }
  //       if (json.body.status !== "OK") {
  //         if (json.body.error.message === "Token do not match") {
  //           props.enqueueSnackbar(t("errorLoginDuplicate"), {
  //             variant: "error",
  //             anchorOrigin: { vertical: "top", horizontal: "right" },
  //           });
  //           deepICRLogging({
  //             LogType: "ERROR",
  //             ErrType: "DuplicateLoginError",
  //             Message: t("errorLoginDuplicate"),
  //             Src: "Toolbar.js",
  //             Line: 0,
  //             Column: 0,
  //             Stack: "",
  //           });
  //           logout();
  //           isError = true;
  //           return;
  //         } else {
  //           if (deepICRCTX.debug === true) {
  //             console.log("[ToolBar - updateJson] token-refresh error for output json file");
  //           }
  //           if (deepICRCTX.debug === true) {
  //             console.log(JSON.stringify(json, null, 1));
  //           }
  //           props.enqueueSnackbar(t("errorSystemError"), {
  //             variant: "error",
  //             anchorOrigin: { vertical: "top", horizontal: "right" },
  //           });
  //           deepICRLogging({
  //             LogType: "ERROR",
  //             ErrType: "TokenRefreshFetchError",
  //             Message: "token-refresh error for output json file",
  //             Src: "Toolbar.js",
  //             Line: 0,
  //             Column: 0,
  //             Stack: "",
  //           });
  //           isError = true;
  //           return;
  //         }
  //       }
  //       newAccessToken = json.body.result.accessToken;
  //       global.accessToken = newAccessToken;
  //       // setDeepICRCTX({
  //       //   ...deepICRCTX,
  //       //   accessToken: json.body.result.accessToken
  //       // });
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - updateJson] token-refresh catch error for output json file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "TokenRefreshCatchError",
  //         Message: "token-refresh catch error for output json file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });

  //   if (isError) {
  //     return;
  //   }

  //   // Get Presigned URL for updated output JSON file
  //   let presignedUrl = "";
  //   requestJson.head.command = "getPresignedUrl";
  //   requestJson.body = {
  //     keys: [deepICRCTX.s3Path + "/" + md5hash + "/" + yyyymmddhhmmss + "/" + filename],
  //     operation: "PUT",
  //   };
  //   await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
  //     method: "POST",
  //     mode: "cors",
  //     headers: { Authorization: newAccessToken, "Content-Type": "application/json" },
  //     body: JSON.stringify(requestJson),
  //   })
  //     .then((res) => {
  //       return res.json();
  //     })
  //     .then((json) => {
  //       // Timeout access token
  //       // if(json.message === "Unauthorized"){
  //       //   props.enqueueSnackbar(
  //       //     t('errorLoginTimeout'),
  //       //     {variant: 'error', anchorOrigin: {vertical: 'top', horizontal: 'right'}}
  //       //   );
  //       //   logout();
  //       //   isError = true;
  //       //   return;
  //       // }
  //       if (json.body.status !== "OK") {
  //         if (deepICRCTX.debug === true) {
  //           console.log("[ToolBar - updateJson] get-signed-url error for output json file");
  //         }
  //         if (deepICRCTX.debug === true) {
  //           console.log(JSON.stringify(json, null, 1));
  //         }
  //         props.enqueueSnackbar(t("errorSystemError"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "SignedUrlFetchError",
  //           Message: "get-signed-url error for output json file",
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         isError = true;
  //         return;
  //       }
  //       presignedUrl = json.body.result.urls[0];
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - updateJson] get-signed-url catch error for output json file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "SignedUrlCatchError",
  //         Message: "get-signed-url catch error for output json file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });

  //   if (isError) {
  //     return;
  //   }

  //   // Put updated output JSON file to S3
  //   await fetch(presignedUrl, {
  //     method: "PUT",
  //     mode: "cors",
  //     headers: { "Content-Type": "application/json" },
  //     body: JSON.stringify(json, undefined, 1),
  //   })
  //     .then((json) => {
  //       if (json.ok !== true) {
  //         if (deepICRCTX.debug === true) {
  //           console.log("[ToolBar - updateJson] fetch error for output json file");
  //         }
  //         if (deepICRCTX.debug === true) {
  //           console.log(JSON.stringify(json, null, 1));
  //         }
  //         props.enqueueSnackbar(t("errorUpload"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "UploadError",
  //           Message: t("errorUpload"),
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         isError = true;
  //         return;
  //       }
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - updateJson] fetch catch error for output json file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "UploadCatchError",
  //         Message: t("errorUpload"),
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });

  //   if (isError) {
  //     return;
  //   }
  //   props.enqueueSnackbar(t("infoUpdated"), {
  //     variant: "info",
  //     anchorOrigin: { vertical: "top", horizontal: "right" },
  //   });
  // };

  //-------------------------------------------------------------------------------------------------
  // Update JSON file locally, local_environment
  //-------------------------------------------------------------------------------------------------
  // const updateJson = async () => {
  //   try {
  //     let fileNameArray = deepICRCTX.file.name.split(".");
  //     fileNameArray.pop();
  //     let filename = fileNameArray.join(".") + "_out.json";

  //     // Reflecting the change for Original Output Data
  //     const oChangeTextArray = deepICRCTX.originalOutputData.data;
  //     for (let keyPage in oChangeTextArray) {
  //       const numberRegexp = new RegExp(/^[0-9]+$/);
  //       if (!numberRegexp.test(keyPage)) continue;
  //       for (let keyItem in oChangeTextArray[keyPage].data) {
  //         if (!numberRegexp.test(keyItem)) continue;
  //         if (oChangeTextArray[keyPage].data[keyItem].color === "blue") {
  //           let i, j, k, l, m;
  //           if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromLine") {
  //             [i, j, k, l, m] = ["", "", "", "", ""];

  //             if (oChangeTextArray[keyPage].data[keyItem].key.split("-").length === 4) {
  //               [i, j, k, l] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
  //             } else {
  //               [i, j, k] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
  //             }

  //             if (
  //               json.original_output.pages[i].regions[j].type === "Multi Line" ||
  //               json.original_output.pages[i].regions[j].type === "Handwritten"
  //             ) {
  //               if (
  //                 json.original_output.pages[i].regions[j].lines[k].words[l].text !==
  //                 oChangeTextArray[keyPage].data[keyItem].originalText
  //               ) {
  //                 if (deepICRCTX.debug === true)
  //                   console.log(
  //                     "blue text unmatch " +
  //                     json.original_output.pages[i].regions[j].lines[k].words[l].text +
  //                     ":" +
  //                     oChangeTextArray[keyPage].data[keyItem].originalText
  //                   );
  //               }
  //               json.original_output.pages[i].regions[j].lines[k].words[l].text =
  //                 oChangeTextArray[keyPage].data[keyItem].text;
  //             } else {
  //               if (
  //                 json.original_output.pages[i].regions[j].words[k].text !==
  //                 oChangeTextArray[keyPage].data[keyItem].originalText
  //               ) {
  //                 if (deepICRCTX.debug === true)
  //                   console.log(
  //                     "blue text unmatch " +
  //                     json.original_output.pages[i].regions[j].words[k].text +
  //                     ":" +
  //                     oChangeTextArray[keyPage].data[keyItem].originalText
  //                   );
  //               }
  //               json.original_output.pages[i].regions[j].words[k].text =
  //                 oChangeTextArray[keyPage].data[keyItem].text;
  //             }
  //           } else if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromTable") {
  //             [i, j, k, l, m] = ["", "", "", "", ""];
  //             [i, j, k, l, m] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
  //             if (
  //               json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text !==
  //               oChangeTextArray[keyPage].data[keyItem].originalText
  //             ) {
  //               if (deepICRCTX.debug === true)
  //                 console.log(
  //                   "blue text unmatch " +
  //                   json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text +
  //                   ":" +
  //                   oChangeTextArray[keyPage].data[keyItem].originalText
  //                 );
  //             }
  //             json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text =
  //               oChangeTextArray[keyPage].data[keyItem].text;
  //           }
  //         }
  //       }
  //     }

  //     // Reflecting the change for Extracted Output Data
  //     const eChangeTextArray = deepICRCTX.extractedOutputData.data;
  //     for (let key in eChangeTextArray) {
  //       for (let i = 0; i < eChangeTextArray[key].values.length; i++) {
  //         if (eChangeTextArray[key].values[i].originalValue !== "") {
  //           json.extracted_output[key].values[i] = eChangeTextArray[key].values[i].value;
  //         }
  //       }
  //     }
  //     const eChangeTableTextArray = deepICRCTX.extractedOutputTable.data;
  //     for (let page in eChangeTableTextArray) {
  //       for (let table in eChangeTableTextArray[page]) {
  //         for (let i = 0; i < eChangeTableTextArray[page][table].length; i++) {
  //           for (let j = 0; j < eChangeTableTextArray[page][table][i].length; j++) {
  //             if (eChangeTableTextArray[page][table][i][j] !== "") {
  //               json.extracted_output["details"].values[page][table][i][j] =
  //                 eChangeTableTextArray[page][table][i][j].value;
  //             }
  //           }
  //         }
  //       }
  //     }
  //     props.enqueueSnackbar("Json Updated.", {
  //       autoHideDuration: 2000,
  //       variant: "info",
  //       anchorOrigin: { vertical: "top", horizontal: "right" },
  //     });

  //   } catch (err) {
  //     deepICRLogging({
  //       LogType: "ERROR",
  //       ErrType: "updateJsonFunctionError",
  //       Message: "",
  //       Src: "Toolbar.js",
  //       Line: 0,
  //       Column: 0,
  //       Stack: err,
  //     });
  //     props.enqueueSnackbar("Something went wrong", {
  //       autoHideDuration: 2000,
  //       variant: "info",
  //       anchorOrigin: { vertical: "top", horizontal: "right" },
  //     });

  //   }


  // };

  const uploadTemplateJson = async () => {
    // Configure AWS SDK with your credentials
    // const s3 = new AWS.S3({
    //   accessKeyId: 'AKIAS5DAOBGR6UBFZU62',
    //   secretAccessKey: 'GUgQLkCo9eohU3Vla6DU3NEQ+Y3Y/1TaPlnz2t/C',
    //   region: 'eu-north-1'
    // });

    for (const file of files) {
      const fileContent = file;
      console.log({ fileContent });
      // Construct parameters for putObject
      // const params = {
      //   Bucket: 'feasibilitytestbuckettemplateupload',
      //   Key: `/a/b/c/${file.name}`, // Set the S3 path for the file
      //   Body: fileContent
      // };

      // try {
      //   await s3.upload(params).promise();
      //   console.log(`File uploaded successfully: ${file.name}`);
      // } catch (error) {
      //   console.error(`Error uploading file: ${file.name}`, error);
      // }
    }

  }


  function isThereSelection() {
    if (objectSize(deepICRCTX.shapeList) > 0) {
      let isFound = false;
      for (let key in deepICRCTX.shapeList) {
        if (objectSize(deepICRCTX.shapeList[key]) > 0) {
          isFound = true;
          break;
        }
      }
      if (isFound) setIsSelection(true);
      else setIsSelection(false);
    } else setIsSelection(false);
  }

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(isThereSelection, [JSON.stringify(deepICRCTX.shapeList)]);

  //-------------------------------------------------------------------------------------------------
  // return 
  //-------------------------------------------------------------------------------------------------
  return (
    <div className={styles.styleToolBar} data-id={deepICRCTX.isImage}>

      <Toolbar style={{
        paddingLeft: 0,
        paddingRight: 0,
        backgroundColor: "#EAEAF0",
        display: "flex",
        justifyContent: "space-between",

      }}>
        {/* left side tool bar */}

        <div className={styles.styleDivToolbar} >


          <div style={{ display: "flex", width: "100%", justifyContent: "space-between", margin: "0 10px" }}>
            <div style={{ display: "flex", }}>
              <input
                type="file"
                accept=".pdf,.jpg"
                style={{ display: "none" }}
                id="fileUploadInputButton"
                onChange={getFile}
                webkitdirectory
              // onClick={PopupModalBeforeFileUpload}
              />
              <label htmlFor="fileUploadInputButton">
                <Button

                  onClick={(e) => {
                    if (isthereAnyShape(deepICRCTX.selectedRegion)) {
                      e.preventDefault()
                      openModal();
                    }
                  }}
                  startIcon={<BsUpload />}
                  className={styles.styleFileUpload} variant="outlined" component="span">
                  <Typography variant="h6">{t("stringToolBarFileUpload")}</Typography>
                </Button>
              </label>
              <Divider className={styles.styleDivider} />
              {/* webkitdirectory="" mozdirectory directory="" */}
              {/* <p>Directory: <input type="file" multiple={true} webkitdirectory="" mozdirectory directory="" onChange={(e) => {
                setFiles(e.target.files); console.log(e.target.files);
              }} /></p>
              <button onClick={uploadTemplateJson}>upload</button>  */}
              <CroppingTool isLeft={true} />


              {/* Button For Template Library */}
              <Button

                className={styles.styleFileUpload}
                variant="outlined"
                component="span"
                onClick={() => handleReturn()}
              >
                <Typography variant="h6">Template Library</Typography>
              </Button>

            </div>
            <div style={{ display: "flex", }}>
              <div style={{ width: "2px", backgroundColor: "#EAEAF0", }}></div>
              <Divider className={styles.styleDivider} />
              <InputBase
                placeholder={t("stringToolBarPageNumber")}
                classes={{
                  root: styles.stylePageNumberInputRoot,
                  input: styles.stylePageNumberInput,
                }}
                className={(deepICRCTX.fileBase64.length && deepICRCTX.pdfBase64) ? "styleAcitveBottomBar" : ""}
                inputProps={{ "aria-label": "Search" }}
                readOnly={(deepICRCTX.fileBase64.length && deepICRCTX.pdfBase64) ? false : true}
                onBlur={validatePdfPages}
                value={inputPages}
                onChange={(e) => { setInputPages(e.target.value); setDeepICRCTX({ ...deepICRCTX, targetPages: e.target.value }) }}

              />
              <Divider className={styles.styleDivider} />

              <CustomButton
                startIcon={<PiPathFill />}
                className={styles.styleConvert}
                variant="outlined"
                disabled={typeof deepICRCTX.file.name === "undefined" || deepICRCTX.file.name === "" || isDisableConvert}
                onClick={(e) => {
                  if (isthereAnyShape(deepICRCTX.selectedRegion)) {
                    openModalC()
                  } else {
                    uploadAndConvert()

                  }

                }}
              // startIcon={ < Router />}
              >
                <Typography variant="h6">{t("stringToolBarConvert")}</Typography>
              </CustomButton>

            </div>

          </div>

        </div>

        {/* right side tool bar */}

        <div className={styles.styleDivToolbar} >
          <div style={{ display: "flex", justifyContent: "space-between", minWidth: "-webkit-fill-available" }}>
            <div style={{ display: "flex" }} >
              <CroppingTool />

            </div>
            <div style={{ display: "flex", justifyContent: "space-around" }} >
              <IconButton style={{ display: "none" }}>
                <SvgIcon
                  htmlColor="#888888"
                  style={{ fill: "#FFFFFF", stroke: "#888888", strokeMiterlimit: "10" }}
                >
                  <path d="M19,21H5c-1.1,0-2-0.89-2-2V5c0-1.1,0.89-2,2-2H19c1.1,0,2,0.89,2,2V19C21,20.11,20.11,21,19,21z" />
                  <path
                    d="M19,21.5H5c-1.38,0-2.5-1.12-2.5-2.5V5c0-1.38,1.12-2.5,2.5-2.5H19c1.38,0,2.5,1.12,2.5,2.5V19
							C21.5,20.38,20.38,21.5,19,21.5z M5,3.5C4.17,3.5,3.5,4.17,3.5,5V19c0,0.83,0.67,1.5,1.5,1.5H19c0.83,0,1.5-0.67,1.5-1.5V5
							c0-0.83-0.67-1.5-1.5-1.5H5z"
                  />
                  <rect x="11.5" y="3" width="1" height="18" />
                  <path d="M18.4,12.5H12c-0.28,0-0.5-0.22-0.5-0.5s0.22-0.5,0.5-0.5h6.4c0.28,0,0.5,0.22,0.5,0.5S18.68,12.5,18.4,12.5z" />
                  <path
                    d="M18.4,12.5c-0.19,0-0.37-0.11-0.45-0.29l-2.3-4.98c-0.12-0.25-0.01-0.55,0.24-0.66c0.25-0.12,0.55-0.01,0.66,0.24l2.3,4.98
							c0.12,0.25,0.01,0.55-0.24,0.66C18.54,12.49,18.47,12.5,18.4,12.5z"
                  />
                  <path
                    d="M16.1,17.48c-0.07,0-0.14-0.01-0.21-0.05c-0.25-0.12-0.36-0.41-0.24-0.66l2.3-4.98c0.12-0.25,0.41-0.36,0.66-0.24
							c0.25,0.12,0.36,0.41,0.24,0.66l-2.3,4.98C16.47,17.37,16.29,17.48,16.1,17.48z"
                  />
                </SvgIcon>
              </IconButton>

              <IconButton style={{ display: "none" }}>
                <SvgIcon
                  htmlColor="#888888"
                  style={{ fill: "#FFFFFF", stroke: "#888888", strokeMiterlimit: "10" }}
                >
                  <path d="M19,21H5c-1.1,0-2-0.89-2-2V5c0-1.1,0.89-2,2-2H19c1.1,0,2,0.89,2,2V19C21,20.11,20.11,21,19,21z" />
                  <path
                    d="M19,21.5H5c-1.38,0-2.5-1.12-2.5-2.5V5c0-1.38,1.12-2.5,2.5-2.5H19c1.38,0,2.5,1.12,2.5,2.5V19
							C21.5,20.38,20.38,21.5,19,21.5z M5,3.5C4.17,3.5,3.5,4.17,3.5,5V19c0,0.83,0.67,1.5,1.5,1.5H19c0.83,0,1.5-0.67,1.5-1.5V5
							c0-0.83-0.67-1.5-1.5-1.5H5z"
                  />
                  <rect x="11.5" y="3" width="1" height="18" />
                </SvgIcon>
              </IconButton>

              <IconButton style={{ display: "none" }}>
                <SvgIcon
                  htmlColor="#888888"
                  style={{ fill: "#FFFFFF", stroke: "#888888", strokeMiterlimit: "10" }}
                >
                  <path d="M19,21H5c-1.1,0-2-0.89-2-2V5c0-1.1,0.89-2,2-2H19c1.1,0,2,0.89,2,2V19C21,20.11,20.11,21,19,21z" />
                  <path
                    d="M19,21.5H5c-1.38,0-2.5-1.12-2.5-2.5V5c0-1.38,1.12-2.5,2.5-2.5H19c1.38,0,2.5,1.12,2.5,2.5V19
							C21.5,20.38,20.38,21.5,19,21.5z M5,3.5C4.17,3.5,3.5,4.17,3.5,5V19c0,0.83,0.67,1.5,1.5,1.5H19c0.83,0,1.5-0.67,1.5-1.5V5
							c0-0.83-0.67-1.5-1.5-1.5H5z"
                  />
                  <rect x="11.5" y="3" width="1" height="18" />
                  <path d="M12,12.5H5.6c-0.28,0-0.5-0.22-0.5-0.5s0.22-0.5,0.5-0.5H12c0.28,0,0.5,0.22,0.5,0.5S12.28,12.5,12,12.5z" />
                  <path
                    d="M7.9,17.48c-0.19,0-0.37-0.11-0.45-0.29l-2.3-4.98c-0.12-0.25-0.01-0.55,0.24-0.66c0.25-0.12,0.55-0.01,0.66,0.24l2.3,4.98
							c0.12,0.25,0.01,0.55-0.24,0.66C8.04,17.46,7.97,17.48,7.9,17.48z"
                  />
                  <path
                    d="M5.6,12.5c-0.07,0-0.14-0.01-0.21-0.05c-0.25-0.12-0.36-0.41-0.24-0.66l2.3-4.98c0.12-0.25,0.41-0.36,0.66-0.24
							c0.25,0.12,0.36,0.41,0.24,0.66l-2.3,4.98C5.97,12.39,5.79,12.5,5.6,12.5z"
                  />
                </SvgIcon>
              </IconButton>

              <Divider className={styles.styleDivider} />

              <Select
                className={(deepICRCTX.outputSw === false && deepICRCTX.documentId === "") ? styles.styleFormat:styles.styleFormatActive}
                id="select-format"
                value={format}
                disabled={(deepICRCTX.outputSw === false && deepICRCTX.documentId === "") || (Object.keys(deepICRCTX.outputJson?.original_output).length ? false : true)}
                onChange={setSelectValue}
                classes={{
                  underline: styles.inputUnderline,
                }}

              >
                <MenuItem
                  disabled={!isthereAnyShape(deepICRCTX.selectedRegion)}
                  value={"csv"}
                  selected={deepICRCTX.shapeListRight.length > 0 && deepICRCTX.isSelection === true}
                >
                  <Typography variant="h6">CSV</Typography>
                </MenuItem>
                <MenuItem
                  disabled={!isthereAnyShape(deepICRCTX.selectedRegion)}
                  value={"csv_rpa"}
                  selected={deepICRCTX.shapeListRight.length > 0 && deepICRCTX.isSelection}
                >
                  <Typography variant="h6">CSV_RPA</Typography>
                </MenuItem>

                <MenuItem
                  // disabled={deepICRCTX.isSelection}
                  selected={format === "csv_full"}
                  value={"csv_full"}

                >
                  <Typography variant="h6">CSV_{t("stringCSVFullPage")}</Typography>
                </MenuItem>
                {/* <MenuItem
                  // disabled={deepICRCTX.isSelection}
                  // selected={!deepICRCTX.isSelection}
                  value={"tsv"}
                  
                >
                  <Typography variant="h6">tsv</Typography>
                </MenuItem> */}

              </Select>
              <Divider className={styles.styleDivider} />
              <CustomButton
                startIcon={<BsDownload />}
                className={styles.styleExport}
                variant="outlined"
                disabled={deepICRCTX.outputSw === false && deepICRCTX.documentId === "" || (Object.keys(deepICRCTX.outputJson?.original_output).length ? false : true)}
                onClick={downloadCSV}
              >
                <Typography variant="h6">{t("stringToolBarExport")}</Typography>
              </CustomButton>
              <Divider className={styles.styleDivider} />
            </div>

          </div>


        </div>

      </Toolbar>

      {/* pop up modal for file convert */}
      <PopupModal isOpen={isOpenC} closeModal={closeModalC} cb={uploadAndConvert} textBtnInfo={{ alertTitle: "stringPopUpMessage", positiveBtn: "stringPopUpMessageOk", negativeBtn: "stringPopUpMessageCancel" }} isPositiveGreen/>


      {/* modal  start*/}
      <input
        type="file"
        accept=".pdf,.jpg"
        style={{ display: "none" }}
        id="fileUploadInputButton-another"
        onChange={(e) => { getFile(e); closeModal() }}
      />
      <div className="fileUploadModal">

        <Dialog
          className={styles.modal}
          open={isOpen}
          onClose={closeModal}
          // closeAfterTransition
          // BackdropComponent={Backdrop}
          // BackdropProps={{
          //   timeout: 500,

          // }}
          TransitionProps={{ onEntered }}
          aria-labelledby="alert-dialog-description"

        >
          <Fade in={isOpen}>
            <div className={styles.paper}>
              {/* <h2 id="transition-modal-title"></h2> */}
              <p id="transition-modal-description">{t("stringPopUpMessage")}</p>
              {/* <input
                type="file"
                accept=".pdf,.jpg"
                style={{ display: "none" }}
                id="fileUploadInputButton-another"
                onChange={(e) => { getFile(e); closeModal() }}
                
                // onBlur={e=> console.log(e)}
              /> */}
              <label htmlFor="fileUploadInputButton-another">
                <Button
                  className={styles.styleOkButton}
                  style={{
                    minWidth: deepICRCTX.language === "en" ? "49%" : "",
                  }}
                  onClick={closeModal}

                  variant="outlined" component="span">
                  <Typography
                    style={{
                      letterSpacing: deepICRCTX.language === "en" ? "1px" : "",
                      fontWeight: deepICRCTX.language === "en" ? "600" : "initial"
                    }}
                    variant="h6">{t("stringPopUpMessageOk")}</Typography>
                </Button>
              </label>


              <Button
                // ref={cancelRefButton}
                id="btn-cancel"
                className={styles.styleCancelButton}
                style={{
                  minWidth: deepICRCTX.language === "en" ? "49%" : "",
                }}
                onClick={closeModal}
                action={(actions) => {
                  // console.log("actions", );
                  cancelRefButton.current = actions
                }}
                variant="outlined" component="span">


                <Typography
                  style={{
                    letterSpacing: deepICRCTX.language === "en" ? "1px" : "",
                    fontWeight: deepICRCTX.language === "en" ? "600" : "initial"
                  }}
                  variant="h6">{t("stringPopUpMessageCancel")}</Typography>
              </Button>
            </div>
          </Fade>
        </Dialog>
      </div>
      {/* modal end */}

    </div>
  );
};

export default withSnackbar(ToolBar);
