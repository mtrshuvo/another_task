import * as React from "react";
import PropTypes from "prop-types";
import { useTheme } from "@mui/material/styles";
import AppBar from "@mui/material/AppBar";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Grid2 from "@mui/material/Unstable_Grid2/Grid2";
import { Grid, Paper, styled } from "@mui/material";
import { Link } from "react-router-dom";
import BugReportIcon from '@mui/icons-material/BugReport';
const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
}));
function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`full-width-tabpanel-${index}`}
            aria-labelledby={`full-width-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 3 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired
};

function a11yProps(index) {
    return {
        id: `full-width-tab-${index}`,
        "aria-controls": `full-width-tabpanel-${index}`
    };
}

export default function ExTab() {
    const theme = useTheme();
    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    const handleChangeIndex = (index) => {
        setValue(index);
    };

    return (
        <Box sx={{ bgcolor: "background.paper", width: "50%", margin: "150px auto", border: "1px solid" }}>
            <AppBar position="static">
                <Tabs className="nav-tab-hover"
                    TabIndicatorProps={{
                        style: { backgroundColor: '#f50057' }
                        // sx: { height: 4, backgroundColor: "red" } //width: "25% !important"
                    }}
                    value={value}
                    onChange={handleChange}
                    indicatorColor="red"
                    textColor="inherit"
                    variant="fullWidth"
                    aria-label="full width tabs example"
                    sx={{
                        backgroundColor: "white",
                        color: "black",
                        "": {
                            color: "black",
                        }
                    }}
                >
                    <Tab sx={{ color: "#F23460" }} label="Standard QA Services" {...a11yProps(0)} />
                    <Tab sx={{ color: "#F23460" }} label="Specialized QA Services" {...a11yProps(1)} />
                </Tabs>
            </AppBar>

            <TabPanel value={value} index={0} dir={theme.direction}>
                <Grid container spacing={2}>
                    <Grid xs={6} lg={6} >
                        <p style={{ color: "#F23460", paddingLeft: "2rem" }}>Manual Testing</p>
                        <Item elevation={'0'}>
                            <ul style={{ color: "black" }}>
                                <li>
                                    <span><BugReportIcon sx={{ color: "#F23460" }} /></span>
                                    <Link style={{ color: "black" }}  >Funtionl testing services</Link>
                                </li>
                                <li>
                                    <span><BugReportIcon sx={{ color: "#F23460" }} /></span>
                                    <Link style={{ color: "black" }}>Funtionl testing services</Link>
                                </li>
                                <li>
                                    <span><BugReportIcon sx={{ color: "#F23460" }} /></span>
                                    <Link style={{ color: "black" }}>Funtionl testing services</Link>
                                </li>
                            </ul>
                        </Item>
                    </Grid>
                    <Grid xs={6} lg={6}>
                        <div>Manual Testing</div>
                        <Item elevation={'0'} >
                            <ul>
                                <li>
                                    <span>logo</span>
                                    <Link style={{ color: "black" }}>Funtionl testing services</Link>
                                </li>
                                <li>
                                    <span>logo</span>
                                    <Link style={{ color: "black" }}>Funtionl testing services</Link>
                                </li>
                                <li>
                                    <span>logo</span>
                                    <Link style={{ color: "black" }}>Funtionl testing services</Link>
                                </li>
                                <li>
                                    <span>logo</span>
                                    <Link style={{ color: "black" }}>Funtionl testing services</Link>
                                </li>
                            </ul>
                        </Item>
                    </Grid>


                </Grid>
            </TabPanel>
            <TabPanel value={value} index={1} dir={theme.direction}>
                Item Two
            </TabPanel>
        </Box>
    );
}
