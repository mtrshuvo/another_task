/**
 * Download file from browser
 * @param {Object} blob - blob for download
 * @param {string} filename - filename of download file
 * @return {undefined} nothing
 */
exports.deepICRDownload = (blob, filename) => {
  if(window.navigator.msSaveBlob) {
    // for IE
    window.navigator.msSaveBlob(blob, filename);
  } else {
    // for Chrome, etc...
    const csvURL = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    document.body.appendChild(link);
    link.href = csvURL;
    link.setAttribute('download', filename);
    link.click();
    document.body.removeChild(link);
  }
  return;
}

/**
 * Change to blob with BOM
 * @param {string} target - text file data
 * @param {string} contentType - content-type of target file
 * @return {Object} blob - filename of download file
 */
exports.deepICRtoBlobWithBom = (target, contentType) => {
  const bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
  return(new Blob([bom, target], {"type": contentType}));
}

/**
 * Get YYYYMMDDHHMMSS and Micro seconds
 * @return {Array<string>} [ymdhms, unixtime, microsec] - Current time in YYYYMMDDHHMMSS format, unix time, micro seconds
 */
exports.deepICRNow = () => {
  const az = (nbr) => {return(nbr < 10 ? "0" : "") + nbr;}
  const now = new Date();
  const ymdhms = ""
    + now.getFullYear()
    + az(now.getMonth() + 1)
    + az(now.getDate())
    + az(now.getHours())
    + az(now.getMinutes())
    + az(now.getSeconds());
  const utm = (performance.now() + performance.timing.navigationStart) / 1000;
  const uts = Math.floor((new Date().getTime()) / 1000);
  let ms = String(Math.round((utm - uts) * 1000000));
  if(ms.length === 1){ms = "00000" + ms}
  if(ms.length === 2){ms = "0000" + ms}
  if(ms.length === 3){ms = "000" + ms}
  if(ms.length === 4){ms = "00" + ms}
  if(ms.length === 5){ms = "0" + ms}
  return [ymdhms, uts, ms];
}

/**
 * Encode binary file to base64 format
 * @param {Object} bin - binary file
 * @return {string} base64 - base64 formatted file
 */
exports.deepICRToBase64 = (bin) => {
  const dic = [
    'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P',
    'Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f',
    'g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v',
    'w','x','y','z','0','1','2','3','4','5','6','7','8','9','+','/'
  ];
  const base64 = [];
  const num = bin.length;
  let n = 0;
  let b = 0;
  let i = 0;
  while(i < num){
    b = bin.charCodeAt(i);
    if(b > 0xff) return null;
    base64.push(dic[(b >> 2)]);
    n = (b & 0x03) << 4;
    i ++;
    if(i >= num) break;

    b = bin.charCodeAt(i);
    if(b > 0xff) return null;
    base64.push(dic[n | (b >> 4)]);
    n = (b & 0x0f) << 2;
    i ++;
    if(i >= num) break;

    b = bin.charCodeAt(i);
    if(b > 0xff) return null;
    base64.push(dic[n | (b >> 6)]);
    base64.push(dic[(b & 0x3f)]);
    i ++;
  }

  var m = num % 3;
  if(m){
    base64.push(dic[n]);
  }
  if(m === 1){
    base64.push("==");
  }else if(m === 2){
    base64.push("=");
  }
  return base64.join("");
}

/**
 * Rotate Image
 * @param {dataUrl} dataUrl - input image by dataURL format
 * @param {integer} degree - rotation angle (90 or -90)
 * @param {Object} fileSize - json {"height": xxx, "width": xxx}
 * @return {dataUrl} dataUrl - rotated output image by dataURL format
 */
exports.deepICRRotate = (dataUrl, degree, fileSize) => {
  const img = new Image()
  img.src = dataUrl;
  const canvas = document.createElement("canvas");
  canvas.height = fileSize.width;
  canvas.width = fileSize.height;
  let context = canvas.getContext("2d");
  if(degree === 90){
    context.transform(0, 1, -1, 0, fileSize.height, 0); // 右90度
  } else if(degree === -90) {
    context.transform(0, -1, 1, 0, 0, fileSize.width); // 左90度
  }
  context.drawImage(img, 0, 0);
  return(canvas.toDataURL("image/jpeg"));
}
