import React, { useState, useEffect, useContext } from 'react';
import { useTranslation } from 'react-i18next';
import { makeStyles, Typography } from '@material-ui/core';

// import react components
import DeepICRContext from '../resources/DeepICRContext';
import deepICRTheme from '../resources/deepICRTheme';

// Style Sheet
const useStyles = makeStyles(theme => ({
  styleButton: {
    color: theme.palette.deepICR.color,
  },
  styleText: {
    cursor: "pointer",
    '&:hover': {textDecoration: "underline"},
  },
}));

// Japanese flag(SVG)
// const IconJa = createSvgIcon(
//   <>
//     <rect x="0" y="0" fill="#FFFFFF" width="24" height="24"/>
//     <circle fill="#FF0000" cx="12" cy="12" r="6"/>
//   </>
//   , 'Copy');

// British flag(SVG)
// const IconEn = createSvgIcon(
//   <>
//     <rect fill="#001468" width="24" height="24"/>
//     <path fill="#FFFFFF" d="M24,24h-2.6l-6.8-7.8V24H9.4v-7.8L2.6,24H0v-2.4l5.2-6H0V8.4h5.2L0,2.4V0h2.6l6.8,7.8V0h5.2v7.8L21.4,0H24v2.4 l-5.2,6H24v7.2h-5.2l5.2,6V24z"/>
//     <path fill="#FF0000" d="M22.7,24l-7.3-8.4h2.2l6.4,7.8V24H22.7z M13.7,24h-3.4v-9.6H0V9.6h10.3V0h3.4v9.6H24v4.8H13.7V24z M15.4,8.4 L22.7,0H24v0.6l-6.4,7.8H15.4z M0,0.6V0h1.3l7.3,8.4H6.4L0,0.6z M8.6,15.6L1.3,24H0v-0.6l6.4-7.8H8.6z"/>
//   </>
//   , 'Copy');

// Switching react State between 'ja'' and 'en
const changeLang = (lang) => {
  return(lang === 'en' ? 'ja' : 'en');
}

// [React function component]
// Switching between Japanese and English
const ButtonSwitchLang = () => {
  const styles = useStyles();

  // for multiple language
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [t, i18n] = useTranslation();
  const [lang, setLang] = useState();

  useEffect(() => {
    i18n.changeLanguage(lang);
  }, [lang, i18n]);

  if(deepICRCTX.language === "ja"){
    return (
      <div className={styles.styleButton}>
        <Typography variant="h6">
          {t('stringMenuBarLangage')}&nbsp;&nbsp;
          <font style={{color: deepICRTheme.palette.deepICR.blue4}}>
            {t('stringMenuBarLangageJa')}
          </font>
          /
          <font className={styles.styleText}
            onClick={() => {
              let newLang = changeLang(lang);
              setLang(newLang);
              setDeepICRCTX({
                ...deepICRCTX,
                language: newLang,
              });
            }}>
            {t('stringMenuBarLangageEn')}
          </font>
        </Typography>
      </div>
    );
  } else {
    return (
      <div className={styles.styleButton}>
        <Typography variant="h6">
          {t('stringMenuBarLangage')}&nbsp;&nbsp;
          <font className={styles.styleText}
            onClick={() => {
              let newLang = changeLang(lang);
              setLang(newLang);
              setDeepICRCTX({
                ...deepICRCTX,
                language: newLang,
              });
            }}>
            {t('stringMenuBarLangageJa')}
          </font>
          /
          <font style={{color: deepICRTheme.palette.deepICR.blue4}}>
            {t('stringMenuBarLangageEn')}
          </font>
        </Typography>
      </div>
    );
  }
  // return (
  //   <div className={styles.styleButton}>
  //     <IconButton onClick={() => {
  //       let newLang = changeLang(lang);
  //       setLang(newLang);
  //       setDeepICRCTX({
  //         ...deepICRCTX,
  //         language: newLang, 
  //       });
  //     }}>
  //       {lang === 'en' ? <IconJa /> : <IconEn />}
  //     </IconButton>
  //   </div>
  // );
}

export default ButtonSwitchLang;
