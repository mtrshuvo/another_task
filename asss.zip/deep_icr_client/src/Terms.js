import React, { useContext, useState } from 'react';
// import { useTranslation } from 'react-i18next';
import { Redirect } from 'react-router-dom';
import { makeStyles, withStyles } from '@material-ui/core';
import { withSnackbar } from 'notistack';
import Typography from '@material-ui/core/Typography';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Button from '@material-ui/core/Button';
import Link from '@material-ui/core/Link';
import { deepICRNow } from './deepICRCommon';

// import resource files
import DeepICRContext from './resources/DeepICRContext';
import deepICRLogging from './Logging/deepICRLogging';
// Style Sheet
const useStyles = makeStyles(theme => ({
  styleLogin: {
    margin: theme.spacing(0, 0, 0, 0),
    display: 'flex',
    flexDirection: 'column',
  },
  styleDeloitteGreen: {
    color: theme.palette.deepICR.deloitteGreen,
  },
  styleLogo: {
    margin: theme.spacing(1, 0, 0, 4),
  },
  styleTitle: {
    margin: theme.spacing(6, 0, 0, 6),
  },
  styleTermsTitle: {
    margin: theme.spacing(2, 0, 0, 6),
  },
  styleTermsTextarea: {
    margin: theme.spacing(1, 0, 0, 6),
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.backgroundColor,
    width: '800px',
  },
  styleForm: {
    margin: theme.spacing(4, 0, 0, 6),
    color: theme.palette.deepICR.color,
  },
  styleSubmit: {
    margin: theme.spacing(3, 0, 0, 0),
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    fontSize: theme.palette.deepICR.loginFont,
    width: '200px',
    height: '60px',
    verticalAlign: 'middle',
    padding: "0 0 0 0",
  },
  styleFooter: {
    margin: theme.spacing(8, 0, 0, 2),
  },
}));
const CustomCheckbox = withStyles({
  root: {
    color: "#ffffff",
    '&$checked': {
      color: "#ffffff",
    },
  },
  checked: {},
})(Checkbox);
const CustomButton = withStyles({
  contained: {
    '&$disabled': {
      color: "#ffffff",
      backgroundColor: "#888888",
    },
  },
  disabled: {},
})(Button);

// [React function component]
// Authentication Wrapper component
export const Terms = (props) => {
  const styles = useStyles();
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [checked, setChecked] = useState(false);

  // for multiple language
  // const [t] = useTranslation();

  // Do logout (Change isLogin Context to false)
  const doLogout = async () => {
    const [, unixtime, microsec] = deepICRNow();
    let requestJson = {
      "type": "request",
      "head": {
        "command": "signout",
        "format_version": deepICRCTX.apiFormatVersion,
        "service_id": deepICRCTX.apiServiceId,
        "transaction_id": deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
        "unix_time": unixtime,
        "micro_seconds": microsec,
        "time_zone": deepICRCTX.apiTimeZone
      },
    };
    await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiSignout, {
      method: "POST",
      mode: "cors",
      headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
      body: JSON.stringify(requestJson)
    }).then((res) => {
      return res.json();
    }).then((json) => {
      if (deepICRCTX.debug === true) { console.log(json); }
    }).catch((err) => {
      if (deepICRCTX.debug === true) { console.log('[ToolBar - logout] signout catch error'); }
      if (deepICRCTX.debug === true) { console.log(err); }
      deepICRLogging({
        "LogType": "ERROR",
        "ErrType": "SignOutCatchError",
        "Message": "Signput catch error",
        "Src": "Terms.js",
        "Line": 0,
        "Column": 0,
        "Stack": ""
      });
    });

    global.rotation = [];
    setDeepICRCTX({
      ...deepICRCTX,
      isLogin: false,
      isTerms: false,
      isContract: false,
      changePassword: false,
      documentId: "",
      cognitoUser: {},
      inputViewerBounds: { "bounds": { "height": 100, "width": 100, "top": 0, "bottom": 100, "left": 0, "right": 100 } },
      imageScale: 1,
      outputTab: 0,
      file: {},
      requestedFile: "",
      fileBase64: [],
      fileSize: [{ "height": 0, "width": 0 }],
      pdfBase64: "",
      pdfPage: 1,
      pdfPages: 1,
      targetPages: "",
      size: 12,
      originalOutputFontScale: 1,
      outputSw: false,
      outputLinkSw: false,
      originalOutputSize: { "height": 0, "width": 0 },
      originalOutputData: { "data": [] },
      originalOutputTable: { "data": [] },
      extractedOutputData: { "data": [] },
      extractedOutputTable: { "data": [] },
      searchText: ""
    });
  }

  if (deepICRCTX.isTerms) {
    let documentId = "";
    if (!(typeof props.match.params.id === "undefined")) {
      documentId = props.match.params.id;
    }
    if (documentId === "") {
      return (
        <Redirect to={'/deepICR'} />
      );
    } else {
      return (
        <Redirect to={'/deepICR/' + documentId} />
      );
    }
  } else {
    return (
      <div className={styles.styleLogin}>
        <header className={styles.styleLogo}>
          <img alt="Deloitte. Logo" src="/DEL_g_SEC_RGB.jpg" width="142" height="44" />
        </header>
        <div>
          <Typography className={styles.styleTitle} component="h1" variant="h4">
            Deep ICR®
          </Typography>
          <Typography className={styles.styleTermsTitle} component="h1" variant="h4">
            利用規約
          </Typography>
          <TextareaAutosize
            className={styles.styleTermsTextarea}
            aria-label="terms of service"
            rowsMax={15}
            defaultValue={deepICRCTX.termsOfService.join("\n")} />
          <form className={styles.styleForm} noValidate>
            <FormControlLabel
              control={
                <CustomCheckbox
                  inputProps={{ 'aria-label': 'checkbox' }}
                  checked={checked}
                  onChange={(e) => { setChecked(e.target.checked); }} />
              }
              label={
                <Typography component="h1" variant="h6">
                  私は利用規約を理解し、内容に同意の上本サービスを利用いたします。
                </Typography>
              } />
            <br />
            <CustomButton
              className={styles.styleSubmit}
              variant="contained"
              disabled={!checked}
              onClick={() => {
                setDeepICRCTX({
                  ...deepICRCTX,
                  isTerms: true,
                });
              }}>
              同意
            </CustomButton>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <Button
              className={styles.styleSubmit}
              variant="contained"
              onClick={doLogout}>
              同意しない<br style={{ lineHeight: 1 }} />（サインオフ）
            </Button>
          </form>
        </div>
        <footer className={styles.styleFooter}>
          <Typography>
            <Link color="inherit" href="https://deepicr.jp/deepicr_guide.docx">
              利用ガイド
            </Link>
            &nbsp;&nbsp;{'|'}&nbsp;&nbsp;
            {'利用規程'}
            &nbsp;&nbsp;{'|'}&nbsp;&nbsp;
            <Link color="inherit" href="https://www2.deloitte.com/jp/ja/footerlinks1/cookies/cookies-for-other-sites.html">
              クッキーに関する通知
            </Link>
            &nbsp;&nbsp;{'|'}&nbsp;&nbsp;
            <Link color="inherit" href="https://www2.deloitte.com/jp/ja/footerlinks1/privacy/privacy-for-other-sites.html">
              プライバシーポリシー
            </Link>
            <br />
            <br />
            {'© '}{new Date().getFullYear()}{'.'}&nbsp;{'詳細は'}&nbsp;
            <font className={styles.styleDeloitteGreen}>利用規程</font>
            &nbsp;{'をご覧ください。'}
            <br />
            {'Deloitte（デロイト）とは、デロイト トウシュ トーマツ リミテッド（“DTTL”）、そのグローバルネットワーク組織を構成するメンバーファームおよびそれらの関係法人のひとつまたは複数を指します。'}
            <br />
            {'DTTL（または“Deloitte Global”）ならびに各メンバーファームおよびそれらの関係法人はそれぞれ法的に独立した別個の組織体です。DTTLはクライアントへのサービス提供を行いません。'}
            <br />
            {'詳細は'}&nbsp;
            <Link color="inherit" href="https://www.deloitte.com/jp/about"><font className={styles.styleDeloitteGreen}>www.deloitte.com/jp/about</font></Link>
            &nbsp;{'をご覧ください。'}
          </Typography>
        </footer>
      </div>
    );
  }
}

export default withSnackbar(Terms);
