import React, { useContext } from 'react';
// import {useTranslation} from 'react-i18next';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';

// import react components
import DeepICRContext from '../resources/DeepICRContext';
import { objectSize } from '../resources/CommonMethods';

// [React function component]
// Extracted output component
const ExtractedOutput = () => {
	const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);

	// for multiple language
	// const [t] = useTranslation();

	if ((deepICRCTX.outputSw === false) && (deepICRCTX.documentId === "")) {
		return (
			<div style={{ fontSize: `${deepICRCTX.size}px` }} />
		);
	}

	return (
		<React.Fragment>
			{deepICRCTX.isSelection === false && objectSize(deepICRCTX.extractedOutputData.data) > 0 && <div
				style={{
					width: deepICRCTX.inputViewerBounds.bounds.width,
					height: deepICRCTX.inputViewerBounds.bounds.height,
					overflowY: 'scroll',
				}}>
				<Table size="small" aria-label="extracted table1">
					<TableBody>
						{Object.keys(deepICRCTX.extractedOutputData.data).map(key =>
							<TableRow key={key}>
								<TableCell><div style={{ color: "#26890d", fontWeight: 'bold', fontSize: deepICRCTX.size }}>{deepICRCTX.language === "ja" ? deepICRCTX.extractedOutputData.data[key].jp_label : deepICRCTX.extractedOutputData.data[key].en_label}</div></TableCell>
								<TableCell>
									{deepICRCTX.extractedOutputData.data[key].values.map(data =>

										<div
											style={{
												fontSize: deepICRCTX.size,
												color: deepICRCTX.searchText !== "" && data.value !== undefined && data.value.indexOf !== undefined && data.value.indexOf(deepICRCTX.searchText) >= 0 ? "#000" : data.color,
												backgroundColor: deepICRCTX.searchText !== "" && data.value !== undefined && data.value.indexOf !== undefined && data.value.indexOf(deepICRCTX.searchText) >= 0 ? "#F5FF5B" : "inherit",
											}}
											key={key + data.key}
											id={key + data.key}
											contentEditable={'true'}
											suppressContentEditableWarning
											onDrop={(e) => { e.preventDefault() }}
											onBlur={(e) => {
												if (e.target.innerText !== deepICRCTX.extractedOutputData.data[key].values[data.key].value) {
													const eData = deepICRCTX.extractedOutputData;
													if ((eData.data[key].values[data.key].null === false)
														&& (eData.data[key].values[data.key].originalValue === '')) {
														eData.data[key].values[data.key].originalValue
															= eData.data[key].values[data.key].value;
													}
													eData.data[key].values[data.key].value = e.target.innerText;
													if (e.target.innerText !== eData.data[key].values[data.key].originalValue) {
														eData.data[key].values[data.key].color = 'blue';
													} else {
														eData.data[key].values[data.key].color = 'black';
													}
													setDeepICRCTX({
														...deepICRCTX,
														extractedOutputData: eData,
													});
												}
											}}>
											{data.value}
										</div>
									)}
								</TableCell>
							</TableRow>
						)}
					</TableBody>
				</Table>

				<div>&nbsp;</div>
				<div>&nbsp;</div>

				{Object.keys(deepICRCTX.extractedOutputTable.data).map((page, p) =>
					<div key={p} style={{ width: "100%" }}>
						{Object.keys(deepICRCTX.extractedOutputTable.data[page]).map((table, tb) =>
							<React.Fragment key={tb}>
								<div style={{ fontWeight: "bold", padding: "4px 16px", color: "#26890d", fontSize: deepICRCTX.size, display: "block", width: "100%", }}>{page + " # " + table}</div>
								<Table key={tb} aria-label="extracted table2" style={{ width: "100%", maxWidth: "100%", borderTop: "6px solid #ddd" }}>
									<TableBody>
										{deepICRCTX.extractedOutputTable.data[page][table].map((row, r) =>
											<TableRow key={r}>
												{Object.keys(row).map((col, c) =>
													<TableCell key={c} style={{ border: "1px solid #e0e0e0" }}>
														<div
															style={{
																fontSize: deepICRCTX.size,
																color: deepICRCTX.searchText !== "" && row[col].value !== undefined && row[col].value.indexOf !== undefined && row[col].value.indexOf(deepICRCTX.searchText) >= 0 ? "#000" : row[col].color,
																backgroundColor: deepICRCTX.searchText !== "" && row[col].value !== undefined && row[col].value.indexOf !== undefined && row[col].value.indexOf(deepICRCTX.searchText) >= 0 ? "#F5FF5B" : "inherit",
															}}
															key={row[col].row + '-' + row[col].column}
															id={row[col].row + '-' + row[col].column}
															contentEditable={'true'}
															suppressContentEditableWarning
															onDrop={(e) => { e.preventDefault() }}
															onBlur={(e) => {
																if (e.target.innerText !== deepICRCTX.extractedOutputTable.data[page][table][r][c].value) {
																	const eTable = deepICRCTX.extractedOutputTable;
																	if ((eTable.data[page][table][r][c].null === false) && (eTable.data[page][table][r][c].originalValue === '')) {
																		eTable.data[page][table][r][c].originalValue = eTable.data[page][table][r][c].value;
																	}
																	eTable.data[page][table][r][c].value = e.target.innerText;
																	if (e.target.innerText !== eTable.data[page][table][r][c].originalValue) {
																		eTable.data[page][table][r][c].color = 'blue';
																	} else {
																		eTable.data[page][table][r][c].color = 'black';
																	}
																	setDeepICRCTX({
																		...deepICRCTX,
																		extractedOutputTable: eTable,
																	});
																}
															}}>
															{row[col].value}
														</div>
													</TableCell>
												)}
											</TableRow>
										)}
									</TableBody>
								</Table>
							</React.Fragment>
						)}

					</div>
				)}
			</div>}
		</React.Fragment>
	);
}

export default ExtractedOutput;
