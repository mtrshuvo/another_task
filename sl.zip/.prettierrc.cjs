// prettier.config.js or .prettierrc.js
module.exports = {
  printWidth: 100,
  trailingComma: "es5",
  tabWidth: 2,
  semi: true,
  singleQuote: false,
  endOfLine: "lf",
};
