import { createMuiTheme } from "@material-ui/core";

// Custom Theme for Deep ICR
const deepICRTheme = createMuiTheme({
  spacing: 8, // Default: 8
  typography: {
    button: {
      textTransform: "none",
    },
    fontSize: 10,
  },
  mixins: {
    toolbar: {
      minHeight: 40,
    },
  },
  palette: {
    primary: {
      main: "#444444",
    },
    secondary: {
      main: "#aaaaaa",
    },
    error: {
      main: "#ff0000",
    },
    deepICR: {
      maxSnack: 3,
      dismissColor: "#cccccc",
      loginFont: "large",
      color: "#ffffff",
      backgroundColor: "#000000",
      main: "#a3e7b0",
      deloitteGreen: "#86bc25",
      blue4: "#26890d",
      borderColor: "#d0d0ce",
      dividerHeight: 36,
      dividerMargin: 4,
      pageNumberInputSize: 350,
      pageNumberInputSizeFocus: 350,
      input: "#f1f1f1",
      inputWidth: "400px",
      imageBackground: "#ffffff",
      outputBackground: "#ffffff",
      tabOpacity: "0.5",
      tabFontSize: "medium",
      searchInputSize: 200,
      searchInputSizeFocus: 300,
    },
  },
});

export default deepICRTheme;
