import React, { createContext, useState } from "react";

// import resource files
import jsonDeepICRContext from "./deepICRContext.json";

// Context for Deep ICR
const DeepICRContext = createContext([jsonDeepICRContext, () => {}]);

// Context Provider for Deep ICR Context
export const DeepICRContextProvider = (props) => {
  const [value, setValue] = useState(jsonDeepICRContext);

  return (
    <DeepICRContext.Provider value={[value, setValue]}>{props.children}</DeepICRContext.Provider>
  );
};

export default DeepICRContext;
