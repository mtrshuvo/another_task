import React, { useEffect, useContext } from "react";
import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import { BrowserRouter, Route, Switch, Redirect } from "react-router-dom";
import { makeStyles } from "@material-ui/core";
import { SnackbarProvider } from "notistack";
import Button from "@material-ui/core/Button";
import { Container } from "react-simple-resizer";
import { ThemeProvider } from "@material-ui/core";

// import react components
import Login from "./Login";
import Auth from "./Auth";
import Terms from "./Terms";
import TermsOfService from "./TermsOfService";
import MenuBar from "./MenuBar/MenuBar";
import ToolBar from "./ToolBar/ToolBar";
import InputViewer from "./InputViewer/InputViewer";
import OutputViewer from "./OutputViewer/OutputViewer";
import ThumbnailView from "./Thumbnail/ThumbnailView";

// import resource files
import deepICRTheme from "./resources/deepICRTheme";
import { DeepICRContextProvider } from "./resources/DeepICRContext";
import jsonEn from "./resources/en.json";
import jsonJa from "./resources/ja.json";
import DeepICRContext from "./resources/DeepICRContext";
import ErrorBoundary from "./Logging/ErrorBoundary";
import deepICRLogging from "./Logging/deepICRLogging";
import { generateMessageFromError } from "./resources/CommonMethods";

// Global Variable
global.inputViewerBounds = {};
global.inputViewerWidth = 100;
global.inputViewerHeight = 100;
global.documentIdFileNotFound = false;
global.accessToken = "";
global.refreshToken = "";
global.rotation = [];
global.md5hash = "Unknown";

// Reading resource files of language
i18n.use(initReactI18next).init({
  resources: {
    en: { translation: jsonEn },
    ja: { translation: jsonJa },
  },
  lng: "ja", // default language
  fallbackLng: "ja", // else language
  interpolation: { escapeValue: false },
});

// Style Sheet
const useStyles = makeStyles((theme) => ({
  styleRoot: {
    backgroundColor: "#EAEAF0",
    color: deepICRTheme.palette.deepICR.backgroundColor,
    boxSizing: "border-box",
    height: "100%",
    display: "flex",
    flexDirection: "column",
    flex: 1,
  },
  styleContainer: {
    boxSizing: "border-box",
    height: "100%",
    flex: 1,
    padding: theme.spacing(1, 1, 1, 1),
    justifyContent: "space-between",
  },
  styleBar: {
    margin: deepICRTheme.spacing(0, 0, 0, 0),
    padding: 4,
  },
}));

// Add dismiss action to snackbars
const notistackRef = React.createRef();
const onClickDismiss = (key) => () => {
  notistackRef.current.closeSnackbar(key);
};

// Main view
const MainView = (props) => {
  const styles = useStyles();
  const [deepICRCTX] = useContext(DeepICRContext);

  // Set Context Request parameter with Document id
  let documentId = "";
  if (!(typeof props.match.params.id === "undefined")) {
    documentId = props.match.params.id;
  }

  if (deepICRCTX.isTerms) {
    return (
      <div className={styles.styleRoot}>
        <header>
          <MenuBar />
          {documentId === "" ? <ToolBar /> : <ToolBar documentId={documentId} />}
        </header>
        <Container className={styles.styleContainer}>
          {documentId === "" ? <InputViewer /> : <InputViewer documentId={documentId} />}
          <div className={styles.styleBar} />
          <OutputViewer />
        </Container>
        {/* <ThumbnailView /> */}
      </div>
    );
  } else {
    return <Terms />;
  }
};

// [React function component]
// Main component
const App = () => {

  useEffect(() => {
    window.onerror = function (msg, src, lineno, colno, error) {
      var string = msg.toLowerCase();
      var substring = "script error";
      if (string.indexOf(substring) > -1) {
        console.log("Script Error: See Browser Console for Detail");
      } else {
        let message = generateMessageFromError(error);
        deepICRLogging(message);
      }
      return false;
    };
  }, []);
  return (
    <ErrorBoundary>
      <ThemeProvider theme={deepICRTheme}>
        <SnackbarProvider
          maxSnack={deepICRTheme.palette.deepICR.maxSnack}
          dense
          preventDuplicate
          ref={notistackRef}
          action={(key) => (
            <Button
              onClick={onClickDismiss(key)}
              style={{ color: deepICRTheme.palette.deepICR.dismissColor }}
            >
              ✕
            </Button>
          )}
        >
          <DeepICRContextProvider>
            <BrowserRouter>
              <Switch>
                <Route exact path="/termsOfService" component={TermsOfService} />
                <Route exact path="/login" component={Login} />
                <Route exact path="/deepICR/data/:id" component={Login} />
                <Auth>
                  <Switch>
                    <Route exact path="/deepICR" component={MainView} />
                    <Route exact path="/deepICR/:id" component={MainView} />
                    <Redirect from="/" to="/deepICR" />
                  </Switch>
                </Auth>
              </Switch>
            </BrowserRouter>
          </DeepICRContextProvider>
        </SnackbarProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
};

export default App;
