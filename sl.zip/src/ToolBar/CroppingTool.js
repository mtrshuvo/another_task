// Dependencies
import React, { useContext } from "react";
import { IconButton } from "@material-ui/core";
import { makeStyles } from "@material-ui/core";
import { useTranslation } from "react-i18next";

// Context
import DeepICRContext from "../resources/DeepICRContext";

// Making stylesheet
const useStyles = makeStyles((theme) => ({
  active: {
    backgroundColor: "#26890d52",
    padding: 8,
    marginLeft: 8,
  },
  iconBtn: {
    padding: 8,
    marginLeft: 8,
  },
}));

const CroppingTool = (props) => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);

  const [t] = useTranslation();
  const styles = useStyles();

  return (
    <>
      {/* Selection left */}
      <IconButton
        variant="outlined"
        component="span"
        onClick={() =>
          setDeepICRCTX({
            ...deepICRCTX,
            croppingToolId: 0,
            // currentShape: [],
            selectedButton: !deepICRCTX.selectedButton
          })
        }
        className={deepICRCTX.selectedButton? styles.active : styles.iconBtn}
      >
        <img
          title={t("stringToolSelection") + " [Ctrl + S]"}
          width={18}
          height={18}
          alt=""
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAABHNCSVQICAgIfAhkiAAAAfFJREFUaEPt2mtRxDAUBeCzCgAF4ACQgANQADgABWABBSBhJSABHIACQAHMmWlnOp3dPrL3cdKl/9vNl9tkm5OssGfXas+8+AcXVvwSwHNz7z2Al8LnuN9mVeEvAIed1t6qoq3AvxtKI4n2BLMP7gA8ub+nM37AG8ymcDyz2hJXBFgK7QX+AXDQK6lEpb3A5wBeFdFeYD73bAuaHXEF4DtjUHuC6SGar/JpD/cG4CID7Q2mkx8krKoEOgIshY4Cj6E5pj8ixnQkeAjNCYxjmmPb9YoGtxhOZNc9WQg6C9x+fYWjM8Ep6GzwENolSFAAE/0I4CFiTa0CpvWmExN17aZBghI4BK0GHkKbpCeK4CH0zmtqVXC70jJfUyuDXdDqYHN0DeAh9Oz0pBawWXpSE3hsTT0pMqoNvDO6RvAYejA9qRVcnJ7UDC5KT5YAnhUkLAU8Gb0k8KT0RAXcnhHpHpuwjms5e68VwNuSDmswY+CjbHAUlp33zs29THAk9rM5b5L2SocEdpvGREaF07DsgGhwKjYanI6NBEtgo8Ay2AiwFNYbLIf1BHMDrD0/7bYxVvLt6fW3tKktpruAJVjPCvfbI4GNAstgI8BSWG+wHNYSzFN0x52BK4m1BDOi4cGUk+asxrp0FvW+z+pvybudZs//Ay5vsD0VqpunAAAAAElFTkSuQmCC"
        />
      </IconButton>
      {/* Hand Tool */}
      <IconButton
        variant="outlined"
        component="span"
        onClick={() =>
          setDeepICRCTX({
            ...deepICRCTX,
            croppingToolId: 1,
            currentShape: [],
            selectedShape: [],
            selectedButton: false
          })
        }
        className={deepICRCTX.croppingToolId === 1 ? styles.active : styles.iconBtn}
      >
        <img
          title={t("stringToolHand") + " [ Ctrl + H ]"}
          width={22}
          height={22}
          alt=""
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAAilBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATAggvAAAALXRSTlMA9/T9cUj5F0bw2E2Z7EA8GbyIXC8M6MOnUkMjHwXVm2g5yq52Kia2lBTlz34NDID9AAACPklEQVRo3u2Z6Y6jMAyATdILSrkG6DX0bqdz+P1fb8VmWm+QZgMh3j/L9yuyon44di1FgYGBf0u8D4QI9jHw8JriN2+vwEBe4pMyB+dMPxCJMnEuWKHGChyTS10gr+CIKAyE/5mpBLzRNBl5KoXs0xdBGEE/tin+yaiOjbRQuoUeHBeoMa2DiR5bHHt0fok6KowNg30OKbYRYAqWbLCdAG0rHeqdQ4JmPLQUBHrnkKAZ31kKBHXOVBM0476lgH7UtB4ExvV9J2guMQhoLnEJaC5xCWguMQsw5RZgxCDQ5xKDQJ9LDAJ9LjEI9PUgGASDYBDwCMz8T4KZusvPmAS3JX6zvHEIIh+f+Bv3gpuPSEzmzgVLRN3gWDBDhZSo8BwL9lgjDkVxEEi4EdCN7FAvY8Eh+P2jsgBlYBD4JCADxxEpNp5zQaiKHD+aykOeNhURKMYezx+NDHOPaVSIzcMwcSegwuoGpwIqrDenOvQUmA1OBWSYkMGtAMbNHOY9BeYcXAvIsIZuVCp1MDK2MNAtcwFshiPdk9ueknzpIrhgzRmAIweaZV/QzdA+h3eJNTG0NHQ+pUzVuKrXHHVIBNbc6zVLDiu1Oa/XHDlckHqoew4HMLGWqieuYGXAzPT9kvZZGExvf8kKFacKrA3iUvzU/9ljT0lfYWFAP1xvG5Jqehwt5XNDDjbEPhro+755DbANJ/sX2iKUaGKSVdCD6IR/RZ57v2yO337OYnHPwQHvL+HpQzQOZrE7f8UVDAzw8guj0EtyGpOpKgAAAABJRU5ErkJggg=="
        />
      </IconButton>
      {/* polygon */}
      {/* <IconButton
        variant="outlined"
        component="span"
        onClick={() =>
          setDeepICRCTX({
            ...deepICRCTX,
            croppingToolId: 2,
            // selectedButton: !deepICRCTX.selectedButton
          })
        }
        className={deepICRCTX.selectedButton === true ? styles.active : styles.iconBtn}
      >
        <img
          title={t("stringToolPolygon") + " [ Ctrl + P ]"}
          width={18}
          height={18}
          alt=""
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAMAAADDpiTIAAAArlBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABeyFOlAAAAOXRSTlMA/fk4BwP2txZZ1/EumRrblnpCKE5Irgq77B5zoVQRh4MOkXdk4eiejNGlPDPAaSNtyOXMfsVfqbImT11VAAAb7ElEQVR42uzc61biMBQF4JNeQRBG7mClgoNasALDzf3+Lza/Zy1XG7ChKbO/B8ivNuuck53IRWpufR+l26T92nCCP0k6eIuPH0Oh/8CsHx8a+I5ahHGfX8Et8/rznUImZ/Ty4QvdotX9GFpe35tCN6b7vsAZtp8zodvhfimcKXhbC92GfopLqGVXqPo6CS6lTiwGqm4ywE+o+6lQdXn7AD/0Wheqqk4bBRixGqwmL1YoRLARqp71FoU5cUJcOfUGCnTHjrBa/DmKFbAWrBLvhMI9C1XFNIUBv3hKWBGtBEYsPaEKmCxgSMhmoAJqbRiTcg+w3iyBQSchuw0PMOpdyGZ+CMMehSwWwzTFiZDFegrGBZwKW2syxhUkbAUs5e1wFXMhK81xJT0hC7kKVzJuCVnHT3A1SyHrvOCKVkKWmQS4ooRHw7YJcR51iOLNkztpffQ+n99SB+dhTtQyK5wjGByn8o/ZUzTGGRo1IZuMoE0t+558w1/9cjgMqKgVtIXNjEIiUtAU8M6YTUbQtOtIpqb2Snsha7jQ0zhKrv4CWsbMh9ljAC3trmioHZgMqJiaAx2jqWjxIuhYcBZgi0fomPv6Cypo6AvZ4Q4aNoUnSyIhK7gG0pwb5GuwDLTDPfKFvoFFn4Qs4I+R624mZ/JS5BoIWcBFrvHayA0jh69J2uABuepyAZfZsGpIkWdnarwUC5Vu6CBPRy7SzV15K1S6HvKExtoLh41g+WLkUE25UCvI31uobF8Gr3THPBO2X9tgqd7kJMB6Q4VswVAut0C2RKgQtv6kc2RrCJWsjhxHo1lDhoPLtkc2NTV6zuAKlWuObAf5kQjZ+F5I2ZbIFpndYLYPvS6jYWUKzY7rfyOfkywfemt+Bn/Zu9el1GEoCsA7pS2VVkAuIncQKHc8oCLr/V/s3JjhKFhCkl0Kh++34+i4ZLJ2k+Y8lryH+EqQ5d5icBY53l07M5zGfW30bjGIU8i7TPcQIToGt6uGJPAHoEZaHIHfbjFIrByiZUmPhS2dGJRrdPMvxytOS/3eaLh5bOTbb/V1qsV1JmBGWjyY4S6H9VsM/sg2n5cW9lSXjYepTSd75d22F8Ak/1cM/uc9JM7sx2SACO7TQ8oxuyNwQVrKMEz8v+8ZTd37kOA3yo7BQVCHYRCkI0P/p2wvA2nhaGZsFDw0MAqWdztMcpDdTAucZrx2zJwKmJOWIf663T6nrvJWhYLBwiYJJd7TOysYdkfRrm6I6KxXUBTKrJhfwPnANgXTAorWC+f5ReF69pkUxtCwatJRLqJ9JOoGEmHLbUCoXkcMihtoeirqPg70bVKXgWEZ6bnGNgY/LjgG3bwFbVa7orlMK2sEGBFYSoDj4o9riMEsByNyKb0XBA0TVALRkVzSXEEMFhYMsepaszqrSIpaPiKwlIDStdxV0f2AQZsWfSvLN3sZwbhAc6zhXkhNDHIwajClb/kAz6aQmgXThK052Hyli9B3YZjVVD8dijnDlnCmEjC+ilfTjWCeWEScDWIpAoFABLYSEK1HF2AEFh06rOLjmFWWTlYZYysRJUBye0NtMT17U2iDyb2j/FG9tDXeO5CgEoAXiaOSv4fJ0xbJupi/P3BPBxVw3CQZv4Z2CZD/scP581li0AGjNh3irHDcg/qh40sqARt8Fj4dicFF/f2BuvKiQzTpBFMXHHLsJSCHra8x6McTgwcw6yvv3BQ9knbnIgJjCbA0S4At8L3VrxhkiVVBgJkoK/zjbDVsvY8x/hJQ1O2zwXlfa+aFYFfNql8b++6RhMojpIgzlICa7tLFI0bOE2IwdxRe6LebKB9VfIUUUayV68Oln6gS0EG0kL66qAXAXx2d0rYpUqTsUJx4g/guBvwlYKn7euM5MZoKROBdBnRDSBLDLH2r1XYhSeyStItBQkvATp74tAaISdjSOsDhfnfq4OWhCmkT2pKPgX4JqB8tAZrnpF52c4NkjE6lJ4LOGCcYPBcc+izVzmBL4QPgQAwusgSU1MdHTcRHpCLmwZKqk86ilKrZTnZW6r8NVzhNg7aOx0C+BDTPXgIevs4NpGPg5BCjsUN70lAioKLq0Y50DALNLYi+bgmoSh60U4jBAqdx0/mHfjnwvKDcf7t/svRHwkUL8VnTjnQMjpaAj7OXgHHUFDEVEYNKiBNUh6UKfdK9m/g4ge/Rnjxi80QqsrolYMhbAnar0MgYdDVHAFa+4NABdrkhIG1Ee7wqYuK+kJLEl4AiZKzSo68x8HxIEpOakYNErkd7ygLx6JGaxJeAJuQN/o3BMySlA4o0fdeZB9YRi7RDahJfAt4QISIGNUvyqwt0VCmEFL8VsYhlNWiRosSXgA+o8U0+jKuNIeWN9tmvYGfNiEnzY2ydtwRkwGloExl8HBse+nbZENwWxMgpNt8+MtaZSoBtgY+ok7SOABTvbZ1a4DUkfvY2BnGXgAB8RIlOsBbK+6v6YPXoUFzsoNl5zFgxloA78Kmb31tqeXRIHozSNsXMDu5+xUDEUgI6YDNUurhZ6SoA5x5s5hWSwxGDCXsJeASXd5vjYNZr3DuTll1KMu0SkAOTgUcnq4WA6mBkbYHDvEWJltEsARUBJgVSUNJ4JlfwYd4k4W/51S4BMzDZkJJ3jQN/wQqmtSnhtEvAGjxEkenWTqzoW9kxjBILSjrtEtDGJ+cfnWxwTES0uk8waFWgxPtTGHNCvQRswMLNkqKigMadcHbPhSmPCV/+7c8NVErAACxGpKyhd+r/JQ0j3D5dmm0MElECAsbrOl4pWnMFfe8Xe/HXNgbnLQEDUmf7umflunkBPeGaLtzfGFjnKgE/2bsTpTSCKArDZ4ZBlEHBQcMmIgguQCQalbrv/2KpSBbLYHfP0kx3ON8jWI3Af5m+E+Qw16cgncq95BDeuR3/0hyDjvndXqVHIONvNufQqg56klWtjf1RExviCDmMwyJWQ0dHXyWDYL7EPpmJDWvk0i3oadf2pCfpHEz2bM3jWP5wKKAeF3b7W/T68j8NfrZzaztOEev7n4scMzRaMzFVw76p1GaBFG+IXB4KvvHiZDj6esD9jp8YV17vajMpVAW5nFm4Pb3amN7WA1ELsbeKPQZ9u29MTWS0Eg1fNnP85uoxiJBLX9fprD2IWQFpj4H9Xdkntg4AmqJ2BPp7DKaZj0EfuSxFrWmtMJyCth0Dxz4E3lsrDMegIo7B0O76/hdkdcoQkPsYOBCCusjqiCGgkGNQt5uCW7ZWAmLBEFCIV7vDoJq1q09PGAJ2MkLoVZFDR5dtB2AIKNdYNBY2vwTIGRgCSvYkanfI4UI02mAIKFnXWqoBqj19aGQIKNnE4os0Ef3pYggo2YNoPNv7EihrgCGgZInBhX4ZrUKDzMQQULLDwNqTAXPRaQAMAWV7FI1whUyWgWjEVYAhoGyntn4a3jX65SZDQNkalmbC52a3djMElG4mOs1LpHb4JForAAwBpZuIVreKlKJHs2viGALKd27jGeELw70NDAHli2LRmyKVgRhYAWAIcMBa9MIEKZwFYvgOwBDggEQMhFMYGwRi+k+FIcAFj2JiUoWR6FZM9DoAGAKcMBQjtTEMHL6k2BrFEOAE072x9SW0kpmIGG8LYAhww1TMBOsVlBq1VPePMgQ4Irox3xuqeOX2zXeHhm0AYAhwxbUYi0cNbFWZhGKshfwWonYAMjWOJYXZJKl+XBzcekq/PJohwB0Pkk5vPvo2rPSjqF8ZfhutY0nnFD8xBDjkRbIIJJOnTQNgCHBIOxQ1h66eYgiw4UqUHLp9kiHAiqguO3JziJ8YAhyzCGQ3zvCGIcA1x7ITF3jDEOCczr3sQH2MNwwB7jl5Eut6K7xhCHDR8kAsCxJsMAQ46SwQuwbYYAhw1LVY1cIGQ4CzbsWiW/zCEOCsqCbWXFSxwRDgsGgulsyr2GAIcNudbLj++mcIsGUQSPGuYAFDgB1HoRQsfMVfDAHOS2IpVJzAiq6oXYOyadSlQI8rvMcQ4IHoLpCCBKMI7zAEeGLRlELMEnzAEOCHTiuQ3IKLS3zAEOCNZCY5fa9AwX4IOATlMR7FksPNtIotGAI8cnkVS0bx1SW2YgjwSsYjcHM9xnYMAb4ZP/ckpeZDhM8xBPimL2n0WhWoMAR4ZynGDr4MI6gxBHhnKEbCl+dFBB2GAP9ci078eDs478AQQ4BnjkVtfYJUGAI80y34194MAZ5pFvzAP0OAX7TPYC2RCkOAZ1aiMUYqDAGeSUSth3QYAjwzFbXvKE2FIWAHRhYu/WEI8Mha1EZIiSHAL9+L3/3AEOCTnqglSIchwC9jG+ufGAL8sRS1sIq0GAJ8MhS1JtJjCPDIQNS6SI0hwCctl99mGQLsqzn9QZsh4BP7MAxmCFDYh2EwQ8Au9EXjEhkwBHgjEbUY6TEEeMThYTBDwC5cidoXpMcQ4JG5qN0hC4YAbzyK2gMyYAjwx42onSMLhgBfdFweBjME2NcQtSBCNgwBfjgTtRkyYAjwx0DUviIbhgBPtOysAWEI8EXN9c1MDAF21Z3/lsUQ8N4e/nkZAj7Yt3+wDAE2LdweBjME2PYqavcoHUPAP/ZnGMwQsN3eDIMZAmx7cXwY7MfnVI+5Pgz245uqvzqi0Ub5GALsabs+DGYI2Gp/hsEmIaAFyuqb68NghgC7Jq4PgxkCfrB3L9pJA1EUhk/SgKyVKhULhXKz2ELvpQjCfv8XU5f10lInF+bgGbO/Zwgh85/JRNcGbksxgCFgW3WGwQwBqupBLLEZAn6p5m+LIWBLtb7JwxDwQpWGwQwBmpZw24gJDAFaBnCbiAkMAVpWcJuLCQwBWhYBDIPDWayEJ4kCGAYzBGyp1jCYIUBPG24LMYIhQMccbisxgiFAxwRuAzGCIeCZag2DGQL0XMHtixjBEKCjDrcbMYIhQEUDGd6JFQwBT6p6Y2UI+Kmij1a2v2oSqkCGwQwBWmZhDIMZArTchTEMDuzfKiAXcDsWMwJ6Xg1HMMNghgAdH5DhROxgCPCvDbepGBLEK0yBuQ9lGMwQoOMSbtdiCEOAfx24fRRDGAJ+quAwmCFARxrKMJgh4LdqDoMZAjQcwC0WUxgCvqvwvypDwHcVfq5mCPBtFtbKmiHAtzu49cWUwG5YAQhoGBzgI4t9mcPgQzGFIcCzh5CGwQwBT6o6DGYI8O8ebo9iTFYIGAr9t8NghoAnVR0GMwT49xlu52IMQ4BfKdxaYgxDgFcjZDgVYxgCvLqFW1wTYxgCvBrCrSnmMAT49Cm8RyqGAJFKL6oYAnzqhjUMDvSaNawZ3v2UIcCjWhzWMJghwLMHZDgTcxgCPGrBrSf2MAR4dA63z2IQQ4A/Y7itxSCGAH/WcBuLQQwBFR4GMwT41QttGMwQ4NUZMjyIQQwBFR4GMwR8U+lhMEOAT324dcWkOkOAH+/WcHsrJjEE7Oyk3Z89pkCYK2qGgJ0kN8tVjB/C/CkxBJSXDDt15HYrJjEElNWapfhTcHvCGQJ2cNK/QEG998ZeDmcIKG207KGE3ieDlwBDQGGNyxQlTfv2LgGGgGJq8xQ7mM4TsYUhoJDWFXa0uBdTGAIKaHTgQdfU3ypDQH7HU3gxtbQ1gCEgr+QIvkQf7cyGGQJyOryCR3dmDo5nCMjnuA6velZODWUIyGUewbPo0siCkCEgW20CBV0bVwBDQKakAxUbE1cAQ0CWZAMlawuLAYaADLUO1AwMXAEBnmyzV7U1dmF/pyBDgNs1VE2kJIaA/VhiV9bfGW0wBDgMI2h7L6UwBOzDYR0eGH9rlCHgr0ZN7MHFmRTHELAPG+zFTEpgCNB3jj1pS2EMAfpOU+zJYiQlMAQo62JvBlICQ4Cue/hk+JuiDAGvGqUoI0Ip05H8O/UwX2tUdolieuvxfHhwmiSnB8P5eJ3iBcOflGMIeMVDjAIuJq2aPJO0jxZ4xm5vexPeOff6rpFbOj6UVx1MYvxmd7HFELDtNkJO8VHDsZIcRAHcAhgCtnWQU+eDOB2+sX8LYAjY8hAhl+aBZGpdWD9DhCFgywS5dEeSQ2OFXDZSCENABv0GMKlJLskMeUTvpAiGAD2fkEN8Lrn1IwB2T5JjCHihiWxxSwo4jgDA6sMWQ4Dj3GdPx//3LT8GMgQ8N9bYzTswvEWYIaDwP0C3JgUlj8jUq0kRDAE6bpGpOZLCGgtkupH8GAK0jJWybRuZllIAQ4CSFbJ0tLYYrSQ/hgAlJzEyxB+0JkzxmRTBEKChBWitiq6tbg1jCCjyNmDaKL/LxOhCkCHgD28UX+c8QoY7KYIh4Ct796GcNhCEAXhPSKII03uHAKZXg/nf/8VSJpMe6VT2dLbve4DMhEmk1X+7txy6CFBkfL0sKQQTBHAYIcCConO6CDCiMEwQkLwM62t6oGcUZIKAn/Ks09wN6Lli2gQBP0xY8/q2C38rCsEEAQw28PdKsWT1HBAxQcAPe947fSp6fnCZIOCHM/ydKJaqnqcBJghQ9Tac6/nFbYKAHxa8AzxN+LtQCCYIYNDl3QBa1POXNkHADxZ8CZv3lxYkzwQBievNNwgQ9x+Ank8AEwQQjYZPZf4l0EU9T4M+ehDQbq6uAsH4i8AFhWCCgCQ4merewk8f8jPwwwYB9dPDQygn3n6jNYVjgoDoevfBRfn17k96tgR9uCBgNKwUEMkrxdLR9MrIjxQE2LXxVSAqz6YYppaeoyEfJghwMtWOhViarO0meQrLBAEhKr6Wh9gqFMNG27vC3nsQUJKv+BiPa2xP21ftew4Cpo1ZAcnJ8MVA8CgkEwQEVnyTs8A3Gmx6G5jLAlVydp86LhJn9SiiutB3hdi7CwLqh1YXP2mx3uGh6w0R7y0IyOWfF+AjihTJFkEsm1Ljar7dLkTFtwazLEVy0/aCCJkgAMvOOF/XYNu1D3s7uVlQoMYyFQRMKD1ZyHBv1TrpadfPulBkkaPQeksEKlJ6niCrMNZum+zx8NqFSjebQmqvEahM6Rm1EMKlos9zgKHi49j22YLOb4DjzEVI2Salr91crQVS0Q89c6rvG2D3KhDB+m5Tiuzty81CakSDQrgLaPsGKHYQ1fKTTekoBlV8/ESfpE0EAGgZA45mAjGUm6Tccf66hA4GNklptyDDzZFyzqGLmB5HUiiXfypDG+ccSeitIeWJlNutEZ87adN/vZOK738uTQrUWEKKqJNqfQuJKO+Im7N92VvQUCfg7769abs2LpdFUqwDcSqeHh50JTY+78D6Az9pdthSWyJBmzbx6M03elR8frtDaw79g90cCEjrkFpVgUSt65S40VCnis9Pd9Bo02+m+Y0X+YiZn1NB0rwh+WAY1+RUmDXyCMfNVqrzZjGXKzbnL0+/9J7r+Algt5A8MSfiH9fkdxncS/TFKxTycqTQ6AYO4sA8rsnPax3q9F3JQzK02xmZK4BJn29ck5/bqe4c+sUByqxtUmd6BZsqy7gmP3Ee12z6g3OGIlaR1LH3YDRhGNfkVqg0RvQvRQv/p9OTMwynBVaHKOOa6Vd8/3ZADJpGAM/gZW1DNu+nWPE9TnXyN4AC3RKp0we3bi/+uCY/a1/NODEb+Rg6S9hlLLBbt2ONa/IT13GzTXKOHridSJ3cAgq05Mc11StXhqNkFv+nP2oaXhZKVKXGNdVbbuY9CmsuwOnhkDpVqGEVGcY141d8RYrkBEbXNqlTt6DI2dGjef9HxfeScbT8f3MdkUJ7KHOSHNfkJ9arZpviGYPJbUoK3aGO15MY1+RXfhrmKAETsOi0SaHRElEIC1E8AsY1+S1f50dKyt1C8h42qVQJ3eTyMm/scg5963B4viCck8+4Jjs32y9SompdJO3JJpXqAiEsZluHfpcZF/AWWLfJ1mb4/cpIlHsntTaQ5o6L9E/1F32bc78R61mzTTxGD3zzZjrpoz4ArKeSz6+w0rI5/5vFcz5HnA4ukpIdkWIDSGrVyVdvoNlwzjfd18OR2NWvSITbJ9WOAlLKGQpUXEMrbra/IzXsiUB8jx4p9wwp+5zksKsuxHlSs0lK6rP0312GpN7UTfbDZAIdFGaNKSnXKCMGazalFMwhQZxI2tAFE/mKr0TpsPte9CGyHqVin3hjSsZFarpfm/fTNO0vEIE7K1E6jiL5ztQhUuF2Pu00uKzSyZ8R0nKco7RMEGygyQFJYPO+LjLPXUizWg2b0lNGoLNNYbXAwL95Xy92U+7fgLiecpSmIwJdSvQHPTpmf2ne15LdXJ2tgBPpfOr3rB+YNmEVBfh5rZM+l5L+k7399Chb+NulM5v3SAMtBNlz5cvxm/c1qPhkOL3afFIZvGb313P29WlcvWempAnHQwCxo0h6FtiI67jWJiMBWwTZUEQr8ChXhrpVfG9YFQGsI0U08pC45eauxYvz/dgwrsJ8QaK8h+4V31u0Zrygrg5o0rxv/I9jwV/XoegKCVV8q6ap+JjUwbmxfqxP874R8dRmSDFk4lZ8ekQl71kV/qwpxXFBVN7X5n2D3Qr+9mlcOWPdXrb6HOy9bwOZ9VcqPwTF2lR8KmV5V5XNEcpCg8OxD+YMfweKpRGmeX9+JEO1Mvw1KJYdpLim4ktLF/52FEtJalzTVHzpWcJfiWJxBPzNGtocjH9MC/jrUSw2/Aky0lWGvwzF0oO/JRnpKgQnwZxZcIGMdK3h78T7GXgjI11n+Bvzthw/yEhXC/4GvFNHz2Ska8b7jN7A34qMdJ3gT4woBqer0zosI0pYf6cYaggwJyNddQRocb5g0CAjXW0E8GzGnBGm4yt1ZQRoUmRFBFiQkbYBAgwYm4I3ZKTtgACiThGVXJ02Ihk+j2metO4JQUwXSPocD0FqXDtoPDPspYEsglwpkpZeS1GN//iEQHmmqaAXMtJ3RKDukULLlRGoRoYGrghUmHKsoe+aXlAt9BEs60T5AjBHgW9CDxJWDPs0zXUfmjhDwin8TmXTDvZGnCBj5ZCsTwIS7mToYepBRnZKUuwBZHhmBlgbK0gpHElC6QwpFTJ0UbIgpZunQM0L5OzI0MYAkq418pXZS/9JZHxu7+52EwSCKADDWoEqalELWq1o4w9abSwU9bz/i/WmSdNEG0Egu+v5XmH3YmZ2ZlYeLq5mu8ZFPR8/WAVUzAlXM4/94MIHCQK/OBGilJ5ABpZ/mBh/zB43TWQguAxEMhGyMdNxuH+tvbS3/Y/paieQTWiQXGZLVGjJrRDSmaMgLAKqqZ7gZkwBVeYKVMSsGSShPfJiBKiHEyphsxdYUk6MCiz44ZO0uiZKZ/ERSGIezmIGeDeekBu7AHRQ91GqlJ3gkgs+UaIGfwOQntNAaRKevwKcNUqS8glICZMUpbDZBqyIwEYJjoz/lPGwQeFaLACrxDORAQdB9dONUaAlF0IqxxmgMD7TPwXVvwQK0WT5X1FuigLsuA5WXfMhbiRGjP5V5oxxC/PILSCq2/omchJjHr8O3HxXQLQ4/qULdyOQkfXWNkgfk32CDDpTZv7acaMYV1lE7PvUlDsaWPiXSCKO/WgteA5PCxPnNG2vyyf/uxDUDuHK361jqzmMO431oOU9vjPok8E3UelcKackDq0AAAAASUVORK5CYII="
        />
      </IconButton> */}
      {/* Right Selection */}
      {/* <IconButton
        variant="outlined"
        component="span"
        onClick={() =>
          setDeepICRCTX({
            ...deepICRCTX,
            // croppingToolId: 2,
            selectedButton: !deepICRCTX.selectedButton
          })
        }
        className={deepICRCTX.selectedButton === true ? styles.active : styles.iconBtn}
      >
        <img
          title={t("stringToolPolygon") + " [ Ctrl + P ]"}
          width={18}
          height={18}
          alt=""
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAMAAADDpiTIAAAArlBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABeyFOlAAAAOXRSTlMA/fk4BwP2txZZ1/EumRrblnpCKE5Irgq77B5zoVQRh4MOkXdk4eiejNGlPDPAaSNtyOXMfsVfqbImT11VAAAb7ElEQVR42uzc61biMBQF4JNeQRBG7mClgoNasALDzf3+Lza/Zy1XG7ChKbO/B8ivNuuck53IRWpufR+l26T92nCCP0k6eIuPH0Oh/8CsHx8a+I5ahHGfX8Et8/rznUImZ/Ty4QvdotX9GFpe35tCN6b7vsAZtp8zodvhfimcKXhbC92GfopLqGVXqPo6CS6lTiwGqm4ywE+o+6lQdXn7AD/0Wheqqk4bBRixGqwmL1YoRLARqp71FoU5cUJcOfUGCnTHjrBa/DmKFbAWrBLvhMI9C1XFNIUBv3hKWBGtBEYsPaEKmCxgSMhmoAJqbRiTcg+w3iyBQSchuw0PMOpdyGZ+CMMehSwWwzTFiZDFegrGBZwKW2syxhUkbAUs5e1wFXMhK81xJT0hC7kKVzJuCVnHT3A1SyHrvOCKVkKWmQS4ooRHw7YJcR51iOLNkztpffQ+n99SB+dhTtQyK5wjGByn8o/ZUzTGGRo1IZuMoE0t+558w1/9cjgMqKgVtIXNjEIiUtAU8M6YTUbQtOtIpqb2Snsha7jQ0zhKrv4CWsbMh9ljAC3trmioHZgMqJiaAx2jqWjxIuhYcBZgi0fomPv6Cypo6AvZ4Q4aNoUnSyIhK7gG0pwb5GuwDLTDPfKFvoFFn4Qs4I+R624mZ/JS5BoIWcBFrvHayA0jh69J2uABuepyAZfZsGpIkWdnarwUC5Vu6CBPRy7SzV15K1S6HvKExtoLh41g+WLkUE25UCvI31uobF8Gr3THPBO2X9tgqd7kJMB6Q4VswVAut0C2RKgQtv6kc2RrCJWsjhxHo1lDhoPLtkc2NTV6zuAKlWuObAf5kQjZ+F5I2ZbIFpndYLYPvS6jYWUKzY7rfyOfkywfemt+Bn/Zu9el1GEoCsA7pS2VVkAuIncQKHc8oCLr/V/s3JjhKFhCkl0Kh++34+i4ZLJ2k+Y8lryH+EqQ5d5icBY53l07M5zGfW30bjGIU8i7TPcQIToGt6uGJPAHoEZaHIHfbjFIrByiZUmPhS2dGJRrdPMvxytOS/3eaLh5bOTbb/V1qsV1JmBGWjyY4S6H9VsM/sg2n5cW9lSXjYepTSd75d22F8Ak/1cM/uc9JM7sx2SACO7TQ8oxuyNwQVrKMEz8v+8ZTd37kOA3yo7BQVCHYRCkI0P/p2wvA2nhaGZsFDw0MAqWdztMcpDdTAucZrx2zJwKmJOWIf663T6nrvJWhYLBwiYJJd7TOysYdkfRrm6I6KxXUBTKrJhfwPnANgXTAorWC+f5ReF69pkUxtCwatJRLqJ9JOoGEmHLbUCoXkcMihtoeirqPg70bVKXgWEZ6bnGNgY/LjgG3bwFbVa7orlMK2sEGBFYSoDj4o9riMEsByNyKb0XBA0TVALRkVzSXEEMFhYMsepaszqrSIpaPiKwlIDStdxV0f2AQZsWfSvLN3sZwbhAc6zhXkhNDHIwajClb/kAz6aQmgXThK052Hyli9B3YZjVVD8dijnDlnCmEjC+ilfTjWCeWEScDWIpAoFABLYSEK1HF2AEFh06rOLjmFWWTlYZYysRJUBye0NtMT17U2iDyb2j/FG9tDXeO5CgEoAXiaOSv4fJ0xbJupi/P3BPBxVw3CQZv4Z2CZD/scP581li0AGjNh3irHDcg/qh40sqARt8Fj4dicFF/f2BuvKiQzTpBFMXHHLsJSCHra8x6McTgwcw6yvv3BQ9knbnIgJjCbA0S4At8L3VrxhkiVVBgJkoK/zjbDVsvY8x/hJQ1O2zwXlfa+aFYFfNql8b++6RhMojpIgzlICa7tLFI0bOE2IwdxRe6LebKB9VfIUUUayV68Oln6gS0EG0kL66qAXAXx2d0rYpUqTsUJx4g/guBvwlYKn7euM5MZoKROBdBnRDSBLDLH2r1XYhSeyStItBQkvATp74tAaISdjSOsDhfnfq4OWhCmkT2pKPgX4JqB8tAZrnpF52c4NkjE6lJ4LOGCcYPBcc+izVzmBL4QPgQAwusgSU1MdHTcRHpCLmwZKqk86ilKrZTnZW6r8NVzhNg7aOx0C+BDTPXgIevs4NpGPg5BCjsUN70lAioKLq0Y50DALNLYi+bgmoSh60U4jBAqdx0/mHfjnwvKDcf7t/svRHwkUL8VnTjnQMjpaAj7OXgHHUFDEVEYNKiBNUh6UKfdK9m/g4ge/Rnjxi80QqsrolYMhbAnar0MgYdDVHAFa+4NABdrkhIG1Ee7wqYuK+kJLEl4AiZKzSo68x8HxIEpOakYNErkd7ygLx6JGaxJeAJuQN/o3BMySlA4o0fdeZB9YRi7RDahJfAt4QISIGNUvyqwt0VCmEFL8VsYhlNWiRosSXgA+o8U0+jKuNIeWN9tmvYGfNiEnzY2ydtwRkwGloExl8HBse+nbZENwWxMgpNt8+MtaZSoBtgY+ok7SOABTvbZ1a4DUkfvY2BnGXgAB8RIlOsBbK+6v6YPXoUFzsoNl5zFgxloA78Kmb31tqeXRIHozSNsXMDu5+xUDEUgI6YDNUurhZ6SoA5x5s5hWSwxGDCXsJeASXd5vjYNZr3DuTll1KMu0SkAOTgUcnq4WA6mBkbYHDvEWJltEsARUBJgVSUNJ4JlfwYd4k4W/51S4BMzDZkJJ3jQN/wQqmtSnhtEvAGjxEkenWTqzoW9kxjBILSjrtEtDGJ+cfnWxwTES0uk8waFWgxPtTGHNCvQRswMLNkqKigMadcHbPhSmPCV/+7c8NVErAACxGpKyhd+r/JQ0j3D5dmm0MElECAsbrOl4pWnMFfe8Xe/HXNgbnLQEDUmf7umflunkBPeGaLtzfGFjnKgE/2bsTpTSCKArDZ4ZBlEHBQcMmIgguQCQalbrv/2KpSBbLYHfP0kx3ON8jWI3Af5m+E+Qw16cgncq95BDeuR3/0hyDjvndXqVHIONvNufQqg56klWtjf1RExviCDmMwyJWQ0dHXyWDYL7EPpmJDWvk0i3oadf2pCfpHEz2bM3jWP5wKKAeF3b7W/T68j8NfrZzaztOEev7n4scMzRaMzFVw76p1GaBFG+IXB4KvvHiZDj6esD9jp8YV17vajMpVAW5nFm4Pb3amN7WA1ELsbeKPQZ9u29MTWS0Eg1fNnP85uoxiJBLX9fprD2IWQFpj4H9Xdkntg4AmqJ2BPp7DKaZj0EfuSxFrWmtMJyCth0Dxz4E3lsrDMegIo7B0O76/hdkdcoQkPsYOBCCusjqiCGgkGNQt5uCW7ZWAmLBEFCIV7vDoJq1q09PGAJ2MkLoVZFDR5dtB2AIKNdYNBY2vwTIGRgCSvYkanfI4UI02mAIKFnXWqoBqj19aGQIKNnE4os0Ef3pYggo2YNoPNv7EihrgCGgZInBhX4ZrUKDzMQQULLDwNqTAXPRaQAMAWV7FI1whUyWgWjEVYAhoGyntn4a3jX65SZDQNkalmbC52a3djMElG4mOs1LpHb4JForAAwBpZuIVreKlKJHs2viGALKd27jGeELw70NDAHli2LRmyKVgRhYAWAIcMBa9MIEKZwFYvgOwBDggEQMhFMYGwRi+k+FIcAFj2JiUoWR6FZM9DoAGAKcMBQjtTEMHL6k2BrFEOAE072x9SW0kpmIGG8LYAhww1TMBOsVlBq1VPePMgQ4Irox3xuqeOX2zXeHhm0AYAhwxbUYi0cNbFWZhGKshfwWonYAMjWOJYXZJKl+XBzcekq/PJohwB0Pkk5vPvo2rPSjqF8ZfhutY0nnFD8xBDjkRbIIJJOnTQNgCHBIOxQ1h66eYgiw4UqUHLp9kiHAiqguO3JziJ8YAhyzCGQ3zvCGIcA1x7ITF3jDEOCczr3sQH2MNwwB7jl5Eut6K7xhCHDR8kAsCxJsMAQ46SwQuwbYYAhw1LVY1cIGQ4CzbsWiW/zCEOCsqCbWXFSxwRDgsGgulsyr2GAIcNudbLj++mcIsGUQSPGuYAFDgB1HoRQsfMVfDAHOS2IpVJzAiq6oXYOyadSlQI8rvMcQ4IHoLpCCBKMI7zAEeGLRlELMEnzAEOCHTiuQ3IKLS3zAEOCNZCY5fa9AwX4IOATlMR7FksPNtIotGAI8cnkVS0bx1SW2YgjwSsYjcHM9xnYMAb4ZP/ckpeZDhM8xBPimL2n0WhWoMAR4ZynGDr4MI6gxBHhnKEbCl+dFBB2GAP9ci078eDs478AQQ4BnjkVtfYJUGAI80y34194MAZ5pFvzAP0OAX7TPYC2RCkOAZ1aiMUYqDAGeSUSth3QYAjwzFbXvKE2FIWAHRhYu/WEI8Mha1EZIiSHAL9+L3/3AEOCTnqglSIchwC9jG+ufGAL8sRS1sIq0GAJ8MhS1JtJjCPDIQNS6SI0hwCctl99mGQLsqzn9QZsh4BP7MAxmCFDYh2EwQ8Au9EXjEhkwBHgjEbUY6TEEeMThYTBDwC5cidoXpMcQ4JG5qN0hC4YAbzyK2gMyYAjwx42onSMLhgBfdFweBjME2NcQtSBCNgwBfjgTtRkyYAjwx0DUviIbhgBPtOysAWEI8EXN9c1MDAF21Z3/lsUQ8N4e/nkZAj7Yt3+wDAE2LdweBjME2PYqavcoHUPAP/ZnGMwQsN3eDIMZAmx7cXwY7MfnVI+5Pgz245uqvzqi0Ub5GALsabs+DGYI2Gp/hsEmIaAFyuqb68NghgC7Jq4PgxkCfrB3L9pJA1EUhk/SgKyVKhULhXKz2ELvpQjCfv8XU5f10lInF+bgGbO/Zwgh85/JRNcGbksxgCFgW3WGwQwBqupBLLEZAn6p5m+LIWBLtb7JwxDwQpWGwQwBmpZw24gJDAFaBnCbiAkMAVpWcJuLCQwBWhYBDIPDWayEJ4kCGAYzBGyp1jCYIUBPG24LMYIhQMccbisxgiFAxwRuAzGCIeCZag2DGQL0XMHtixjBEKCjDrcbMYIhQEUDGd6JFQwBT6p6Y2UI+Kmij1a2v2oSqkCGwQwBWmZhDIMZArTchTEMDuzfKiAXcDsWMwJ6Xg1HMMNghgAdH5DhROxgCPCvDbepGBLEK0yBuQ9lGMwQoOMSbtdiCEOAfx24fRRDGAJ+quAwmCFARxrKMJgh4LdqDoMZAjQcwC0WUxgCvqvwvypDwHcVfq5mCPBtFtbKmiHAtzu49cWUwG5YAQhoGBzgI4t9mcPgQzGFIcCzh5CGwQwBT6o6DGYI8O8ebo9iTFYIGAr9t8NghoAnVR0GMwT49xlu52IMQ4BfKdxaYgxDgFcjZDgVYxgCvLqFW1wTYxgCvBrCrSnmMAT49Cm8RyqGAJFKL6oYAnzqhjUMDvSaNawZ3v2UIcCjWhzWMJghwLMHZDgTcxgCPGrBrSf2MAR4dA63z2IQQ4A/Y7itxSCGAH/WcBuLQQwBFR4GMwT41QttGMwQ4NUZMjyIQQwBFR4GMwR8U+lhMEOAT324dcWkOkOAH+/WcHsrJjEE7Oyk3Z89pkCYK2qGgJ0kN8tVjB/C/CkxBJSXDDt15HYrJjEElNWapfhTcHvCGQJ2cNK/QEG998ZeDmcIKG207KGE3ieDlwBDQGGNyxQlTfv2LgGGgGJq8xQ7mM4TsYUhoJDWFXa0uBdTGAIKaHTgQdfU3ypDQH7HU3gxtbQ1gCEgr+QIvkQf7cyGGQJyOryCR3dmDo5nCMjnuA6velZODWUIyGUewbPo0siCkCEgW20CBV0bVwBDQKakAxUbE1cAQ0CWZAMlawuLAYaADLUO1AwMXAEBnmyzV7U1dmF/pyBDgNs1VE2kJIaA/VhiV9bfGW0wBDgMI2h7L6UwBOzDYR0eGH9rlCHgr0ZN7MHFmRTHELAPG+zFTEpgCNB3jj1pS2EMAfpOU+zJYiQlMAQo62JvBlICQ4Cue/hk+JuiDAGvGqUoI0Ip05H8O/UwX2tUdolieuvxfHhwmiSnB8P5eJ3iBcOflGMIeMVDjAIuJq2aPJO0jxZ4xm5vexPeOff6rpFbOj6UVx1MYvxmd7HFELDtNkJO8VHDsZIcRAHcAhgCtnWQU+eDOB2+sX8LYAjY8hAhl+aBZGpdWD9DhCFgywS5dEeSQ2OFXDZSCENABv0GMKlJLskMeUTvpAiGAD2fkEN8Lrn1IwB2T5JjCHihiWxxSwo4jgDA6sMWQ4Dj3GdPx//3LT8GMgQ8N9bYzTswvEWYIaDwP0C3JgUlj8jUq0kRDAE6bpGpOZLCGgtkupH8GAK0jJWybRuZllIAQ4CSFbJ0tLYYrSQ/hgAlJzEyxB+0JkzxmRTBEKChBWitiq6tbg1jCCjyNmDaKL/LxOhCkCHgD28UX+c8QoY7KYIh4Ct796GcNhCEAXhPSKII03uHAKZXg/nf/8VSJpMe6VT2dLbve4DMhEmk1X+7txy6CFBkfL0sKQQTBHAYIcCConO6CDCiMEwQkLwM62t6oGcUZIKAn/Ks09wN6Lli2gQBP0xY8/q2C38rCsEEAQw28PdKsWT1HBAxQcAPe947fSp6fnCZIOCHM/ydKJaqnqcBJghQ9Tac6/nFbYKAHxa8AzxN+LtQCCYIYNDl3QBa1POXNkHADxZ8CZv3lxYkzwQBievNNwgQ9x+Ank8AEwQQjYZPZf4l0EU9T4M+ehDQbq6uAsH4i8AFhWCCgCQ4merewk8f8jPwwwYB9dPDQygn3n6jNYVjgoDoevfBRfn17k96tgR9uCBgNKwUEMkrxdLR9MrIjxQE2LXxVSAqz6YYppaeoyEfJghwMtWOhViarO0meQrLBAEhKr6Wh9gqFMNG27vC3nsQUJKv+BiPa2xP21ftew4Cpo1ZAcnJ8MVA8CgkEwQEVnyTs8A3Gmx6G5jLAlVydp86LhJn9SiiutB3hdi7CwLqh1YXP2mx3uGh6w0R7y0IyOWfF+AjihTJFkEsm1Ljar7dLkTFtwazLEVy0/aCCJkgAMvOOF/XYNu1D3s7uVlQoMYyFQRMKD1ZyHBv1TrpadfPulBkkaPQeksEKlJ6niCrMNZum+zx8NqFSjebQmqvEahM6Rm1EMKlos9zgKHi49j22YLOb4DjzEVI2Salr91crQVS0Q89c6rvG2D3KhDB+m5Tiuzty81CakSDQrgLaPsGKHYQ1fKTTekoBlV8/ESfpE0EAGgZA45mAjGUm6Tccf66hA4GNklptyDDzZFyzqGLmB5HUiiXfypDG+ccSeitIeWJlNutEZ87adN/vZOK738uTQrUWEKKqJNqfQuJKO+Im7N92VvQUCfg7769abs2LpdFUqwDcSqeHh50JTY+78D6Az9pdthSWyJBmzbx6M03elR8frtDaw79g90cCEjrkFpVgUSt65S40VCnis9Pd9Bo02+m+Y0X+YiZn1NB0rwh+WAY1+RUmDXyCMfNVqrzZjGXKzbnL0+/9J7r+Algt5A8MSfiH9fkdxncS/TFKxTycqTQ6AYO4sA8rsnPax3q9F3JQzK02xmZK4BJn29ck5/bqe4c+sUByqxtUmd6BZsqy7gmP3Ee12z6g3OGIlaR1LH3YDRhGNfkVqg0RvQvRQv/p9OTMwynBVaHKOOa6Vd8/3ZADJpGAM/gZW1DNu+nWPE9TnXyN4AC3RKp0we3bi/+uCY/a1/NODEb+Rg6S9hlLLBbt2ONa/IT13GzTXKOHridSJ3cAgq05Mc11StXhqNkFv+nP2oaXhZKVKXGNdVbbuY9CmsuwOnhkDpVqGEVGcY141d8RYrkBEbXNqlTt6DI2dGjef9HxfeScbT8f3MdkUJ7KHOSHNfkJ9arZpviGYPJbUoK3aGO15MY1+RXfhrmKAETsOi0SaHRElEIC1E8AsY1+S1f50dKyt1C8h42qVQJ3eTyMm/scg5963B4viCck8+4Jjs32y9SompdJO3JJpXqAiEsZluHfpcZF/AWWLfJ1mb4/cpIlHsntTaQ5o6L9E/1F32bc78R61mzTTxGD3zzZjrpoz4ArKeSz6+w0rI5/5vFcz5HnA4ukpIdkWIDSGrVyVdvoNlwzjfd18OR2NWvSITbJ9WOAlLKGQpUXEMrbra/IzXsiUB8jx4p9wwp+5zksKsuxHlSs0lK6rP0312GpN7UTfbDZAIdFGaNKSnXKCMGazalFMwhQZxI2tAFE/mKr0TpsPte9CGyHqVin3hjSsZFarpfm/fTNO0vEIE7K1E6jiL5ztQhUuF2Pu00uKzSyZ8R0nKco7RMEGygyQFJYPO+LjLPXUizWg2b0lNGoLNNYbXAwL95Xy92U+7fgLiecpSmIwJdSvQHPTpmf2ne15LdXJ2tgBPpfOr3rB+YNmEVBfh5rZM+l5L+k7399Chb+NulM5v3SAMtBNlz5cvxm/c1qPhkOL3afFIZvGb313P29WlcvWempAnHQwCxo0h6FtiI67jWJiMBWwTZUEQr8ChXhrpVfG9YFQGsI0U08pC45eauxYvz/dgwrsJ8QaK8h+4V31u0Zrygrg5o0rxv/I9jwV/XoegKCVV8q6ap+JjUwbmxfqxP874R8dRmSDFk4lZ8ekQl71kV/qwpxXFBVN7X5n2D3Qr+9mlcOWPdXrb6HOy9bwOZ9VcqPwTF2lR8KmV5V5XNEcpCg8OxD+YMfweKpRGmeX9+JEO1Mvw1KJYdpLim4ktLF/52FEtJalzTVHzpWcJfiWJxBPzNGtocjH9MC/jrUSw2/Aky0lWGvwzF0oO/JRnpKgQnwZxZcIGMdK3h78T7GXgjI11n+Bvzthw/yEhXC/4GvFNHz2Ska8b7jN7A34qMdJ3gT4woBqer0zosI0pYf6cYaggwJyNddQRocb5g0CAjXW0E8GzGnBGm4yt1ZQRoUmRFBFiQkbYBAgwYm4I3ZKTtgACiThGVXJ02Ihk+j2metO4JQUwXSPocD0FqXDtoPDPspYEsglwpkpZeS1GN//iEQHmmqaAXMtJ3RKDukULLlRGoRoYGrghUmHKsoe+aXlAt9BEs60T5AjBHgW9CDxJWDPs0zXUfmjhDwin8TmXTDvZGnCBj5ZCsTwIS7mToYepBRnZKUuwBZHhmBlgbK0gpHElC6QwpFTJ0UbIgpZunQM0L5OzI0MYAkq418pXZS/9JZHxu7+52EwSCKADDWoEqalELWq1o4w9abSwU9bz/i/WmSdNEG0Egu+v5XmH3YmZ2ZlYeLq5mu8ZFPR8/WAVUzAlXM4/94MIHCQK/OBGilJ5ABpZ/mBh/zB43TWQguAxEMhGyMdNxuH+tvbS3/Y/paieQTWiQXGZLVGjJrRDSmaMgLAKqqZ7gZkwBVeYKVMSsGSShPfJiBKiHEyphsxdYUk6MCiz44ZO0uiZKZ/ERSGIezmIGeDeekBu7AHRQ91GqlJ3gkgs+UaIGfwOQntNAaRKevwKcNUqS8glICZMUpbDZBqyIwEYJjoz/lPGwQeFaLACrxDORAQdB9dONUaAlF0IqxxmgMD7TPwXVvwQK0WT5X1FuigLsuA5WXfMhbiRGjP5V5oxxC/PILSCq2/omchJjHr8O3HxXQLQ4/qULdyOQkfXWNkgfk32CDDpTZv7acaMYV1lE7PvUlDsaWPiXSCKO/WgteA5PCxPnNG2vyyf/uxDUDuHK361jqzmMO431oOU9vjPok8E3UelcKackDq0AAAAASUVORK5CYII="
        />
      </IconButton> */}
      {/* Rect */}
      <IconButton
        variant="outlined"
        component="span"
        onClick={() =>
          setDeepICRCTX({
            ...deepICRCTX,
            croppingToolId: 3,
            currentShape: [],
            selectedButton: false
          })
        }
        className={deepICRCTX.croppingToolId === 3 ? styles.active : styles.iconBtn}
      >
        <img
          title={t("stringToolRectangle") + " [ Ctrl + R ]"}
          width={18}
          height={18}
          alt=""
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIABAMAAAAGVsnJAAAAJ1BMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADdEvm1AAAADHRSTlMA25Ilbkm3gODBlz7Ff0UkAAADAUlEQVR42u3aIY7CQACG0ZJsgsCAR6HXYRCIFVwBwwFQCA6A4xpYPFdgSSAkHGp120m6A0kz077PttP0f3qKQpIkSZIkSZIkSZIkSR1vFts+5TXD6DnFK7ZxygCD6DkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADoJ8Cq3iFfgEdgTgNA4KPLfAFugVcAAPgQ4DhPuEULADkFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAG8DXCcJN20BwAUJAAC6DLCtd8oX4BmY0wDQnJuiAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyBFgXW1XfuFcfX5JGWBU/dtNec29Nrf+je/ykZ8i677Ka37/cQQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABA3wHW1XblI+fq80vKe0fVv92U19xrc4tXbOOUAQbRcwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANBPgG29U74Az8CcBoDAR5f5AtwCrwAAAOAzgOsk4aYtAOQUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALwNcJwn3KIFABckAHQaYFXvkC/AIzCnAaA5N0UBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACQI8Astn3KAMPoOYUkSZIkSZIkSZIkSZI63h/a7iSHXwGjDAAAAABJRU5ErkJggg=="
        />
      </IconButton>
      {/* Circle */}
      {/* <IconButton
        variant="outlined"
        component="span"
        onClick={() =>
          setDeepICRCTX({
            ...deepICRCTX,
            croppingToolId: 4,
            currentShape: [],
          })
        }
        className={deepICRCTX.croppingToolId === 4 ? styles.active : styles.iconBtn}
      >
        <img
          title={t("stringToolCircle") + " [ Ctrl + E ]"}
          width={18}
          height={18}
          alt=""
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAMAAADDpiTIAAAApVBMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABU/knhAAAANnRSTlMALTLvVVoPu/sdAwvEIgf01ffiQxHr5tmZ0Kqj3co3JoOAZky0khcUAYdjPV6unnx3b2lQwIz6BzwAAAAUf0lEQVR42uzSAQ0AIBAAIb+U/aOZws15kIH1n9nXzOJ9AsQJECdAnABxAsQJECdAnABxAsQJECdAnABxAsQJECdAnABxAsQJECdAnABxAsQJECdAnABxAsQJECdAnABxAhz27GwnYSAKwPDYIRQKlC0o0NakLEagEBbzv/+jmV6IemFZa2fK+V5h/uScnHlw2QG0W5naEoD1sgPQKpOWAKwnATw4CeCxVZf5BbCsKmGyVjKPauQXAITBzvGUMI+/il1NKtcAUtqNV74S5vCc3VgD5B7AUduN+xKBEer7tQbII4Bser2vK1Ekz4kjgGICSIXzvqwEBWlUNgOg2ACAwabSUOKf+dOgDZgQANCdJdLA38x5/fMCkAaM5vUDDZgWAKA3sg/krr4NATMDAHqLlhK58SsuYHIAUGtOZBTk42mowfgAAD2UT6O786YuYEcAQJTImfCe3rY9sCkAeF7IlfBenKALtgUA3cBR4narGWBjAEBzqsSNo78J9gYAo0ROA9fzkw7YHQCEO9kHr+Pve4D1AUBvIglczqu8kCpBAGkCMggu8358/lIEAB3ZBS5xGPGlJAHA6KDEeZwPvpUmAIhelTitPqzxQ4kCgLH8FZ7SiLv8UqoAPtm7F6VGYSgMwKGtkJa2BAoFepGW3lW0XuZ//0fbnZ1ZR0fXTQJVcvneQEkD5+TkHIQne7XkK4Nyiguj3pcoLmx6Y78G/6mzhAFy+ynwuXhHYQQ6PxDrg14CYyTlkVjvFB6M8mKLht4aryiawipcTMXQlHBtDwheOTmasZiX/cs2idr3MoZmMFsv0ujPP6jK/vd0CeuXVYAG0JXdBH7r5KhvkW3G39kmbjw5MdTHbEQ4PlHUxdbOT/QJdNbMbgJ1FXnDT//yC6DhNcCMDgfKALVEK+enO4U6pwi1BDfEVPEMdYSzzaANrWIHt1mAOipDE4OTCDUMb9z29Ap2b4aoIbol5hnUCf6CzGlbs+hOnW2Arow7Ijx4kJae4zZ2C3fLHNJe9sQotxEk0e2kve3iJ1vIioxKCZSh9H07p93zAka7EHLomZjCn0FOd9dv/8CI/TqBnLkhnSUKBinJ2VdjYoh/TiCFFcQAky5kJGtXnZEx/uMUMroTor2SSj5+tWYGSS4B+kj0Nsggofvgqzc0yn8IIGGndUYg9iCOZns1p4YdTiHEeTHRVpFC3Hyk7ti40QziUm0/Ba8TCBt21J4b2BlCWKJpTmgTQNT07qj64MhjL4KoQMvWQncUgujO1WFyqMR1R1oS7awhajvSZXRssYWoB6KXQSa+++s0O3gTQdC9VuHguIKgLCay3N7FuERWfA9BlUblor4HMamGKdFbBjFbbc6G/BdbKy1TAe9psgLcIYQstK2Qu04hZKhFO5F4CSGZJuv+M77gJrDUoF74kENEpOHbv0YpdK78CjgwiJhrsel9xZ1BBFN8BYjt/6Hup+F/3AUQkCt9OOgu7TW5j4rclBXgv9iayM+MdxAwVPb/IvT8gytikKvAgHzAeAt+qSHb/1/OAvw8JRNjgwr8tgq/6OTEW/CrVDwZ2oHfScU/sKbjmYJbRpSzNr0A5v+eA43rA0pwi4xtl+ZE4KZYH5ENBa+lYRej39ovwYsqNXDkOgCvmaIxTjPGc/AKFTokLRLwWhneNfl4Aq9EmfsCcQpO9IkY74mCU6pIrDzwwCnsEYs8h+DkqREtZ+DUVeitJqP5C/M7ooBHcJoaG/7Jh4MKvDInFHwiO0Lt1WgBPrT1ObOiCz5pn1iv+gvw6bY8FPAZ+DD7/N/ZM/BJ2100NwMfZnD673P7HHxmpMUeDSp3llS/fLrFhZPXoSnFzpcQ/2LvTrDThoEwAI9NUoydeGMLaylNKbRAWiBz/6P19QCR1GJJY+v/TsCDwZJmkQ0jIBF7et7VbGSK5/9dLfQTod9f2sfvf5/dlI3cZGYEN2xkif3/hwY1G9mQQMME+Z+7PU9auw0Y1Wyih/yvUtRjE7W8bfS8c10NfgwrNnEiYbZsIkH9V+uatLFH8HPR9hyGHBc2UYgqCuSz9m5e5TmwiZWkcaEDm5gH3v9naj9v299pnRiFbND9v/8iW7GBRMyVwnnJBmokgBpOqpdSFoEDGygCG/+9T1y0aBGIk070MslyZQOJiKxaPuvkcKNvGzYwk7AIbNjAq8z6lWDpKxv4Qt5FSYdmWiQZLVmv8p4O2t+wAbQkKljvtie/jmwgqPufmvPYgu92NO7m/SYyvLDeZEQ+vbBeiQzgf8pn0ucF4wQbAJuiQnZGOF21r3DdLlvWW6Xky6XtgyzyLST/xbIJay1lj7KJZ9JqOcnIjwNrJR1//4N9Q7lFoUHBWu8E9m9crQbkw4K1pjgB3i2bstaCPFjLPqF0h0m/1Zqc2z+JXZu65sBaN3Lu2qKWpZbLp6z1lRxLZ6yFE0BDfrLWLCW3HlEDcujMWg/kVFpKL1N1ikHRdZqSSz/EhWS3PQprDMiXrPNK0KC+rEfApQXNat3yuZJUE8pr1jkQNOqddeqcXNmyzgRFQAVLpdcjOZJOZe1IwnBknTIlNx5Y52lPoGAp934lN1asI2JmrWvWrPNETgxlVie7b846P8mFPmtUuArQiudKRPIllt2p3mXfWCci+xasUeAuYEu+91jjTNbtKlwF4M0X1qh2ZNsba4zRB2hNNmaNX2RZWnv/CCH7xRp1SnY94AHgUzb2nQx6wgPAqzfW6JNVMR4AfmVjvyfBFzwAPHvzmoXJeqzWwwPAsk/anyAne44YBfHu4LMUf/OfhwjeoPK3DXxOMArg34LVkgHZspFQiwhe5C0Xn9YSqpHQZ7VlSnYMMQwogrffYcFqJYEL+6mfonDeY7ULgRO//aQCrqxWYBbAkVHh5baAOc6AUpx9dOVmBXrBpYhZrcioeQ8ymtLhr5WHroCTnOFUuLi/oDersAWUY1Q5XwMeMA0kydz5GrBAFlCSr66PZOmYlWq8F86pdMJKk5SatcaNILK8O7489oBCsCyR496sEnUgYUpWmlGjBvJfYRqaDasNqEkXrADSRE5rsyesAOKUDpOBaQ8rgDgbVhqn1Jw1VgB5IofV2V+stCTwoHY3pdfHpUACvTjr0c4L1AEE+spKRU5N+clKBd4N5EVWuLo18AsrnQi8eGWlN1dbgC2BFxdW6rvKAgwIvHhmpV5KzYhwCBRq6SY9s8U8gFBnN326Z7wcQqijmxnBElsAoXZOanSjBJVAqaasNCK9WGvLSqf4A3hzaGNG8QdOrLSNtYj/k7BXWXbbI1uDAGgDBEDgEACBQwAEDgEQOARA4BAAgUMABA4BEDgEQOAQAIFDAAQOARA4BEDgEACBQwAEDgEQOARA4BAAgUMABA4BEDgEQOAQAIFDAAQOARA4BEDg/rB3BycQQkEUBAVBFIxn8w9tE1jmsgf9dHUMdZ03AMQDIN5zAPaxc0UAx9RLX5/NAM597C8A1zZ1Lwjg+Iy9U8AM4N6mLgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYHtjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADws8t5uPNwAxGLZyEkHgDxAIgHQDwA4gEQD4B4AMQDIB4A8QCIB0A8AOIBEA+AeADEAyAeAPEAiAdAPADiARAPgHgAxAPgy96dZicOA0EALkyGxSQYE7YBQgjJJGTDCQx1/6PNCdL6o+0N9V3AvGe5W2qpxYXTALhwGgAXTgPgwoUcAIXTjqbP4gcTiCeT4gefNO0KJ7h1erSMIMnMael14MWIpj4kkWdG+TYPyvWZ+qBpAT/eXI+RRA40vcGPFk1rSCJrmu7hR9nWJCBLNzS1S3jSpWkHSeJI0xN8eXA9SJJ4oqmBL+801QNIAoOKpg18GVY0PUISeKSpGgKRJgF/IAks4mXmL5rGkATGNH3Dn4K2FiS6grYCBs+VgAdIdFuapiU8+qRpDoluTtMSPh2VA3JTMGZ5rk/bFhLZK6MW6H8rB2RmTtMd/NoqB+SlYNx5+Ya2V0hUZ9oK+FXOaJqVEEvs97GHZwfabiERPTL2Ma0r2laQiJaMuz/n3nusM/3Drf/TpKapGsC7JXUuKBvHBPH4irZrSDR3tJ3g37BNWwGJpKCtPUQAK6o/IBOHJDPyE22VukEjmVQe1gABcsA3JIrvJBnAHXhGe0gE+zltB4RxS1UDc5DsPezXVIdIBrq0rUsE8kBtCqfXokODUG56zuQjwa1o6/URTJe2nhqFg+vXtHURzi/qXEhq55S3sw3atLXVJxpYpx24CGBb0OELElRDpmzUbNFhqhAQVGeaeCX2VyEgqYYOXYR1pRCQ0mBKhxPCKscKAQk1dBiXCKxRCEinM03/+b3UdGgggWzpUL8guBUdqmdIEM8VM6jFFyR1ZVASC2axG9elQ+8eEsB9j1nsx9/SZQkJYEmXd0RxR5cNxLsNmUlrxoku1zod6N3+mmQeF3buR3T5gHj2RpdRCUPc3zJTq6hng1lGX91wTJczxKszXdZDRLOjS62l4D/27gM9cRiIArApi4UNuACmmRoIoaZs8u5/tP3Ylmw2iSQXLMnz3wD8bKvMyJmaM/DsrevpxOCxLZIhGzwDx7qiI3049Cvm/9+OD57+1iIZ2fYVmgL8UgdU2JgoiQm46tZ13Y0AahW8ki64Ro51Zd/BNehYJANuDGUWAd94BqhN5CpewPVsXV+VgYcdLJLagYGHVa0CTMAVU31gau5A1fF20wMVB+VvCK6gaRViASUHJ2bp4kLNTza5EbhCOjoslV4Irsi1CrIHqDwsXydAqV2gfzlTAKAzhPPzBL6pYxWmysAV0MFBiVUCcLGZVaAN+HyaCybk+lB9otWIAIAOEc7HGXxRzyrUN0C1rWpjHLX4b23wBXSSfAIVD3zPhRfgzwPwhVQcIq0XA1qUXi4hwKavykly1gCgQyu+M8UFfVw4WzsIGClRcVFl4GPfLSKhDgFMkSWWBQQE1DAqoepB4U2g9zojCIjoHGFht6E+LwDhlwCmtCIoyJ0CULQMKMVLAOPC56x6cE7QbVzdmQKgItGMvEDEVJkXwEXbw0/0XbH0niDCU2AJ6K09RLC6RTi+MUDpKpBPjCEioG4hjm4AaFlo1QshoqbQ0FVFlRoAPUstDwwiorZFPjWPAEDTjpsFhIS0IPSpdgjtZoCvHJsSkE4zBnTeW+3FEDKg06Q/dOsD0Lq6YhZAiE8J+MDWh8YDgF8eIWakbIaLsx1BzJOlsAnoGZDM7QjQdAVAupL9YkAjwQ/e/wZ0Wcz7EBNTAt5oxxDTV2wL4H9dBjEhrQj9NQ8hhmmwlL6HoIhWhX+rRDBhAPjHBoI8DeJ8Dd0aLpTvA5StaOcLCu9rUsH3ANB7BfC9hg8AVCEi5pFB0EDBLUDOVIBvV/I6QecFMGYC8GrmQdRJ8XltvtwTLsxrrLhhEDUq8YLA7RQ/Gdha9Q2g6SBPNcSFnjWAPPcQ5mkW7qzUPfykSxuwpA3E7TSZ32TJWTL8YugpO84J4tbazHCysrUhbqzlDdJZQ1yo1Rg3vWoMcbZSTUDiXBvivFKtCh4DiLO1nSm7z5Aw0fZ3ynI3kNDS+H9pTCHBV+TAi7xVfEgYaT08kktAUIqtgaOHi5KUT259yBhrHXcRvRNk+Jpff8vqTSEjMvwLE90QZbr/L3otSBlqPOaRG/3xTQ24/rJzASBWuPEhndkAUloNywiuDSlsZ+RDwH1hAEox/3+vc4Kc2MBqwcMActbGXP8ECcB5ayXVqOemYSW1nUDSWNP13485G0jqr6yEKshNxUqo3oeks5b7P1+4hyx7bkoA5jZ+MXr/n+fIIIltGiYEwF0GkMSM/NRa14Os/qOjewDujhFkeYauhs36kNaa6R2AWQvS+sbWRswHkDee6xuA+RjyfIO7Zt015LHhrZ4B2O4CyLON3g9zNkjAW7r6BcBdeEhgY9r0770VQwL9ZUOvALiPERJgJaiIOPSRLAI9fQLgPiT8kQYugf9v7iOR/n1DjwA07vtIxNeo/TMNd4xkvE1T/QDcLmt4RVWxH1oFSIaNZ2oHoDJM/NMerBKZhUjK7t6pGoC7ro1/UGcMpzMqmcHDVsUANFY+Ensu3cmZzoIhMe9cVS0A1XOAxNjC9Nn/Rw4hUpiueuoEoPc0RQqhsVWQX2tMkEawrndUCIDTnXh4h5ohxOw9pBK9VIoOQPUlQiqedmd/ZKndQkrx5lBcACrLAVKalmTx5zOdBUNag0W1iABUFwOkxZZGlX4mUpkivWhSd68ZALe7CZHeqLTnY73VWTJkIFg/ta8TgPbTOgBAt79aD4GLaLxq5huA2/owBgC6/TPVuQ+QlcEJuTkNkJXgnm7/d6XzpfJcktNQJNyEKI3oWPIzsj/U2DCUAhsa0vaduWoLJTAt2cavDGcfIWfM/hJDzqJ9GTf+xLkPHnJVs75UQ668HT39eZpDhjeMCsDY4KafDFWf8cqgALTo5S/qZoQ/jAnAyNCW33zc/Y2AIQHwjzT2k+PUB7gwIgDxii6/PGcfAjAgADHN/BLqHH39A+AfadcnzVigpXcAWje06p/SYa1vAFo08s9C5RzoGIDgTFu+WWk8xroFIFoacdK3MpzuWqcAtOo08M9cZVPTIwC1Tclr/XPTqa+Z6gFgrVV5znkoQPMhVjkA4Y72+/J21z3X1AxA7dylSf9VON1JTbUAeOMbWvG7os7NxFMnAMH6SC/+q3O/DyMVAhANb+jqF6Xy0Co2AP7uQO/9YjWfTv1iAtC/dCISFbRX49p1A+DZD1Va7FNJ53Bv164TgNqP9u7eBEAYCMAoNmITMoA/lTZBEPdfzg0CKYIJeW+FfKmO487n8PhNCve1L1UD2NbXz2/bnOoFkKx1dGCqF4ABfw8EMDgBDC4fQAxZUQDd+/1iCEUEgAAQAAJAAAgAASAABIAAEAACQAAIAAEgAASAABAAAkAACAABIAAEgAAQAAIYnABKfEiHHr+kRdauAAAAAElFTkSuQmCC"
        />
      </IconButton> */}
      {/* Delete */}
      <IconButton
        variant="outlined"
        component="span"
        onClick={() => {
          // console.log("Clicked delete");
          // setDeepICRCTX({
          //   ...deepICRCTX,
          //   selectedRegion: {
          //     pages: [{}]
          //   }
          // })
          if (deepICRCTX.selectedShape.length > 0) {
            let image_id = deepICRCTX.selectedShape[0].image_id;
            let shape_id = deepICRCTX.selectedShape[0].shape_id;
            let pages = deepICRCTX.shapeList;

            console.log("img id: ", image_id, "shape_id: ", shape_id, "pages:", pages);
            for (let page in pages) {
              if (page === image_id) {
                let shapes = pages[page];
                delete shapes[shape_id];
                let temp_shapes = {};
                let i = 1;
                for (let shape in shapes) {
                  temp_shapes["s_" + i] = shapes[shape];
                  i++;
                }
                pages[page] = temp_shapes;
              }
            }
            setDeepICRCTX({
              ...deepICRCTX,
              shapeList: pages,
              selectedShape: [],
              popUpDialog: {
                image_id: "",
                shape_id: "",
                label: "",
                meta: "",
                left: 0,
                top: 0,
                show: false,
                testShow: false
              },
            });
          }
          if (deepICRCTX.selectedShapeRight.length > 0) {
            let image_id = deepICRCTX.selectedShapeRight[0].image_id;
            let shape_id = deepICRCTX.selectedShapeRight[0].shape_id;
            let pages = deepICRCTX.shapeListRight;
            let tempPageNo = deepICRCTX.selectedShapeRight[0].image_id.split('_')
            // let pageNo = tempPageNo[tempPageNo.length - 1]

            const updatedJson = deepICRCTX.outputJson

            let selectedpageNo =  updatedJson.original_output.pages.map((val,i)=>{
              // console.log({val});
              let pageArr =  val.id.split('_')
              let pagesPageNo = pageArr[pageArr.length - 1]
              // console.log({pagesPageNo});
              if(pagesPageNo === tempPageNo[tempPageNo.length - 1]){
                return i
              }
            })
           
            // console.log({selectedpageNo});
            let pageNo = selectedpageNo.filter((val)=>{return val!== undefined})[0]
            // console.log({pageNo});
            let selectedObjectPages = deepICRCTX.selectedRegion.pages
            if(selectedObjectPages.length>0){
              let selectedRegions = deepICRCTX.selectedRegion.pages[pageNo]?.regions
  
              for (let i = 0; i < selectedRegions?.length; i++) {
                const selectedObject = selectedRegions[i]
  
                let hasValue = false
                // Delete the selected object from selectedRegion object 
                for (const key in selectedObject) {
                  // search the specified page number's region key. 
                  // Where the shape id matches make it found
                  if (key.includes(shape_id)) {
                    hasValue = true;
                    break;
                  }
                }
  
                // If the data is found then delete from the array
                if (hasValue) {
                  selectedRegions.splice(i, 1);
                  break;
                }

                // let inc = 1
                // for(let key of selectedRegions){
                //   console.log("key: ",Object.keys(key));
                // }
                
                // Update the region
                selectedObjectPages[pageNo].regions = selectedRegions
                // console.log("after delete",selectedObjectPages);
  
                setDeepICRCTX({
                  ...deepICRCTX,
                  selectedRegion: {
                    pages: selectedObjectPages
                  }
                })
              }

              function resetCounterInPropertyNames(objArray) {
                for (let i = 0; i < objArray?.length; i++) {
                  const obj = objArray[i];
                  for (const prop in obj) {
                    const matches = prop.match(/^(.*?)(\d+)$/);
                    if (matches) {
                      const prefix = matches[1];
                      const currentCounter = parseInt(matches[2], 10);
                      if (currentCounter > i + 1) {
                        // Decrease the counter by one
                        const newCounter = currentCounter - 1;
                        const newPropertyName = `${prefix}${newCounter}`;
                        obj[newPropertyName] = obj[prop];
                        delete obj[prop];
                      }
                    }
                  }
                }
              }

              resetCounterInPropertyNames(selectedRegions)
              // console.log("Seleccted Region",selectedRegions);
            }

            for (let page in pages) {
              if (page === image_id) {
                let shapes = pages[page];
                delete shapes[shape_id];
                let temp_shapes = {};
                let i = 1;
                for (let shape in shapes) {
                  temp_shapes["sr_" + i] = shapes[shape];
                  i++;
                }
                pages[page] = temp_shapes;
              }
            }
            setDeepICRCTX({
              ...deepICRCTX,
              shapeListRight: pages,
              selectedShapeRight: [],
              popUpDialog: {
                image_id: "",
                shape_id: "",
                label: "",
                meta: "",
                left: 0,
                top: 0,
                show: false,
                testShow: false
              },
            });
          }
          setDeepICRCTX({
            ...deepICRCTX,
            currentShape: [],
            selectedShape: [],
            currentShapeRight: [],
            selectedShapeRight: [],
          });
        }}
        className={styles.iconBtn}
      >
        <img
          title={t("stringDelete") + " [ Del ]"}
          width={18}
          height={18}
          alt=""
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAABHNCSVQICAgIfAhkiAAAAjFJREFUaEPtmzlSBDEMRd+EZFyArQoCMiAgBW4AB2HLIAKiIWM7CHACiAlYYghYDgARhFCqagqP6RlbbXs6kcORLelL8h/bpe5QbowAi8AqsAZMeKZegHPgArgBvkq40imhFJgD7hS6BawE4l6xJmpqCYA7QDfK+v9Ju8Bhw7W1y3IDnAduEx1cUGZ/oLmcAGXPfXrWLoHjqvQ+ajxZBvaBJUcm5Tqba0/mBCjOXjmOCjjZVzHj2gO5AshvySMnwBNgw/FI46QfnFNgMxkdkBPgs/dXoNE9Crx7ZTpZCuB3DsUt6ugJbF2UDWCL2YkxbRnsFyW/dDUkEhP50JxG9jVONjIQ8lohb2TfADoRbhRBRYZCUxvZtwxaBv8iIAfrPUCOXdvVTd0tu1R56yXqnkXlZi53Q3ekylsHGHKgtLyWpHKSTGkAIf0GMPV/KBTh0nLLoGXQi4BPUKVLMKTfStRK1Eq0NwLD3qO2B20P2h60PdgTgdwkZCRjJGMkYyRjJONGQMuyxqLGogEWdR92H6p2rn4Pv03krd/o5Wlemnrk6X6rz9N9irx1gKEST5UbwLoI5ny6T81QaL1lMDWDr8CYo2QKEOYcxvAbbN+A8RjDmhL1m+2kFfmgRJeu57j0rB15nYvRzXoagNPAY0zUhjBnBniKsaMBKPr8LMbYyD0nOntiWAtQ5ksHr9sXmhvAIH0CTg4R0Q2DWoC/xqVc16vPBVziKQFWCEU+PziLLUvXiR8pDeI550/wuQAAAABJRU5ErkJggg=="
        />
      </IconButton>
    </>
  );
};

export default CroppingTool;
