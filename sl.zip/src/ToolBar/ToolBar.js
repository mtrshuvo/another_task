import React, { useContext, useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { makeStyles, withStyles } from "@material-ui/core";
import { withSnackbar } from "notistack";
import Toolbar from "@material-ui/core/Toolbar";
import Divider from "@material-ui/core/Divider";
import Typography from "@material-ui/core/Typography";
import InputBase from "@material-ui/core/InputBase";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import SvgIcon from "@material-ui/core/SvgIcon";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import crypto from "crypto";
import JSZip from "jszip";
import { pdfjs } from "react-pdf";
import { jsPDF } from "jspdf";
import { deepICRDownload, deepICRtoBlobWithBom, deepICRNow } from "../deepICRCommon";

// import resource files
import DeepICRContext from "../resources/DeepICRContext";
import CroppingTool from "./CroppingTool";
import { objectSize, deepCopy, commaRemovingFromNumberValue, isthereAnySHape, formatYYYYMMDDHHMMSS } from "../resources/CommonMethods";
import deepICRLogging from "../Logging/deepICRLogging";

// pdfjs Setting
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

//local_environment
const host_address = "172.16.16.230"
// Style Sheet
const useStyles = makeStyles((theme) => ({
  styleToolBar: {
    flexGrow: 1,
    backgroundColor: theme.palette.deepICR.color,
    padding: "4px 0",
  },
  styleDivider: {
    margin: theme.spacing(1),
  },
  styleSpacer: { flexGrow: 1 },
  styleFileUpload: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
  },
  stylePageNumberInputRoot: {
    color: "inherit",
    backgroundColor: theme.palette.deepICR.input,
    fontSize: "0.9rem",
  },
  stylePageNumberInput: {
    padding: theme.spacing(1, 1, 1, 2),
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      width: theme.palette.deepICR.pageNumberInputSize,
      "&:focus": {
        width: theme.palette.deepICR.pageNumberInputSizeFocus,
        backgroundColor: theme.palette.deepICR.input,
      },
    },
  },
  styleConvert: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
  },
  styleFormat: {},
  styleType: {},
  styleExport: {
    color: theme.palette.deepICR.color,
    backgroundColor: theme.palette.deepICR.blue4,
    borderRadius: 2,
  },
}));
const CustomButton = withStyles({
  outlined: {
    "&$disabled": {
      color: "#ffffff",
      backgroundColor: "#888888",
    },
  },
  disabled: {},
})(Button);

// [React function component]
// Tool bar component
const ToolBar = (props) => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [format, setFormat] = useState("csv");
  const [type, setType] = useState("invoice");
  const [json, setJson] = useState("");

  const [t] = useTranslation(); // for multiple language
  const styles = useStyles(); // for metarial ui theme

  if (deepICRCTX.debug === true) {
    console.log("ToolBar");
  }

  const [isSelection, setIsSelection] = useState(true);

  // Logout
  const logout = async () => {
    const [, unixtime, microsec] = deepICRNow();
    let requestJson = {
      type: "request",
      head: {
        command: "signout",
        format_version: deepICRCTX.apiFormatVersion,
        service_id: deepICRCTX.apiServiceId,
        transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
        unix_time: unixtime,
        micro_seconds: microsec,
        time_zone: deepICRCTX.apiTimeZone,
      },
    };
    await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiSignout, {
      method: "POST",
      mode: "cors",
      headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
      body: JSON.stringify(requestJson),
    })
      .then((res) => {
        return res.json();
      })
      .then((json) => {
        if (deepICRCTX.debug === true) {
          console.log(json);
        }
      })
      .catch((err) => {
        if (deepICRCTX.debug === true) {
          console.log("[ToolBar - logout] signout catch error");
        }
        if (deepICRCTX.debug === true) {
          console.log(err);
        }

        deepICRLogging({
          LogType: "ERROR",
          ErrType: "SignoutCatchError",
          Message: "Signout catch error",
          Src: "Toolbar.js",
          Line: 0,
          Column: 0,
          Stack: "",
        });
      });

    global.accessToken = "";
    global.refreshToken = "";
    global.rotation = [];
    setDeepICRCTX({
      ...deepICRCTX,
      isLogin: false,
      isTerms: false,
      isContract: false,
      changePassword: false,
      documentId: "",
      cognitoUser: {},
      // accessToken: "",
      // refreshToken: "",
      inputViewerBounds: {
        bounds: { height: 100, width: 100, top: 0, bottom: 100, left: 0, right: 100 },
      },
      imageScale: 1,
      outputTab: 0,
      file: {},
      requestedFile: "",
      fileBase64: [],
      fileSize: [{ height: 0, width: 0 }],
      pdfBase64: "",
      pdfPage: 1,
      pdfPages: 1,
      targetPages: "",
      size: 12,
      originalOutputFontScale: 1,
      outputSw: false,
      outputLinkSw: false,
      originalOutputSize: { height: 0, width: 0 },
      originalOutputData: { data: [] },
      originalOutputTable: { data: [] },
      extractedOutputData: { data: [] },
      extractedOutputTable: { data: [] },
      searchText: "",
    });
  };

  //-------------------------------------------------------------------------------------------------
  // Get Specified Document ID
  //-------------------------------------------------------------------------------------------------
  let documentId = "";

  if (
    deepICRCTX.outputLinkSw === false &&
    !(typeof props.documentId === "undefined") &&
    global.documentIdFileNotFound === false
  ) {
    documentId = props.documentId;
    const yyyymmddhhmmss = documentId.substr(0, 14);
    const fileName = documentId.substr(14);

    // Parse output json file
    const parseOutputJson = (outputJson, fileSize) => {
      console.log("naki etai");
      if (
        outputJson === undefined ||
        outputJson.original_output === undefined ||
        outputJson.original_output.pages === undefined
      ) {
        deepICRLogging({
          Type: "UndefinedError",
          Message: "pages key not found in json file",
          Src: "ToolBar.js",
          Line: 0,
          Column: 0,
          Stack: "",
        });

        return [0, 0, {}, {}, [], [], {}];
      }
      if (
        outputJson.statusCode === null ||
        outputJson.statusCode === undefined ||
        outputJson.statusCode.length === 0 ||
        (outputJson.statusCode.length > 0 && outputJson.statusCode[0] !== 200) ||
        outputJson.statusCode !== 200
      ) {
        if (deepICRCTX.language === "ja") {
          for (let i = 0; i < outputJson.statusDescription.length; i++) {
            let msg = outputJson.statusDescription[i].split("|")[0];
            props.enqueueSnackbar(msg, {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
          }
        } else if (deepICRCTX.language === "en") {
          for (let i = 0; i < outputJson.statusDescription.length; i++) {
            let msg = outputJson.statusDescription[i].split("|")[1];
            props.enqueueSnackbar(msg, {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
          }
        }
        return [0, 0, {}, {}, [], [], {}];
      }
      const oResultArray = outputJson.original_output.pages;
      const oDataHeight = outputJson.original_output.pages[0].height;
      const oDataWidth = outputJson.original_output.pages[0].width;
      const documentName = outputJson.original_output.document_name;
      const prefixArray = documentName.split(".");
      prefixArray.pop();
      const prefix = prefixArray.join(".");
      let id = 1;
      // let uniqueKeyForData = 0;
      let shapes = {};
      let isSel = false;

      const oData = { documentName: documentName };
      const oTable = { documentName: documentName };
      for (let i = 0; i < oResultArray.length; i++) {
        let uniqueKeyForData = 0;
        if (oResultArray[i].id !== prefix) {
          id = oResultArray[i].id.replace(prefix + "_page_", "");
          
        }
        oData[id] = {
          id: oResultArray[i].id,
          height: oResultArray[i].height,
          width: oResultArray[i].width,
          data: [],
        };
        oTable[id] = {
          id: oResultArray[i].id,
          data: [],
        };
        for (let j = 0; j < oResultArray[i].regions.length; j++) {
          if (oResultArray[i].regions[j].selection_id !== undefined) isSel = true;
          if (
            oResultArray[i].regions[j].type === "Single Line" ||
            oResultArray[i].regions[j].type === "Line"
          ) {
            for (let k = 0; k < oResultArray[i].regions[j].words.length; k++) {
              oData[id].data.push({
                shape_id: oResultArray[i].regions[j].selection_id,
                shape_type: oResultArray[i].regions[j].selection_type,
                meta: oResultArray[i].regions[j].meta,
                x: oResultArray[i].regions[j].words[k].x,
                y: oResultArray[i].regions[j].words[k].y,
                width: oResultArray[i].regions[j].words[k].width,
                height: oResultArray[i].regions[j].words[k].height,
                text: oResultArray[i].regions[j].words[k].text,
                confidence: oResultArray[i].regions[j].words[k].confidence,
                key: i + "-" + j + "-" + k,
                color: oResultArray[i].regions[j].words[k].confidence < 0.9 ? "red" : "black",
                originalText: "",
                type: "dataFromLine",
                uniqueKey: uniqueKeyForData,
              });
              uniqueKeyForData++;
            }
          } else if (oResultArray[i].regions[j].type === "Image") {
            // const img = deepICRCTX.fileBase64[i];
            const ratio = fileSize[i].width / oResultArray[i].width;

            let shape_info = {};
            let points = "";

            if (oResultArray[i].regions[j].selection_type === "rect") {
              let x = oResultArray[i].regions[j].x;
              let y = oResultArray[i].regions[j].y;
              let w = oResultArray[i].regions[j].width;
              let h = oResultArray[i].regions[j].height;
              shape_info = { type: "rect", x: x * ratio, y: y * ratio, w: w * ratio, h: h * ratio };
            } else if (oResultArray[i].regions[j].selection_type === "ellipse") {
              let x = oResultArray[i].regions[j].x;
              let y = oResultArray[i].regions[j].y;
              let w = oResultArray[i].regions[j].width;
              let h = oResultArray[i].regions[j].height;
              shape_info = {
                type: "ellipse",
                x: x * ratio,
                y: y * ratio,
                w: w * ratio,
                h: h * ratio,
              };
            } else if (oResultArray[i].regions[j].selection_type === "polygon") {
              points = oResultArray[i].regions[j].points;

              let points_arr = points.split(" ");
              let points_dic = [];
              for (let p = 0; p < points_arr.length; p++) {
                let point = points_arr[p].split(",");
                points_dic.push({ x: point[0] * ratio, y: point[1] * ratio });
              }
              shape_info = { type: "polygon", points: points_dic };
            }

            oData[id].data.push({
              shape_id: oResultArray[i].regions[j].selection_id,
              shape_type: oResultArray[i].regions[j].selection_type,
              meta: oResultArray[i].regions[j].meta,
              x: oResultArray[i].regions[j].x,
              y: oResultArray[i].regions[j].y,
              width: oResultArray[i].regions[j].width,
              height: oResultArray[i].regions[j].height,
              key: i + "-" + j,
              points: oResultArray[i].regions[j].points,
              type: "Image",
              uniqueKey: uniqueKeyForData,
            });

            shapes[i + "-" + j] = shape_info;
            uniqueKeyForData++;
          } else if (oResultArray[i].regions[j].type === "Blank") {
            oData[id].data.push({
              shape_id: oResultArray[i].regions[j].selection_id,
              shape_type: oResultArray[i].regions[j].selection_type,
              meta: oResultArray[i].regions[j].meta,
              x: oResultArray[i].regions[j].x,
              y: oResultArray[i].regions[j].y,
              width: oResultArray[i].regions[j].width,
              height: oResultArray[i].regions[j].height,
              key: i + "-" + j,
              points: oResultArray[i].regions[j].points,
              type: "Blank",
              uniqueKey: uniqueKeyForData,
            });
            uniqueKeyForData++;
          } else if (oResultArray[i].regions[j].type === "Multi Line") {
            for (let k = 0; k < oResultArray[i].regions[j].lines.length; k++) {
              for (let l = 0; l < oResultArray[i].regions[j].lines[k].words.length; l++) {
                oData[id].data.push({
                  shape_id: oResultArray[i].regions[j].selection_id,
                  shape_type: oResultArray[i].regions[j].selection_type,
                  meta: oResultArray[i].regions[j].meta,
                  x: oResultArray[i].regions[j].lines[k].words[l].x,
                  y: oResultArray[i].regions[j].lines[k].words[l].y,
                  width: oResultArray[i].regions[j].lines[k].words[l].width,
                  height: oResultArray[i].regions[j].lines[k].words[l].height,
                  text: oResultArray[i].regions[j].lines[k].words[l].text,
                  confidence: oResultArray[i].regions[j].lines[k].words[l].confidence,
                  key: i + "-" + j + "-" + k + "-" + l,
                  color:
                    oResultArray[i].regions[j].lines[k].words[l].confidence < 0.9 ? "red" : "black",
                  originalText: "",
                  type: "dataFromLine",
                  uniqueKey: uniqueKeyForData,
                });
                uniqueKeyForData++;
              }
            }
          } else if (oResultArray[i].regions[j].type === "Handwritten") {
            if ("lines" in oResultArray[i].regions[j]) {
              for (let k = 0; k < oResultArray[i].regions[j].lines.length; k++) {
                for (let l = 0; l < oResultArray[i].regions[j].lines[k].words.length; l++) {
                  oData[id].data.push({
                    shape_id: oResultArray[i].regions[j].selection_id,
                    shape_type: oResultArray[i].regions[j].selection_type,
                    meta: oResultArray[i].regions[j].meta,
                    x: oResultArray[i].regions[j].lines[k].words[l].x,
                    y: oResultArray[i].regions[j].lines[k].words[l].y,
                    width: oResultArray[i].regions[j].lines[k].words[l].width,
                    height: oResultArray[i].regions[j].lines[k].words[l].height,
                    text: oResultArray[i].regions[j].lines[k].words[l].text,
                    confidence: oResultArray[i].regions[j].lines[k].words[l].confidence,
                    key: i + "-" + j + "-" + k + "-" + l,
                    color:
                      oResultArray[i].regions[j].lines[k].words[l].confidence < 0.9
                        ? "red"
                        : "black",
                    originalText: "",
                    type: "dataFromLine",
                    uniqueKey: uniqueKeyForData,
                  });
                  uniqueKeyForData++;
                }
              }
            }
          }
          //} else if(oResultArray[i].regions[j].type.match(/_Table/)) {
          else if (
            oResultArray[i].regions[j].type === "Table" ||
            oResultArray[i].regions[j].type.match(/_Table/)
          ) {
            for (let k = 0; k < oResultArray[i].regions[j].cells.length; k++) {
              oTable[id].data.push({
                shape_id: oResultArray[i].regions[j].selection_id,
                shape_type: oResultArray[i].regions[j].selection_type,
                meta: oResultArray[i].regions[j].meta,
                x: oResultArray[i].regions[j].cells[k].x,
                y: oResultArray[i].regions[j].cells[k].y,
                width: oResultArray[i].regions[j].cells[k].width,
                height: oResultArray[i].regions[j].cells[k].height,
                row_no: oResultArray[i].regions[j].cells[k].row_no,
                col_no: oResultArray[i].regions[j].cells[k].col_no,
                row_span: oResultArray[i].regions[j].cells[k].row_span,
                col_span: oResultArray[i].regions[j].cells[k].col_span,
                key: i + "-" + j + "-" + k,
                type: "borderFromTable",
              });
              for (let l = 0; l < oResultArray[i].regions[j].cells[k].cell.length; l++) {
                for (let m = 0; m < oResultArray[i].regions[j].cells[k].cell[l].words.length; m++) {
                  if (oResultArray[i].regions[j].cells[k].cell[l].words[m].text !== "") {
                    oData[id].data.push({
                      shape_id: oResultArray[i].regions[j].selection_id,
                      shape_type: oResultArray[i].regions[j].selection_type,
                      meta: oResultArray[i].regions[j].meta,
                      x: oResultArray[i].regions[j].cells[k].cell[l].words[m].x,
                      y: oResultArray[i].regions[j].cells[k].cell[l].words[m].y,
                      width: oResultArray[i].regions[j].cells[k].cell[l].words[m].width,
                      height: oResultArray[i].regions[j].cells[k].cell[l].words[m].height,
                      text: oResultArray[i].regions[j].cells[k].cell[l].words[m].text,
                      confidence: oResultArray[i].regions[j].cells[k].cell[l].words[m].confidence,
                      key: i + "-" + j + "-" + k + "-" + l + "-" + m,
                      color:
                        oResultArray[i].regions[j].cells[k].cell[l].words[m].confidence < 0.9
                          ? "red"
                          : "black",
                      originalText: "",
                      type: "dataFromTable",
                      uniqueKey: uniqueKeyForData,
                    });
                    uniqueKeyForData++;
                  }
                }
              }
            }
          }
        }
      }
      if (isSel) setFormat("crop");
      else setFormat("csv"); //tsv

      setDeepICRCTX({
        ...deepICRCTX,
        isSelection: isSel,
      });

      const eData = {};
      const eTable = {};
      const eResultArray = outputJson.extracted_output;
      Object.keys(eResultArray).forEach((key) => {
        if (key === "details") {
          for (let p in eResultArray[key].values) {
            let tables = {};
            for (let t in eResultArray[key].values[p]) {
              let rows = [];
              for (let i = 0; i < eResultArray[key].values[p][t].length; i++) {
                let cols = [];
                for (let j = 0; j < eResultArray[key].values[p][t][i].length; j++) {
                  cols.push({
                    row: i,
                    column: j,
                    value: eResultArray[key].values[p][t][i][j],
                    originalValue: "",
                    color: "black",
                    null: eResultArray[key].values[p][t][i][j] === "" ? true : false,
                  });
                }
                rows.push(cols);
              }
              tables[t] = rows;
            }
            eTable[p] = tables;
          }
        } else {
          eData[key] = [];
          if (eResultArray[key] !== undefined) {
            if (
              eResultArray[key].values !== undefined &&
              typeof eResultArray[key].values === "string"
            ) {
              eData[key] = {
                en_label: eResultArray[key].en_label,
                jp_label: eResultArray[key].jp_label,
                values: [
                  {
                    key: 0,
                    value: eResultArray[key].values,
                    originalValue: "",
                    color: "black",
                    null: eResultArray[key].values === "" ? true : false,
                  },
                ],
              };
            } else {
              if (eResultArray[key].values === undefined || eResultArray[key].values.length === 0) {
                eData[key] = {
                  en_label: eResultArray[key].en_label,
                  jp_label: eResultArray[key].jp_label,
                  values: [
                    {
                      key: 0,
                      value: "",
                      originalValue: "",
                      color: "black",
                      null: true,
                    },
                  ],
                };
              } else {
                let values = [];
                if (eResultArray[key].values !== undefined) {
                  for (let i = 0; i < eResultArray[key].values.length; i++) {
                    values.push({
                      key: i,
                      value: eResultArray[key].values[i],
                      originalValue: "",
                      color: "black",
                      null: eResultArray[key].values[i] === "" ? true : false,
                    });
                  }
                }
                eData[key] = {
                  en_label: eResultArray[key].en_label,
                  jp_label: eResultArray[key].jp_label,
                  values: values,
                };
              }
            }
          }
        }
      });
      return [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes];
    };

    const [, unixtime, microsec] = deepICRNow(); // Get image file from S3
    const md5 = crypto.createHash("md5"); // Get hash of Username
    const md5hash = md5.update(deepICRCTX.cognitoUser.Username, "binary").digest("hex");

    // Get Presigned URL for image file
    let requestJson = {
      type: "request",
      head: {
        command: "getPresignedUrl",
        format_version: deepICRCTX.apiFormatVersion,
        service_id: deepICRCTX.apiServiceId,
        transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
        unix_time: unixtime,
        micro_seconds: microsec,
        time_zone: deepICRCTX.apiTimeZone,
      },
      body: {
        keys: [
          deepICRCTX.s3Path +
          "/" +
          md5hash +
          "/" +
          yyyymmddhhmmss +
          "/" +
          (fileName.substr(-4) === ".pdf"
            ? fileName.substr(0, fileName.length - 4) + ".zip"
            : fileName),
        ],
        operation: "GET",
      },
    };

    global.documentIdFileNotFound = true;

    Promise.resolve()
      .then(() => {
        return new Promise((resolve, reject) => {
          fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
            method: "POST",
            mode: "cors",
            // headers: {Authorization: `${deepICRCTX.accessToken}`, "Content-Type": "application/json"},
            headers: { Authorization: `${global.accessToken}`, "Content-Type": "application/json" },
            body: JSON.stringify(requestJson),
          })
            .then((res) => {
              return res.json();
            })
            .then((json) => {
              if (json.body.status !== "OK") {
                deepICRLogging({
                  LogType: "ERROR",
                  ErrType: "TokenRefreshError",
                  Message: "token-refresh error after convert failure",
                  Src: "Toolbar.js",
                  Line: 0,
                  Column: 0,
                  Stack: "",
                });
                reject("error");
              } else {
                resolve(json.body.result.urls[0]);
              }
            })
            .catch((err) => {
              deepICRLogging({
                LogType: "ERROR",
                ErrType: "TokenRefreshError",
                Message: "token-refresh catch error after convert failure",
                Src: "Toolbar.js",
                Line: 0,
                Column: 0,
                Stack: "",
              });
              reject(err);
            });
        });
      })
      .then((presignedUrl) => {
        return new Promise((resolve, reject) => {
          fetch(presignedUrl, {
            method: "GET",
            mode: "cors",
          })
            .then((res) => {
              if (res.ok) {
                return res.blob();
              } else {
                if (deepICRCTX.debug === true) {
                  console.log("[ToolBar - documentId] fetch 404 error for image file");
                }
                if (deepICRCTX.debug === true) {
                  console.log(res);
                }
                props.enqueueSnackbar(t("errorFileNotFound"), {
                  variant: "error",
                  anchorOrigin: { vertical: "top", horizontal: "right" },
                });

                deepICRLogging({
                  LogType: "ERROR",
                  ErrType: "FileNotFoundError",
                  Message: "Fetch 404 error for image file.",
                  Src: "Toolbar.js",
                  Line: 0,
                  Column: 0,
                  Stack: "",
                });

                reject("fileNotFound");
              }
            })
            .then((blob) => {
              resolve(blob);
            })
            .catch((err) => {
              deepICRLogging({
                LogType: "ERROR",
                ErrType: "ImageFileCatchError",
                Message: "Catch 404 error for image file ",
                Src: "Toolbar.js",
                Line: 0,
                Column: 0,
                Stack: "",
              });
              reject(err);
            });
        });
      })
      .then((blob) => {
        return new Promise((resolve, reject) => {
          function readAsDataURL(blob) {
            return new Promise((resolve, reject) => {
              let reader = new FileReader();
              reader.onload = () => {
                resolve(reader.result);
              };
              reader.onerror = () => {
                reject(reader.error);
              };
              reader.readAsDataURL(blob);
            });
          }
          readAsDataURL(blob)
            .then((dataUrl) => {
              resolve([blob.type, dataUrl]);
            })
            .catch((err) => {
              deepICRLogging({
                LogType: "ERROR",
                ErrType: "NetworkError",
                Message: err.message,
                Src: "Toolbar.js",
                Line: 0,
                Column: 0,
                Stack: "",
              });
              reject(err);
            });
        });
      })
      .then(([contentType, fileBase64]) => {
        requestJson.body.keys = [
          deepICRCTX.s3Path +
          "/" +
          md5hash +
          "/" +
          yyyymmddhhmmss +
          "/" +
          fileName.match(/(.*)(?:\.([^.]+$))/)[1] +
          "_out.json",
        ];
        return new Promise((resolve, reject) => {
          fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
            method: "POST",
            mode: "cors",
            // headers: {Authorization: `${deepICRCTX.accessToken}`, "Content-Type": "application/json"},
            headers: { Authorization: `${global.accessToken}`, "Content-Type": "application/json" },
            body: JSON.stringify(requestJson),
          })
            .then((res) => {
              return res.json();
            })
            .then((json) => {
              if (json.body.status !== "OK") {
                reject("error");
              } else {
                resolve([json.body.result.urls[0], contentType, fileBase64]);
              }
            })
            .catch((err) => {
              reject(err);
            });
        });
      })
      .then(([presignedUrl, contentType, fileBase64]) => {
        return new Promise((resolve, reject) => {
          fetch(presignedUrl, {
            method: "GET",
            mode: "cors",
          })
            .then((res) => {
              if (res.ok) {
                return res.text();
              } else {
                if (deepICRCTX.debug === true) {
                  console.log("[ToolBar - documentId] fetch 404 error for output json file");
                }
                if (deepICRCTX.debug === true) {
                  console.log(res);
                }
                props.enqueueSnackbar(t("errorFileNotFound"), {
                  variant: "error",
                  anchorOrigin: { vertical: "top", horizontal: "right" },
                });
                deepICRLogging({
                  LogType: "ERROR",
                  ErrType: "FileNotFoundError",
                  Message: "Fetch 404 error for output json file",
                  Src: "Toolbar.js",
                  Line: 0,
                  Column: 0,
                  Stack: "",
                });
                reject("fileNotFound");
              }
            })
            .then((text) => {
              let outputJson = JSON.parse(text);
              if (
                outputJson.statusCode === null ||
                outputJson.statusCode === undefined ||
                outputJson.statusCode.length === 0 ||
                (outputJson.statusCode.length > 0 && outputJson.statusCode[0] !== 200) ||
                (typeof outputJson.statusCode !== "object" && outputJson.statusCode !== 200)
              ) {
                if (deepICRCTX.debug === true) {
                  console.log("[ToolBar - uploadAndConvert] fetch error for output json file");
                }
                if (deepICRCTX.debug === true) {
                  console.log(JSON.stringify(outputJson, null, 1));
                }
                props.enqueueSnackbar(t("errorConvert"), {
                  variant: "error",
                  persist: true,
                  anchorOrigin: { vertical: "top", horizontal: "right" },
                });
                deepICRLogging({
                  LogType: "ERROR",
                  ErrType: "ConvertError",
                  Message: t("errorConvert"),
                  Src: "Toolbar.js",
                  Line: 0,
                  Column: 0,
                  Stack: "",
                });
                setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
                // isError = true;
                return;
              }
              const isContract = outputJson.target_type === "contract" ? true : false;
              setJson(outputJson);
              let oDataHeight = 0;
              let oDataWidth = 0;
              let oData = {};
              let oTable = {};
              let eData = [];
              let eTable = [];
              let shapes = {};

              if (contentType === "image/jpeg") {
                const img = new Image();
                img.onload = () => {
                  if (
                    deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height !== img.height &&
                    deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width !== img.width
                  ) {
                    [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes] =
                      parseOutputJson(outputJson, [{ height: img.height, width: img.width }]);
                    setDeepICRCTX({
                      ...deepICRCTX,
                      isContract: isContract,
                      documentId: yyyymmddhhmmss,
                      inputViewerBounds: global.inputViewerBounds,
                      imageScale: global.inputViewerBounds.bounds.width / img.width,
                      file: { type: contentType, name: fileName },
                      fileBase64: [fileBase64],
                      fileSize: [{ height: img.height, width: img.width }],
                      pdfBase64: "",
                      originalOutputSize: { height: oDataHeight, width: oDataWidth },
                      originalOutputData: { data: oData },
                      originalOutputTable: { data: oTable },
                      extractedOutputData: { data: eData },
                      extractedOutputTable: { data: eTable },
                      shapeList: outputJson.selection_info,
                      croppedImages: shapes,
                      outputSw: true,
                      outputLinkSw: true,
                    });
                  }
                };
                // asynchronous
                img.src = fileBase64;
              } else {
                JSZip.loadAsync(fileBase64.split(",")[1], { base64: true })
                  .then((zip) => {
                    let promises = [];
                    let fileNames = [];
                    let fileBase64 = [];
                    let pdfBase64 = "";
                    let fileSize = [];
                    let pdfIndex = 0;
                    let pdfPages = 0;
                    Object.keys(zip.files).forEach((fileName) => {
                      promises.push(zip.file(fileName).async("base64"));
                      fileNames.push(fileName);
                    });
                    Promise.all(promises)
                      .then((zips) => {
                        for (let i = 0; i < promises.length; i++) {
                          if (fileNames[i].substr(-4) === ".pdf") {
                            pdfBase64 = "data:application/pdf;base64," + zips[i];
                            pdfIndex = i;
                          } else if (fileNames[i].substr(-4) === ".jpg") {
                            fileBase64.push("data:image/jpeg;base64," + zips[i]);
                            pdfPages++;
                          } else if (fileNames[i].substr(-4) === ".txt") {
                            fileSize = JSON.parse(window.atob(zips[i]));
                          }
                        }
                        [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes] =
                          parseOutputJson(outputJson, fileSize);
                        setDeepICRCTX({
                          ...deepICRCTX,
                          isContract: isContract,
                          documentId: yyyymmddhhmmss,
                          inputViewerBounds: global.inputViewerBounds,
                          imageScale: global.inputViewerBounds.bounds.width / fileSize[0].width,
                          file: { type: "application/pdf", name: fileNames[pdfIndex] },
                          fileBase64: fileBase64,
                          fileSize: fileSize,
                          pdfBase64: pdfBase64,
                          pdfPages: pdfPages,
                          originalOutputSize: { height: oDataHeight, width: oDataWidth },
                          originalOutputData: { data: oData },
                          originalOutputTable: { data: oTable },
                          extractedOutputData: { data: eData },
                          extractedOutputTable: { data: eTable },
                          shapeList: outputJson.selection_info,
                          croppedImages: shapes,
                          outputSw: true,
                          outputLinkSw: true,
                        });
                      })
                      .catch((err) => {
                        if (deepICRCTX.debug === true) {
                          console.log(err);
                        }
                        props.enqueueSnackbar(t("errorZipProcess"), {
                          variant: "error",
                          anchorOrigin: { vertical: "top", horizontal: "right" },
                        });
                        deepICRLogging({
                          LogType: "ERROR",
                          ErrType: "ZipProcessError",
                          Message: t("errorZipProcess"),
                          Src: "Toolbar.js",
                          Line: 0,
                          Column: 0,
                          Stack: "",
                        });
                        global.documentIdFileNotFound = true;
                      });
                  })
                  .catch((err) => {
                    if (deepICRCTX.debug === true) {
                      console.log(err);
                    }
                    props.enqueueSnackbar(t("errorZipProcess"), {
                      variant: "error",
                      anchorOrigin: { vertical: "top", horizontal: "right" },
                    });
                    deepICRLogging({
                      LogType: "ERROR",
                      ErrType: "ZipProcessError",
                      Message: t("errorZipProcess"),
                      Src: "Toolbar.js",
                      Line: 0,
                      Column: 0,
                      Stack: "",
                    });
                    global.documentIdFileNotFound = true;
                  });
              }
            })
            .catch((err) => {
              reject(err);
            });
        });
      })
      .catch((err) => {
        if (err !== "fileNotFound") {
          props.enqueueSnackbar(t("errorSystemError"), {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          deepICRLogging({
            LogType: "ERROR",
            ErrType: "FileNotFoundError",
            Message: t("errorFileNotFound"),
            Src: "Toolbar.js",
            Line: 0,
            Column: 0,
            Stack: "",
          });
        } else {
          global.documentIdFileNotFound = true;
        }
      });
  }

  //-------------------------------------------------------------------------------------------------
  // Get File
  //-------------------------------------------------------------------------------------------------
  const getFile = (e) => {

    if (typeof e.target.files[0] === "undefined") {
      return;
    }

    if (deepICRCTX.requestedFile !== "") {
      props.enqueueSnackbar(t("errorCannotChange"), {
        variant: "error",
        anchorOrigin: { vertical: "top", horizontal: "right" },
      });
      return;
    }

    // convert pdf file to jpeg images
    const pdfToJpeg = async (dataUrl) => {
      const tmpBase64 = dataUrl.split(",", 2)[1];
      const dataUrls = [];
      const fileSizes = [];
      const pdf = await pdfjs.getDocument({
        data: atob(tmpBase64),
        cMapUrl: `//cdn.jsdelivr.net/npm/pdfjs-dist@${pdfjs.version}/cmaps/`,
        cMapPacked: true,
      }).promise;
      let page;
      for (let i = 0; i < pdf.numPages; i++) {
        page = await pdf.getPage(i + 1);
        const oList = await page.getOperatorList();
        let j;
        const jpegs = [];
        for (j = 0; j < oList.fnArray.length; j++) {
          if (oList.fnArray[j] === pdfjs.OPS.paintJpegXObject) {
            jpegs.push(j);
          }
        }
        let scale = 1;
        let canvasHeight = 0;
        let canvasWidth = 0;
        // if(jpegs.length === 1){
        //     // Jpeg file in pdf
        //   const j = jpegs[0];
        //   const op = oList.argsArray[j][0];
        //   const img = page.objs.get(op);
        //   if(img.height > img.width){
        //     scale = img.height / page.getViewport({scale: 1}).height;
        //   }else{
        //     scale = img.width / page.getViewport({scale: 1}).width;
        //   }
        //   canvasHeight = img.height;
        //   canvasWidth = img.width;
        // }else{
        // Not jpeg file in pdf
        const viewportPdf = await page.getViewport({ scale: 1 });
        if (viewportPdf.height > viewportPdf.width) {
          scale = deepICRCTX.pdfDefaultHeight / viewportPdf.height;
          canvasHeight = deepICRCTX.pdfDefaultHeight;
          canvasWidth = Math.ceil(viewportPdf.width * scale);
        } else {
          scale = deepICRCTX.pdfDefaultHeight / viewportPdf.width;
          canvasWidth = deepICRCTX.pdfDefaultHeight;
          canvasHeight = Math.ceil(viewportPdf.height * scale);
        }
        // }
        const canvas = document.createElement("canvas");
        const viewport = await page.getViewport({ scale: scale });
        canvas.height = canvasHeight;
        canvas.width = canvasWidth;
        const context = canvas.getContext("2d");
        const task = page.render({
          canvasContext: context,
          viewport: viewport,
        });
        try {
          await task.promise;
        } catch (e) {
          if (deepICRCTX.debug === true) {
            console.log(e);
          }
        }
        dataUrls.push(canvas.toDataURL("image/jpeg"));
        fileSizes.push({ height: canvasHeight, width: canvasWidth });
      }
      return [dataUrls, fileSizes, pdf.numPages];
    };

    const file = e.target.files[0];

    const options = {
      mode: "cors",
      headers: {
        'filename': encodeURI(file.name),
        'content-type': file.type,
      },
      method: 'PUT',
      body: file,
      rejectUnauthorized: false
    }

    if (file !== null) {
      fetch('http://' + host_address + ':5000/fileUpload',
        options
      )
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          if (deepICRCTX.debug === true) console.log(data);
        })
        .catch(error => {
          if (deepICRCTX.debug === true) console.error(error)
        })
    }
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (e) => {
      // if(file.type === 'image/jpeg' || file.type === 'image/png') {
      if (file.type === "image/jpeg") {
        const img = new Image();
        img.onload = () => {
          global.rotation = [0];
          setDeepICRCTX({
            ...deepICRCTX,
            isContract: false,
            documentId: "",
            imageScale: deepICRCTX.inputViewerBounds.bounds.width / img.width,
            file: file,
            requestedFile: "",
            fileBase64: [reader.result],
            fileSize: [{ height: img.height, width: img.width }],
            pdfBase64: "",
            pdfPage: 1,
            pdfPages: 1,
            targetPages: "",
            size: 12,
            originalOutputFontScale: 1,
            originalOutputSize: { height: 0, width: 0 },
            originalOutputData: { data: [] },
            originalOutputTable: { data: [] },
            extractedOutputData: { data: [] },
            extractedOutputTable: { data: [] },
            selectedRegion:{
              pages:[]
            },
            shapeListRight:{},
            currentShapeRight:[],
            selectedShapeRight:[],
            outputJson:{},
            searchText: "",
            outputSw: false,
            croppingToolId: 6,
            shapeList: {},
            currentShape: [],
            selectedShape: [],
            shapeCounter: 0,
            pointCounter: 0,
            selectionPoints: [],
            popUpDialog: {
              image_id: "",
              shape_id: "",
              label: "",
              meta: "",
              left: 0,
              top: 0,
              show: false,
              testShow: false
            },
            
          });
        };
        img.src = e.target.result;
      } else if (file.type === "application/pdf") {
        Promise.resolve()
          .then(() => {
            return new Promise((resolve, reject) => {
              resolve(pdfToJpeg(reader.result));
            });
          })
          .then(([dataUrls, fileSizes, pdfPages]) => {
            global.rotation = [];
            for (let i = 0; i < pdfPages; i++) {
              global.rotation.push(0);
            }
            setDeepICRCTX({
              ...deepICRCTX,
              isContract: false,
              documentId: "",
              imageScale: deepICRCTX.inputViewerBounds.bounds.width / fileSizes[0].width,
              file: file,
              requestedFile: "",
              fileBase64: dataUrls,
              fileSize: fileSizes,
              pdfBase64: reader.result,
              pdfPage: 1,
              pdfPages: pdfPages,
              targetPages: "",
              size: 12,
              originalOutputFontScale: 1,
              originalOutputSize: { height: 0, width: 0 },
              originalOutputData: { data: [] },
              originalOutputTable: { data: [] },
              extractedOutputData: { data: [] },
              extractedOutputTable: { data: [] },
              searchText: "",
              outputSw: false,
              croppingToolId: 6,
              selectedRegion:{
                pages:[]
              },
              shapeListRight:{},
              currentShapeRight:[],
              selectedShapeRight:[],
              outputJson:{},
              shapeList: {},
              currentShape: [],
              selectedShape: [],
              shapeCounter: 0,
              pointCounter: 0,
              selectionPoints: [],
              popUpDialog: {
                image_id: "",
                shape_id: "",
                label: "",
                meta: "",
                left: 0,
                top: 0,
                show: false,
              },
            });
          })
          .catch((e) => {
            if (deepICRCTX.debug === true)
              if (deepICRCTX.debug === true) {
                console.log(e);
              }
            props.enqueueSnackbar(t("errorPdfToJpegProcess"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "PdfToJpegProcessError",
              Message: t("errorPdfToJpegProcess"),
              Src: "Toolbar.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
          });
      }
    };
  };

  //-------------------------------------------------------------------------------------------------
  // Validate input of pdf pages
  //-------------------------------------------------------------------------------------------------
  const validatePdfPages = (e) => {
    const inputText = e.target.value;
    if (inputText !== "") {
      if (typeof deepICRCTX.file.type === "undefined") {
        e.target.value = "";
        props.enqueueSnackbar(t("errorBeforeSetFile"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
      } else if (deepICRCTX.file.type !== "application/pdf") {
        e.target.value = "";
        props.enqueueSnackbar(t("errorNotPDF"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
      } else {
        if (!/^[0-9,-]+$/.test(inputText)) {
          e.target.value = "";
          props.enqueueSnackbar(t("errorInputType") + "(" + inputText + ")", {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
        } else {
          let checkArray1 = [];
          let checkArray2 = {};
          const inputTextArray = inputText.split(",");
          inputTextArray.forEach((item) => {
            if (/^[1-9]\d*-[1-9]\d*$/.test(item)) {
              const [start, end] = item.split("-");
              if (Number(start) >= Number(end)) {
                e.target.value = "";
                props.enqueueSnackbar(t("errorInputSequence") + "(" + item + ")", {
                  variant: "error",
                  anchorOrigin: { vertical: "top", horizontal: "right" },
                });
              }
              for (let i = Number(start); i <= Number(end); i++) {
                checkArray1.push(i);
                checkArray2[i] = "";
              }
            } else {
              if (!/^[1-9]\d*$/.test(item)) {
                e.target.value = "";
                props.enqueueSnackbar(t("errorInputPattern") + "(" + item + ")", {
                  variant: "error",
                  anchorOrigin: { vertical: "top", horizontal: "right" },
                });
              } else {
                checkArray1.push(Number(item));
                checkArray2[Number(item)] = "";
              }
            }
          });
          if (e.target.value !== "") {
            const newCheckArray2 = Object.keys(checkArray2);
            if (checkArray1.length !== newCheckArray2.length) {
              e.target.value = "";
              props.enqueueSnackbar(t("errorDuplicate") + "(" + inputText + ")", {
                variant: "error",
                anchorOrigin: { vertical: "top", horizontal: "right" },
              });
            } else {
              checkArray1.sort((a, b) => {
                return a - b;
              });
              let checkArray = [];
              let addText = "";
              checkArray1.forEach((n) => {
                if (n > deepICRCTX.pdfPages) {
                  if (checkArray.length < 10) {
                    checkArray.push(n);
                  } else {
                    addText = "...";
                  }
                }
              });
              if (checkArray.length !== 0) {
                if (addText !== "") {
                  checkArray.push(addText);
                }
                e.target.value = "";
                props.enqueueSnackbar(t("errorOverPDFPages") + "(" + checkArray.join(",") + ")", {
                  variant: "error",
                  anchorOrigin: { vertical: "top", horizontal: "right" },
                });
              } else {
                setDeepICRCTX({ ...deepICRCTX, targetPages: checkArray1.join(",") });
              }
            }
          }
        }
      }
    }
  };

  //-------------------------------------------------------------------------------------------------
  // Parse output json file
  //-------------------------------------------------------------------------------------------------
  const parseOutputJson = (outputJson) => {
    if (outputJson.original_output.pages === undefined) return [0, 0, {}, {}, [], [], {}];
    const oResultArray = outputJson.original_output.pages;
    const oDataHeight = outputJson.original_output.pages[0].height;
    const oDataWidth = outputJson.original_output.pages[0].width;
    const documentName = outputJson.original_output.document_name;
    const prefixArray = documentName.split(".");
    prefixArray.pop();
    const prefix = prefixArray.join(".");
    console.log("prefix", prefix);
    let id = 1;
    // let uniqueKeyForData = 0;
    let shapes = {};
    let isSel = false;

    const oData = { documentName: documentName };
    const oTable = { documentName: documentName };
    // console.log("result array", oResultArray);
    for (let i = 0; i < oResultArray.length; i++) {
      //  i = parseInt(oResultArray[i].id.replace(prefix + "_page_", "")) - 1;
      // let pageNo = oResultArray[i].id.split("_");
      // i = parseInt(pageNo[pageNo.length - 1] - 1);

      let uniqueKeyForData = 0;

      // const pag = oResultArray[i].id;
      // let pagLength = pag.split("_")
      // let pageNo = pagLength[pagLength.length - 1];
      // let i = parseInt(pageNo - 1);
      // console.log("page no", pageNo);
      // console.log("oresid", oResultArray[i].id);

      if (oResultArray[i].id !== prefix) {
        id = oResultArray[i].id.replace(prefix + "_page_", "");

      }
      oData[id] = {
        id: oResultArray[i].id,
        height: oResultArray[i].height,
        width: oResultArray[i].width,
        data: [],
      };
      oTable[id] = {
        id: oResultArray[i].id,
        data: [],
      };

      for (let j = 0; j < oResultArray[i].regions.length; j++) {
        // console.log("before",oResultArray[i].regions);
       const sortedRegions = oResultArray[i].regions.sort((shapeA, shapeB)=> {
          if (shapeA.y < shapeB.y) return -1;
          if (shapeA.y > shapeB.y) return 1;
          if (shapeA.x < shapeB.x) return -1;
          if (shapeA.x > shapeB.x) return 1;          
          return 0;
        })
        // console.log("after",sortedRegions);
        if (oResultArray[i].regions[j].selection_id !== undefined) isSel = true;
        if (
          oResultArray[i].regions[j].type === "Single Line" ||
          oResultArray[i].regions[j].type === "Line"
        ) {
          for (let k = 0; k < oResultArray[i].regions[j].words.length; k++) {
            oData[id].data.push({
              shape_id: oResultArray[i].regions[j].selection_id,
              shape_type: oResultArray[i].regions[j].selection_type,
              meta: oResultArray[i].regions[j].meta,
              x: oResultArray[i].regions[j].words[k].x,
              y: oResultArray[i].regions[j].words[k].y,
              width: oResultArray[i].regions[j].words[k].width,
              height: oResultArray[i].regions[j].words[k].height,
              text: oResultArray[i].regions[j].words[k].text,
              confidence: oResultArray[i].regions[j].words[k].confidence,
              key: i + "-" + j + "-" + k,
              color: oResultArray[i].regions[j].words[k].confidence < 0.9 ? "red" : "black",
              originalText: "",
              type: "dataFromLine",
              uniqueKey: uniqueKeyForData,
            });
            uniqueKeyForData++;
          }
        } else if (oResultArray[i].regions[j].type === "Image") {
          // const img = deepICRCTX.fileBase64[i];
          const ratio = deepICRCTX.fileSize[i].width / oResultArray[i].width;

          let shape_info = {};
          let points = "";

          if (oResultArray[i].regions[j].selection_type === "rect") {
            let x = oResultArray[i].regions[j].x;
            let y = oResultArray[i].regions[j].y;
            let w = oResultArray[i].regions[j].width;
            let h = oResultArray[i].regions[j].height;
            shape_info = { type: "rect", x: x * ratio, y: y * ratio, w: w * ratio, h: h * ratio };
            console.log("from 1396", shape_info);
          } else if (oResultArray[i].regions[j].selection_type === "ellipse") {
            let x = oResultArray[i].regions[j].x;
            let y = oResultArray[i].regions[j].y;
            let w = oResultArray[i].regions[j].width;
            let h = oResultArray[i].regions[j].height;
            shape_info = {
              type: "ellipse",
              x: x * ratio,
              y: y * ratio,
              w: w * ratio,
              h: h * ratio,
            };
          } else if (oResultArray[i].regions[j].selection_type === "polygon") {
            points = oResultArray[i].regions[j].points;

            let points_arr = points.split(" ");
            let points_dic = [];
            for (let p = 0; p < points_arr.length; p++) {
              let point = points_arr[p].split(",");
              points_dic.push({ x: point[0] * ratio, y: point[1] * ratio });
            }
            shape_info = { type: "polygon", points: points_dic };
          }

          oData[id].data.push({
            shape_id: oResultArray[i].regions[j].selection_id,
            shape_type: oResultArray[i].regions[j].selection_type,
            meta: oResultArray[i].regions[j].meta,
            x: oResultArray[i].regions[j].x,
            y: oResultArray[i].regions[j].y,
            width: oResultArray[i].regions[j].width,
            height: oResultArray[i].regions[j].height,
            key: i + "-" + j,
            points: oResultArray[i].regions[j].points,
            type: "Image",
            uniqueKey: uniqueKeyForData,
          });

          shapes[i + "-" + j] = shape_info;
          uniqueKeyForData++;
        } else if (oResultArray[i].regions[j].type === "Blank") {
          oData[id].data.push({
            shape_id: oResultArray[i].regions[j].selection_id,
            shape_type: oResultArray[i].regions[j].selection_type,
            meta: oResultArray[i].regions[j].meta,
            x: oResultArray[i].regions[j].x,
            y: oResultArray[i].regions[j].y,
            width: oResultArray[i].regions[j].width,
            height: oResultArray[i].regions[j].height,
            key: i + "-" + j,
            points: oResultArray[i].regions[j].points,
            type: "Blank",
            uniqueKey: uniqueKeyForData,
          });
          uniqueKeyForData++;
        } else if (oResultArray[i].regions[j].type === "Multi Line") {
          for (let k = 0; k < oResultArray[i].regions[j].lines.length; k++) {
            for (let l = 0; l < oResultArray[i].regions[j].lines[k].words.length; l++) {
              oData[id].data.push({
                shape_id: oResultArray[i].regions[j].selection_id,
                shape_type: oResultArray[i].regions[j].selection_type,
                meta: oResultArray[i].regions[j].meta,
                x: oResultArray[i].regions[j].lines[k].words[l].x,
                y: oResultArray[i].regions[j].lines[k].words[l].y,
                width: oResultArray[i].regions[j].lines[k].words[l].width,
                height: oResultArray[i].regions[j].lines[k].words[l].height,
                text: oResultArray[i].regions[j].lines[k].words[l].text,
                confidence: oResultArray[i].regions[j].lines[k].words[l].confidence,
                key: i + "-" + j + "-" + k + "-" + l,
                color:
                  oResultArray[i].regions[j].lines[k].words[l].confidence < 0.9 ? "red" : "black",
                originalText: "",
                type: "dataFromLine",
                uniqueKey: uniqueKeyForData,
              });
              uniqueKeyForData++;
            }
          }
        } else if (oResultArray[i].regions[j].type === "Handwritten") {
          if ("lines" in oResultArray[i].regions[j]) {
            for (let k = 0; k < oResultArray[i].regions[j].lines.length; k++) {
              for (let l = 0; l < oResultArray[i].regions[j].lines[k].words.length; l++) {
                oData[id].data.push({
                  shape_id: oResultArray[i].regions[j].selection_id,
                  shape_type: oResultArray[i].regions[j].selection_type,
                  meta: oResultArray[i].regions[j].meta,
                  x: oResultArray[i].regions[j].lines[k].words[l].x,
                  y: oResultArray[i].regions[j].lines[k].words[l].y,
                  width: oResultArray[i].regions[j].lines[k].words[l].width,
                  height: oResultArray[i].regions[j].lines[k].words[l].height,
                  text: oResultArray[i].regions[j].lines[k].words[l].text,
                  confidence: oResultArray[i].regions[j].lines[k].words[l].confidence,
                  key: i + "-" + j + "-" + k + "-" + l,
                  color:
                    oResultArray[i].regions[j].lines[k].words[l].confidence < 0.9 ? "red" : "black",
                  originalText: "",
                  type: "dataFromLine",
                  uniqueKey: uniqueKeyForData,
                });
                uniqueKeyForData++;
              }
            }
          }
        }
        //} else if(oResultArray[i].regions[j].type.match(/_Table/)) {
        else if (
          oResultArray[i].regions[j].type === "Table" ||
          oResultArray[i].regions[j].type.match(/_Table/)
        ) {
          for (let k = 0; k < oResultArray[i].regions[j].cells.length; k++) {
            oTable[id].data.push({
              shape_id: oResultArray[i].regions[j].selection_id,
              shape_type: oResultArray[i].regions[j].selection_type,
              meta: oResultArray[i].regions[j].meta,
              x: oResultArray[i].regions[j].cells[k].x,
              y: oResultArray[i].regions[j].cells[k].y,
              width: oResultArray[i].regions[j].cells[k].width,
              height: oResultArray[i].regions[j].cells[k].height,
              row_no: oResultArray[i].regions[j].cells[k].row_no,
              col_no: oResultArray[i].regions[j].cells[k].col_no,
              row_span: oResultArray[i].regions[j].cells[k].row_span,
              col_span: oResultArray[i].regions[j].cells[k].col_span,
              key: i + "-" + j + "-" + k,
              type: "borderFromTable",
            });
            for (let l = 0; l < oResultArray[i].regions[j].cells[k].cell.length; l++) {
              for (let m = 0; m < oResultArray[i].regions[j].cells[k].cell[l].words.length; m++) {
                if (oResultArray[i].regions[j].cells[k].cell[l].words[m].text !== "") {
                  oData[id].data.push({
                    shape_id: oResultArray[i].regions[j].selection_id,
                    shape_type: oResultArray[i].regions[j].selection_type,
                    meta: oResultArray[i].regions[j].meta,
                    x: oResultArray[i].regions[j].cells[k].cell[l].words[m].x,
                    y: oResultArray[i].regions[j].cells[k].cell[l].words[m].y,
                    width: oResultArray[i].regions[j].cells[k].cell[l].words[m].width,
                    height: oResultArray[i].regions[j].cells[k].cell[l].words[m].height,
                    text: oResultArray[i].regions[j].cells[k].cell[l].words[m].text,
                    confidence: oResultArray[i].regions[j].cells[k].cell[l].words[m].confidence,
                    key: i + "-" + j + "-" + k + "-" + l + "-" + m,  //page: i, regions: j, cells: k, cell: l, words: m
                    color:
                      oResultArray[i].regions[j].cells[k].cell[l].words[m].confidence < 0.9
                        ? "red"
                        : "black",
                    originalText: "",
                    type: "dataFromTable",
                    uniqueKey: uniqueKeyForData,
                  });
                  uniqueKeyForData++;
                }
              }
            }
          }
        }
      }
    }
    if (isSel) setFormat("crop");
    else setFormat("csv"); //tsv

    setDeepICRCTX({
      ...deepICRCTX,
      isSelection: isSel,
    });

    const eData = {};
    const eTable = {};
    const eResultArray = outputJson.extracted_output;
    Object.keys(eResultArray).forEach((key) => {
      if (key === "details") {
        for (let p in eResultArray[key].values) {
          let tables = {};
          for (let t in eResultArray[key].values[p]) {
            let rows = [];
            for (let i = 0; i < eResultArray[key].values[p][t].length; i++) {
              let cols = [];
              for (let j = 0; j < eResultArray[key].values[p][t][i].length; j++) {
                cols.push({
                  row: i,
                  column: j,
                  value: eResultArray[key].values[p][t][i][j],
                  originalValue: "",
                  color: "black",
                  null: eResultArray[key].values[p][t][i][j] === "" ? true : false,
                });
              }
              rows.push(cols);
            }
            tables[t] = rows;
          }
          eTable[p] = tables;
        }
      } else {
        eData[key] = [];
        if (eResultArray[key] !== undefined) {
          if (
            eResultArray[key].values !== undefined &&
            typeof eResultArray[key].values === "string"
          ) {
            eData[key] = {
              en_label: eResultArray[key].en_label,
              jp_label: eResultArray[key].jp_label,
              values: [
                {
                  key: 0,
                  value: eResultArray[key].values,
                  originalValue: "",
                  color: "black",
                  null: eResultArray[key].values === "" ? true : false,
                },
              ],
            };
          } else {
            if (eResultArray[key].values === undefined || eResultArray[key].values.length === 0) {
              eData[key] = {
                en_label: eResultArray[key].en_label,
                jp_label: eResultArray[key].jp_label,
                values: [
                  {
                    key: 0,
                    value: "",
                    originalValue: "",
                    color: "black",
                    null: true,
                  },
                ],
              };
            } else {
              let values = [];
              if (eResultArray[key].values !== undefined) {
                for (let i = 0; i < eResultArray[key].values.length; i++) {
                  values.push({
                    key: i,
                    value: eResultArray[key].values[i],
                    originalValue: "",
                    color: "black",
                    null: eResultArray[key].values[i] === "" ? true : false,
                  });
                }
              }
              eData[key] = {
                en_label: eResultArray[key].en_label,
                jp_label: eResultArray[key].jp_label,
                values: values,
              };
            }
          }
        }
      }
    });
    return [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes];
  };



  //-------------------------------------------------------------------------------------------------
  // Upload file to S3 and Convert by Deep ICR
  //-------------------------------------------------------------------------------------------------

  // const uploadAndConvert = async () => {
  //   if (typeof deepICRCTX.file.name === "undefined" || deepICRCTX.file.name === "") {
  //     props.enqueueSnackbar(t("errorBeforeSetFile"), {
  //       variant: "error",
  //       anchorOrigin: { vertical: "top", horizontal: "right" },
  //     });
  //     deepICRLogging({
  //       LogType: "ERROR",
  //       ErrType: "BeforeSetFileError",
  //       Message: t("errorBeforeSetFile"),
  //       Src: "Toolbar.js",
  //       Line: 0,
  //       Column: 0,
  //       Stack: "",
  //     });
  //     return;
  //   }

  //   if (deepICRCTX.file.name === deepICRCTX.requestedFile) {
  //     props.enqueueSnackbar(t("errorRequestSameFile"), {
  //       variant: "error",
  //       anchorOrigin: { vertical: "top", horizontal: "right" },
  //     });
  //     deepICRLogging({
  //       LogType: "ERROR",
  //       ErrType: "RequestSameFileError",
  //       Message: t("errorRequestSameFile"),
  //       Src: "Toolbar.js",
  //       Line: 0,
  //       Column: 0,
  //       Stack: "",
  //     });
  //     return;
  //   }

  //   // Upload image data and input json to S3
  //   const snackbarDoConvert = props.enqueueSnackbar(t("infoDoConvert") + deepICRCTX.file.name, {
  //     variant: "info",
  //     persist: true,
  //     anchorOrigin: { vertical: "bottom", horizontal: "right" },
  //   });
  //   const [yyyymmddhhmmss, unixtime, microsec] = deepICRNow();
  //   // Get hash of Username
  //   const md5 = crypto.createHash("md5");
  //   const md5hash = md5.update(deepICRCTX.cognitoUser.Username, "binary").digest("hex");

  //   // Refresh token
  //   let isError = false;
  //   let newAccessToken = "";
  //   let requestJson = {
  //     type: "request",
  //     head: {
  //       command: "refreshToken",
  //       format_version: deepICRCTX.apiFormatVersion,
  //       service_id: deepICRCTX.apiServiceId,
  //       transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
  //       unix_time: unixtime,
  //       micro_seconds: microsec,
  //       time_zone: deepICRCTX.apiTimeZone,
  //     },
  //     //      "body": {refreshToken: deepICRCTX.refreshToken, username: deepICRCTX.cognitoUser.Username}
  //     body: { refreshToken: global.refreshToken, username: deepICRCTX.cognitoUser.Username },
  //   };
  //   await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTokenRefresh, {
  //     method: "POST",
  //     mode: "cors",
  //     //        headers: {Authorization: deepICRCTX.accessToken, "Content-Type": "application/json"},
  //     headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
  //     body: JSON.stringify(requestJson),
  //   })
  //     .then((res) => {
  //       return res.json();
  //     })
  //     .then((json) => {
  //       // Timeout access token
  //       if (json.message === "Unauthorized") {
  //         props.closeSnackbar(snackbarDoConvert);
  //         props.enqueueSnackbar(t("errorLoginTimeout"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "LoginTimeoutError",
  //           Message: t("errorLoginTimeout"),
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         logout();
  //         isError = true;
  //         return;
  //       }
  //       if (json.body.status !== "OK") {
  //         if (json.body.error.message === "Token do not match") {
  //           props.closeSnackbar(snackbarDoConvert);
  //           props.enqueueSnackbar(t("errorLoginDuplicate"), {
  //             variant: "error",
  //             anchorOrigin: { vertical: "top", horizontal: "right" },
  //           });
  //           deepICRLogging({
  //             LogType: "ERROR",
  //             ErrType: "DuplicateLoginError",
  //             Message: t("errorLoginDuplicate"),
  //             Src: "Toolbar.js",
  //             Line: 0,
  //             Column: 0,
  //             Stack: "",
  //           });
  //           logout();
  //           isError = true;
  //           return;
  //         } else {
  //           if (deepICRCTX.debug === true) {
  //             console.log("[ToolBar - updateJson] token-refresh error for output json file");
  //           }
  //           if (deepICRCTX.debug === true) {
  //             console.log(JSON.stringify(json, null, 1));
  //           }
  //           props.closeSnackbar(snackbarDoConvert);
  //           props.enqueueSnackbar(t("errorSystemError"), {
  //             variant: "error",
  //             anchorOrigin: { vertical: "top", horizontal: "right" },
  //           });
  //           deepICRLogging({
  //             LogType: "ERROR",
  //             ErrType: "TokenRefreshFetchError",
  //             Message: "token-refresh error for output json file",
  //             Src: "Toolbar.js",
  //             Line: 0,
  //             Column: 0,
  //             Stack: "",
  //           });
  //           isError = true;
  //           return;
  //         }
  //       }
  //       newAccessToken = json.body.result.accessToken;
  //       global.accessToken = newAccessToken;
  //       // setDeepICRCTX({
  //       //   ...deepICRCTX,
  //       //   accessToken: json.body.result.accessToken
  //       // });
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - updateJson] token-refresh catch error for output json file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.closeSnackbar(snackbarDoConvert);
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "TokenRefreshCatchError",
  //         Message: "token-refresh catch error for output json file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });
  //   if (isError) {
  //     return;
  //   }

  //   // Get Presigned URL for image file
  //   let presignedUrl = "";
  //   requestJson.head.command = "getPresignedUrl";
  //   let putFileName = deepICRCTX.file.name;
  //   let putFileNamePre = "";
  //   if (deepICRCTX.file.type === "application/pdf") {
  //     let parts = deepICRCTX.file.name.split(".");
  //     parts.pop();
  //     putFileNamePre = parts.join(".");
  //     putFileName = putFileNamePre + ".zip";
  //   }
  //   requestJson.body = {
  //     keys: [deepICRCTX.s3Path + "/" + md5hash + "/" + yyyymmddhhmmss + "/" + putFileName],
  //     operation: "PUT",
  //   };
  //   await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
  //     method: "POST",
  //     mode: "cors",
  //     headers: { Authorization: newAccessToken, "Content-Type": "application/json" },
  //     body: JSON.stringify(requestJson),
  //   })
  //     .then((res) => {
  //       return res.json();
  //     })
  //     .then((json) => {
  //       if (json.body.status !== "OK") {
  //         if (deepICRCTX.debug === true) {
  //           console.log("[ToolBar - uploadAndConvert] get-signed-url error for image file");
  //         }
  //         if (deepICRCTX.debug === true) {
  //           console.log(JSON.stringify(json, null, 1));
  //         }
  //         props.enqueueSnackbar(t("errorSystemError"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "SignedUrlFetchError",
  //           Message: "get-signed-url error for image file",
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         isError = true;
  //         return;
  //       }
  //       presignedUrl = json.body.result.urls[0];
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - uploadAndConvert] get-signed-url catch error for image file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.closeSnackbar(snackbarDoConvert);
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "SignedUrlCatchError",
  //         Message: "get-signed-url catch error for image file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });
  //   if (isError) {
  //     return;
  //   }

  //   // Put image file to S3
  //   let binFile = "";
  //   let contentType = deepICRCTX.file.type;
  //   if (deepICRCTX.file.type === "image/jpeg") {
  //     const encodedFile = deepICRCTX.fileBase64[0].replace(/^data:\w+\/\w+;base64,/, "");
  //     binFile = new Buffer(encodedFile, "base64");
  //   } else {
  //     // Create Zip file
  //     const zip = new JSZip();
  //     const now = new Date();
  //     const dateWithOffset = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  //     try {
  //       zip.file(deepICRCTX.file.name, deepICRCTX.pdfBase64.replace(/^data:\w+\/\w+;base64,/, ""), {
  //         date: dateWithOffset,
  //         base64: true,
  //       });
  //       for (let i = 1; i <= deepICRCTX.pdfPages; i++) {
  //         zip.file(
  //           `${putFileNamePre}_${i}.jpg`,
  //           deepICRCTX.fileBase64[i - 1].replace(/^data:\w+\/\w+;base64,/, ""),
  //           { date: dateWithOffset, base64: true }
  //         );
  //       }
  //       zip.file(putFileNamePre + ".txt", JSON.stringify(deepICRCTX.fileSize), {
  //         date: dateWithOffset,
  //       });
  //       binFile = await zip.generateAsync({ type: "arraybuffer" });
  //       contentType = "application/zip";
  //     } catch (e) {
  //       if (deepICRCTX.debug === true) {
  //         if (deepICRCTX.debug === true) {
  //           console.log(e);
  //         }
  //       }
  //       props.closeSnackbar(snackbarDoConvert);
  //       props.enqueueSnackbar(t("errorZipProcess"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "ZipProcessError",
  //         Message: t("errorZipProcess"),
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     }
  //   }
  //   await fetch(presignedUrl, {
  //     method: "PUT",
  //     mode: "cors",
  //     headers: { "Content-Type": contentType },
  //     body: binFile,
  //   })
  //     .then((json) => {
  //       if (json.ok !== true) {
  //         if (deepICRCTX.debug === true) {
  //           console.log("[ToolBar - uploadAndConvert] fetch error for image file");
  //         }
  //         if (deepICRCTX.debug === true) {
  //           console.log(JSON.stringify(json, null, 1));
  //         }
  //         props.closeSnackbar(snackbarDoConvert);
  //         props.enqueueSnackbar(t("errorUpload"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "UploadError",
  //           Message: t("errorUpload"),
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         isError = true;
  //         return;
  //       }
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - uploadAndConvert] fetch catch error for image file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.closeSnackbar(snackbarDoConvert);
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       isError = true;
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "ImageFileCatchError",
  //         Message: "fetch catch error for image file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       return;
  //     });
  //   if (isError) {
  //     return;
  //   }

  //   // Get Presigned URL for input json file
  //   presignedUrl = "";
  //   requestJson.head.command = "getPresignedUrl";
  //   requestJson.body = {
  //     keys: [
  //       deepICRCTX.s3Path +
  //         "/" +
  //         md5hash +
  //         "/" +
  //         yyyymmddhhmmss +
  //         "/" +
  //         deepICRCTX.file.name.match(/(.*)(?:\.([^.]+$))/)[1] +
  //         "_in.json",
  //     ],
  //     operation: "PUT",
  //   };
  //   await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
  //     method: "POST",
  //     mode: "cors",
  //     headers: { Authorization: newAccessToken, "Content-Type": "application/json" },
  //     body: JSON.stringify(requestJson),
  //   })
  //     .then((res) => {
  //       return res.json();
  //     })
  //     .then((json) => {
  //       if (json.body.status !== "OK") {
  //         if (deepICRCTX.debug === true) {
  //           console.log("[ToolBar - uploadAndConvert] get-signed-url error for input json file");
  //         }
  //         if (deepICRCTX.debug === true) {
  //           console.log(JSON.stringify(json, null, 1));
  //         }
  //         props.closeSnackbar(snackbarDoConvert);
  //         props.enqueueSnackbar(t("errorSystemError"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "SignedUrlFetchError",
  //           Message: "get-signed-url error for input json file",
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         isError = true;
  //         return;
  //       }
  //       presignedUrl = json.body.result.urls[0];
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log(
  //           "[ToolBar - uploadAndConvert] get-signed-url catch error for input json file"
  //         );
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.closeSnackbar(snackbarDoConvert);
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "SignedUrlCatchError",
  //         Message: "get-signed-url catch error for input json file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });

  //   if (isError) {
  //     return;
  //   }

  //   // Put input json file to S3
  //   let pagesArray = [];
  //   if (deepICRCTX.targetPages !== "") {
  //     deepICRCTX.targetPages.split(",").forEach((item) => {
  //       pagesArray.push(isNaN(item) ? item : Number(item));
  //     });
  //   }
  //   const inputJson = {
  //     bucket_name: deepICRCTX.s3Bucket,
  //     img_path: deepICRCTX.s3Path + "/" + md5hash + "/" + yyyymmddhhmmss,
  //     img_file_name: putFileName,
  //     output_path: deepICRCTX.s3Path + "/" + md5hash + "/" + yyyymmddhhmmss,
  //     output_json_name: deepICRCTX.file.name.match(/(.*)(?:\.([^.]+$))/)[1] + "_out.json",
  //     target_type: type,
  //     custom_pages: pagesArray,
  //     pdf_pages: deepICRCTX.file.type === "application/pdf" ? deepICRCTX.pdfPages : 0,
  //     pdf_rotations: global.rotation,
  //     file_size: deepICRCTX.file.size,
  //     selection_info: deepICRCTX.shapeList,
  //   };
  //   await fetch(presignedUrl, {
  //     method: "PUT",
  //     mode: "cors",
  //     headers: { "Content-Type": "application/json" },
  //     body: JSON.stringify(inputJson, null, 4),
  //   })
  //     .then((json) => {
  //       if (json.ok !== true) {
  //         if (deepICRCTX.debug === true) {
  //           console.log("[ToolBar - uploadAndConvert] fetch error for input json file");
  //         }
  //         if (deepICRCTX.debug === true) {
  //           console.log(JSON.stringify(json, null, 1));
  //         }
  //         props.closeSnackbar(snackbarDoConvert);
  //         props.enqueueSnackbar(t("errorUpload"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "UploadError",
  //           Message: t("errorUpload"),
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         isError = true;
  //         return;
  //       }
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - uploadAndConvert] fetch catch error for input json file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.closeSnackbar(snackbarDoConvert);
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "ImageFileCatchError",
  //         Message: "fetch catch error for input json file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });

  //   if (isError) {
  //     return;
  //   }

  //   setDeepICRCTX({
  //     ...deepICRCTX,
  //     documentId: "",
  //     requestedFile: deepICRCTX.file.name,
  //     originalOutputFontScale: 1,
  //     originalOutputSize: { height: 0, width: 0 },
  //     originalOutputData: { data: [] },
  //     originalOutputTable: { data: [] },
  //     extractedOutputData: { data: [] },
  //     extractedOutputTable: { data: [] },
  //     searchText: "",
  //     outputSw: false,
  //   });

  //   // Check response from Deep ICR
  //   requestJson.body = {
  //     key:
  //       deepICRCTX.s3Path +
  //       "/" +
  //       md5hash +
  //       "/" +
  //       yyyymmddhhmmss +
  //       "/" +
  //       deepICRCTX.file.name.match(/(.*)(?:\.([^.]+$))/)[1] +
  //       "_out.json",
  //   };
  //   const checkS3 = (time, limit, counter) => {
  //     setTimeout(() => {
  //       console.log("polling...");
  //       fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiPolling, {
  //         method: "POST",
  //         mode: "cors",
  //         headers: { Authorization: newAccessToken, "Content-Type": "application/json" },
  //         body: JSON.stringify(requestJson),
  //       })
  //         .then((res) => {
  //           return res.json();
  //         })
  //         .then((json) => {
  //           if (json.body.status !== "OK") {
  //             if (deepICRCTX.debug === true) {
  //               console.log("[ToolBar - uploadAndConvert] polling error");
  //             }
  //             if (deepICRCTX.debug === true) {
  //               console.log(JSON.stringify(json, null, 1));
  //             }
  //             props.closeSnackbar(snackbarDoConvert);
  //             props.enqueueSnackbar(t("errorSystemError"), {
  //               variant: "error",
  //               anchorOrigin: { vertical: "top", horizontal: "right" },
  //             });
  //             deepICRLogging({
  //               LogType: "ERROR",
  //               ErrType: "PollingError",
  //               Message: "Polling error",
  //               Src: "Toolbar.js",
  //               Line: 0,
  //               Column: 0,
  //               Stack: "",
  //             });
  //             setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //             isError = true;
  //             return;
  //           } else if (json.body.result === "Exists") {
  //             props.closeSnackbar(snackbarDoConvert);

  //             // Get Presigned URL for input json file
  //             requestJson.body = {
  //               keys: [
  //                 deepICRCTX.s3Path +
  //                   "/" +
  //                   md5hash +
  //                   "/" +
  //                   yyyymmddhhmmss +
  //                   "/" +
  //                   deepICRCTX.file.name.match(/(.*)(?:\.([^.]+$))/)[1] +
  //                   "_out.json",
  //               ],
  //               operation: "GET",
  //             };
  //             presignedUrl = "";
  //             Promise.resolve()
  //               .then(() => {
  //                 return new Promise((resolve, reject) => {
  //                   fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
  //                     method: "POST",
  //                     mode: "cors",
  //                     headers: {
  //                       Authorization: newAccessToken,
  //                       "Content-Type": "application/json",
  //                     },
  //                     body: JSON.stringify(requestJson),
  //                   })
  //                     .then((res) => {
  //                       return res.json();
  //                     })
  //                     .then((json) => {
  //                       if (json.body.status !== "OK") {
  //                         if (deepICRCTX.debug === true) {
  //                           console.log(
  //                             "[ToolBar - uploadAndConvert] get-signed-url error for output json file"
  //                           );
  //                         }
  //                         if (deepICRCTX.debug === true) {
  //                           console.log(JSON.stringify(json, null, 1));
  //                         }
  //                         deepICRLogging({
  //                           LogType: "ERROR",
  //                           ErrType: "SignedUrlFetchError",
  //                           Message: "get-signed-url error for output json file",
  //                           Src: "Toolbar.js",
  //                           Line: 0,
  //                           Column: 0,
  //                           Stack: "",
  //                         });
  //                         reject("error");
  //                       } else {
  //                         resolve(json.body.result.urls[0]);
  //                       }
  //                     })
  //                     .catch((err) => {
  //                       if (deepICRCTX.debug === true) {
  //                         console.log(
  //                           "[ToolBar - uploadAndConvert] get-signed-url catch error for output json file"
  //                         );
  //                       }
  //                       if (deepICRCTX.debug === true) {
  //                         console.log(err);
  //                       }
  //                       deepICRLogging({
  //                         LogType: "ERROR",
  //                         ErrType: "SignedUrlCatchError",
  //                         Message: "get-signed-url catch error for output json file",
  //                         Src: "Toolbar.js",
  //                         Line: 0,
  //                         Column: 0,
  //                         Stack: "",
  //                       });
  //                       reject(err);
  //                     });
  //                 });
  //               })
  //               .then((presignedUrl) => {
  //                 return new Promise((resolve, reject) => {
  //                   fetch(presignedUrl, {
  //                     method: "GET",
  //                     mode: "cors",
  //                   })
  //                     .then((res) => {
  //                       return res.text();
  //                     })
  //                     .then((text) => {
  //                       let outputJson = JSON.parse(text);
  //                       if (
  //                         outputJson.statusCode === null ||
  //                         outputJson.statusCode === undefined ||
  //                         outputJson.statusCode.length === 0 ||
  //                         (outputJson.statusCode.length > 0 && outputJson.statusCode[0] !== 200) ||
  //                         (typeof outputJson.statusCode !== "object" &&
  //                           outputJson.statusCode !== 200)
  //                       ) {
  //                         if (deepICRCTX.debug === true) {
  //                           console.log(
  //                             "[ToolBar - uploadAndConvert] fetch error for output json file"
  //                           );
  //                         }
  //                         if (deepICRCTX.debug === true) {
  //                           console.log(JSON.stringify(outputJson, null, 1));
  //                         }
  //                         props.enqueueSnackbar(t("errorConvert"), {
  //                           variant: "error",
  //                           persist: true,
  //                           anchorOrigin: { vertical: "top", horizontal: "right" },
  //                         });
  //                         deepICRLogging({
  //                           LogType: "ERROR",
  //                           ErrType: "ConvertError",
  //                           Message: t("errorConvert"),
  //                           Src: "Toolbar.js",
  //                           Line: 0,
  //                           Column: 0,
  //                           Stack: "",
  //                         });
  //                         setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //                         isError = true;
  //                         return;
  //                       }

  //                       // Refresh token
  //                       requestJson.head.command = "refreshToken";
  //                       //                  requestJson.body = {refreshToken: deepICRCTX.refreshToken, username: deepICRCTX.cognitoUser.Username};
  //                       requestJson.body = {
  //                         refreshToken: global.refreshToken,
  //                         username: deepICRCTX.cognitoUser.Username,
  //                       };
  //                       fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTokenRefresh, {
  //                         method: "POST",
  //                         mode: "cors",
  //                         //                      headers: {Authorization: deepICRCTX.accessToken, "Content-Type": "application/json"},
  //                         headers: {
  //                           Authorization: global.accessToken,
  //                           "Content-Type": "application/json",
  //                         },
  //                         body: JSON.stringify(requestJson),
  //                       })
  //                         .then((res) => {
  //                           return res.json();
  //                         })
  //                         .then((json) => {
  //                           // Timeout access token
  //                           if (json.message === "Unauthorized") {
  //                             props.enqueueSnackbar(t("errorLoginTimeout"), {
  //                               variant: "error",
  //                               anchorOrigin: { vertical: "top", horizontal: "right" },
  //                             });
  //                             deepICRLogging({
  //                               LogType: "ERROR",
  //                               ErrType: "LoginTimeoutError",
  //                               Message: t("errorLoginTimeout"),
  //                               Src: "Toolbar.js",
  //                               Line: 0,
  //                               Column: 0,
  //                               Stack: "",
  //                             });
  //                             logout();
  //                             isError = true;
  //                             return;
  //                           }
  //                           if (json.body.status !== "OK") {
  //                             if (json.body.error.message === "Token do not match") {
  //                               props.enqueueSnackbar(t("errorLoginDuplicate"), {
  //                                 variant: "error",
  //                                 anchorOrigin: { vertical: "top", horizontal: "right" },
  //                               });
  //                               deepICRLogging({
  //                                 LogType: "ERROR",
  //                                 ErrType: "DuplicateLoginError",
  //                                 Message: t("errorLoginDuplicate"),
  //                                 Src: "Toolbar.js",
  //                                 Line: 0,
  //                                 Column: 0,
  //                                 Stack: "",
  //                               });
  //                               logout();
  //                               isError = true;
  //                               return;
  //                             } else {
  //                               if (deepICRCTX.debug === true) {
  //                                 console.log(
  //                                   "[ToolBar - uploadAndConvert] token-refresh error after convert success"
  //                                 );
  //                               }
  //                               if (deepICRCTX.debug === true) {
  //                                 console.log(JSON.stringify(json, null, 1));
  //                               }
  //                               props.enqueueSnackbar(t("errorSystemError"), {
  //                                 variant: "error",
  //                                 anchorOrigin: { vertical: "top", horizontal: "right" },
  //                               });
  //                               deepICRLogging({
  //                                 LogType: "ERROR",
  //                                 ErrType: "TokenRefreshFetchError",
  //                                 Message: t("tracFetchError"),
  //                                 Src: "Toolbar.js",
  //                                 Line: 0,
  //                                 Column: 0,
  //                                 Stack: "",
  //                               });
  //                               setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //                               isError = true;
  //                               return;
  //                             }
  //                           }
  //                           newAccessToken = json.body.result.accessToken;
  //                           global.accessToken = newAccessToken;

  //                           const isContract = outputJson.target_type === "contract" ? true : false;
  //                           setJson(outputJson);
  //                           let oDataHeight = 0;
  //                           let oDataWidth = 0;
  //                           let oData = {};
  //                           let oTable = {};
  //                           let eData = [];
  //                           let eTable = [];
  //                           let shapes = {};
  //                           [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes] =
  //                             parseOutputJson(outputJson);
  //                           const file = deepICRCTX.file;
  //                           file.yyyymmddhhmmss = yyyymmddhhmmss;
  //                           setDeepICRCTX({
  //                             ...deepICRCTX,
  //                             //                      accessToken: newAccessToken,
  //                             isContract: isContract,
  //                             outputTab: 0,
  //                             file: file,
  //                             requestedFile: "",
  //                             originalOutputSize: { height: oDataHeight, width: oDataWidth },
  //                             originalOutputData: { data: oData },
  //                             originalOutputTable: { data: oTable },
  //                             extractedOutputData: { data: eData },
  //                             extractedOutputTable: { data: eTable },
  //                             croppedImages: shapes,
  //                             outputSw: true,
  //                           });
  //                         })
  //                         .catch((err) => {
  //                           if (deepICRCTX.debug === true) {
  //                             console.log(
  //                               "[ToolBar - uploadAndConvert] token-refresh catch error after convert success"
  //                             );
  //                           }
  //                           if (deepICRCTX.debug === true) {
  //                             console.log(err);
  //                           }
  //                           props.enqueueSnackbar(t("errorSystemError"), {
  //                             variant: "error",
  //                             anchorOrigin: { vertical: "top", horizontal: "right" },
  //                           });
  //                           deepICRLogging({
  //                             LogType: "ERROR",
  //                             ErrType: "TokenRefreshCatchError",
  //                             Message: "token-refresh catch error after convert success",
  //                             Src: "Toolbar.js",
  //                             Line: 0,
  //                             Column: 0,
  //                             Stack: "",
  //                           });
  //                           setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //                           isError = true;
  //                           return;
  //                         });
  //                       if (isError) {
  //                         return;
  //                       }
  //                     })
  //                     .catch((err) => {
  //                       if (deepICRCTX.debug === true) {
  //                         console.log(
  //                           "[ToolBar - uploadAndConvert] fetch catch error for output json file"
  //                         );
  //                       }
  //                       if (deepICRCTX.debug === true) {
  //                         console.log(err);
  //                       }
  //                       deepICRLogging({
  //                         LogType: "ERROR",
  //                         ErrType: "OutputJsonCatchError",
  //                         Message: "fetch catch error for output json file",
  //                         Src: "Toolbar.js",
  //                         Line: 0,
  //                         Column: 0,
  //                         Stack: "",
  //                       });
  //                       reject(err);
  //                     });
  //                 });
  //               })
  //               .catch((err) => {
  //                 if (deepICRCTX.debug === true) {
  //                   console.log(
  //                     "[ToolBar - uploadAndConvert] get-signed-url catch error for output json file"
  //                   );
  //                 }
  //                 if (deepICRCTX.debug === true) {
  //                   console.log(err);
  //                 }
  //                 props.enqueueSnackbar(t("errorSystemError"), {
  //                   variant: "error",
  //                   anchorOrigin: { vertical: "top", horizontal: "right" },
  //                 });
  //                 deepICRLogging({
  //                   LogType: "ERROR",
  //                   ErrType: "SignedUrlCatchError",
  //                   Message: "get-signed-url catch error for output json file",
  //                   Src: "Toolbar.js",
  //                   Line: 0,
  //                   Column: 0,
  //                   Stack: "",
  //                 });
  //                 setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //                 isError = true;
  //                 return;
  //               });
  //           } else {
  //             if (counter < limit) {
  //               counter++;
  //               checkS3(time, limit, counter);
  //             } else {
  //               props.closeSnackbar(snackbarDoConvert);
  //               props.enqueueSnackbar(t("errorCannotConvert"), {
  //                 variant: "error",
  //                 persist: true,
  //                 anchorOrigin: { vertical: "top", horizontal: "right" },
  //               });
  //               deepICRLogging({
  //                 LogType: "ERROR",
  //                 ErrType: "CovertError",
  //                 Message: t("errorCannotConvert"),
  //                 Src: "Toolbar.js",
  //                 Line: 0,
  //                 Column: 0,
  //                 Stack: "",
  //               });

  //               // Refresh token
  //               requestJson.head.command = "refreshToken";
  //               // requestJson.body = {refreshToken: deepICRCTX.refreshToken, username: deepICRCTX.cognitoUser.Username};
  //               requestJson.body = {
  //                 refreshToken: global.refreshToken,
  //                 username: deepICRCTX.cognitoUser.Username,
  //               };

  //               fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTokenRefresh, {
  //                 method: "POST",
  //                 mode: "cors",
  //                 // headers: {Authorization: deepICRCTX.accessToken, "Content-Type": "application/json"},
  //                 headers: {
  //                   Authorization: global.accessToken,
  //                   "Content-Type": "application/json",
  //                 },
  //                 body: JSON.stringify(requestJson),
  //               })
  //                 .then((res) => {
  //                   return res.json();
  //                 })
  //                 .then((json) => {
  //                   // Timeout access token
  //                   if (json.message === "Unauthorized") {
  //                     props.enqueueSnackbar(t("errorLoginTimeout"), {
  //                       variant: "error",
  //                       anchorOrigin: { vertical: "top", horizontal: "right" },
  //                     });
  //                     deepICRLogging({
  //                       LogType: "ERROR",
  //                       ErrType: "LoginTimeoutError",
  //                       Message: t("errorLoginTimeout"),
  //                       Src: "Toolbar.js",
  //                       Line: 0,
  //                       Column: 0,
  //                       Stack: "",
  //                     });
  //                     logout();
  //                     isError = true;
  //                     return;
  //                   }
  //                   if (json.body.status !== "OK") {
  //                     if (json.body.error.message === "Token do not match") {
  //                       props.enqueueSnackbar(t("errorLoginDuplicate"), {
  //                         variant: "error",
  //                         anchorOrigin: { vertical: "top", horizontal: "right" },
  //                       });
  //                       deepICRLogging({
  //                         LogType: "ERROR",
  //                         ErrType: "DuplicateLoginError",
  //                         Message: t("errorLoginDuplicate"),
  //                         Src: "Toolbar.js",
  //                         Line: 0,
  //                         Column: 0,
  //                         Stack: "",
  //                       });
  //                       logout();
  //                       isError = true;
  //                       return;
  //                     } else {
  //                       if (deepICRCTX.debug === true) {
  //                         console.log(
  //                           "[ToolBar - uploadAndConvert] token-refresh error after convert failure"
  //                         );
  //                       }
  //                       if (deepICRCTX.debug === true) {
  //                         console.log(JSON.stringify(json, null, 1));
  //                       }
  //                       props.enqueueSnackbar(t("errorSystemError"), {
  //                         variant: "error",
  //                         anchorOrigin: { vertical: "top", horizontal: "right" },
  //                       });
  //                       deepICRLogging({
  //                         LogType: "ERROR",
  //                         ErrType: "TokenRefreshError",
  //                         Message: "token-refresh error after convert failure",
  //                         Src: "Toolbar.js",
  //                         Line: 0,
  //                         Column: 0,
  //                         Stack: "",
  //                       });
  //                       setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //                       isError = true;
  //                       return;
  //                     }
  //                   }
  //                   global.accessToken = json.body.result.accessToken;
  //                   // setDeepICRCTX({
  //                   //   ...deepICRCTX,
  //                   //   accessToken: json.body.result.accessToken
  //                   // });
  //                 })
  //                 .catch((err) => {
  //                   if (deepICRCTX.debug === true) {
  //                     console.log(
  //                       "[ToolBar - uploadAndConvert] token-refresh catch error after convert failure"
  //                     );
  //                   }
  //                   if (deepICRCTX.debug === true) {
  //                     console.log(err);
  //                   }
  //                   props.enqueueSnackbar(t("errorSystemError"), {
  //                     variant: "error",
  //                     anchorOrigin: { vertical: "top", horizontal: "right" },
  //                   });
  //                   deepICRLogging({
  //                     LogType: "ERROR",
  //                     ErrType: "TokenRefreshError",
  //                     Message: "token-refresh catch error after convert failure",
  //                     Src: "Toolbar.js",
  //                     Line: 0,
  //                     Column: 0,
  //                     Stack: "",
  //                   });
  //                   setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //                   isError = true;
  //                   return;
  //                 });
  //               if (isError) {
  //                 return;
  //               }
  //             }
  //           }
  //         })
  //         .catch((err) => {
  //           if (deepICRCTX.debug === true) {
  //             console.log("[ToolBar - uploadAndConvert] polling catch error");
  //           }
  //           if (deepICRCTX.debug === true) {
  //             console.log(err);
  //           }
  //           props.closeSnackbar(snackbarDoConvert);
  //           props.enqueueSnackbar(t("errorSystemError"), {
  //             variant: "error",
  //             anchorOrigin: { vertical: "top", horizontal: "right" },
  //           });
  //           deepICRLogging({
  //             LogType: "ERROR",
  //             ErrType: "PollingCatchError",
  //             Message: "Polling Catch Error",
  //             Src: "Toolbar.js",
  //             Line: 0,
  //             Column: 0,
  //             Stack: "",
  //           });

  //           setDeepICRCTX({ ...deepICRCTX, requestedFile: "" });
  //           isError = true;
  //           return;
  //         });
  //       if (isError) {
  //         return;
  //       }
  //     }, time);
  //   };
  //   checkS3(deepICRCTX.setTimeoutTime, deepICRCTX.setTimeoutLimit, 1);
  // };

  //-------------------------------------------------------------------------------------------------
  //local_environment
  //-------------------------------------------------------------------------------------------------
  const uploadAndConvert = async () => {
    console.log("Same file name", deepICRCTX.file.name, "Requested file", deepICRCTX.requestedFile);
    if ((deepICRCTX.file.name === deepICRCTX.requestedFile)) {
      props.enqueueSnackbar(
        t('errorRequestSameFile'),
        { variant: 'error', anchorOrigin: { vertical: 'top', horizontal: 'right' } }
      );
      deepICRLogging({
        "LogType": "ERROR",
        "ErrType": "RequestSameFileError",
        "Message": t('errorRequestSameFile'),
        "Src": "Toolbar.js",
        "Line": 0,
        "Column": 0,
        "Stack": ""
      });
      return;
    }
    const snackbarDoConvert = props.enqueueSnackbar(
      t('infoDoConvert') + deepICRCTX.file.name,
      {
        variant: 'info',
        persist: true,
        anchorOrigin: { vertical: 'bottom', horizontal: 'right' }
      }
    );
    const isContract = false;
    const [yyyymmddhhmmss, unixtime, microsec] = deepICRNow();
    console.log(unixtime, microsec, isContract);

    let putFileName = deepICRCTX.file.name;

    let pagesArray = [];
    if (deepICRCTX.targetPages !== "") {
      deepICRCTX.targetPages.split(',').forEach((item) => {
        pagesArray.push(isNaN(item) ? item : Number(item));
      });
    }
    console.log("Rotation Value:", global.rotation);

    const inputJson = {
      "bucket_name": deepICRCTX.s3Bucket,
      "img_path": deepICRCTX.s3Path,
      "img_file_name": putFileName,
      "output_path": deepICRCTX.s3Path,
      "output_json_name": deepICRCTX.file.name.match(/(.*)(?:\.([^.]+$))/)[1] + '_out.json',
      "target_type": type,
      "custom_pages": pagesArray,
      "pdf_pages": deepICRCTX.file.type === 'application/pdf' ? deepICRCTX.pdfPages : 0,
      "pdf_rotations": global.rotation,
      "file_size": deepICRCTX.file.size,
      "selection_info": deepICRCTX.shapeList,
    };

    setDeepICRCTX({
      ...deepICRCTX,
      documentId: "",
      isContract: false,
      requestedFile: deepICRCTX.file.name,
      originalOutputFontScale: 1,
      originalOutputSize: { height: 0, width: 0 },
      originalOutputData: { data: [] },
      originalOutputTable: { data: [] },
      extractedOutputData: { data: [] },
      extractedOutputTable: { data: [] },
      searchText: "",
      outputSw: false,
      selectedRegion:{
        pages:[]
      },
    });

    // Upload Reqest Json
    let file_name = deepICRCTX.file.name.split(".");
    file_name[file_name.length - 1] = "json";
    file_name = file_name.join(".");

    fetch('http://' + host_address + ':5000?json=' + JSON.stringify(inputJson, null, 2) + "&filename=" + encodeURI(file_name), {
      method: "GET",
      mode: "cors",
      rejectUnauthorized: false
    })
      .then(response => {
        return response.json();
      }).then(json => {
        console.log(json);
        if (json["Status"] === "Success") {
          console.log("Selection json load Successfully");
          fetch('http://' + host_address + ':5000/input/' + file_name)
            .then(response => {
              console.log("Selection Response: ", response)
              return response.json();
            })
            .then(json => {
              let shape_list = JSON.parse(JSON.stringify(json)).selection_info;
              console.log("Shape List:", shape_list);
              setDeepICRCTX({
                ...deepICRCTX,
                shapeList: shape_list,
              });
              checkDeepStorage(deepICRCTX.setTimeoutTime, 100, 1);
            })
            .catch(er => {
              deepICRLogging({
                "LogType": "ERROR",
                "ErrType": "NetworkError",
                "Message": er.message,
                "Src": "Toolbar.js",
                "Line": 0,
                "Column": 0,
                "Stack": ""
              });
              return;
            })
        }
      })
      .catch(er => {
        console.log("TEST2:", er.message, er.stack);
        deepICRLogging({
          "LogType": "ERROR",
          "ErrType": "NetworkError",
          "Message": er.message,
          "Src": "Toolbar.js",
          "Line": 0,
          "Column": 0,
          "Stack": ""
        });
        return;
      })

    const checkDeepStorage = (time, limit, counter) => {
      setTimeout(() => {
        console.log("polling...");
        fetch('http://' + host_address + ':5000/output/' + encodeURI(file_name))
          .then(response => {
            return response.json();
          })
          .then(json => {
            console.log(json);
            let outputJson = JSON.parse(JSON.stringify(json));
            setJson(outputJson);

            const file = deepICRCTX.file;
            file.yyyymmddhhmmss = yyyymmddhhmmss

            let oDataHeight = 0;
            let oDataWidth = 0;
            let oData = {};
            let oTable = {};
            let eData = [];
            let eTable = [];
            let shapes = {};

            [oDataHeight, oDataWidth, oData, oTable, eData, eTable, shapes] = parseOutputJson(outputJson);

            // console.log("aaa", oDataHeight, oDataWidth,);
            // console.log("aaa", oData,);
            // console.log("aaa", oTable,);
            // console.log("aaa", eData,);
            // console.log("aaa", eTable,);
            // console.log("aaa", shapes);


            props.closeSnackbar(snackbarDoConvert);

            setDeepICRCTX({
              ...deepICRCTX,
              // accessToken: newAccessToken,
              outputJson: outputJson,
              isContract: isContract,
              outputTab: 0,
              file: file,
              requestedFile: "",
              originalOutputSize: { height: oDataHeight, width: oDataWidth },
              originalOutputData: { data: oData },
              originalOutputTable: { data: oTable },
              extractedOutputData: { data: eData },
              extractedOutputTable: { data: eTable },
              croppedImages: shapes,
              outputSw: true,
            });

          })
          .catch(err => {
            console.log(err);
            counter++;
            if (counter < limit) {
              checkDeepStorage(time, limit, counter);
            }
            else {
              console.log("ERROR:", [err]);
              deepICRLogging({
                "LogType": "ERROR",
                "ErrType": "NetworkError",
                "Message": err.message,
                "Src": "Toolbar.js",
                "Line": 0,
                "Column": 0,
                "Stack": ""
              });
              const errorSnackBar = props.enqueueSnackbar(
                "Time Out.. please convert again",
                {
                  variant: 'error',
                  persist: true,
                  anchorOrigin: { vertical: 'bottom', horizontal: 'right' }
                }
              );
              props.closeSnackbar(errorSnackBar);
            }
          });
      }, time);
    }

  }


  //-------------------------------------------------------------------------------------------------
  // Set select value/type
  //-------------------------------------------------------------------------------------------------
  const setSelectValue = (e) => setFormat(e.target.value);
  const setSelectType = (e) => setType(e.target.value);

  //-------------------------------------------------------------------------------------------------
  // Download TSV/HTML/JSON file
  //-------------------------------------------------------------------------------------------------
  const downloadCSV = () => {
    if (deepICRCTX.outputSw === false && deepICRCTX.documentId === "") {
      props.enqueueSnackbar(t("errorDownloadNothing"), {
        variant: "error",
        anchorOrigin: { vertical: "top", horizontal: "right" },
      });
      deepICRLogging({
        LogType: "ERROR",
        ErrType: "DownloadError",
        Message: t("errorDownloadNothing"),
        Src: "Toolbar.js",
        Line: 0,
        Column: 0,
        Stack: "",
      });
      return;
    }

    let fileNameArray = deepICRCTX.file.name.split(".");
    fileNameArray.pop();
    let filename = fileNameArray.join(".");
    let data = "";

    // Process by format (TSV=default/HTML/HTML(Zip)/JSON)
    if (format === "html" || format === "htmlzip") {
      // Download HTML data
      const title = filename;
      filename += ".html";
      const ratio =
        deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.originalOutputData.data[1].width;

      let startPosition = format === "html" ? 8 : 40;

      // html head
      let html = "<!DOCTYPE html>\n";
      html += '<html lang="ja">\n';
      html += "<head>\n";
      html += '<meta charset="utf-8" />\n';
      html += '<meta name="viewport" content="width=device-width, initial-scale=1" />\n';
      html += '<meta name="description" content="Deep ICR" />\n';
      html += "<title>" + title + "</title>\n";
      html += "</head>\n";

      // html body
      html += "<body>\n";
      if (format === "htmlzip") {
        html +=
          '<a href="' +
          encodeURI(deepICRCTX.file.name) +
          `" target="_brank">${deepICRCTX.file.name}</a>\n`;
      }
      if (deepICRCTX.isSelection) {
        let selectionOutput = {};
        if (objectSize(deepICRCTX.originalOutputData.data) > 0) {
          for (let i in deepICRCTX.originalOutputData.data) {
            let textData = deepICRCTX.originalOutputData.data[i].data;
            let tableData = deepICRCTX.originalOutputTable.data[i].data;
            let selOutput = {};

            for (let ti in textData) {
              let td = textData[ti];
              if ("shape_id" in td) {
                let shape_id = td["shape_id"];
                if (shape_id in selOutput && "text" in selOutput[shape_id]) {
                  selOutput[shape_id].text.push(td);
                } else if (shape_id in selOutput && !("text" in selOutput[shape_id])) {
                  selOutput[shape_id]["text"] = [td];
                } else {
                  selOutput[shape_id] = {};
                  selOutput[shape_id]["text"] = [td];
                }
              }
            }

            for (let tj in tableData) {
              let td = tableData[tj];
              if ("shape_id" in td) {
                let shape_id = td["shape_id"];
                if (shape_id in selOutput && "cell" in selOutput[shape_id]) {
                  selOutput[shape_id].cell.push(td);
                } else if (shape_id in selOutput && !("cell" in selOutput[shape_id])) {
                  selOutput[shape_id]["cell"] = [td];
                } else {
                  selOutput[shape_id] = {};
                  selOutput[shape_id]["cell"] = [td];
                }
              }
            }

            for (let key in selOutput) {
              let selection = selOutput[key];
              let x = Infinity,
                y = Infinity,
                w = -Infinity,
                h = -Infinity;
              let meta = "";
              if ("text" in selection) {
                let texts = selection["text"];
                for (let i = 0; i < texts.length; i++) {
                  if (x > texts[i].x) x = texts[i].x;
                  if (w < texts[i].x + texts[i].width) w = texts[i].x + texts[i].width;
                  if (y > texts[i].y) y = texts[i].y;
                  if (h < texts[i].y + texts[i].height) h = texts[i].y + texts[i].height;
                  meta = texts[i].meta;
                }
              }
              if ("cell" in selection) {
                let cells = selection["cell"];
                for (let i = 0; i < cells.length; i++) {
                  if (x > cells[i].x) x = cells[i].x;
                  if (w < cells[i].x + cells[i].width) w = cells[i].x + cells[i].width;
                  if (y > cells[i].y) y = cells[i].y;
                  if (h < cells[i].y + cells[i].height) h = cells[i].y + cells[i].height;
                  meta = cells[i].meta;
                }
              }
              selOutput[key]["x"] = x;
              selOutput[key]["y"] = y;
              selOutput[key]["width"] = w - x;
              selOutput[key]["height"] = h - y;
              selOutput[key]["meta"] = meta;
            }
            let sortable = [];
            for (let shape_id in selOutput) {
              sortable.push([shape_id, selOutput[shape_id]]);
            }

            sortable.sort(function (a, b) {
              return a[0].split("_")[1] - b[0].split("_")[1];
            });

            let output = {};
            for (let x = 0; x < sortable.length; x++) {
              output["" + sortable[x][0]] = deepCopy(sortable[x][1]);
            }
            selectionOutput[i] = output;
          }

          for (let page in selectionOutput) {
            html +=
              '<div style="padding:10px;position:absolute;left:8px;top:' +
              startPosition +
              "px;width:" +
              deepICRCTX.originalOutputData.data[page].width * ratio +
              "px;min-height:" +
              deepICRCTX.originalOutputData.data[page].height * ratio +
              'px;border:1px solid #ddd;margin-bottom:8px;">';
            for (let s in selectionOutput[page]) {
              let texts = selectionOutput[page][s].text;
              let cells = selectionOutput[page][s].cell;

              let x = selectionOutput[page][s].x;
              let y = selectionOutput[page][s].y;
              let w = selectionOutput[page][s].width;
              let h = selectionOutput[page][s].height;
              let meta = selectionOutput[page][s].meta;

              html +=
                '<div style="margin-top:16px;display:block;position:relative;max-width:' +
                w * ratio +
                'px;height:auto;">' +
                meta +
                "</div>";
              html +=
                '<div style="border:1px solid #ddd;display:block;position:relative;width:' +
                w * ratio +
                "px;height:" +
                h * ratio +
                'px;">';

              if (cells) {
                for (let i = 0; i < cells.length; i++) {
                  let cx = cells[i].x;
                  let cy = cells[i].y;
                  let cw = cells[i].width;
                  let ch = cells[i].height;
                  html +=
                    '<div style="border:1px solid #000;position:absolute;left:' +
                    Math.abs(x - cx) * ratio +
                    "px;top:" +
                    Math.abs(y - cy) * ratio +
                    "px;width:" +
                    cw * ratio +
                    "px;height:" +
                    ch * ratio +
                    'px;"></div>';
                }
              }

              if (texts) {
                for (let i = 0; i < texts.length; i++) {
                  let tx = texts[i].x;
                  let ty = texts[i].y;
                  let tw = texts[i].width;
                  let th = texts[i].height;
                  let txt = texts[i].text;
                  if (texts[i].type === "Image") {
                    html +=
                      '<img src="' +
                      deepICRCTX.croppedImages[texts[i].key] +
                      '" style="position:absolute;left:' +
                      Math.abs(x - tx) * ratio +
                      "px;top:" +
                      Math.abs(y - ty) * ratio +
                      "px;width:" +
                      tw * ratio +
                      "px;height:" +
                      th * ratio +
                      'px;">';
                  } else {
                    html +=
                      '<div style="font-size:' +
                      th * ratio * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale +
                      "px;position:absolute;left:" +
                      Math.abs(x - tx) * ratio +
                      "px;top:" +
                      Math.abs(y - ty) * ratio +
                      "px;width:" +
                      tw * ratio +
                      "px;height:" +
                      th * ratio +
                      'px;">' +
                      txt +
                      "</div>";
                  }
                }
              }
              html += "</div>";
            }

            // for (let i in deepICRCTX.originalOutputTable.data[page].data) {
            //   html += '<div style="position:absolute;left:'
            //     + (8 + (deepICRCTX.originalOutputTable.data[page].data[i].x * ratio)) + 'px;top:'
            //     + (startPosition + (deepICRCTX.originalOutputTable.data[page].data[i].y * ratio)) + 'px;width:'
            //     + (deepICRCTX.originalOutputTable.data[page].data[i].width * ratio) + 'px;height:'
            //     + (deepICRCTX.originalOutputTable.data[page].data[i].height * ratio)
            //     + 'px;border:1px solid;"></div>\n';
            //}
            // for (let i in deepICRCTX.originalOutputData.data[page].data) {
            //   html += '<div style="position:absolute;left:'
            //     + (8 + (deepICRCTX.originalOutputData.data[page].data[i].x * ratio)) + 'px;top:'
            //     + (startPosition + (deepICRCTX.originalOutputData.data[page].data[i].y * ratio)) + 'px;width:'
            //     + (deepICRCTX.originalOutputData.data[page].data[i].width * ratio) + 'px;height:'
            //     + (deepICRCTX.originalOutputData.data[page].data[i].height * ratio) + 'px;font-size:'
            //     + (deepICRCTX.originalOutputData.data[page].data[i].height * ratio * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale) + 'px;color:'
            //     + deepICRCTX.originalOutputData.data[page].data[i].color + ';padding:0;margin:0;white-space:nowrap">'
            //     + deepICRCTX.originalOutputData.data[page].data[i].text + '</div>\n';
            //}

            html += "</div>\n";
            startPosition =
              startPosition + 8 + deepICRCTX.originalOutputData.data[page].height * ratio;
          }
        }
      } else {
        for (let page in deepICRCTX.originalOutputData.data) {
          html +=
            '<div style="position:absolute;left:8px;top:' +
            startPosition +
            "px;width:" +
            deepICRCTX.originalOutputData.data[page].width * ratio +
            "px;height:" +
            deepICRCTX.originalOutputData.data[page].height * ratio +
            'px;border:1px solid;margin-bottom:8px;"></div>\n';
          for (let i in deepICRCTX.originalOutputTable.data[page].data) {
            html +=
              '<div style="position:absolute;left:' +
              (8 + deepICRCTX.originalOutputTable.data[page].data[i].x * ratio) +
              "px;top:" +
              (startPosition + deepICRCTX.originalOutputTable.data[page].data[i].y * ratio) +
              "px;width:" +
              deepICRCTX.originalOutputTable.data[page].data[i].width * ratio +
              "px;height:" +
              deepICRCTX.originalOutputTable.data[page].data[i].height * ratio +
              'px;border:1px solid;"></div>\n';
          }
          for (let i in deepICRCTX.originalOutputData.data[page].data) {
            html +=
              '<div style="position:absolute;left:' +
              (8 + deepICRCTX.originalOutputData.data[page].data[i].x * ratio) +
              "px;top:" +
              (startPosition + deepICRCTX.originalOutputData.data[page].data[i].y * ratio) +
              "px;width:" +
              deepICRCTX.originalOutputData.data[page].data[i].width * ratio +
              "px;height:" +
              deepICRCTX.originalOutputData.data[page].data[i].height * ratio +
              "px;font-size:" +
              deepICRCTX.originalOutputData.data[page].data[i].height *
              ratio *
              deepICRCTX.originalOutputFontScale *
              deepICRCTX.fontScale +
              "px;color:" +
              deepICRCTX.originalOutputData.data[page].data[i].color +
              ';padding:0;margin:0;white-space:nowrap">' +
              deepICRCTX.originalOutputData.data[page].data[i].text +
              "</div>\n";
          }
          startPosition =
            startPosition + 8 + deepICRCTX.originalOutputData.data[page].height * ratio;
        }
      }
      html += "<br><br>\n";
      html += "</body>\n";
      html += "<html>\n";

      if (format === "html") {
        deepICRDownload(deepICRtoBlobWithBom(html, "text/html"), filename);
      } else {
        // format === 'htmlzip'
        const zip = new JSZip();
        const now = new Date();
        const dateWithOffset = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
        try {
          zip.file(filename, deepICRtoBlobWithBom(html, "text/html"), { date: dateWithOffset });
        } catch (e) {
          if (deepICRCTX.debug === true) {
            if (deepICRCTX.debug === true) {
              console.log(e);
            }
          }
          props.enqueueSnackbar(t("errorZipProcess"), {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          deepICRLogging({
            LogType: "ERROR",
            ErrType: "ZipProcessError",
            Message: t("errorZipProcess"),
            Src: "Toolbar.js",
            Line: 0,
            Column: 0,
            Stack: "",
          });
          return;
        }

        // Add pdf/jpeg file to zip
        if (deepICRCTX.file.type === "image/jpeg") {
          const base64Array = deepICRCTX.fileBase64[0].split(";base64,", 2);
          zip.file(deepICRCTX.file.name, base64Array[1], { date: dateWithOffset, base64: true });
        } else {
          let newPdf = "";
          try {
            let orientation =
              deepICRCTX.fileSize[0].width > deepICRCTX.fileSize[0].height
                ? "landscape"
                : "portrait";
            const pdf = new jsPDF({
              unit: "px",
              format: [deepICRCTX.fileSize[0].width, deepICRCTX.fileSize[0].height],
              orientation: orientation,
            });
            for (let i = 0; i < deepICRCTX.pdfPages; i++) {
              if (i > 0) {
                orientation =
                  deepICRCTX.fileSize[i].width > deepICRCTX.fileSize[i].height
                    ? "landscape"
                    : "portrait";
                pdf.addPage(
                  [deepICRCTX.fileSize[i].width, deepICRCTX.fileSize[i].height],
                  orientation
                );
              }
              pdf.addImage(
                deepICRCTX.fileBase64[i],
                "JPEG",
                0,
                0,
                deepICRCTX.fileSize[i].width,
                deepICRCTX.fileSize[i].height
              );
            }
            newPdf = pdf.output("datauristring", "new.pdf");
          } catch (e) {
            if (deepICRCTX.debug === true) {
              if (deepICRCTX.debug === true) {
                console.log(e);
              }
            }
            props.enqueueSnackbar(t("errorPdfToJpegProcess"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "PdfToJpegProcessError",
              Message: t("errorPdfToJpegProcess"),
              Src: "Toolbar.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
            return;
          }
          try {
            zip.file(
              deepICRCTX.file.type === "application/pdf" ? title + ".pdf" : title + ".jpg",
              newPdf.split(";base64,", 2)[1],
              { date: dateWithOffset, base64: true }
            );
          } catch (e) {
            if (deepICRCTX.debug === true) {
              console.log(e);
            }
            props.enqueueSnackbar(t("errorZipProcess"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "ZipProcessError",
              Message: t("errorZipProcess"),
              Src: "Toolbar.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
            return;
          }
        }

        // Create zip file
        zip
          .generateAsync({ type: "blob" })
          .then((blob) => deepICRDownload(blob, title + ".zip"))
          .catch((e) => {
            if (deepICRCTX.debug === true) {
              console.log(e);
            }
            props.enqueueSnackbar(t("errorZipProcess"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "ZipProcessError",
              Message: t("errorZipProcess"),
              Src: "Toolbar.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
            return;
          });
      }
    } else if (format === "json") {
      // Download JSON data
      filename += ".json";

      // Reflecting the change for Original Output Data
      const oChangeTextArray = deepICRCTX.originalOutputData.data;
      for (let keyPage in oChangeTextArray) {
        const numberRegexp = new RegExp(/^[0-9]+$/);
        if (!numberRegexp.test(keyPage)) continue;
        for (let keyItem in oChangeTextArray[keyPage].data) {
          if (!numberRegexp.test(keyItem)) continue;
          if (oChangeTextArray[keyPage].data[keyItem].color === "blue") {
            let i, j, k, l, m;
            if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromLine") {
              [i, j, k, l, m] = ["", "", "", "", ""];

              if (oChangeTextArray[keyPage].data[keyItem].key.split("-").length === 4) {
                [i, j, k, l] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              } else {
                [i, j, k] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              }

              if (
                json.original_output.pages[i].regions[j].type === "Multi Line" ||
                json.original_output.pages[i].regions[j].type === "Handwritten"
              ) {
                if (
                  json.original_output.pages[i].regions[j].lines[k].words[l].text !==
                  oChangeTextArray[keyPage].data[keyItem].originalText
                ) {
                  if (deepICRCTX.debug === true)
                    console.log(
                      "blue text unmatch " +
                      json.original_output.pages[i].regions[j].lines[k].words[l].text +
                      ":" +
                      oChangeTextArray[keyPage].data[keyItem].originalText
                    );
                }
                json.original_output.pages[i].regions[j].lines[k].words[l].text =
                  oChangeTextArray[keyPage].data[keyItem].text;
              } else {
                if (
                  json.original_output.pages[i].regions[j].words[k].text !==
                  oChangeTextArray[keyPage].data[keyItem].originalText
                ) {
                  if (deepICRCTX.debug === true)
                    console.log(
                      "blue text unmatch " +
                      json.original_output.pages[i].regions[j].words[k].text +
                      ":" +
                      oChangeTextArray[keyPage].data[keyItem].originalText
                    );
                }
                json.original_output.pages[i].regions[j].words[k].text =
                  oChangeTextArray[keyPage].data[keyItem].text;
              }
            } else if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromTable") {
              [i, j, k, l, m] = ["", "", "", "", ""];
              [i, j, k, l, m] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              if (
                json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text !==
                oChangeTextArray[keyPage].data[keyItem].originalText
              ) {
                if (deepICRCTX.debug === true)
                  console.log(
                    "blue text unmatch " +
                    json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text +
                    ":" +
                    oChangeTextArray[keyPage].data[keyItem].originalText
                  );
              }
              json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text =
                oChangeTextArray[keyPage].data[keyItem].text;
            }
          }
        }
      }

      // Reflecting the change for Extracted Output Data
      const eChangeTextArray = deepICRCTX.extractedOutputData.data;
      for (let key in eChangeTextArray) {
        for (let i = 0; i < eChangeTextArray[key].values.length; i++) {
          if (eChangeTextArray[key].values[i].originalValue !== "") {
            json.extracted_output[key].values[i] = eChangeTextArray[key].values[i].value;
          }
        }
      }
      const eChangeTableTextArray = deepICRCTX.extractedOutputTable.data;
      for (let page in eChangeTableTextArray) {
        for (let table in eChangeTableTextArray[page]) {
          for (let i = 0; i < eChangeTableTextArray[page][table].length; i++) {
            for (let j = 0; j < eChangeTableTextArray[page][table][i].length; j++) {
              if (eChangeTableTextArray[page][table][i][j] !== "") {
                json.extracted_output["details"].values[page][table][i][j] =
                  eChangeTableTextArray[page][table][i][j].value;
              }
            }
          }
        }
      }
      deepICRDownload(
        deepICRtoBlobWithBom(JSON.stringify(json, undefined, 1), "application/json"),
        filename
      );
    } else if (format === "crop") {
      const title = filename;
      const zip = new JSZip();
      const now = new Date();
      const dateWithOffset = new Date(now.getTime() - now.getTimezoneOffset() * 60000);

      const ratio =
        deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.originalOutputData.data[1].width;

      let startPosition = 8;

      // html head
      let html = "<!DOCTYPE html>\n";
      html += '<html lang="ja">\n';
      html += "<head>\n";
      html += '<meta charset="utf-8" />\n';
      html += '<meta name="viewport" content="width=device-width, initial-scale=1" />\n';
      html += '<meta name="description" content="Deep ICR" />\n';
      html += "<title>" + title + "</title>\n";
      html += "</head>\n";

      // html body
      html += "<body>\n";

      let selectionOutput = {};
      if (objectSize(deepICRCTX.originalOutputData.data) > 0) {
        for (let i in deepICRCTX.originalOutputData.data) {
          let textData = deepICRCTX.originalOutputData.data[i].data;
          let tableData = deepICRCTX.originalOutputTable.data[i].data;
          let selOutput = {};

          for (let ti in textData) {
            let td = textData[ti];
            if ("shape_id" in td) {
              let shape_id = td["shape_id"];
              if (shape_id in selOutput && "text" in selOutput[shape_id]) {
                selOutput[shape_id].text.push(td);
              } else if (shape_id in selOutput && !("text" in selOutput[shape_id])) {
                selOutput[shape_id]["text"] = [td];
              } else {
                selOutput[shape_id] = {};
                selOutput[shape_id]["text"] = [td];
              }
            }
          }

          for (let tj in tableData) {
            let td = tableData[tj];
            if ("shape_id" in td) {
              let shape_id = td["shape_id"];
              if (shape_id in selOutput && "cell" in selOutput[shape_id]) {
                selOutput[shape_id].cell.push(td);
              } else if (shape_id in selOutput && !("cell" in selOutput[shape_id])) {
                selOutput[shape_id]["cell"] = [td];
              } else {
                selOutput[shape_id] = {};
                selOutput[shape_id]["cell"] = [td];
              }
            }
          }

          for (let key in selOutput) {
            let selection = selOutput[key];
            let x = Infinity,
              y = Infinity,
              w = -Infinity,
              h = -Infinity;
            let meta = "";
            if ("text" in selection) {
              let texts = selection["text"];
              for (let i = 0; i < texts.length; i++) {
                if (x > texts[i].x) x = texts[i].x;
                if (w < texts[i].x + texts[i].width) w = texts[i].x + texts[i].width;
                if (y > texts[i].y) y = texts[i].y;
                if (h < texts[i].y + texts[i].height) h = texts[i].y + texts[i].height;
                meta = texts[i].meta;
              }
            }
            if ("cell" in selection) {
              let cells = selection["cell"];
              for (let i = 0; i < cells.length; i++) {
                if (x > cells[i].x) x = cells[i].x;
                if (w < cells[i].x + cells[i].width) w = cells[i].x + cells[i].width;
                if (y > cells[i].y) y = cells[i].y;
                if (h < cells[i].y + cells[i].height) h = cells[i].y + cells[i].height;
                meta = cells[i].meta;
              }
            }
            selOutput[key]["x"] = x;
            selOutput[key]["y"] = y;
            selOutput[key]["width"] = w - x;
            selOutput[key]["height"] = h - y;
            selOutput[key]["meta"] = meta;
          }
          let sortable = [];
          for (let shape_id in selOutput) {
            sortable.push([shape_id, selOutput[shape_id]]);
          }

          sortable.sort(function (a, b) {
            return a[0].split("_")[1] - b[0].split("_")[1];
          });

          let output = {};
          for (let x = 0; x < sortable.length; x++) {
            output["" + sortable[x][0]] = deepCopy(sortable[x][1]);
          }
          selectionOutput[i] = output;
        }
        let index = 1; //added to fix image loading issue in html output
        for (let page in selectionOutput) {
          if (page === "documentName") continue;

          let documentId = deepICRCTX.originalOutputData.data[index].id; //added to fix image loading issue in html output

          html +=
            '<div style="padding:10px;position:absolute;left:8px;top:' +
            startPosition +
            "px;width:" +
            deepICRCTX.originalOutputData.data[page].width * ratio +
            "px;min-height:" +
            deepICRCTX.originalOutputData.data[page].height * ratio +
            'px;border:1px solid #ddd;margin-bottom:8px;">';
          for (let s in selectionOutput[page]) {
            let texts = selectionOutput[page][s].text;
            let cells = selectionOutput[page][s].cell;

            let x = selectionOutput[page][s].x;
            let y = selectionOutput[page][s].y;
            let w = selectionOutput[page][s].width;
            let h = selectionOutput[page][s].height;
            let meta = selectionOutput[page][s].meta;

            html +=
              '<div style="margin-top:16px;display:block;position:relative;max-width:' +
              w * ratio +
              'px;height:auto;">' +
              meta +
              "</div>";
            html +=
              '<div style="border:1px solid #ddd;display:block;position:relative;width:' +
              w * ratio +
              "px;height:" +
              h * ratio +
              'px;">';

            if (cells) {
              for (let i = 0; i < cells.length; i++) {
                let cx = cells[i].x;
                let cy = cells[i].y;
                let cw = cells[i].width;
                let ch = cells[i].height;
                html +=
                  '<div style="border:1px solid #000;position:absolute;left:' +
                  Math.abs(x - cx) * ratio +
                  "px;top:" +
                  Math.abs(y - cy) * ratio +
                  "px;width:" +
                  cw * ratio +
                  "px;height:" +
                  ch * ratio +
                  'px;"></div>';
              }
            }

            if (texts) {
              for (let i = 0; i < texts.length; i++) {
                let tx = texts[i].x;
                let ty = texts[i].y;
                let tw = texts[i].width;
                let th = texts[i].height;
                let txt = texts[i].text;
                if (texts[i].type === "Image") {
                  html +=
                    '<img src="' +
                    documentId +
                    "__" +
                    s +
                    ".jpg" +
                    '" style="position:absolute;left:' +
                    Math.abs(x - tx) * ratio +
                    "px;top:" +
                    Math.abs(y - ty) * ratio +
                    "px;width:" +
                    tw * ratio +
                    "px;height:" +
                    th * ratio +
                    'px;"/>'; //added to fix image loading issue in html output
                } else {
                  html +=
                    '<div style="font-size:' +
                    th * ratio * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale +
                    "px;position:absolute;left:" +
                    Math.abs(x - tx) * ratio +
                    "px;top:" +
                    Math.abs(y - ty) * ratio +
                    "px;width:" +
                    tw * ratio +
                    "px;height:" +
                    th * ratio +
                    'px;">' +
                    txt +
                    "</div>";
                }
              }
            }
            html += "</div>";
          }
          html += "</div>";
          startPosition =
            startPosition + 8 + deepICRCTX.originalOutputData.data[page].height * ratio;
          index++; //added to fix image loading issue in html output
        }
      }

      html += "<br><br>\n";
      html += "</body>\n";
      html += "<html>\n";

      try {
        zip.folder(filename).file(filename + ".html", deepICRtoBlobWithBom(html, "text/html"), {
          date: dateWithOffset,
        });
      } catch (e) {
        if (deepICRCTX.debug === true) {
          console.log(e);
        }
        props.enqueueSnackbar(t("errorZipProcess"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        deepICRLogging({
          LogType: "ERROR",
          ErrType: "ZipProcessError",
          Message: t("errorZipProcess"),
          Src: "Toolbar.js",
          Line: 0,
          Column: 0,
          Stack: "",
        });
        return;
      }

      // Add pdf/jpeg file to zip
      const oChangeTextArray = deepICRCTX.originalOutputData.data;
      for (let keyPage in oChangeTextArray) {
        const numberRegexp = new RegExp(/^[0-9]+$/);
        if (!numberRegexp.test(keyPage)) continue;
        for (let keyItem in oChangeTextArray[keyPage].data) {
          if (!numberRegexp.test(keyItem)) continue;
          if (oChangeTextArray[keyPage].data[keyItem].color === "blue") {
            let i, j, k, l, m;
            if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromLine") {
              [i, j, k, l, m] = ["", "", "", "", ""];

              if (oChangeTextArray[keyPage].data[keyItem].key.split("-").length === 4) {
                [i, j, k, l] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              } else {
                [i, j, k] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              }

              if (
                json.original_output.pages[i].regions[j].type === "Multi Line" ||
                json.original_output.pages[i].regions[j].type === "Handwritten"
              ) {
                if (
                  json.original_output.pages[i].regions[j].lines[k].words[l].text !==
                  oChangeTextArray[keyPage].data[keyItem].originalText
                ) {
                  if (deepICRCTX.debug === true)
                    console.log(
                      "blue text unmatch " +
                      json.original_output.pages[i].regions[j].lines[k].words[l].text +
                      ":" +
                      oChangeTextArray[keyPage].data[keyItem].originalText
                    );
                }
                json.original_output.pages[i].regions[j].lines[k].words[l].text =
                  oChangeTextArray[keyPage].data[keyItem].text;
              } else {
                if (
                  json.original_output.pages[i].regions[j].words[k].text !==
                  oChangeTextArray[keyPage].data[keyItem].originalText
                ) {
                  if (deepICRCTX.debug === true)
                    console.log(
                      "blue text unmatch " +
                      json.original_output.pages[i].regions[j].words[k].text +
                      ":" +
                      oChangeTextArray[keyPage].data[keyItem].originalText
                    );
                }
                json.original_output.pages[i].regions[j].words[k].text =
                  oChangeTextArray[keyPage].data[keyItem].text;
              }
            } else if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromTable") {
              [i, j, k, l, m] = ["", "", "", "", ""];
              [i, j, k, l, m] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              if (
                json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text !==
                oChangeTextArray[keyPage].data[keyItem].originalText
              ) {
                if (deepICRCTX.debug === true)
                  console.log(
                    "blue text unmatch " +
                    json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text +
                    ":" +
                    oChangeTextArray[keyPage].data[keyItem].originalText
                  );
              }
              json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text =
                oChangeTextArray[keyPage].data[keyItem].text;
            }
          }
        }
      }

      try {
        zip
          .folder(filename)
          .file(
            filename + ".json",
            deepICRtoBlobWithBom(JSON.stringify(json, null, 2), "application/json"),
            { date: dateWithOffset }
          );
      } catch (e) {
        if (deepICRCTX.debug === true) {
          console.log(e);
        }
        props.enqueueSnackbar(t("errorZipProcess"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        deepICRLogging({
          LogType: "ERROR",
          ErrType: "ZipProcessError",
          Message: t("errorZipProcess"),
          Src: "Toolbar.js",
          Line: 0,
          Column: 0,
          Stack: "",
        });
        return;
      }

      if ("original_output" in json) {
        console.log({ json });
        let originalOutput = json["original_output"];
        if ("document_name" in originalOutput) {
          if ("pages" in originalOutput) {
            let pages = originalOutput["pages"];

            for (let i = 0; i < pages.length; i++) {
              let page = pages[i];
              let page_id = page["id"];

              if ("regions" in page) {
                let regions = page["regions"];
                for (let j = 0; j < regions.length; j++) {
                  let region = regions[j];

                  let shape_id = "";
                  if ("selection_id" in region) {
                    shape_id = region["selection_id"];
                  }

                  let meta = "";
                  if ("meta" in region) {
                    meta = region["meta"];
                  }

                  if (region["type"] === "Single Line") {
                    let words = region["words"];
                    words.sort(function (a, b) {
                      return a.x - b.x;
                    });
                    let text = "" + meta + "\n";
                    for (let k = 0; k < words.length; k++) {
                      if (k === 0) text += '"' + words[k]["text"] + '"';
                      else text += `\t"${words[k]["text"]}"`;
                    }
                    try {
                      zip
                        .folder(filename)
                        .file(
                          page_id + "__" + shape_id + ".tsv",
                          deepICRtoBlobWithBom(text, "text/plain"),
                          { date: dateWithOffset }
                        );
                    } catch (e) {
                      if (deepICRCTX.debug === true) {
                        console.log(e);
                      }
                      props.enqueueSnackbar(t("errorZipProcess"), {
                        variant: "error",
                        anchorOrigin: { vertical: "top", horizontal: "right" },
                      });
                      deepICRLogging({
                        LogType: "ERROR",
                        ErrType: "ZipProcessError",
                        Message: t("errorZipProcess"),
                        Src: "Toolbar.js",
                        Line: 0,
                        Column: 0,
                        Stack: "",
                      });
                      return;
                    }
                  }
                  if (region["type"] === "Image") {
                    let key = i + "-" + j;

                    try {
                      if (
                        key in deepICRCTX.croppedImages &&
                        "data" in deepICRCTX.croppedImages[key]
                      ) {
                        const base64Array = deepICRCTX.croppedImages[key].data.split(";base64,", 2);
                        zip
                          .folder(filename)
                          .file(page_id + "__" + shape_id + ".jpg", base64Array[1], {
                            date: dateWithOffset,
                            base64: true,
                          });
                      }
                    } catch (e) {
                      if (deepICRCTX.debug === true) {
                        console.log(e);
                      }
                      props.enqueueSnackbar(t("errorZipProcess"), {
                        variant: "error",
                        anchorOrigin: { vertical: "top", horizontal: "right" },
                      });
                      deepICRLogging({
                        LogType: "ERROR",
                        ErrType: "ZipProcessError",
                        Message: t("errorZipProcess"),
                        Src: "Toolbar.js",
                        Line: 0,
                        Column: 0,
                        Stack: "",
                      });
                      return;
                    }
                  }
                  if (region["type"] === "Multi Line") {
                    if ("lines" in region) {
                      let lines = region["lines"];
                      lines.sort(function (a, b) {
                        return a["y"] - b["y"] || a["x"] - b["y"];
                      });
                      let text = "" + meta + "\n";
                      for (let i = 0; i < lines.length; i++) {
                        if ("words" in lines[i]) {
                          let words = lines[i]["words"];
                          words.sort(function (a, b) {
                            return a.x - b.x;
                          });

                          if (i !== 0) text += "\n";

                          for (let k = 0; k < words.length; k++) {
                            if (k === 0) text += '"' + words[k]["text"] + '"';
                            else text += `\t"${words[k]["text"]}"`;
                          }
                        }
                      }
                      try {
                        zip
                          .folder(filename)
                          .file(
                            page_id + "__" + shape_id + ".tsv",
                            deepICRtoBlobWithBom(text, "text/plain"),
                            { date: dateWithOffset }
                          );
                      } catch (e) {
                        if (deepICRCTX.debug === true) {
                          console.log(e);
                        }
                        props.enqueueSnackbar(t("errorZipProcess"), {
                          variant: "error",
                          anchorOrigin: { vertical: "top", horizontal: "right" },
                        });
                        deepICRLogging({
                          LogType: "ERROR",
                          ErrType: "ZipProcessError",
                          Message: t("errorZipProcess"),
                          Src: "Toolbar.js",
                          Line: 0,
                          Column: 0,
                          Stack: "",
                        });
                        return;
                      }
                    }
                  }
                  if (region["type"] === "Handwritten") {
                    if ("lines" in region) {
                      let lines = region["lines"];
                      lines.sort(function (a, b) {
                        return a["y"] - b["y"] || a["x"] - b["y"];
                      });
                      let text = "" + meta + "\n";
                      for (let i = 0; i < lines.length; i++) {
                        if ("words" in lines[i]) {
                          let words = lines[i]["words"];
                          words.sort(function (a, b) {
                            return a.x - b.x;
                          });

                          if (i !== 0) text += "\n";

                          for (let k = 0; k < words.length; k++) {
                            if (k === 0) text += '"' + words[k]["text"] + '"';
                            else text += `\t"${words[k]["text"]}"`;
                          }
                        }
                      }
                      try {
                        zip
                          .folder(filename)
                          .file(
                            page_id + "__" + shape_id + ".tsv",
                            deepICRtoBlobWithBom(text, "text/plain"),
                            { date: dateWithOffset }
                          );
                      } catch (e) {
                        console.log(e);
                        props.enqueueSnackbar(t("errorZipProcess"), {
                          variant: "error",
                          anchorOrigin: { vertical: "top", horizontal: "right" },
                        });
                        deepICRLogging({
                          LogType: "ERROR",
                          ErrType: "ZipProcessError",
                          Message: t("errorZipProcess"),
                          Src: "Toolbar.js",
                          Line: 0,
                          Column: 0,
                          Stack: "",
                        });
                        return;
                      }
                    }
                  }
                  if (region["type"] === "Table") {
                    let row = region["row"];
                    let col = region["column"];

                    let table = [];
                    for (let i = 0; i < row; i++) {
                      let row_val = [];
                      for (let j = 0; j < col; j++) {
                        let col_val = "";
                        row_val.push(col_val);
                      }
                      table.push(row_val);
                    }

                    if ("cells" in region) {
                      let cells = region["cells"];
                      for (let i = 0; i < cells.length; i++) {
                        let row_no = cells[i]["row_no"];
                        let col_no = cells[i]["col_no"];
                        let row_span = cells[i]["row_span"];
                        let col_span = cells[i]["col_span"];

                        if ("cell" in cells[i]) {
                          let lines = cells[i]["cell"];
                          lines.sort(function (a, b) {
                            return a["y"] - b["y"] || a["x"] - b["y"];
                          });
                          let text = "";
                          for (let i = 0; i < lines.length; i++) {
                            if ("words" in lines[i]) {
                              let words = lines[i]["words"];
                              words.sort(function (a, b) {
                                return a.x - b.x;
                              });
                              if (i !== 0) text += "\n";
                              for (let k = 0; k < words.length; k++) {
                                if (k === 0) text += words[k]["text"];
                                else text += " " + words[k]["text"];
                              }
                            }
                          }

                          for (let i = row_no; i < row_no + row_span; i++) {
                            for (let j = col_no; j < col_no + col_span; j++) {
                              table[i][j] = '"' + text + '"';
                            }
                          }
                        }
                      }
                    }
                    let table_text = "" + meta + "\n";
                    for (let i = 0; i < row; i++) {
                      if (i !== 0) table_text += "\n";
                      for (let j = 0; j < col; j++) {
                        if (j === 0) table_text += table[i][j];
                        else table_text += "\t" + table[i][j];
                      }
                    }
                    try {
                      zip
                        .folder(filename)
                        .file(
                          page_id + "__" + shape_id + ".tsv",
                          deepICRtoBlobWithBom(table_text, "text/plain"),
                          { date: dateWithOffset }
                        );
                    } catch (e) {
                      if (deepICRCTX.debug === true) {
                        console.log(e);
                      }
                      props.enqueueSnackbar(t("errorZipProcess"), {
                        variant: "error",
                        anchorOrigin: { vertical: "top", horizontal: "right" },
                      });
                      deepICRLogging({
                        LogType: "ERROR",
                        ErrType: "ZipProcessError",
                        Message: t("errorZipProcess"),
                        Src: "Toolbar.js",
                        Line: 0,
                        Column: 0,
                        Stack: "",
                      });
                      return;
                    }
                  }
                }
              }
            }
          }
        }
      }

      // Create zip file
      zip
        .generateAsync({ type: "blob" })
        .then((blob) => deepICRDownload(blob, title + ".zip"))
        .catch((e) => {
          if (deepICRCTX.debug === true) {
            console.log(e);
          }
          props.enqueueSnackbar(t("errorZipProcess"), {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          deepICRLogging({
            LogType: "ERROR",
            ErrType: "ZipProcessError",
            Message: t("errorZipProcess"),
            Src: "Toolbar.js",
            Line: 0,
            Column: 0,
            Stack: "",
          });
          return;
        });
    } else if (format === "csv") {
      // console.log("Entered else lese", deepICRCTX.originalOutputData);
      filename += `_${formatYYYYMMDDHHMMSS(new Date())}.csv`;
      let pageName = deepICRCTX.outputJson.original_output.document_name.split(".")
      pageName.pop();
      pageName = pageName.join(".")
      //if shape  avaialble
      if (isthereAnySHape(deepICRCTX.shapeListRight)) {
        for (let i = 0; i < deepICRCTX.selectedRegion.pages.length; i++) {
          // console.log(deepICRCTX.selectedRegion.pages[i]);
          for (let j = 0; j < deepICRCTX.selectedRegion?.pages[i]?.regions?.length; j++) {
            let objData = deepICRCTX.selectedRegion.pages[i].regions[j];
            // objData[]

            for (let item in objData) {
              // console.log("item", objData[item]);
              let objectInfo = `${pageName}_page_${objData[item].pageInfo.split("_").pop()}_object_${j + 1}${objData[item].meta ? "_" + objData[item].meta : ""}`
            let cells = objData[item].cells.map(c => c.cell.length ? c.cell.map(u => u.words[0].text) : null);

              // console.log("cells data", cells.flat().filter(v => v !== null));
              let newObjectData = cells.flat().filter(v => v !== null).map(val => '"' + (val ? commaRemovingFromNumberValue(val).replace(/"/g, '""') : '') + '"').join(",");
              // console.log("new object data", newObjectData);
              data += '"' + objectInfo + '"' + "," + newObjectData + "\n";
            }
            // console.log(`page: ${i+1} obj:${j+1} ${JSON.stringify(seletedRegions.pages[i].regions[j])}`);
          }
        }
        console.log("data", data);
        deepICRDownload(deepICRtoBlobWithBom(data, "text/csv;charset=utf-18"), filename);
        
        return
      } 
      else {
        let keys = Object.keys(deepICRCTX.originalOutputData.data);
        for (let i = 0; i < keys.length; i++) {
          if (keys[i] !== "documentName") {
            // For tsv
            // const pageNumber = keys[i];
            // data = data + '"' + deepICRCTX.originalOutputData.data[pageNumber].id + "\"\n";
            // data = data + deepICRCTX.originalOutputData.data[pageNumber].data.map(data => '"' + (data.text ? data.text.replace(/"/g, '""') : '') + '"').join("\n");
            // data = data + "\n";

            // for csv
            const pageNumber = keys[i];
            // console.log("data", deepICRCTX.originalOutputData.data[pageNumber]);
            data = data + '"' + deepICRCTX.originalOutputData.data[pageNumber].id + "\",";
            data = data + deepICRCTX.originalOutputData.data[pageNumber].data.map(data => '"' + (data.text ?
              commaRemovingFromNumberValue(data.text)
                .replace(/"/g, '""') : '') + '"').join(",");
            data = data + "\n";
          }
        }
        // console.log("data", data);
        deepICRDownload(deepICRtoBlobWithBom(data, "text/csv"), filename);

      }

    }
    else {
      if (deepICRCTX.outputTab === 1) {
        // Download TSV of Extracted data
        filename += "_extracted.tsv";

        const dataArray = deepICRCTX.extractedOutputData.data;
        const tableArray = deepICRCTX.extractedOutputTable.data;
        for (let key in dataArray) {
          let d_val = dataArray[key].values.map((row) =>
            row.value
              ? typeof row.value === "string"
                ? '"' + row.value.replace(/"/g, '""') + '"'
                : row.value
              : ""
          );
          data += '"' + key + '"\t' + d_val.join("\t") + "\n";
        }
        for (let p in tableArray) {
          for (let t in tableArray[p]) {
            for (let i = 0; i < tableArray[p][t].length; i++) {
              let t_val = tableArray[p][t][i].map((row) =>
                row.value
                  ? typeof row.value === "string"
                    ? '"' + row.value.replace(/"/g, '""') + '"'
                    : row.value
                  : ""
              );
              data += t_val.join("\t") + "\n";
            }
            data += "\n";
          }
          data += "\n";
        }
      } else {
        filename += "_original.csv";

        let keys = Object.keys(deepICRCTX.originalOutputData.data);
        for (let i = 0; i < keys.length; i++) {
          if (keys[i] !== "documentName") {
            // const pageNumber = keys[i];
            // data = data + '"' + deepICRCTX.originalOutputData.data[pageNumber].id + '"\n';
            // data =
            //   data +
            //   deepICRCTX.originalOutputData.data[pageNumber].data
            //     .map((data) => '"' + (data.text ? data.text.replace(/"/g, '""') : "") + '"')
            //     .join("\n");
            // data = data + "\n";
          
            const pageNumber = keys[i];
            data = data + '"' + deepICRCTX.originalOutputData.data[pageNumber].id + '"\n';
            data =
              data +
              deepICRCTX.originalOutputData.data[pageNumber].data
                .map((data) => '"' + (data.text ? data.text.replace(/"/g, '""') : "") + '"')
                .join("\n");
            data = data + "\n";
          }
        }
      }
      deepICRDownload(deepICRtoBlobWithBom(data, "text/csv"), filename);
    }
  };

  //-------------------------------------------------------------------------------------------------
  // Update JSON file in S3
  //-------------------------------------------------------------------------------------------------
  // const updateJson = async () => {
  //   let fileNameArray = deepICRCTX.file.name.split(".");
  //   fileNameArray.pop();
  //   let filename = fileNameArray.join(".") + "_out.json";

  //   // Reflecting the change for Original Output Data
  //   const oChangeTextArray = deepICRCTX.originalOutputData.data;
  //   for (let keyPage in oChangeTextArray) {
  //     const numberRegexp = new RegExp(/^[0-9]+$/);
  //     if (!numberRegexp.test(keyPage)) continue;
  //     for (let keyItem in oChangeTextArray[keyPage].data) {
  //       if (!numberRegexp.test(keyItem)) continue;
  //       if (oChangeTextArray[keyPage].data[keyItem].color === "blue") {
  //         let i, j, k, l, m;
  //         if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromLine") {
  //           [i, j, k, l, m] = ["", "", "", "", ""];

  //           if (oChangeTextArray[keyPage].data[keyItem].key.split("-").length === 4) {
  //             [i, j, k, l] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
  //           } else {
  //             [i, j, k] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
  //           }

  //           if (
  //             json.original_output.pages[i].regions[j].type === "Multi Line" ||
  //             json.original_output.pages[i].regions[j].type === "Handwritten"
  //           ) {
  //             if (
  //               json.original_output.pages[i].regions[j].lines[k].words[l].text !==
  //               oChangeTextArray[keyPage].data[keyItem].originalText
  //             ) {
  //               if (deepICRCTX.debug === true)
  //                 console.log(
  //                   "blue text unmatch " +
  //                   json.original_output.pages[i].regions[j].lines[k].words[l].text +
  //                   ":" +
  //                   oChangeTextArray[keyPage].data[keyItem].originalText
  //                 );
  //             }
  //             json.original_output.pages[i].regions[j].lines[k].words[l].text =
  //               oChangeTextArray[keyPage].data[keyItem].text;
  //           } else {
  //             if (
  //               json.original_output.pages[i].regions[j].words[k].text !==
  //               oChangeTextArray[keyPage].data[keyItem].originalText
  //             ) {
  //               if (deepICRCTX.debug === true)
  //                 console.log(
  //                   "blue text unmatch " +
  //                   json.original_output.pages[i].regions[j].words[k].text +
  //                   ":" +
  //                   oChangeTextArray[keyPage].data[keyItem].originalText
  //                 );
  //             }
  //             json.original_output.pages[i].regions[j].words[k].text =
  //               oChangeTextArray[keyPage].data[keyItem].text;
  //           }
  //         } else if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromTable") {
  //           [i, j, k, l, m] = ["", "", "", "", ""];
  //           [i, j, k, l, m] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
  //           if (
  //             json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text !==
  //             oChangeTextArray[keyPage].data[keyItem].originalText
  //           ) {
  //             if (deepICRCTX.debug === true)
  //               console.log(
  //                 "blue text unmatch " +
  //                 json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text +
  //                 ":" +
  //                 oChangeTextArray[keyPage].data[keyItem].originalText
  //               );
  //           }
  //           json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text =
  //             oChangeTextArray[keyPage].data[keyItem].text;
  //         }
  //       }
  //     }
  //   }

  //   // Reflecting the change for Extracted Output Data
  //   const eChangeTextArray = deepICRCTX.extractedOutputData.data;
  //   for (let key in eChangeTextArray) {
  //     for (let i = 0; i < eChangeTextArray[key].values.length; i++) {
  //       if (eChangeTextArray[key].values[i].originalValue !== "") {
  //         json.extracted_output[key].values[i] = eChangeTextArray[key].values[i].value;
  //       }
  //     }
  //   }
  //   const eChangeTableTextArray = deepICRCTX.extractedOutputTable.data;
  //   for (let page in eChangeTableTextArray) {
  //     for (let table in eChangeTableTextArray[page]) {
  //       for (let i = 0; i < eChangeTableTextArray[page][table].length; i++) {
  //         for (let j = 0; j < eChangeTableTextArray[page][table][i].length; j++) {
  //           if (eChangeTableTextArray[page][table][i][j] !== "") {
  //             json.extracted_output["details"].values[page][table][i][j] =
  //               eChangeTableTextArray[page][table][i][j].value;
  //           }
  //         }
  //       }
  //     }
  //   }


  //   // Upload updated output JSON file to S3
  //   const [, unixtime, microsec] = deepICRNow();
  //   const yyyymmddhhmmss =
  //     typeof deepICRCTX.file.yyyymmddhhmmss === "undefined"
  //       ? deepICRCTX.documentId
  //       : deepICRCTX.file.yyyymmddhhmmss;
  //   const md5 = crypto.createHash("md5");
  //   const md5hash = md5.update(deepICRCTX.cognitoUser.Username, "binary").digest("hex");


  //   // Refresh token
  //   let isError = false;
  //   let newAccessToken = "";
  //   let requestJson = {
  //     type: "request",
  //     head: {
  //       command: "refreshToken",
  //       format_version: deepICRCTX.apiFormatVersion,
  //       service_id: deepICRCTX.apiServiceId,
  //       transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
  //       unix_time: unixtime,
  //       micro_seconds: microsec,
  //       time_zone: deepICRCTX.apiTimeZone,
  //     },
  //     // "body": {refreshToken: deepICRCTX.refreshToken, username: deepICRCTX.cognitoUser.Username}
  //     body: { refreshToken: global.refreshToken, username: deepICRCTX.cognitoUser.Username },
  //   };

  //   await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiTokenRefresh, {
  //     method: "POST",
  //     mode: "cors",
  //     // headers: {Authorization: deepICRCTX.accessToken, "Content-Type": "application/json"},
  //     headers: { Authorization: global.accessToken, "Content-Type": "application/json" },
  //     body: JSON.stringify(requestJson),
  //   })
  //     .then((res) => {
  //       return res.json();
  //     })
  //     .then((json) => {
  //       // Timeout access token
  //       if (json.message === "Unauthorized") {
  //         props.enqueueSnackbar(t("errorLoginTimeout"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "LoginTimeoutError",
  //           Message: t("errorLoginTimeout"),
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });

  //         logout();
  //         isError = true;
  //         return;
  //       }
  //       if (json.body.status !== "OK") {
  //         if (json.body.error.message === "Token do not match") {
  //           props.enqueueSnackbar(t("errorLoginDuplicate"), {
  //             variant: "error",
  //             anchorOrigin: { vertical: "top", horizontal: "right" },
  //           });
  //           deepICRLogging({
  //             LogType: "ERROR",
  //             ErrType: "DuplicateLoginError",
  //             Message: t("errorLoginDuplicate"),
  //             Src: "Toolbar.js",
  //             Line: 0,
  //             Column: 0,
  //             Stack: "",
  //           });
  //           logout();
  //           isError = true;
  //           return;
  //         } else {
  //           if (deepICRCTX.debug === true) {
  //             console.log("[ToolBar - updateJson] token-refresh error for output json file");
  //           }
  //           if (deepICRCTX.debug === true) {
  //             console.log(JSON.stringify(json, null, 1));
  //           }
  //           props.enqueueSnackbar(t("errorSystemError"), {
  //             variant: "error",
  //             anchorOrigin: { vertical: "top", horizontal: "right" },
  //           });
  //           deepICRLogging({
  //             LogType: "ERROR",
  //             ErrType: "TokenRefreshFetchError",
  //             Message: "token-refresh error for output json file",
  //             Src: "Toolbar.js",
  //             Line: 0,
  //             Column: 0,
  //             Stack: "",
  //           });
  //           isError = true;
  //           return;
  //         }
  //       }
  //       newAccessToken = json.body.result.accessToken;
  //       global.accessToken = newAccessToken;
  //       // setDeepICRCTX({
  //       //   ...deepICRCTX,
  //       //   accessToken: json.body.result.accessToken
  //       // });
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - updateJson] token-refresh catch error for output json file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "TokenRefreshCatchError",
  //         Message: "token-refresh catch error for output json file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });

  //   if (isError) {
  //     return;
  //   }

  //   // Get Presigned URL for updated output JSON file
  //   let presignedUrl = "";
  //   requestJson.head.command = "getPresignedUrl";
  //   requestJson.body = {
  //     keys: [deepICRCTX.s3Path + "/" + md5hash + "/" + yyyymmddhhmmss + "/" + filename],
  //     operation: "PUT",
  //   };
  //   await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiGetPresignedUrl, {
  //     method: "POST",
  //     mode: "cors",
  //     headers: { Authorization: newAccessToken, "Content-Type": "application/json" },
  //     body: JSON.stringify(requestJson),
  //   })
  //     .then((res) => {
  //       return res.json();
  //     })
  //     .then((json) => {
  //       // Timeout access token
  //       // if(json.message === "Unauthorized"){
  //       //   props.enqueueSnackbar(
  //       //     t('errorLoginTimeout'),
  //       //     {variant: 'error', anchorOrigin: {vertical: 'top', horizontal: 'right'}}
  //       //   );
  //       //   logout();
  //       //   isError = true;
  //       //   return;
  //       // }
  //       if (json.body.status !== "OK") {
  //         if (deepICRCTX.debug === true) {
  //           console.log("[ToolBar - updateJson] get-signed-url error for output json file");
  //         }
  //         if (deepICRCTX.debug === true) {
  //           console.log(JSON.stringify(json, null, 1));
  //         }
  //         props.enqueueSnackbar(t("errorSystemError"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "SignedUrlFetchError",
  //           Message: "get-signed-url error for output json file",
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         isError = true;
  //         return;
  //       }
  //       presignedUrl = json.body.result.urls[0];
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - updateJson] get-signed-url catch error for output json file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "SignedUrlCatchError",
  //         Message: "get-signed-url catch error for output json file",
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });

  //   if (isError) {
  //     return;
  //   }

  //   // Put updated output JSON file to S3
  //   await fetch(presignedUrl, {
  //     method: "PUT",
  //     mode: "cors",
  //     headers: { "Content-Type": "application/json" },
  //     body: JSON.stringify(json, undefined, 1),
  //   })
  //     .then((json) => {
  //       if (json.ok !== true) {
  //         if (deepICRCTX.debug === true) {
  //           console.log("[ToolBar - updateJson] fetch error for output json file");
  //         }
  //         if (deepICRCTX.debug === true) {
  //           console.log(JSON.stringify(json, null, 1));
  //         }
  //         props.enqueueSnackbar(t("errorUpload"), {
  //           variant: "error",
  //           anchorOrigin: { vertical: "top", horizontal: "right" },
  //         });
  //         deepICRLogging({
  //           LogType: "ERROR",
  //           ErrType: "UploadError",
  //           Message: t("errorUpload"),
  //           Src: "Toolbar.js",
  //           Line: 0,
  //           Column: 0,
  //           Stack: "",
  //         });
  //         isError = true;
  //         return;
  //       }
  //     })
  //     .catch((err) => {
  //       if (deepICRCTX.debug === true) {
  //         console.log("[ToolBar - updateJson] fetch catch error for output json file");
  //       }
  //       if (deepICRCTX.debug === true) {
  //         console.log(err);
  //       }
  //       props.enqueueSnackbar(t("errorSystemError"), {
  //         variant: "error",
  //         anchorOrigin: { vertical: "top", horizontal: "right" },
  //       });
  //       deepICRLogging({
  //         LogType: "ERROR",
  //         ErrType: "UploadCatchError",
  //         Message: t("errorUpload"),
  //         Src: "Toolbar.js",
  //         Line: 0,
  //         Column: 0,
  //         Stack: "",
  //       });
  //       isError = true;
  //       return;
  //     });

  //   if (isError) {
  //     return;
  //   }
  //   props.enqueueSnackbar(t("infoUpdated"), {
  //     variant: "info",
  //     anchorOrigin: { vertical: "top", horizontal: "right" },
  //   });
  // };

  //-------------------------------------------------------------------------------------------------
  // Update JSON file locally, local_environment
  //-------------------------------------------------------------------------------------------------
  const updateJson = async () => {
    try {
      let fileNameArray = deepICRCTX.file.name.split(".");
      fileNameArray.pop();
      let filename = fileNameArray.join(".") + "_out.json";

      // Reflecting the change for Original Output Data
      const oChangeTextArray = deepICRCTX.originalOutputData.data;
      for (let keyPage in oChangeTextArray) {
        const numberRegexp = new RegExp(/^[0-9]+$/);
        if (!numberRegexp.test(keyPage)) continue;
        for (let keyItem in oChangeTextArray[keyPage].data) {
          if (!numberRegexp.test(keyItem)) continue;
          if (oChangeTextArray[keyPage].data[keyItem].color === "blue") {
            let i, j, k, l, m;
            if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromLine") {
              [i, j, k, l, m] = ["", "", "", "", ""];

              if (oChangeTextArray[keyPage].data[keyItem].key.split("-").length === 4) {
                [i, j, k, l] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              } else {
                [i, j, k] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              }

              if (
                json.original_output.pages[i].regions[j].type === "Multi Line" ||
                json.original_output.pages[i].regions[j].type === "Handwritten"
              ) {
                if (
                  json.original_output.pages[i].regions[j].lines[k].words[l].text !==
                  oChangeTextArray[keyPage].data[keyItem].originalText
                ) {
                  if (deepICRCTX.debug === true)
                    console.log(
                      "blue text unmatch " +
                      json.original_output.pages[i].regions[j].lines[k].words[l].text +
                      ":" +
                      oChangeTextArray[keyPage].data[keyItem].originalText
                    );
                }
                json.original_output.pages[i].regions[j].lines[k].words[l].text =
                  oChangeTextArray[keyPage].data[keyItem].text;
              } else {
                if (
                  json.original_output.pages[i].regions[j].words[k].text !==
                  oChangeTextArray[keyPage].data[keyItem].originalText
                ) {
                  if (deepICRCTX.debug === true)
                    console.log(
                      "blue text unmatch " +
                      json.original_output.pages[i].regions[j].words[k].text +
                      ":" +
                      oChangeTextArray[keyPage].data[keyItem].originalText
                    );
                }
                json.original_output.pages[i].regions[j].words[k].text =
                  oChangeTextArray[keyPage].data[keyItem].text;
              }
            } else if (oChangeTextArray[keyPage].data[keyItem].type === "dataFromTable") {
              [i, j, k, l, m] = ["", "", "", "", ""];
              [i, j, k, l, m] = oChangeTextArray[keyPage].data[keyItem].key.split("-");
              if (
                json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text !==
                oChangeTextArray[keyPage].data[keyItem].originalText
              ) {
                if (deepICRCTX.debug === true)
                  console.log(
                    "blue text unmatch " +
                    json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text +
                    ":" +
                    oChangeTextArray[keyPage].data[keyItem].originalText
                  );
              }
              json.original_output.pages[i].regions[j].cells[k].cell[l].words[m].text =
                oChangeTextArray[keyPage].data[keyItem].text;
            }
          }
        }
      }

      // Reflecting the change for Extracted Output Data
      const eChangeTextArray = deepICRCTX.extractedOutputData.data;
      for (let key in eChangeTextArray) {
        for (let i = 0; i < eChangeTextArray[key].values.length; i++) {
          if (eChangeTextArray[key].values[i].originalValue !== "") {
            json.extracted_output[key].values[i] = eChangeTextArray[key].values[i].value;
          }
        }
      }
      const eChangeTableTextArray = deepICRCTX.extractedOutputTable.data;
      for (let page in eChangeTableTextArray) {
        for (let table in eChangeTableTextArray[page]) {
          for (let i = 0; i < eChangeTableTextArray[page][table].length; i++) {
            for (let j = 0; j < eChangeTableTextArray[page][table][i].length; j++) {
              if (eChangeTableTextArray[page][table][i][j] !== "") {
                json.extracted_output["details"].values[page][table][i][j] =
                  eChangeTableTextArray[page][table][i][j].value;
              }
            }
          }
        }
      }
      props.enqueueSnackbar("Json Updated.", {
        autoHideDuration: 2000,
        variant: "info",
        anchorOrigin: { vertical: "top", horizontal: "right" },
      });

    } catch (err) {
      deepICRLogging({
        LogType: "ERROR",
        ErrType: "updateJsonFunctionError",
        Message: "",
        Src: "Toolbar.js",
        Line: 0,
        Column: 0,
        Stack: err,
      });
      props.enqueueSnackbar("Something went wrong", {
        autoHideDuration: 2000,
        variant: "info",
        anchorOrigin: { vertical: "top", horizontal: "right" },
      });

    }


  };


  function isThereSelection() {
    if (objectSize(deepICRCTX.shapeList) > 0) {
      let isFound = false;
      for (let key in deepICRCTX.shapeList) {
        if (objectSize(deepICRCTX.shapeList[key]) > 0) {
          isFound = true;
          break;
        }
      }
      if (isFound) setIsSelection(true);
      else setIsSelection(false);
    } else setIsSelection(false);
  }

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(isThereSelection, [JSON.stringify(deepICRCTX.shapeList)]);

  //-------------------------------------------------------------------------------------------------
  // return 
  //-------------------------------------------------------------------------------------------------
  return (
    <div className={styles.styleToolBar} data-id={deepICRCTX.isImage}>
      <Toolbar style={{ paddingLeft: 10, paddingRight: 10 }}>
        <input
          type="file"
          accept=".pdf,.jpg"
          style={{ display: "none" }}
          id="fileUploadInputButton"
          onChange={getFile}
        />
        <label htmlFor="fileUploadInputButton">
          <Button className={styles.styleFileUpload} variant="outlined" component="span">
            <Typography variant="h6">{t("stringToolBarFileUpload")}</Typography>
          </Button>
        </label>
        <Divider className={styles.styleDivider} />
        <CroppingTool />
        <Divider className={styles.styleDivider} />
        <InputBase
          disabled={isSelection}
          placeholder={t("stringToolBarPageNumber")}
          classes={{
            root: styles.stylePageNumberInputRoot,
            input: styles.stylePageNumberInput,
          }}
          inputProps={{ "aria-label": "Search" }}
          onBlur={validatePdfPages}
        />
        <Divider className={styles.styleDivider} />

        <CustomButton
          className={styles.styleConvert}
          variant="outlined"
          disabled={typeof deepICRCTX.file.name === "undefined" || deepICRCTX.file.name === ""}
          onClick={uploadAndConvert}
        >
          <Typography variant="h6">{t("stringToolBarConvert")}</Typography>
        </CustomButton>

        <Typography className={styles.styleSpacer}></Typography>

        <IconButton style={{ display: "none" }}>
          <SvgIcon
            htmlColor="#888888"
            style={{ fill: "#FFFFFF", stroke: "#888888", strokeMiterlimit: "10" }}
          >
            <path d="M19,21H5c-1.1,0-2-0.89-2-2V5c0-1.1,0.89-2,2-2H19c1.1,0,2,0.89,2,2V19C21,20.11,20.11,21,19,21z" />
            <path
              d="M19,21.5H5c-1.38,0-2.5-1.12-2.5-2.5V5c0-1.38,1.12-2.5,2.5-2.5H19c1.38,0,2.5,1.12,2.5,2.5V19
							C21.5,20.38,20.38,21.5,19,21.5z M5,3.5C4.17,3.5,3.5,4.17,3.5,5V19c0,0.83,0.67,1.5,1.5,1.5H19c0.83,0,1.5-0.67,1.5-1.5V5
							c0-0.83-0.67-1.5-1.5-1.5H5z"
            />
            <rect x="11.5" y="3" width="1" height="18" />
            <path d="M18.4,12.5H12c-0.28,0-0.5-0.22-0.5-0.5s0.22-0.5,0.5-0.5h6.4c0.28,0,0.5,0.22,0.5,0.5S18.68,12.5,18.4,12.5z" />
            <path
              d="M18.4,12.5c-0.19,0-0.37-0.11-0.45-0.29l-2.3-4.98c-0.12-0.25-0.01-0.55,0.24-0.66c0.25-0.12,0.55-0.01,0.66,0.24l2.3,4.98
							c0.12,0.25,0.01,0.55-0.24,0.66C18.54,12.49,18.47,12.5,18.4,12.5z"
            />
            <path
              d="M16.1,17.48c-0.07,0-0.14-0.01-0.21-0.05c-0.25-0.12-0.36-0.41-0.24-0.66l2.3-4.98c0.12-0.25,0.41-0.36,0.66-0.24
							c0.25,0.12,0.36,0.41,0.24,0.66l-2.3,4.98C16.47,17.37,16.29,17.48,16.1,17.48z"
            />
          </SvgIcon>
        </IconButton>

        <IconButton style={{ display: "none" }}>
          <SvgIcon
            htmlColor="#888888"
            style={{ fill: "#FFFFFF", stroke: "#888888", strokeMiterlimit: "10" }}
          >
            <path d="M19,21H5c-1.1,0-2-0.89-2-2V5c0-1.1,0.89-2,2-2H19c1.1,0,2,0.89,2,2V19C21,20.11,20.11,21,19,21z" />
            <path
              d="M19,21.5H5c-1.38,0-2.5-1.12-2.5-2.5V5c0-1.38,1.12-2.5,2.5-2.5H19c1.38,0,2.5,1.12,2.5,2.5V19
							C21.5,20.38,20.38,21.5,19,21.5z M5,3.5C4.17,3.5,3.5,4.17,3.5,5V19c0,0.83,0.67,1.5,1.5,1.5H19c0.83,0,1.5-0.67,1.5-1.5V5
							c0-0.83-0.67-1.5-1.5-1.5H5z"
            />
            <rect x="11.5" y="3" width="1" height="18" />
          </SvgIcon>
        </IconButton>

        <IconButton style={{ display: "none" }}>
          <SvgIcon
            htmlColor="#888888"
            style={{ fill: "#FFFFFF", stroke: "#888888", strokeMiterlimit: "10" }}
          >
            <path d="M19,21H5c-1.1,0-2-0.89-2-2V5c0-1.1,0.89-2,2-2H19c1.1,0,2,0.89,2,2V19C21,20.11,20.11,21,19,21z" />
            <path
              d="M19,21.5H5c-1.38,0-2.5-1.12-2.5-2.5V5c0-1.38,1.12-2.5,2.5-2.5H19c1.38,0,2.5,1.12,2.5,2.5V19
							C21.5,20.38,20.38,21.5,19,21.5z M5,3.5C4.17,3.5,3.5,4.17,3.5,5V19c0,0.83,0.67,1.5,1.5,1.5H19c0.83,0,1.5-0.67,1.5-1.5V5
							c0-0.83-0.67-1.5-1.5-1.5H5z"
            />
            <rect x="11.5" y="3" width="1" height="18" />
            <path d="M12,12.5H5.6c-0.28,0-0.5-0.22-0.5-0.5s0.22-0.5,0.5-0.5H12c0.28,0,0.5,0.22,0.5,0.5S12.28,12.5,12,12.5z" />
            <path
              d="M7.9,17.48c-0.19,0-0.37-0.11-0.45-0.29l-2.3-4.98c-0.12-0.25-0.01-0.55,0.24-0.66c0.25-0.12,0.55-0.01,0.66,0.24l2.3,4.98
							c0.12,0.25,0.01,0.55-0.24,0.66C8.04,17.46,7.97,17.48,7.9,17.48z"
            />
            <path
              d="M5.6,12.5c-0.07,0-0.14-0.01-0.21-0.05c-0.25-0.12-0.36-0.41-0.24-0.66l2.3-4.98c0.12-0.25,0.41-0.36,0.66-0.24
							c0.25,0.12,0.36,0.41,0.24,0.66l-2.3,4.98C5.97,12.39,5.79,12.5,5.6,12.5z"
            />
          </SvgIcon>
        </IconButton>

        <Divider className={styles.styleDivider} />

        <Select
          className={styles.styleFormat}
          id="select-format"
          value={format}
          disabled={deepICRCTX.outputSw === false && deepICRCTX.documentId === ""}
          onChange={setSelectValue}
        >
          <MenuItem
            disabled={deepICRCTX.isSelection}
            value={"csv"}
            selected={!deepICRCTX.isSelection}
          >
            <Typography  variant="h6">CSV</Typography>
          </MenuItem>
          {/* <MenuItem  value={"csv"}>
            <Typography variant="h6">CSV</Typography>
          </MenuItem> */}
          {/* {deepICRCTX.isSelection} */}
          <MenuItem disabled value={"jpeg"}>
            <Typography variant="h6">TSV</Typography>
          </MenuItem>
          <MenuItem disabled value={"html"}>
            <Typography variant="h6">HTML</Typography>
          </MenuItem>
          <MenuItem disabled value={"json"}>
            <Typography variant="h6">Zip(Image)</Typography>
          </MenuItem>
          <MenuItem disabled value={"jpeg"}>
            <Typography variant="h6">Zip ({t('stringZipImage')})</Typography>
          </MenuItem>
          <MenuItem disabled  value={"htmlzip"}>
            <Typography variant="h6">Zip ({t('stringZipFullPage')})</Typography>
          </MenuItem>
          {/* <MenuItem
          disabled
            // disabled={!deepICRCTX.isSelection}
            value={"crop"}
            // selected={deepICRCTX.isSelection}
          >
            <Typography variant="h6">{"Cropped (Zip)"}</Typography>
          </MenuItem> */}
        </Select>
        <Divider className={styles.styleDivider} />
        <CustomButton
          className={styles.styleExport}
          variant="outlined"
          disabled={deepICRCTX.outputSw === false && deepICRCTX.documentId === ""}
          onClick={downloadCSV}
        >
          <Typography variant="h6">{t("stringToolBarExport")}</Typography>
        </CustomButton>
        <Divider className={styles.styleDivider} />
        {/* <CustomButton
          className={styles.styleExport}
          variant="outlined"
          disabled={deepICRCTX.outputSw === false && deepICRCTX.documentId === ""}
          onClick={updateJson}
        >
          <Typography variant="h6">{t("stringToolBarUpdate")}</Typography>
        </CustomButton> */}
      </Toolbar>
    </div>
  );
};

export default withSnackbar(ToolBar);
