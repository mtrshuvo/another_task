import React, { useContext, useState } from "react";
import { Redirect } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { makeStyles, withStyles } from "@material-ui/core";
import { withSnackbar } from "notistack";
import Typography from "@material-ui/core/Typography";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import Box from "@material-ui/core/Box";
import Link from "@material-ui/core/Link";
import { deepICRNow } from "./deepICRCommon";
import crypto from "crypto";

// import resource files
import DeepICRContext from "./resources/DeepICRContext";
import jsonDeepICRContext from "./resources/deepICRContext.json";
import deepICRLogging from "./Logging/deepICRLogging";

// Style Sheet
const useStyles = makeStyles((theme) => ({
  styleLogin: {
    margin: theme.spacing(0, 0, 0, 0),
    display: "flex",
    flexDirection: "column",
  },
  styleDeloitteGreen: {
    color: theme.palette.deepICR.deloitteGreen,
  },
  styleLogo: {
    margin: theme.spacing(1, 0, 0, 4),
  },
  styleTitle: {
    margin: theme.spacing(6, 0, 0, 6),
  },
  styleForm: {
    width: theme.palette.deepICR.inputWidth,
    margin: theme.spacing(4, 0, 0, 6),
    color: theme.palette.deepICR.color,
  },
  styleSubmit: {
    margin: theme.spacing(3, 0, 0, 0),
    color: theme.palette.deepICR.color,
    fontSize: theme.palette.deepICR.loginFont,
    backgroundColor: theme.palette.deepICR.blue4,
  },
  styleChangePassword: {
    margin: theme.spacing(3, 0, 0, 6),
    cursor: "pointer",
    "&:hover": { textDecoration: "underline" },
  },
  styleFooter: {
    margin: theme.spacing(8, 0, 0, 2),
  },
}));
const CustomTextField = withStyles({
  root: {
    "& input": {
      color: "#ffffff",
    },
    "& label.Mui-required": {
      color: "#ffffff",
    },
    "& label.Mui-focused": {
      color: "#ffffff",
    },
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        borderColor: "#ffffff",
      },
      "&:hover fieldset": {
        borderColor: "#ffffff",
      },
      "&.Mui-focused fieldset": {
        borderColor: "#ffffff",
        borderWidth: 1,
      },
    },
  },
})(TextField);

// [React function component]
// Authentication Wrapper component
export const Login = (props) => {
  const styles = useStyles();
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [user, setUser] = useState({ username: "", data: "", data1: "", data2: "", digits: "" });

  // for multiple language
  const [t, i18n] = useTranslation();

  // Change Password or Do login
  const doLogin = async (e) => {
    if (deepICRCTX.changePassword === true) {
      // Change Password
      if (user.username.trim() === "") {
        props.enqueueSnackbar(t("errorNoUsername"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        return;
      }
      if (user.data.trim() === "") {
        props.enqueueSnackbar(t("errorNoPassword"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        return;
      }
      if (user.digits.trim() === "") {
        props.enqueueSnackbar(t("errorNoMfaCode"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        return;
      }
      const regExpMfa = new RegExp(/[0-9]{6}/);
      if (!regExpMfa.test(user.digits.trim())) {
        props.enqueueSnackbar(t("errorIncorrectMfaCode"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        setUser({ ...user, digits: "" });
        return;
      }
      if (user.data1.trim() === "") {
        props.enqueueSnackbar(t("errorNoPassword1"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        return;
      }
      // if(user.data1.trim().search(/[^a-zA-Z0-9]/) > -1) {
      //   props.enqueueSnackbar(
      //     t('errorPassword1Character'),
      //     {variant: 'error', anchorOrigin: {vertical: 'top', horizontal: 'right'}}
      //   );
      //   setUser({...user, data1: ""});
      //   return;
      // }
      if (
        !(
          user.data1.trim().search(/[A-Z]/) > -1 &&
          user.data1.trim().search(/[a-z]/) > -1 &&
          user.data1.trim().search(/[0-9]/) > -1
        )
      ) {
        props.enqueueSnackbar(t("errorPassword1"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        setUser({ ...user, data1: "" });
        return;
      }
      if (user.data1.trim().length < 10 || user.data1.trim().length > 32) {
        props.enqueueSnackbar(t("errorPassword1Length"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        setUser({ ...user, data1: "" });
        return;
      }
      if (user.data1.trim() !== user.data2.trim()) {
        props.enqueueSnackbar(t("errorPassword1Password2"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        setUser({ ...user, data2: "" });
        return;
      }

      // Do login for getting access token
      const [, unixtime, microsec] = deepICRNow();
      const requestJson = {
        type: "request",
        head: {
          command: "authentication",
          format_version: deepICRCTX.apiFormatVersion,
          service_id: deepICRCTX.apiServiceId,
          transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
          unix_time: unixtime,
          micro_seconds: microsec,
          time_zone: deepICRCTX.apiTimeZone,
        },
        body: {
          username: user.username.trim(),
          password: user.data.trim(),
          mfaCode: user.digits.trim(),
        },
      };
      let accessToken = "";
      await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiSignin, {
        method: "POST",
        mode: "cors",
        body: JSON.stringify(requestJson),
      })
        .then((res) => {
          return res.json();
        })
        .then((json) => {
          if (json.body.status !== "OK") {
            props.enqueueSnackbar(t("errorLogin"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "LoginError",
              Message: t("errorLogin"),
              Src: "Login.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
            setUser({ ...user, data: "", digits: "" });
            return;
          }
          accessToken = json.body.result.accessToken;
        })
        .catch((err) => {
          props.enqueueSnackbar(t("errorLoginSystemError"), {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          deepICRLogging({
            LogType: "ERROR",
            ErrType: "LoginSystemError",
            Message: t("errorLoginSystemError"),
            Src: "Login.js",
            Line: 0,
            Column: 0,
            Stack: "",
          });
          setUser({ ...user, data: "", digits: "", data1: "", data2: "" });
          return;
        });

      // Change password
      requestJson.body = {
        previousPassword: user.data,
        proposedPassword: user.data1,
      };

      fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiChangePassword, {
        method: "POST",
        mode: "cors",
        headers: { Authorization: accessToken, "Content-Type": "application/json" },
        body: JSON.stringify(requestJson),
      })
        .then((res) => {
          return res.json();
        })
        .then((json) => {
          if (json.body.status !== "OK") {
            props.enqueueSnackbar(t("errorChangePassword"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            setUser({ ...user, data: "", digits: "", data1: "", data2: "" });
            return;
          }
          props.enqueueSnackbar(t("infoChangePassword"), {
            variant: "info",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          setUser({ ...user, data: "", digits: "", data1: "", data2: "" });
          setDeepICRCTX({
            ...jsonDeepICRContext,
          });
          i18n.changeLanguage("ja");
        })
        .catch((err) => {
          props.enqueueSnackbar(t("errorLoginSystemError"), {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          deepICRLogging({
            LogType: "ERROR",
            ErrType: "LoginSystemError",
            Message: t("errorLoginSystemError"),
            Src: "Login.js",
            Line: 0,
            Column: 0,
            Stack: "",
          });
          setUser({ ...user, data: "", digits: "", data1: "", data2: "" });
          return;
        });

      // Do login
    } else {
      if (user.username.trim() === "") {
        props.enqueueSnackbar(t("errorNoUsername"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        return;
      }
      if (user.data.trim() === "") {
        props.enqueueSnackbar(t("errorNoPassword"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        return;
      }
      if (user.digits.trim() === "") {
        props.enqueueSnackbar(t("errorNoMfaCode"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        return;
      }
      const regExpMfa = new RegExp(/[0-9]{6}/);
      if (!regExpMfa.test(user.digits.trim())) {
        props.enqueueSnackbar(t("errorIncorrectMfaCode"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
        setUser({ ...user, digits: "" });
        return;
      }
      const [, unixtime, microsec] = deepICRNow();
      const requestJson = {
        type: "request",
        head: {
          command: "authentication",
          format_version: deepICRCTX.apiFormatVersion,
          service_id: deepICRCTX.apiServiceId,
          transaction_id: deepICRCTX.apiServiceId + "_" + unixtime + "_" + microsec,
          unix_time: unixtime,
          micro_seconds: microsec,
          time_zone: deepICRCTX.apiTimeZone,
        },
        body: {
          username: user.username.trim(),
          password: user.data.trim(),
          mfaCode: user.digits.trim(),
        },
      };
      await fetch(deepICRCTX.apiUrlBase + deepICRCTX.apiSignin, {
        method: "POST",
        mode: "cors",
        body: JSON.stringify(requestJson),
      })
        .then((res) => {
          return res.json();
        })
        .then((json) => {
          if (json.body.status !== "OK") {
            props.enqueueSnackbar(t("errorLogin"), {
              variant: "error",
              anchorOrigin: { vertical: "top", horizontal: "right" },
            });
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "LoginError",
              Message: t("errorLogin"),
              Src: "Toolbar.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
            setUser({ ...user, data: "", digits: "" });
            return;
          }
          global.accessToken = json.body.result.accessToken;
          global.refreshToken = json.body.result.refreshToken;
          const userData = { Username: user.username.trim() };
          setDeepICRCTX({
            ...jsonDeepICRContext,
            isLogin: true,
            cognitoUser: userData,
            // accessToken: json.body.result.accessToken,
            // refreshToken: json.body.result.refreshToken,
          });
          const md5 = crypto.createHash("md5"); // Get hash of Username
          global.md5hash = md5.update(userData.Username, "binary").digest("hex");

          i18n.changeLanguage("ja");
        })
        .catch((err) => {
          props.enqueueSnackbar(t("errorLoginSystemError"), {
            variant: "error",
            anchorOrigin: { vertical: "top", horizontal: "right" },
          });
          deepICRLogging({
            LogType: "ERROR",
            ErrType: "LoginSystemError",
            Message: t("errorLoginSystemError"),
            Src: "Login.js",
            Line: 0,
            Column: 0,
            Stack: "",
          });
          setUser({ ...user, data: "", digits: "" });
          return;
        });
    }
  };

  // Debug
  const debug = () => {
    const json = { ...deepICRCTX, termsOfService: [] };
    console.log(JSON.stringify(json, null, 1));
  };

  if (deepICRCTX.isLogin) {
    let documentId = "";
    if (!(typeof props.match.params.id === "undefined")) {
      documentId = props.match.params.id;
    }
    if (documentId === "") {
      return <Redirect to={"/deepICR"} />;
    } else {
      return <Redirect to={"/deepICR/" + documentId} />;
    }
  } else {
    return (
      <div className={styles.styleLogin}>
        <header className={styles.styleLogo}>
          <img alt="Deloitte. Logo" src="/DEL_g_SEC_RGB.jpg" width="142" height="44" />
        </header>
        <div>
          <Typography className={styles.styleTitle} component="h1" variant="h4">
            Deep ICR®
          </Typography>
          <form className={styles.styleForm} noValidate>
            <CustomTextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              name="username"
              label="ユーザ名 / Username"
              id="username"
              autoComplete="email"
              autoFocus
              value={user.username}
              onChange={(e) => {
                setUser({ ...user, username: e.target.value });
              }}
            />
            <CustomTextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              name="password"
              label="パスワード / Password"
              type="password"
              id="password"
              autoComplete="Current-password"
              value={user.data}
              onChange={(e) => {
                setUser({ ...user, data: e.target.value });
              }}
            />
            <CustomTextField
              variant="outlined"
              margin="normal"
              required
              fullWidth
              name="digits"
              label="MFAコード / MFA Code"
              id="digits"
              value={user.digits}
              onChange={(e) => {
                setUser({ ...user, digits: e.target.value });
              }}
            />
            {deepICRCTX.changePassword === true ? (
              <CustomTextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                name="newPassword1"
                label="新しいパスワード / New Password"
                type="password"
                id="newPassword1"
                autoComplete="Current-password"
                value={user.data1}
                onChange={(e) => {
                  setUser({ ...user, data1: e.target.value });
                }}
              />
            ) : (
              <React.Fragment />
            )}
            {deepICRCTX.changePassword === true ? (
              <CustomTextField
                variant="outlined"
                margin="normal"
                required
                fullWidth
                name="newPassword2"
                label="新しいパスワード（再入力） / New Password (Re-input)"
                type="password"
                id="newPassword2"
                autoComplete="Current-password"
                value={user.data2}
                onChange={(e) => {
                  setUser({ ...user, data2: e.target.value });
                }}
              />
            ) : (
              <React.Fragment />
            )}
            <Button className={styles.styleSubmit} fullWidth variant="contained" onClick={doLogin}>
              {deepICRCTX.changePassword === true
                ? "パスワード変更 / Change Password"
                : "ログイン / Login"}
            </Button>
            <Button
              className={styles.styleSubmit}
              fullWidth
              variant="contained"
              onClick={debug}
              style={{ display: deepICRCTX.debugButton === true ? "inherit" : "none" }}
            >
              "デバッグ / Debug"
            </Button>
          </form>
        </div>
        {deepICRCTX.changePassword === true ? (
          <Box className={styles.styleChangePassword}>
            <Typography>
              <font onClick={() => setDeepICRCTX({ ...deepICRCTX, changePassword: false })}>
                パスワードを変更しない / Not Change Password
              </font>
            </Typography>
          </Box>
        ) : (
          <Box className={styles.styleChangePassword}>
            <Typography>
              <font onClick={() => setDeepICRCTX({ ...deepICRCTX, changePassword: true })}>
                パスワードを変更する / Change Password
              </font>
            </Typography>
          </Box>
        )}
        <footer className={styles.styleFooter}>
          <Typography>
            <Link color="inherit" href="https://deepicr.jp/deepicr_guide.docx">
              利用ガイド
            </Link>
            &nbsp;&nbsp;{"|"}&nbsp;&nbsp;
            <Link color="inherit" href="/termsOfService">
              利用規程
            </Link>
            &nbsp;&nbsp;{"|"}&nbsp;&nbsp;
            <Link
              color="inherit"
              href="https://www2.deloitte.com/jp/ja/footerlinks1/cookies/cookies-for-other-sites.html"
            >
              クッキーに関する通知
            </Link>
            &nbsp;&nbsp;{"|"}&nbsp;&nbsp;
            <Link
              color="inherit"
              href="https://www2.deloitte.com/jp/ja/footerlinks1/privacy/privacy-for-other-sites.html"
            >
              プライバシーポリシー
            </Link>
            <br />
            <br />
            {"© "}
            {new Date().getFullYear()}
            {"."}&nbsp;{"詳細は"}&nbsp;
            <Link color="inherit" href="/termsOfService">
              <font className={styles.styleDeloitteGreen}>利用規程</font>
            </Link>
            &nbsp;{"をご覧ください。"}
            <br />
            {
              "Deloitte（デロイト）とは、デロイト トウシュ トーマツ リミテッド（“DTTL”）、そのグローバルネットワーク組織を構成するメンバーファームおよびそれらの関係法人のひとつまたは複数を指します。"
            }
            <br />
            {
              "DTTL（または“Deloitte Global”）ならびに各メンバーファームおよびそれらの関係法人はそれぞれ法的に独立した別個の組織体です。DTTLはクライアントへのサービス提供を行いません。"
            }
            <br />
            {"詳細は"}&nbsp;
            <Link color="inherit" href="https://www.deloitte.com/jp/about">
              <font className={styles.styleDeloitteGreen}>www.deloitte.com/jp/about</font>
            </Link>
            &nbsp;{"をご覧ください。"}
          </Typography>
        </footer>
      </div>
    );
  }
};

export default withSnackbar(Login);
