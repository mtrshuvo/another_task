import React, { useContext } from "react";
import { useTranslation } from "react-i18next";
import { makeStyles } from "@material-ui/core";
import { withSnackbar } from "notistack";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from "@material-ui/core/IconButton";
import ZoomIn from "@material-ui/icons/ZoomIn";
import ZoomOut from "@material-ui/icons/ZoomOut";
import ZoomOutMap from "@material-ui/icons/ZoomOutMap";
import FirstPage from "@material-ui/icons/FirstPage";
import LastPage from "@material-ui/icons/LastPage";
import NavigateBefore from "@material-ui/icons/NavigateBefore";
import NavigateNext from "@material-ui/icons/NavigateNext";
import RotateLeft from "@material-ui/icons/RotateLeft";
import RotateRight from "@material-ui/icons/RotateRight";
import Typography from "@material-ui/core/Typography";
import Measure from "react-measure";
import Button from "@material-ui/core/Button";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { deepICRRotate, deepICRDownload, deepICRtoBlobWithBom } from "../deepICRCommon";

// import resource files
import DeepICRContext from "../resources/DeepICRContext";
import { objectSize } from "../resources/CommonMethods";
import SvgImage from "./SvgImage";
import deepICRLogging from "../Logging/deepICRLogging";

// pdfjs Setting
// pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

// Style Sheet
const useStyles = makeStyles((theme) => ({
  styleInputViewer: {
    backgroundColor: theme.palette.deepICR.color,
    color: theme.palette.deepICR.backgroundColor,
    boxSizing: "border-box",
    height: "99.5%",
    display: "flex",
    flexDirection: "column",
    flex: 1,
    overflow: "hidden",
  },
  styleImage: {
    display: "flex",
    flexDirection: "column",
    flexGrow: 1,
    backgroundColor: theme.palette.deepICR.imageBackground,
    margin: theme.spacing(0, 0, 0, 0),
    boxSizing: "border-box",
    height: "100%",
    overflow: "hidden",
  },
  toolBtn: {
    padding: 8,
  },
  button: {
    padding: "3px 6px",
    fontSize: "0.9rem",
  },
  menuItem: {
    padding: "3px 32px 3px 32px",
    fontSize: "0.9rem",
  },
}));

// [React function component]
// Document viewer component
const DocumentViewer = () => {
  const [deepICRCTX] = useContext(DeepICRContext);
  if (deepICRCTX.file.type === "application/pdf" || deepICRCTX.file.type === "image/jpeg") {
    let width = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
    let height = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

    global.inputViewerWidth = width;
    global.inputViewerHeight = height;

    return (
      <div
        id={"imgDiv"}
        style={{
          width: deepICRCTX.inputViewerBounds.bounds.width,
          height: deepICRCTX.inputViewerBounds.bounds.height,
          overflow: "auto",
        }}
      // onScroll={(e) => {
      //   if(deepICRCTX.outputSw === true && deepICRCTX.isSelection === false){
      //     document.getElementById('originalOutputDiv').scrollLeft = document.getElementById('imgDiv').scrollLeft;
      //     document.getElementById('originalOutputDiv').scrollTop = document.getElementById('imgDiv').scrollTop;
      //   }
      // }}
      >
        <SvgImage height={height} width={width} imageIndex={deepICRCTX.pdfPage - 1} />
      </div>
    );
  } else {
    return <div />;
  }
};

// [React function component]
// Input viewer component

const InputViewer = (props) => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [anchorEl, setAnchorEl] = React.useState(null);

  let width = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
  let height = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

  if (deepICRCTX.debug === true) {
    console.log("inputViewer");
  }

  const [t] = useTranslation(); // for multiple language
  const styles = useStyles(); // for material ui style

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleImportTemplate = () => {
    setAnchorEl(null);
  };

  const handleExportTemplate = () => {
    let page_index = "p_" + width + "_" + height + "_" + deepICRCTX.pdfPage;
    if (
      objectSize(deepICRCTX.shapeList) === 0 ||
      deepICRCTX.shapeList[page_index] === undefined ||
      objectSize(deepICRCTX.shapeList[page_index]) === 0
    ) {
      props.enqueueSnackbar(t("noSelectionError"), {
        variant: "error",
        anchorOrigin: { vertical: "top", horizontal: "right" },
      });
    } else {
      let tempJson = {};
      tempJson[page_index] = deepICRCTX.shapeList[page_index];
      let fileName = deepICRCTX.file.name.split(".");
      fileName.pop();
      fileName = fileName.join(".");
      deepICRDownload(
        deepICRtoBlobWithBom(JSON.stringify(tempJson, null, 1), "application/json"),
        fileName + ".json"
      );
    }
    setAnchorEl(null);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const getTemplateJson = (e) => {
    let page_index = "p_" + width + "_" + height + "_" + deepICRCTX.pdfPage;

    let file = e.target.files[0];
    let reader = new FileReader();
    let isError = false;

    reader.onload = function (e) {
      let tempJson = JSON.parse(e.target.result);
      let shapeList = deepICRCTX.shapeList;

      for (let p in tempJson) {
        let keyArr = p.split("_");
        if (keyArr && keyArr.length === 4 && keyArr[0] === "p") {
          let w = parseInt(keyArr[1]);
          let h = parseInt(keyArr[2]);

          if (typeof w !== "number" || typeof h !== "number") {
            deepICRLogging({
              LogType: "ERROR",
              ErrType: "TypeError",
              Message: t("whValueError"),
              Src: "InputViewer.js",
              Line: 0,
              Column: 0,
              Stack: "",
            });
            isError = true;
            break;
          }

          let ratio = width / w;
          if (height < h * ratio) {
            ratio = height / h;
          }

          for (let s in tempJson[p]) {
            let sArr = s.split("_");
            if (sArr.length !== 2 || sArr[0] !== "s" || typeof parseInt(sArr[1]) !== "number") {
              deepICRLogging({
                LogType: "ERROR",
                ErrType: "TypeError",
                Message: t("shapeIndexformatError"),
                Src: "InputViewer.js",
                Line: 0,
                Column: 0,
                Stack: "",
              });
              isError = true;
            }
            if (tempJson[p][s].type === "rect") {
              tempJson[p][s].x = parseInt(tempJson[p][s].x) * ratio;
              tempJson[p][s].y = parseInt(tempJson[p][s].y) * ratio;
              tempJson[p][s].width = parseInt(tempJson[p][s].width) * ratio;
              tempJson[p][s].height = parseInt(tempJson[p][s].height) * ratio;
            } else if (tempJson[p][s].type === "ellipse") {
              tempJson[p][s].cx = parseInt(tempJson[p][s].cx) * ratio;
              tempJson[p][s].cy = parseInt(tempJson[p][s].cy) * ratio;
              tempJson[p][s].rx = parseInt(tempJson[p][s].rx) * ratio;
              tempJson[p][s].ry = parseInt(tempJson[p][s].ry) * ratio;
            } else if (tempJson[p][s].type === "polygon") {
              let str_points = "";
              let points = tempJson[p][s].points.split(" ");
              for (let i = 0; i < points.length; i++) {
                let point = points[i].split(",");
                if (i === 0)
                  str_points += parseInt(point[0]) * ratio + "," + parseInt(point[1]) * ratio;
                else
                  str_points += " " + parseInt(point[0]) * ratio + "," + parseInt(point[1]) * ratio;
              }
              tempJson[p][s].points = str_points;
            }
          }
          shapeList[page_index] = tempJson[p];
        } else {
          deepICRLogging({
            LogType: "ERROR",
            ErrType: "TypeError",
            Message: t("pageIndexformatError"),
            Src: "InputViewer.js",
            Line: 0,
            Column: 0,
            Stack: "",
          });
          isError = true;
          break;
        }
      }
      if (isError) {
        props.enqueueSnackbar(t("templateFormatError"), {
          variant: "error",
          anchorOrigin: { vertical: "top", horizontal: "right" },
        });
      } else {
        setDeepICRCTX({
          ...deepICRCTX,
          selectedShape: {},
          shapeList: shapeList,
        });
      }
    };

    reader.onerror = function (e) {
      deepICRLogging({
        LogType: "ERROR",
        ErrType: "TemplateFormatError",
        Message: t("templateImportError"),
        Src: "InputViewer.js",
        Line: 0,
        Column: 0,
        Stack: "",
      });
      if (deepICRCTX.debug === true) console.log(e);
    };
    reader.readAsText(file);
    e.target.value = null;
  };

  return (
    <div className={styles.styleInputViewer}>
      <Toolbar style={{ paddingLeft: 0, paddingRight: 0, borderBottom: "1px solid #EAEAF0" }}>
        <div style={{ flexGrow: 1 }}>
          <Typography variant="h6" align="left" style={{ paddingLeft: 8 }}>
            {t("stringInputViewerTitle")}
            {typeof deepICRCTX.file.name !== "undefined" &&
              deepICRCTX.file.name !== "" &&
              deepICRCTX.file.name.length > 50 &&
              deepICRCTX.file.name.substr(0, 15) +
              "..." +
              deepICRCTX.file.name.substr(
                deepICRCTX.file.name.length - 15,
                deepICRCTX.file.name.length
              )}
            {typeof deepICRCTX.file.name !== "undefined" &&
              deepICRCTX.file.name !== "" &&
              deepICRCTX.file.name.length < 50 &&
              deepICRCTX.file.name}
          </Typography>
        </div>
        {/* <div>
          <input
            type="file"
            accept=".json"
            style={{ display: "none" }}
            id="templateUpload"
            onChange={getTemplateJson}
          />
          <Button
            className={styles.button}
            endIcon={<ExpandMoreIcon></ExpandMoreIcon>}
            disabled={typeof deepICRCTX.file.name === "undefined" || deepICRCTX.file.name === ""}
            aria-controls="simple-menu"
            aria-haspopup="true"
            onClick={handleClick}
          >
            {t("stringTemplate")}
          </Button>

          <Menu
            id="simple-menu"
            anchorEl={anchorEl}
            keepMounted
            open={Boolean(anchorEl)}
            onClose={handleClose}
          >
            <label htmlFor="templateUpload">
              <MenuItem onClick={handleImportTemplate} className={styles.menuItem}>
                {t("stringTemplateImport")}
              </MenuItem>
            </label>
            <MenuItem onClick={handleExportTemplate} className={styles.menuItem}>
              {t("stringTemplateExport")}
            </MenuItem>
          </Menu>
        </div> */}
        <div>
          <IconButton
            className={styles.toolBtn}
            disabled={typeof deepICRCTX.file.name === "undefined" || deepICRCTX.file.name === ""}
            onClick={() => {
              if (deepICRCTX.imageScale < 2) {
                setDeepICRCTX({
                  ...deepICRCTX,
                  imageScale: deepICRCTX.imageScale + 0.1,
                });
              }
            }}
          >
            <ZoomIn />
          </IconButton>
          <IconButton
            className={styles.toolBtn}
            disabled={typeof deepICRCTX.file.name === "undefined" || deepICRCTX.file.name === ""}
            onClick={() => {
              if (deepICRCTX.imageScale > 0.15) {
                setDeepICRCTX({
                  ...deepICRCTX,
                  imageScale: deepICRCTX.imageScale - 0.1,
                });
              }
            }}
          >
            <ZoomOut />
          </IconButton>
          <IconButton
            className={styles.toolBtn}
            disabled={typeof deepICRCTX.file.name === "undefined" || deepICRCTX.file.name === ""}
            onClick={() => {
              setDeepICRCTX({
                ...deepICRCTX,
                // imageScale: 1,
                imageScale:
                  deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.fileSize[0].width,
              });
            }}
          >
            <ZoomOutMap />
          </IconButton>
          <IconButton
            className={styles.toolBtn}
            disabled={
              deepICRCTX.outputSw === true ||
              deepICRCTX.documentId !== "" ||
              typeof deepICRCTX.file.name === "undefined" ||
              deepICRCTX.file.name === "" ||
              (objectSize(deepICRCTX.shapeList) > 0 &&
                deepICRCTX.shapeList["p_" + width + "_" + height + "_" + deepICRCTX.pdfPage] !==
                undefined &&
                objectSize(
                  deepICRCTX.shapeList["p_" + width + "_" + height + "_" + deepICRCTX.pdfPage]
                ) > 0)
            }
            onClick={() => {
              const dataUrls = deepICRCTX.fileBase64;
              dataUrls[deepICRCTX.pdfPage - 1] = deepICRRotate(
                deepICRCTX.fileBase64[deepICRCTX.pdfPage - 1],
                -90,
                deepICRCTX.fileSize[deepICRCTX.pdfPage - 1]
              );
              const fileSizes = deepICRCTX.fileSize;
              fileSizes[deepICRCTX.pdfPage - 1] = {
                height: deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width,
                width: deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height,
              };
              global.rotation[deepICRCTX.pdfPage - 1] =
                global.rotation[deepICRCTX.pdfPage - 1] - 90;
              if (global.rotation[deepICRCTX.pdfPage - 1] === -360) {
                global.rotation[deepICRCTX.pdfPage - 1] = 0;
              }
              setDeepICRCTX({
                ...deepICRCTX,
                // imageScale: 1,
                fileBase64: dataUrls,
                fileSize: fileSizes,
                imageScale:
                  deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.fileSize[0].width,
              });
            }}
          >
            <RotateLeft />
          </IconButton>
          <IconButton
            // data-id={(objectSize(deepICRCTX.shapeList) > 0)+" "+ (deepICRCTX.shapeList["p_" + width + "_" + height + "_" + (deepICRCTX.pdfPage)] !== undefined )+" "+ (objectSize(deepICRCTX.shapeList["p_" + width + "_" + height + "_" + (deepICRCTX.pdfPage)]) > 0)}
            className={styles.toolBtn}
            disabled={
              deepICRCTX.outputSw === true ||
              deepICRCTX.documentId !== "" ||
              typeof deepICRCTX.file.name === "undefined" ||
              deepICRCTX.file.name === "" ||
              (objectSize(deepICRCTX.shapeList) > 0 &&
                deepICRCTX.shapeList["p_" + width + "_" + height + "_" + deepICRCTX.pdfPage] !==
                undefined &&
                objectSize(
                  deepICRCTX.shapeList["p_" + width + "_" + height + "_" + deepICRCTX.pdfPage]
                ) > 0)
            }
            onClick={() => {
              const dataUrls = deepICRCTX.fileBase64;
              dataUrls[deepICRCTX.pdfPage - 1] = deepICRRotate(
                deepICRCTX.fileBase64[deepICRCTX.pdfPage - 1],
                90,
                deepICRCTX.fileSize[deepICRCTX.pdfPage - 1]
              );
              const fileSizes = deepICRCTX.fileSize;
              fileSizes[deepICRCTX.pdfPage - 1] = {
                height: deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width,
                width: deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height,
              };
              global.rotation[deepICRCTX.pdfPage - 1] =
                global.rotation[deepICRCTX.pdfPage - 1] + 90;
              if (global.rotation[deepICRCTX.pdfPage - 1] === 360) {
                global.rotation[deepICRCTX.pdfPage - 1] = 0;
              }
              setDeepICRCTX({
                ...deepICRCTX,
                // imageScale: 1,
                fileBase64: dataUrls,
                fileSize: fileSizes,
                imageScale:
                  deepICRCTX.inputViewerBounds.bounds.width / deepICRCTX.fileSize[0].width,
              });
            }}
          >
            <RotateRight />
          </IconButton>
        </div>
        <div style={{ align: "right" }}>
          <IconButton
            className={styles.toolBtn}
            onClick={() => {
              let pageNumber = deepICRCTX.pdfPage - 1;
              if (pageNumber >= 1) {
                setDeepICRCTX({
                  ...deepICRCTX,
                  pdfPage: pageNumber,
                  selectedShape: [],
                  selectedShapeRight: []
                });
              }
            }}
          >
            <NavigateBefore />
          </IconButton>
        </div>
        <div>
          <Typography variant="h6" style={{ whiteSpace: "nowrap" }}>
            {deepICRCTX.pdfPage} {"/"} {deepICRCTX.pdfPages}
          </Typography>
        </div>
        <div>
          <IconButton
            className={styles.toolBtn}
            onClick={() => {
              let pageNumber = deepICRCTX.pdfPage + 1;
              if (pageNumber <= deepICRCTX.pdfPages) {
                setDeepICRCTX({
                  ...deepICRCTX,
                  pdfPage: pageNumber,
                  selectedShape: [],
                  selectedShapeRight: []
                });
              }
            }}
          >
            <NavigateNext />
          </IconButton>
        </div>
      </Toolbar>
      <Measure
        bounds
        onResize={(contentRect) => {
          contentRect.bounds.height = parseInt(contentRect.bounds.height) - 0;
          contentRect.bounds.width = parseInt(contentRect.bounds.width) - 0;
          global.inputViewerBounds = contentRect;
          setDeepICRCTX({
            ...deepICRCTX,
            inputViewerBounds: contentRect,
          });
        }}
      >
        {({ measureRef }) => (
          <div className={styles.styleImage} ref={measureRef}>
            <DocumentViewer />
          </div>
        )}
      </Measure>
      {/* <div className={styles.styleImage}>
        			<DocumentViewer />
      		</div> */}
      <footer style={{ display: "none" }}>
        <Toolbar style={{ paddingLeft: 0, paddingRight: 0 }}>
          <div style={{ paddingLeft: "172px", flexGrow: 1 }}>
            <Typography variant="h6">
              {t("stringInputViewerFile")} {deepICRCTX.file.name}
            </Typography>
          </div>
          <div style={{ align: "right" }}>
            <IconButton
              className={styles.toolBtn}
              onClick={() => {
                let pageNumber = deepICRCTX.pdfPage - 1;
                if (pageNumber >= 1) {
                  setDeepICRCTX({
                    ...deepICRCTX,
                    pdfPage: pageNumber,
                  });
                }
              }}
            >
              <NavigateBefore />
            </IconButton>
          </div>
          <div>
            <IconButton
              className={styles.toolBtn}
              onClick={() => {
                if (deepICRCTX.pdfPage !== 1) {
                  setDeepICRCTX({
                    ...deepICRCTX,
                    pdfPage: 1,
                  });
                }
              }}
            >
              <FirstPage />
            </IconButton>
          </div>
          <div>
            <Typography variant="h6">
              {deepICRCTX.pdfPage} of {deepICRCTX.pdfPages}
            </Typography>
          </div>
          <div>
            <IconButton
              className={styles.toolBtn}
              onClick={() => {
                if (deepICRCTX.pdfPage !== deepICRCTX.pdfPages) {
                  setDeepICRCTX({
                    ...deepICRCTX,
                    pdfPage: deepICRCTX.pdfPages,
                  });
                }
              }}
            >
              <LastPage />
            </IconButton>
          </div>
          <div>
            <IconButton
              className={styles.toolBtn}
              onClick={() => {
                let pageNumber = deepICRCTX.pdfPage + 1;
                if (pageNumber <= deepICRCTX.pdfPages) {
                  setDeepICRCTX({
                    ...deepICRCTX,
                    pdfPage: pageNumber,
                  });
                }
              }}
            >
              <NavigateNext />
            </IconButton>
          </div>
        </Toolbar>
      </footer>
    </div>
  );
};

export default withSnackbar(InputViewer);
