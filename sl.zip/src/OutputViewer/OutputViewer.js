import React, { useContext, useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { makeStyles, withStyles } from "@material-ui/core";
import { withSnackbar } from "notistack";
import { Tabs, Tab } from "@material-ui/core";
import Toolbar from "@material-ui/core/Toolbar";
import Divider from "@material-ui/core/Divider";
import Typography from "@material-ui/core/Typography";
import InputBase from "@material-ui/core/InputBase";
import IconButton from "@material-ui/core/IconButton";
import Search from "@material-ui/icons/Search";

// import react components
import deepICRTheme from "../resources/deepICRTheme";
import ButtonEnlargeFont from "./ButtonEnlargeFont";
import ButtonShrinkFont from "./ButtonShrinkFont";
import ButtonResetFont from "./ButtonResetFont";
import ExtractedOutput from "./ExtractedOutput";
import OriginalOutput from "./OriginalOutput";

// import resource files
import DeepICRContext from "../resources/DeepICRContext";
import CroppingOutput from "./CroppingOutput";

// Style Sheet
const useStyles = makeStyles((theme) => ({
  styleOutputViewer: {
    // border: "2px solid " + theme.palette.deepICR.borderColor,
    backgroundColor: theme.palette.deepICR.color,
    color: theme.palette.deepICR.backgroundColor,
    // margin: theme.spacing(1, 1, 0, 0),
    // padding: theme.spacing(0, 0, 0, 0),
    boxSizing: "border-box",
    height: "99.5%",
    display: "flex",
    flexDirection: "column",
    flex: 1,
  },
  styleOutputs: {
    margin: theme.spacing(0, 0, 0, 0),
    boxSizing: "border-box",
    height: "100%",
  },
  styleOutput: {
    display: "flex",
    flexDirection: "column",
    flexGrow: 1,
    backgroundColor: theme.palette.deepICR.outputBackground,
    boxSizing: "border-box",
    height: "100%",
  },
  styleToolbar: {
    paddingLeft: 0,
    paddingRight: 0,
    borderBottom: "1px solid #EAEAF0",
  },
  styleDivider: {
    height: theme.palette.deepICR.dividerHeight,
    margin: theme.palette.deepICR.deviderMargin,
  },
  styleSearchInputRoot: {
    // border: '2px solid ' + theme.palette.deepICR.borderColor,
    color: "inherit",
    backgroundColor: theme.palette.deepICR.input,
  },
  styleSearchInput: {
    padding: theme.spacing(1, 1, 1, 2),
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      width: theme.palette.deepICR.searchInputSize,
      "&:focus": {
        width: theme.palette.deepICR.searchInputSizeFocus,
        backgroundColor: theme.palette.deepICR.input,
      },
    },
  },
  styleSearchIcon: { padding: theme.spacing(1) },
  styleSpacer: { flexGrow: 1 },
}));
const CustomTabs = withStyles({
  indicator: {
    backgroundColor: deepICRTheme.palette.deepICR.blue4,
  },
})(Tabs);

// Output Tab Panel
const TabPanel = (props) => {
  const styles = useStyles();
  const { children, value, index, ...other } = props;

  return (
    <div
      className={styles.styleOutputs}
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      {...other}
    >
      <div className={styles.styleOutput}>{children}</div>
    </div>
  );
};

// Set Tab Property
const retProps = (value, index) => {
  if (value === index) {
    return {
      id: `tabpanel-${index}`,
      style: {
        minHeight: "auto",
        backgroundColor: "inherit",
        color: deepICRTheme.palette.deepICR.blue4,
        // fontSize: deepICRTheme.palette.deepICR.tabFontSize,
        fontSize: "0.9rem",
      },
    };
  } else {
    return {
      id: `tabpanel-${index}`,
      style: {
        // fontSize: deepICRTheme.palette.deepICR.tabFontSize,
        minHeight: "auto",
        fontSize: "0.9rem",
      },
    };
  }
};

// [React function component]
// Output viewer component
const OutputViewer = (props) => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [value, setValue] = useState(0);
  const [searchText, setSearchText] = useState("");
  const [isSwitch,setIsSwitch] = useState(false)


  if (deepICRCTX.debug === true) {
    console.log("OutputViewer");
  }

 const handleChange = (event, newValue) => {
    if(newValue === 1) {
      setIsSwitch(true)
    }else{
      setIsSwitch(false)
    }
    setValue(newValue);
    setDeepICRCTX({...deepICRCTX, outputTab: newValue,isSwitch:isSwitch});
  }

  if(deepICRCTX.outputTab === 0 && value === 1){
    // console.log("Changing tab");
    setValue(0);
    setIsSwitch(false)
    // setDeepICRCTX({...deepICRCTX,isSwitch:false});
  }

  useEffect(()=>{
    setDeepICRCTX({...deepICRCTX,isSwitch:isSwitch})
  },[isSwitch])

  let width = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
  let height = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

  const [t] = useTranslation(); // for multiple language
  const styles = useStyles(); // for material ui style

  return (
    <div className={styles.styleOutputViewer}>
      <Toolbar className={styles.styleToolbar}>
        <CustomTabs
          value={value}
          onChange={handleChange}
          aria-label="output tabs"
          style={{ minHeight: "auto" }}
        >
          <Tab label={t("stringOutputViewerTabOriginal")} {...retProps(value, 0)} />
          <Tab label={t('stringCroppingOutput')} {...retProps(value, 1)} />
          {/* {!deepICRCTX.isContract && deepICRCTX.isSelection === false && ( */}
          <Tab label={t("stringOutputViewerTabExtracted")} {...retProps(value, 2)} />
          {/* )} */}
        </CustomTabs>
        <Typography className={styles.styleSpacer}></Typography>
        <InputBase
          placeholder={t("stringMenuBarSearch")}
          classes={{
            root: styles.styleSearchInputRoot,
            input: styles.styleSearchInput,
          }}
          inputProps={{ "aria-label": "Search" }}
          onChange={(e) => {
            setSearchText(e.target.value);
            if (e.target.value === "") {
              setDeepICRCTX({ ...deepICRCTX, searchText: e.target.value });
            }
          }}
        />
        <IconButton
          className={styles.styleSearchIcon}
          onClick={(e) => {
            if (searchText !== "") {
              if (Object.keys(deepICRCTX.originalOutputData.data).length !== 0) {
                setDeepICRCTX({ ...deepICRCTX, searchText: searchText });
              }
            }
          }}
        >
          <Search />
        </IconButton>
        <div style={{ display: "none" }}>
          <Divider orientation="vertical" className={styles.styleDivider} />
          <ButtonEnlargeFont value={value} />
          <ButtonShrinkFont value={value} />
          <ButtonResetFont value={value} />
        </div>
      </Toolbar>

      <TabPanel value={value} index={0}>
        <OriginalOutput height={global.inputViewerHeight} width={global.inputViewerWidth} />
      </TabPanel>
      <TabPanel value={value} index={1}>
        <CroppingOutput height={height} width={width} imageIndex={deepICRCTX.pdfPage - 1} isSwitch={deepICRCTX.isSwitch}/>
      </TabPanel>
      <TabPanel value={value} index={2}>
        <ExtractedOutput />
      </TabPanel>
      <footer style={{ display: "none" }}>
        <Toolbar />
      </footer>
    </div>
  );
};

export default withSnackbar(OutputViewer);


