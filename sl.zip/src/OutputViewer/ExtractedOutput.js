import React, { useContext, useEffect, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import deepICRLogging from "../Logging/deepICRLogging";
import {
  objectSize,
  deepCopy,
  cropImage,
  isthereAnySHape,
  formatDataForPreview,
} from "../resources/CommonMethods";

// import react components
import DeepICRContext from "../resources/DeepICRContext";

const ExtractedOutput = () => {
  const [deepICRCTX, setDeepICRCTX] = useContext(DeepICRContext);
  const [checkChange, setCheckChange] = useState(false);
  const [shapeWithData, setShapeWithData] = useState({});

  // for multiple language
  const [t] = useTranslation();

  useEffect(() => {
    setShapeWithData(formatDataForPreview(deepICRCTX.selectedRegion.pages));
  }, [deepICRCTX]);

  // console.log("selection output", selectionOutput);
  if (deepICRCTX.outputSw === false && deepICRCTX.documentId === "") {
    return <div style={{ fontSize: `${deepICRCTX.size}px` }} />;
  }
  let pageNumber = 1;
  if (deepICRCTX.file.type === "application/pdf") {
    pageNumber = deepICRCTX.pdfPage;
  }

  let ratio = deepICRCTX.imageScale;
  let width = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].width;
  let height = deepICRCTX.fileSize[deepICRCTX.pdfPage - 1].height;

  if (pageNumber in deepICRCTX.originalOutputData.data) {
    ratio = (width * deepICRCTX.imageScale) / deepICRCTX.originalOutputData.data[pageNumber].width;
  }

  global.inputViewerWidth = width;
  global.inputViewerHeight = height;
  let fontsize =
    72 * deepICRCTX.imageScale * deepICRCTX.originalOutputFontScale * deepICRCTX.fontScale;
  if (fontsize > 20) fontsize = 20;
  let counterId = 0;
  if(!isthereAnySHape(deepICRCTX.shapeListRight)) return <div style={{ fontSize: fontsize + 10 ,margin: "auto"}} >{t("stringNoDataToPreview")}</div>

  return (
    <div
      key={deepICRCTX.isImage}
      data-status={checkChange}
      id={"previewOutputDiv"}
      style={{
        width: deepICRCTX.inputViewerBounds.bounds.width,
        height: deepICRCTX.inputViewerBounds.bounds.height,
        overflow: "auto",
      }}
      data-change={checkChange}
    >
      <div
        id={"previewOutputViewer"}
        style={{
        
          position: "relative",
          width: width * deepICRCTX.imageScale,
          minHeight: height * deepICRCTX.imageScale,
          marginLeft: "10px"
        }}
      >

        {isthereAnySHape(deepICRCTX.shapeListRight) > 0 ? (
          <>
            {Object.keys(shapeWithData).map((page) => {

              if (shapeWithData[page].length) {
                return (
                  <>
                    <div
                      style={{
                        fontWeight: "bold",
                        padding: "4px 10px",
                        color: "#26890d",
                        fontSize: "1rem",
                        position: "relative",
                        display: "block",
                        width: "100%",
                        height: "auto",

                      }}
                    >
                    </div>
                    {shapeWithData[page]?.map((shape, si, sll) => {
                      let sx = 0;
                      let sy = 0;
                      counterId = counterId + 1
                      return (
                        <div id={`preview_${shape.page}_${shape?.shapeKeyId}`}>
                          <div
                            style={{
                              fontWeight: "bold",
                              padding: "4px 10px",
                              fontSize: fontsize,
                              position: "relative",
                              display: "block",
                              width: "100%",
                              height: "auto",
                            }}
                          >
                            {counterId}. {shape?.meta}{" "}
                          </div>

                          <div
                            style={{
                              display: "block",
                              position: "relative",
                              marginTop: "10px",
                              height:
                                10 +
                                shape.cells.reduce(
                                  (acc, currentVal, currentInd, allCells) =>
                                  (acc +=
                                    currentVal?.row_no !== allCells[currentInd - 1]?.row_no
                                      ? currentVal?.height
                                      : 0),
                                  0
                                ) *
                                ratio +
                                "px",
                            }}
                          >
                            {shape?.cells?.map((c, i, all) => {
                              if (i > 0 && c.row_no !== all[i - 1]?.row_no) {
                                sx = 0;
                                sy += all[i - 1].height;
                              } else {
                                sx = i === 0 ? 0 : sx + all[i - 1].width;
                                sy = i === 0 ? 0 : sy;
                              }

                              return (
                                <div
                                  id={`${c.row_no}-${c.col_no}`}
                                  style={{
                                    position: "absolute",
                                    border: "1px solid black",
                                    left: c.x * ratio - all[0].x * ratio,
                                    top: c.y * ratio - all[0].y * ratio,
                                    width: c.width * ratio,
                                    height: c.height * ratio,
                                  }}
                                ></div>
                              );
                            })}
                            {shape.cells?.map((c, ci, cll) => {
                              return c.cell.map((l, li, lll) => {
                                return (
                                  <div
                                    style={{
                                      position: "absolute",
                                      left: l.x * ratio - cll[0].x * ratio,
                                      top: l.y * ratio - cll[0].y * ratio,
                                      width: l.width * ratio,
                                      height: l.height * ratio,
                                      fontSize:
                                        l.height *
                                        ratio *
                                        deepICRCTX.originalOutputFontScale *
                                        deepICRCTX.fontScale,
                                      whiteSpace: "nowrap",
                                    }}
                                  >
                                    {l.words.map((w) => w.text).join(" ")}
                                  </div>
                                );
                              });
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </>
                );
              } else return "";
            })}
          </>
        ) : ""
        
        }

      </div>
    </div>
  );
};

export default ExtractedOutput;
