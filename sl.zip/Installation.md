### Installation
1. Check system has <kbd>npx</kbd> or not by following command in terminal.
   ```ps
   npx -v
   ``` 
2. If there is no <kbd>npx</kbd> then run the following command in terminal to install npx
   ```ps
   npm install -g npx
   ``` 
3. Open project root folder and run the following command in terminal.
   ```ps
   npm install
   ``` 
4. For vulnerability check run the following command in terminal.
   ```ps
   npm audit
   ```
5. For vulnerability check for production run the following command terminal.
   ```ps
   npm audit --production
   ```  
6. After installation complete run the following command for check application work correctly.
   ```ps
   npm start
   ```
7. For production build run the following command in terminal.
   ```ps
   npm run build
   ```

If all the processes not going well then try to same step after install <kbd>nodejs@14.17.1</kbd> , <kbd>npm@17.20.5</kbd> & <kbd>npx@17.20.5</kbd>.



